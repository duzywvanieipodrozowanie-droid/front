import {defineConfig} from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

function createProxyConfig() {
    const target = 'http://localhost:8080';
    const proxyConfig = {};

    proxyConfig[`/api`] = {
        target: target,
        rewrite: (url) => url.replace(`/api`, ``),
        secure: false,
        changeOrigin: true,
        logLevel: 'debug',
        ws: true
    };

    return proxyConfig;
}

export default defineConfig({
    plugins: [react(), tailwindcss()],
    define: {
        'global': 'window',
    },
    server: {
        host: "0.0.0.0",
        proxy: createProxyConfig(),
    }
});
