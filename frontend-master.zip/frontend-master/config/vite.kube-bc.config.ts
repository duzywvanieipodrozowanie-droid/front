import {defineConfig} from 'vite'
import react from '@vitejs/plugin-react'

function createProxyConfig() {
    const target = 'http://zenstage-dev.entrypoint.buttoncode.pl';

    const proxyConfig = {};

    proxyConfig[`/api`] = {
        target: target,
        rewrite: (url) => url.replace(`/api`, `/backend`),
        secure: false,
        changeOrigin: true,
        logLevel: 'debug',
        ws: true,
    };

    return proxyConfig;
}

export default defineConfig({
    plugins: [react()],
    define: {
        'global': 'window',
    },
    server: {
        host: "0.0.0.0",
        proxy: createProxyConfig(),
    }
});
