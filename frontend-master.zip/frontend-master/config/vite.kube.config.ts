import { defineConfig, loadEnv, ProxyOptions } from "vite";
import react from "@vitejs/plugin-react";

type ProxyConfig = Record<string, ProxyOptions>;

export default defineConfig(({ mode }) => {
    const env = loadEnv(mode, process.cwd(), "VITE_");
    const allowedOrigin = env.VITE_ALLOWED_ORIGIN;

    const proxyConfig: ProxyConfig = {};

    proxyConfig[`/api`] = {
        target: `http://backend:8080`,
        rewrite: (url: string) => url.replace(`/api`, ''),
        secure: false,
        changeOrigin: true,
        ws: true,
    };

    return {
        plugins: [react()],
        define: {
            'global': 'window',
        },
        server: {
            host: "0.0.0.0",
            cors: {
                origin: allowedOrigin,
                methods: ["GET", "POST"],
                allowedHeaders: ["Content-Type"],
            },
            proxy: proxyConfig,
        },
    };
});
