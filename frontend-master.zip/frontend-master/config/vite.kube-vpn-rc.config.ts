import {defineConfig} from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

function createProxyConfig() {
    const target = 'http://backend.zs:30000';
    const localHost = 'localhost:5173';
    const proxyConfig = {};

    proxyConfig[`/api`] = {
        target: target,
        secure: false,
        changeOrigin: true,
        logLevel: 'debug',
        ws: true,
        configure: (proxy, options) => {
            proxy.on('proxyReq', (proxyReq, req, res) => {
                // Wymuś localhost jako Host dla backendu
                proxyReq.setHeader('Host', localHost);
                proxyReq.setHeader('X-Forwarded-Host', localHost);
                proxyReq.setHeader('X-Forwarded-Proto', 'http');
                proxyReq.setHeader('X-Forwarded-Port', '5173');
            });
        }
    };

    return proxyConfig;
}

export default defineConfig({
    plugins: [react(), tailwindcss()],
    define: {
        'global': 'window',
    },
    server: {
        host: "0.0.0.0",
        proxy: createProxyConfig(),
    }
});
