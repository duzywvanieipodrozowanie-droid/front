/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        indigo: {
          50: '#e8f6ef',
          100: '#d1eddf',
          200: '#a3dbbf',
          300: '#75c99f',
          400: '#47b780',
          500: '#00A14B',
          600: '#0E8F45',
          700: '#0B6E36',
          800: '#084F27',
          900: '#06381C',
        },
      },
      fontFamily: {
        sans: ['var(--font-family-sans)'],
      },
    },
  },
  plugins: [],
};
