import { fetchTeams, extractUniqueMembers } from './teamService';
import { fetchPersonData, PersonData } from './personService';

export interface DeveloperRow {
  userId: string;
  givenName: string;
  personData: PersonData | null;
  flattenedData: { [key: string]: any };
  dqi: number;
}

const flattenObject = (obj: any, prefix = ''): { [key: string]: any } => {
  const flattened: { [key: string]: any } = {};

  for (const key in obj) {
    if (obj.hasOwnProperty(key)) {
      const value = obj[key];
      const newKey = prefix ? `${prefix}.${key}` : key;

      if (value !== null && typeof value === 'object' && !Array.isArray(value)) {
        Object.assign(flattened, flattenObject(value, newKey));
      } else {
        flattened[newKey] = value;
      }
    }
  }

  return flattened;
};

// Normalize value to 0-1 range based on max value in the dataset
const normalize = (value: number, max: number): number => {
  if (max === 0) return 0;
  return Math.min(1, value / max);
};

// Calculate Developer Quality Index (DQI)
const calculateDQI = (
  flattenedData: { [key: string]: any },
  maxValues: { bugs: number; smells: number; debt: number; cost: number }
): number => {
  // Extract metrics from total
  const bugs = flattenedData['total.newBugs'] || 0;
  const smells = flattenedData['total.newCodeSmells'] || 0;
  const debt = flattenedData['total.newTechnicalDebt'] || 0;
  const cost = flattenedData['total.newDevelopmentCost'] || 0;
  const reliability = flattenedData['total.newReliabilityRating'] || 0;
  const security = flattenedData['total.newSecurityRating'] || 0;
  const maintainability = flattenedData['total.newMaintainabilityRating'] || 0;

  // Check if developer has any activity - if all values are 0, return 0
  const hasActivity = bugs > 0 || smells > 0 || debt > 0 || cost > 0 || 
                      reliability > 0 || security > 0 || maintainability > 0;

  if (!hasActivity) {
    return 0; // No data = no quality index
  }

  // Normalize negative metrics (0-1 range)
  const normalizedBugs = normalize(bugs, maxValues.bugs);
  const normalizedSmells = normalize(smells, maxValues.smells);
  const normalizedDebt = normalize(debt, maxValues.debt);
  const normalizedCost = normalize(cost, maxValues.cost);

  // Weights
  const weights = {
    bugs: 0.20,
    smells: 0.15,
    debt: 0.15,
    cost: 0.10,
    reliability: 0.15,
    security: 0.15,
    maintainability: 0.10
  };

  // Calculate DQI: 100 - (negative part) + (positive part)
  const negativePart = 
    weights.bugs * normalizedBugs * 100 +
    weights.smells * normalizedSmells * 100 +
    weights.debt * normalizedDebt * 100 +
    weights.cost * normalizedCost * 100;

  const positivePart = 
    weights.reliability * reliability * 2 +
    weights.security * security * 2 +
    weights.maintainability * maintainability * 2;

  const dqi = 100 - negativePart + positivePart;

  // Clamp between 0 and 100
  return Math.max(0, Math.min(100, Math.round(dqi * 10) / 10));
};

export const fetchAllDevelopersData = async (
  timeframe: 'WEEK' | 'MONTH' | 'QUARTER' | 'YEAR' = 'WEEK'
): Promise<{
  developers: DeveloperRow[];
  columns: string[];
}> => {
  console.log('Starting fetchAllDevelopersData with timeframe:', timeframe);

  const teamsData = await fetchTeams(timeframe);
  console.log('Teams data received:', teamsData);

  // Use members from teamsData which already have personData
  const developers = teamsData.members.map((member: any) => {
    const flattenedData = member.personData ? flattenObject(member.personData) : {};
    return {
      userId: member.id,
      givenName: member.name,
      personData: member.personData,
      flattenedData,
      dqi: 0
    };
  });

  console.log('Developers processed:', developers.length);

  // Filter out "Automat" users
  const filteredDevelopers = developers.filter(dev => dev.givenName !== 'Automat');

  // Calculate max values for normalization across all developers
  const maxValues = {
    bugs: Math.max(...filteredDevelopers.map(d => d.flattenedData['total.newBugs'] || 0), 1),
    smells: Math.max(...filteredDevelopers.map(d => d.flattenedData['total.newCodeSmells'] || 0), 1),
    debt: Math.max(...filteredDevelopers.map(d => d.flattenedData['total.newTechnicalDebt'] || 0), 1),
    cost: Math.max(...filteredDevelopers.map(d => d.flattenedData['total.newDevelopmentCost'] || 0), 1)
  };

  // Calculate DQI for each developer
  filteredDevelopers.forEach(dev => {
    dev.dqi = calculateDQI(dev.flattenedData, maxValues);
  });

  // Debug: Check what keys are actually available
  const firstDeveloper = filteredDevelopers.find(dev => Object.keys(dev.flattenedData).length > 0);
  if (firstDeveloper) {
    console.log('Available keys in flattened data:', Object.keys(firstDeveloper.flattenedData));
    console.log('Sample flattened data:', firstDeveloper.flattenedData);
  }

  // Check if API uses 'avg' or 'average' prefix
  const hasAvgPrefix = firstDeveloper && Object.keys(firstDeveloper.flattenedData).some(key => key.startsWith('avg.'));
  const prefix = hasAvgPrefix ? 'avg' : 'average';

  console.log('Using prefix:', prefix);

  // Define specific columns to display (DQI-related metrics only)
  const columns = [
    'total.newBugs',
    `${prefix}.newCodeSmells`,
    `${prefix}.newTechnicalDebt`,
    `${prefix}.newReliabilityRating`,
    `${prefix}.newSecurityRating`,
    `${prefix}.newMaintainabilityRating`,
    `${prefix}.newDevelopmentCost`
  ];

  console.log('Columns to display:', columns);
  console.log('DQI values calculated for', filteredDevelopers.length, 'developers');

  return { developers: filteredDevelopers, columns };
};
