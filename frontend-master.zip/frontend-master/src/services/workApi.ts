
export interface EmployeeMetrics {
  interval: 'WEEK' | 'MONTH' | 'QUARTER' | 'YEAR';
  employeeId: string;
  total: {
    numberOfCommits: number;
    additions: number;
    deletions: number;
    total: number;
  };
  avg: {
    commitPerDay: number;
    additions: number;
    deletions: number;
    total: number;
  };
}

export interface WorkApiResponse {
  interval: 'WEEK' | 'MONTH' | 'QUARTER' | 'YEAR';
  unitId: string;
  level: number;
  manager: boolean;
  // Unit-level totals returned by the API
  total: {
    numberOfCommits: number;
    additions: number;
    deletions: number;
    total: number;
    newBugs?: number;
    newCodeSmells?: number;
    newTechnicalDebt?: number;
    newViolations?: number;
    newReliabilityRating?: number;
    newSecurityRating?: number;
    newMaintainabilityRating?: number;
    newDevelopmentCost?: number;
    newDuplicatedBlocks?: number;
    newReliabilityRemediationEffort?: number;
    newDuplicatedLinesDensity?: number;
    newSecurityReviewRating?: number;
  };
  // Previous period totals
  prevTotal: {
    numberOfCommits: number;
    additions: number;
    deletions: number;
    total: number;
    newBugs?: number;
    newCodeSmells?: number;
    newTechnicalDebt?: number;
    newViolations?: number;
    newReliabilityRating?: number;
    newSecurityRating?: number;
    newMaintainabilityRating?: number;
    newDevelopmentCost?: number;
    newDuplicatedBlocks?: number;
    newReliabilityRemediationEffort?: number;
    newDuplicatedLinesDensity?: number;
    newSecurityReviewRating?: number;
  };
  // Unit-level averages returned by the API
  avg: {
    commitPerDay: number;
    additions: number;
    deletions: number;
    total: number;
    newBugs?: number;
    newCodeSmells?: number;
    newTechnicalDebt?: number;
    newViolations?: number;
    newReliabilityRating?: number;
    newSecurityRating?: number;
    newMaintainabilityRating?: number;
    newDevelopmentCost?: number;
    newDuplicatedBlocks?: number;
    newReliabilityRemediationEffort?: number;
    newDuplicatedLinesDensity?: number;
    newSecurityReviewRating?: number;
  };
  // Previous period averages
  prevAvg: {
    commitPerDay: number;
    additions: number;
    deletions: number;
    total: number;
    newBugs?: number;
    newCodeSmells?: number;
    newTechnicalDebt?: number;
    newViolations?: number;
    newReliabilityRating?: number;
    newSecurityRating?: number;
    newMaintainabilityRating?: number;
    newDevelopmentCost?: number;
    newDuplicatedBlocks?: number;
    newReliabilityRemediationEffort?: number;
    newDuplicatedLinesDensity?: number;
    newSecurityReviewRating?: number;
  };
  // Some environments may not return metrics; keep it optional
  metrics?: EmployeeMetrics[];
}

type Timeframe = 'week' | 'month' | 'quarter' | 'year';

const timeframeToInterval = (timeframe: Timeframe): 'WEEK' | 'MONTH' | 'QUARTER' | 'YEAR' => {
  const mapping = {
    'week': 'WEEK',
    'month': 'MONTH',
    'quarter': 'QUARTER',
    'year': 'YEAR'
  } as const;

  return mapping[timeframe];
};

export const fetchWorkStatistics = async (
  timeframe: Timeframe
): Promise<WorkApiResponse> => {
  const interval = timeframeToInterval(timeframe);


  const params = new URLSearchParams({
    interval
  });

  try {
    const url = `/api/work?${params.toString()}`;
    console.log('Fetching work statistics from:', url);

    const response = await fetch(url, {
      method: 'GET',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('API Error Response:', errorText);
      throw new Error(`Failed to fetch work statistics: ${response.status} ${response.statusText}`);
    }

    const data: WorkApiResponse = await response.json();
    console.log('Work statistics received:', data);
    return data;
  } catch (error) {
    console.error('Error fetching work statistics:', error);
    throw error;
  }
};
