import axios from 'axios';

const API_BASE_URL = '/api'; // Using proxy for API calls

export interface PollQuestion {
  questionId: number;
  question: string;
  answerType: 'NUMBER' | 'TEXT';
}

export interface PollResponse {
  questionId: number;
  answer: number | null;
  answerDescription: string | null;
}

export interface PollResponseData {
  numberOfQuestions: number;
  questions: PollQuestion[];
  message: string | null;
}

export const getPollQuestions = async (): Promise<PollQuestion[]> => {
  try {
    // console.log('Fetching poll questions from:', `${API_BASE_URL}/getPollQuestions`);
    const response = await axios.get<PollResponseData>(`${API_BASE_URL}/getPollQuestions`);
    // console.log('Poll questions response:', response.data);
    return response.data.questions;
  } catch (error) {
    // console.error('Error fetching poll questions:', error.message);
    if (axios.isAxiosError(error)) {
      console.error('Axios error details:', error.response?.data, error.response?.status);
    }
    throw error;
  }
};

export interface PollReportData {
  questionId: number;
 question: string;
  answerType: 'NUMBER' | 'TEXT';
  dailyResponses: {
    date: string; // YYYY-MM-DD
    averageRating: number;
    responseCount: number;
  }[];
  recentOpenResponses: {
    date: string; // YYYY-MM-DD
    response: string;
    rating: number;
 }[];
}

// New interface for the actual API response - needs to be updated to handle daily breakdowns
export interface ApiResponse {
  numberOfUniqueAnswers: number;
  periodFrom: string;
  periodTo: string;
  answers: {
    questionNumber: number;
    midAnswer: number;
    textAnswers: string;
  }[];
}

// Define a new API response format that includes daily breakdowns per question
export interface DailyApiResponse {
  numberOfUniqueAnswers: number;
  periodFrom: string;
  periodTo: string;
  questions: {
    questionId: number;
    question: string;
    answerType: 'NUMBER' | 'TEXT';
    dailyData: {
      date: string;
      averageRating: number;
      responseCount: number;
    }[];
    recentOpenResponses: {
      date: string;
      response: string;
      rating: number;
    }[];
  }[];
}

export const getPollReportData = async (dateFrom: string, dateTo: string): Promise<PollReportData[]> => {
  try {
    console.log(`Fetching poll report data from ${dateFrom} to ${dateTo} from:`, `${API_BASE_URL}/getAllAnswersAggregated`);
    
    // Fetch question texts first to get proper question names
    let questionMap: Map<number, PollQuestion> = new Map();
    let allQuestions: PollQuestion[] = [];
    try {
      allQuestions = await getPollQuestions();
      allQuestions.forEach(q => questionMap.set(q.questionId, q));
    } catch (err) {
      console.warn('Could not fetch question texts, will use defaults');
      // If we can't get questions, create default questions
      for (let i = 1; i <= 6; i++) {
        questionMap.set(i, {
          questionId: i,
          question: `Question ${i}`,
          answerType: i === 6 ? 'TEXT' : 'NUMBER'
        });
      }
    }
    
    // Get the response from the API
    const response = await axios.get(`${API_BASE_URL}/getAllAnswersAggregated`, {
      params: {
        dateFrom,
        dateTo
      }
    });
    console.log('Poll report data response:', response.data);
    
    // Check if response has the detailed daily breakdown format (new format)
    if (response.data && typeof response.data === 'object' && 'questions' in response.data) {
      // New format with daily breakdowns
      const dailyResponse = response.data as DailyApiResponse;
      return dailyResponse.questions.map(question => ({
        questionId: question.questionId,
        question: question.question,
        answerType: question.answerType,
        dailyResponses: question.dailyData,
        recentOpenResponses: question.recentOpenResponses || []
      }));
    }
    // Check if response has the simple aggregated format (old format)
    else if (response.data && typeof response.data === 'object' && 'answers' in response.data) {
      // Old format - need to transform to expected format
      const oldResponse = response.data as ApiResponse;
      
      // Extract date range from the API response instead of generating locally
      const startDate = new Date(oldResponse.periodFrom);
      const endDate = new Date(oldResponse.periodTo);
      
      // Generate dates between periodFrom and periodTo (inclusive) from API response
      const dateRange = [];
      const currentDate = new Date(startDate);
      while (currentDate <= endDate) {
        dateRange.push(new Date(currentDate).toISOString().split('T')[0]);
        currentDate.setDate(currentDate.getDate() + 1);
      }
      
      // Create a map of the answers from the API for quick lookup
      const apiAnswersMap = new Map<number, (typeof oldResponse.answers)[0]>();
      oldResponse.answers.forEach(answer => {
        if (answer.questionNumber > 0) { // Only valid question numbers
          apiAnswersMap.set(answer.questionNumber, answer);
        }
      });
      
      // Create data for all questions (1-6), using API data if available or defaults
      const transformedData: PollReportData[] = [];
      
      // Use all questions from the questionMap, or default to 6 questions
      const questionsToProcess = allQuestions.length > 0 ? allQuestions : Array.from({length: 6}, (_, i) => i + 1).map(id => ({
        questionId: id,
        question: `Question ${id}`,
        answerType: id === 6 ? 'TEXT' : 'NUMBER'
      }));
      
      for (const question of questionsToProcess) {
        const apiAnswer = apiAnswersMap.get(question.questionId);
        
        if (apiAnswer) {
          // Use data from API response
          // Determine if this is a NUMBER or TEXT answer
          // Question 6 is the text question, questions 1-5 are number ratings
          const answerType = question.questionId === 6 ? 'TEXT' : 'NUMBER';
          
          // Create daily responses based on API data without artificial variations
          // The API provides numberOfUniqueAnswers which represents total answers in the period
          // For a more accurate representation, we should determine how many responses
          // were for this specific question
          
          // The API doesn't provide responses per question, only the average (midAnswer) per question
          // So we need to estimate how many responses were for this specific question
          // If numberOfUniqueAnswers is 6 and we have 6 questions in the answers array,
          // we'll assume each question received approximately equal number of responses
          
          // Calculate how many responses this specific question likely received
          // Use the actual number of questions that have answers in this API response
          const totalQuestionsWithAnswers = oldResponse.answers.length;
          let responsesForThisQuestion = Math.floor(oldResponse.numberOfUniqueAnswers / totalQuestionsWithAnswers);
          
          // Distribute any remainder across the first few questions
          const remainder = oldResponse.numberOfUniqueAnswers % totalQuestionsWithAnswers;
          if (apiAnswer.questionNumber <= remainder) {
            responsesForThisQuestion += 1;
          }
          
          // Create daily responses - for aggregated data without specific daily breakdowns,
          // the best approach is to show responses on the most recent day that had responses
          // or on the current/latest day in the range if the responses were just submitted
          const dailyResponses = [];
          
          for (let i = 0; i < dateRange.length; i++) {
            // Initially set all days to have no responses
            dailyResponses.push({
              date: dateRange[i],
              averageRating: 0, // No rating if no responses
              responseCount: 0
            });
          }
          
          // Place all responses for this question on the last day of the range
          // This assumes that if responses were just submitted, they would be for the current/latest date
          if (dateRange.length > 0 && responsesForThisQuestion > 0) {
            const lastDayIndex = dateRange.length - 1; // Last day in the range
            dailyResponses[lastDayIndex] = {
              date: dateRange[lastDayIndex],
              averageRating: apiAnswer.midAnswer, // Use the midAnswer only for the day with responses
              responseCount: responsesForThisQuestion
            };
          }
          
          const recentOpenResponses = apiAnswer.textAnswers && apiAnswer.textAnswers !== "" && apiAnswer.textAnswers !== "null" ? [{
            date: dateFrom,
            response: apiAnswer.textAnswers,
            rating: apiAnswer.midAnswer
          }] : [];
          
          // Get the actual question text if available
          const questionText = questionMap.get(apiAnswer.questionNumber)?.question || `Question ${apiAnswer.questionNumber}`;
          
          transformedData.push({
            questionId: apiAnswer.questionNumber,
            question: questionText,
            answerType,
            dailyResponses,
            recentOpenResponses
          });
        } else {
          // Create default data for questions not in API response
          const dailyResponses = dateRange.map(date => ({
            date: date,
            averageRating: 0, // Default to 0 for no data
            responseCount: 0
          }));
          
          transformedData.push({
            questionId: question.questionId,
            question: question.question,
            answerType: question.answerType,
            dailyResponses,
            recentOpenResponses: []
          });
        }
      }

      console.log('Transformed data:', transformedData);
      console.log('Number of questions:', transformedData.length);
      transformedData.forEach(q => {
        console.log(`Question ${q.questionId} (${q.answerType}): ${q.question}`);
        console.log(` Daily responses:`, q.dailyResponses);
      });
      
      return transformedData;
    }
    // If the response doesn't match expected formats, return default data for all questions
    else {
      console.warn('Unexpected API response format:', response.data);
      
      // Extract date range from the original request parameters since API response is unexpected
      const startDate2 = new Date(dateFrom);
      const endDate2 = new Date(dateTo);
      
      // Generate dates between dateFrom and dateTo (inclusive) from the original request
      const dateRange2 = [];
      const currentDate2 = new Date(startDate2);
      while (currentDate2 <= endDate2) {
        dateRange2.push(new Date(currentDate2).toISOString().split('T')[0]);
        currentDate2.setDate(currentDate2.getDate() + 1);
      }
      
      // Use all questions from the questionMap, or default to 6 questions
      const questionsToProcess2 = allQuestions.length > 0 ? allQuestions : Array.from({length: 6}, (_, i) => i + 1).map(id => ({
        questionId: id,
        question: `Question ${id}`,
        answerType: id === 6 ? 'TEXT' : 'NUMBER'
      }));
      
      const defaultData: PollReportData[] = questionsToProcess2.map(question => ({
        questionId: question.questionId,
        question: question.question,
        answerType: question.answerType,
        dailyResponses: dateRange2.map(date => ({
          date: date,
          averageRating: 0, // Default to 0 for no data
          responseCount: 0
        })),
        recentOpenResponses: []
      }));
      
      return defaultData;
    }
 } catch (error) {
    console.error('Error fetching poll report data:', error.message);
    if (axios.isAxiosError(error)) {
      console.error('Axios error details:', error.response?.data, error.response?.status);
    }
    throw error;
  }
};

export const savePollResponse = async (responses: PollResponse[]): Promise<void> => {
  try {
    await axios.post(`${API_BASE_URL}/savePollResponse`, { responses });
  } catch (error) {
    console.error('Error saving poll response:', error.message);
    if (axios.isAxiosError(error)) {
      console.error('Axios error details:', error.response?.data, error.response?.status);
    }
    throw error;
  }
};