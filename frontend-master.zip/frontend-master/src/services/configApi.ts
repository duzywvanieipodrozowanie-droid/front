// API service for saving dashboard configuration
export interface WidgetConfig {
  id: string;
  title: string;
  type: string;
  x: number;
  y: number;
  width: number;
  height: number;
  visible: boolean;
}

export interface ConfigPayload {
  [key: string]: string;
}

export const saveDashboardConfig = async (widgets: any[]): Promise<void> => {
  try {
    // Convert widgets to config format
    const configPayload: ConfigPayload = {};

    widgets.forEach(widget => {
      const widgetConfig: WidgetConfig = {
        id: widget.i,
        title: widget.title,
        type: widget.type,
        x: widget.x,
        y: widget.y,
        width: widget.w,
        height: widget.h,
        visible: true
      };

      // Create key in format "widget_<widgetId>" and value as JSON string
      const key = `widget_${widget.i}`;
      configPayload[key] = JSON.stringify(widgetConfig);
    });

    console.log('=== Saving Dashboard Config ===');
    console.log('Payload:', configPayload);

    // Call the /config endpoint
    const response = await fetch('/api/config', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      credentials: 'include',
      body: JSON.stringify(configPayload),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Failed to save dashboard config:', errorText);
      throw new Error(`Failed to save config: ${response.status} ${response.statusText}`);
    }

    console.log('Dashboard configuration saved successfully');
  } catch (error) {
    console.error('Error saving dashboard configuration:', error);
    // Optionally show user notification here
    throw error;
  }
};

// Debounced version to avoid too frequent saves during dragging
let saveTimeout: NodeJS.Timeout | null = null;

export const saveDashboardConfigDebounced = (widgets: any[], delay: number = 1000): void => {
  // Clear previous timeout
  if (saveTimeout) {
    clearTimeout(saveTimeout);
  }

  // Set new timeout
  saveTimeout = setTimeout(() => {
    saveDashboardConfig(widgets).catch(error => {
      console.error('Failed to save dashboard config:', error);
    });
  }, delay);
};

export const loadDashboardConfig = async (): Promise<any[] | null> => {
  try {
    console.log('=== Loading Dashboard Config ===');

    // Call the /config endpoint
    const response = await fetch('/api/config', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
      credentials: 'include',
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Failed to load dashboard config:', errorText);
      return null;
    }

    const configData: ConfigPayload = await response.json();
    console.log('Raw config data:', configData);

    // Convert config data back to widgets format
    const widgets: any[] = [];

    Object.entries(configData).forEach(([key, value]) => {
      // Only process widget keys
      if (key.startsWith('widget_')) {
        try {
          const widgetConfig: WidgetConfig = JSON.parse(value);

          // Convert back to Dashboard widget format
          const widget = {
            i: widgetConfig.id,
            type: widgetConfig.type as any, // Cast to WidgetType
            x: widgetConfig.x,
            y: widgetConfig.y,
            w: widgetConfig.width,
            h: widgetConfig.height,
            title: widgetConfig.title,
          };

          widgets.push(widget);
        } catch (parseError) {
          console.error('Failed to parse widget config:', key, parseError);
        }
      }
    });

    console.log('=== Loaded Dashboard Config ===');
    console.log('Widgets count:', widgets.length);
    console.log('Widgets:', widgets);

    return widgets.length > 0 ? widgets : null;
  } catch (error) {
    console.error('Error loading dashboard configuration:', error);
    return null;
  }
};
