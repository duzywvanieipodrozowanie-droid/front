import { Task, TaskTreeResponse, TaskUser, TaskHistory } from '../types/task';

export class TaskTreeService {
  private baseUrl: string;
  private headers: Record<string, string>;

  constructor(baseUrl: string = '', headers: Record<string, string> = {}) {
    this.baseUrl = baseUrl;
    this.headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      // Dodaj authentication jeśli potrzebne
      // 'X-API-Key': 'your-api-key',
      // 'Authorization': 'Bearer your-token',
      ...headers,
    };
  }

  /**
   * Funkcja testowa do sprawdzenia rzeczywistej odpowiedzi API
   */
  async testApiCall(): Promise<any> {
    try {
      const url = `${this.baseUrl}/api/work/task/tree`;
      console.log('🧪 TEST API CALL');
      console.log('🌐 URL:', url);
      console.log('📋 Headers:', JSON.stringify(this.headers, null, 2));

      const response = await fetch(url, {
        method: 'GET',
        headers: this.headers,
        credentials: 'include',
      });

      console.log('📊 RESPONSE STATUS:', response.status);
      console.log('📊 RESPONSE STATUS TEXT:', response.statusText);
      console.log('📊 RESPONSE HEADERS:', JSON.stringify(Object.fromEntries(response.headers.entries()), null, 2));

      const responseText = await response.text();
      console.log('📊 RESPONSE LENGTH:', responseText.length);
      console.log('📊 RAW RESPONSE:', responseText);

      // Spróbuj sparsować jako JSON
      let parsedData = null;
      try {
        parsedData = JSON.parse(responseText);
        console.log('📊 PARSED JSON:', JSON.stringify(parsedData, null, 2));
        console.log('📊 JSON TYPE:', typeof parsedData);
        console.log('📊 IS ARRAY:', Array.isArray(parsedData));
        if (typeof parsedData === 'object' && parsedData !== null) {
          console.log('📊 OBJECT KEYS:', Object.keys(parsedData));
        }
      } catch (parseError) {
        console.log('📊 JSON PARSE ERROR:', parseError);
        console.log('📊 RESPONSE IS NOT JSON');
      }

      return {
        status: response.status,
        statusText: response.statusText,
        headers: Object.fromEntries(response.headers.entries()),
        rawResponse: responseText,
        parsedData: parsedData,
        length: responseText.length
      };

    } catch (error) {
      console.error('🚨 TEST API ERROR:', error);
      throw error;
    }
  }

  /**
   * Pobiera taski z endpointu /api/work/task/tree
   */
  async fetchTaskTree(): Promise<Task[]> {
    try {
      const url = `${this.baseUrl}/api/work/task/tree`;
      console.log('🌳 Pobieranie task tree z:', url);
      console.log('📋 Headers:', this.headers);

      const response = await fetch(url, {
        method: 'GET',
        headers: this.headers,
        // Dodaj credentials jeśli potrzebne dla CORS
        credentials: 'include',
      });

      console.log('📡 Response status:', response.status);
      console.log('📡 Response headers:', Object.fromEntries(response.headers.entries()));

      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ API Error Response:', errorText);
        throw new Error(`HTTP error! status: ${response.status}, message: ${errorText}`);
      }

      const responseText = await response.text();
      console.log('📥 Otrzymano odpowiedź, długość:', responseText.length);
      console.log('📥 Pierwsze 500 znaków:', responseText.substring(0, 500));
      console.log('📥 PEŁNA ODPOWIEDŹ:', responseText);

      // Obsługa pustej odpowiedzi
      if (!responseText || responseText.trim().length === 0) {
        console.warn('⚠️ Otrzymano pustą odpowiedź, zwracam pustą tablicę tasków');
        return [];
      }

      // Parsowanie JSON
      let data: TaskTreeResponse;
      try {
        data = JSON.parse(responseText);
        console.log('✅ JSON sparsowany pomyślnie, liczba kluczy:', Object.keys(data).length);
      } catch (parseError) {
        console.error('❌ Błąd parsowania JSON:', parseError);
        console.error('❌ Problematyczna odpowiedź:', responseText.substring(0, 500));
        return [];
      }

      // Parsowanie odpowiedzi task tree
      const tasks = this.parseTaskTreeResponse(data);
      console.log('✅ Pomyślnie sparsowano', tasks.length, 'tasków z task tree');

      return tasks;
    } catch (error) {
      console.error('❌ Błąd podczas pobierania task tree:', error);
      return [];
    }
  }

  /**
   * Parsuje format odpowiedzi task tree
   */
  private parseTaskTreeResponse(data: TaskTreeResponse): Task[] {
    const tasks: Task[] = [];

    for (const taskString in data) {
      try {
        const task = this.parseTaskFromString(taskString);
        if (task) {
          tasks.push(task);
        }
      } catch (error) {
        console.error('❌ Błąd parsowania task string:', taskString.substring(0, 100), error);
        continue;
      }
    }

    return tasks;
  }

  /**
   * Parsuje pojedynczy task ze stringowej reprezentacji
   */
  private parseTaskFromString(taskString: string): Task | null {
    try {
      // Usuwamy prefix "Task(" i suffix ")"
      const cleanedString = taskString.replace(/^Task\(/, '').replace(/\)$/, '');

      // Parsujemy pary klucz-wartość
      const taskData: any = {};

      // Używamy bardziej zaawansowanego regex do parsowania
      const parts = this.splitTaskString(cleanedString);

      for (const part of parts) {
        const [key, value] = this.parseKeyValuePair(part);
        if (key && value !== undefined) {
          taskData[key] = value;
        }
      }

      // Konwertujemy do obiektu Task
      return {
        id: taskData.id || 0,
        key: taskData.key || '',
        self: taskData.self || '',
        project: taskData.project || '',
        type: taskData.type || '',
        parent: taskData.parent,
        summary: taskData.summary || '',
        labels: taskData.labels || [],
        status: taskData.status || '',
        priority: taskData.priority || '',
        assignee: taskData.assignee,
        creator: taskData.creator || { accountId: '', displayName: '' },
        text: taskData.text || [],
        updated: taskData.updated || '',
        created: taskData.created || '',
        dependencies: taskData.dependencies || [],
        images: taskData.images || [],
        histories: taskData.histories || [],
      };
    } catch (error) {
      console.error('❌ Błąd parsowania task string:', error);
      return null;
    }
  }

  /**
   * Dzieli string taska na części respektując zagnieżdżone struktury
   */
  private splitTaskString(str: string): string[] {
    const parts: string[] = [];
    let current = '';
    let depth = 0;
    let inBrackets = false;

    for (let i = 0; i < str.length; i++) {
      const char = str[i];

      if (char === '[') inBrackets = true;
      if (char === ']') inBrackets = false;
      if (char === '(') depth++;
      if (char === ')') depth--;

      if (char === ',' && depth === 0 && !inBrackets) {
        parts.push(current.trim());
        current = '';
      } else {
        current += char;
      }
    }

    if (current.trim()) {
      parts.push(current.trim());
    }

    return parts;
  }

  /**
   * Parsuje parę klucz-wartość
   */
  private parseKeyValuePair(part: string): [string, any] {
    const equalIndex = part.indexOf('=');
    if (equalIndex === -1) return ['', undefined];

    const key = part.substring(0, equalIndex).trim();
    const valueStr = part.substring(equalIndex + 1).trim();

    let value: any;

    if (valueStr === 'null') {
      value = null;
    } else if (valueStr.startsWith('[') && valueStr.endsWith(']')) {
      // Parsowanie tablic
      value = this.parseArrayValue(valueStr);
    } else if (valueStr.startsWith('Task.User(')) {
      // Parsowanie obiektów User
      value = this.parseUserFromString(valueStr);
    } else if (key === 'histories' && valueStr.includes('Task.History(')) {
      // Parsowanie historii
      value = this.parseHistoriesFromString(valueStr);
    } else if (!isNaN(Number(valueStr))) {
      // Parsowanie liczb
      value = Number(valueStr);
    } else {
      // Wartości tekstowe
      value = valueStr;
    }

    return [key, value];
  }

  /**
   * Parsuje wartości tablicowe ze stringa
   */
  private parseArrayValue(arrayString: string): any[] {
    if (arrayString === '[]') {
      return [];
    }

    // Usuwamy nawiasy kwadratowe i dzielimy po przecinku
    const content = arrayString.slice(1, -1);
    if (!content.trim()) {
      return [];
    }

    return content.split(',').map(item => item.trim());
  }

  /**
   * Parsuje obiekt User ze stringa
   */
  private parseUserFromString(userString: string): TaskUser | null {
    try {
      const match = userString.match(/Task\.User\(accountId=([^,]+), displayName=([^)]+)\)/);
      if (match) {
        return {
          accountId: match[1],
          displayName: match[2],
        };
      }
      return null;
    } catch (error) {
      console.error('❌ Błąd parsowania user string:', error);
      return null;
    }
  }

  /**
   * Parsuje tablicę historii ze stringa
   */
  private parseHistoriesFromString(historiesString: string): TaskHistory[] {
    try {
      if (historiesString === '[]') {
        return [];
      }

      const histories: TaskHistory[] = [];
      const historyRegex = /Task\.History\(fieldType=([^,]+), from=([^,]+), to=([^,]+), created=([^,]+), author=Task\.User\(accountId=([^,]+), displayName=([^)]+)\)\)/g;

      let match;
      while ((match = historyRegex.exec(historiesString)) !== null) {
        histories.push({
          fieldType: match[1],
          from: match[2],
          to: match[3],
          created: match[4],
          author: {
            accountId: match[5],
            displayName: match[6],
          },
        });
      }

      return histories;
    } catch (error) {
      console.error('❌ Błąd parsowania histories string:', error);
      return [];
    }
  }

  /**
   * Konwertuje obiekty Task do formatu kompatybilnego z Jira
   */
  convertTasksToJiraFormat(tasks: Task[]): any[] {
    return tasks.map(task => ({
      id: task.id,
      key: task.key,
      self: task.self,
      fields: {
        project: { key: task.project },
        issuetype: { name: task.type },
        parent: task.parent ? { key: task.parent } : null,
        summary: task.summary,
        labels: task.labels,
        status: { name: task.status },
        priority: { name: task.priority },
        assignee: task.assignee ? {
          accountId: task.assignee.accountId,
          displayName: task.assignee.displayName,
        } : null,
        creator: {
          accountId: task.creator.accountId,
          displayName: task.creator.displayName,
        },
        description: task.text.join('\n'),
        updated: task.updated,
        created: task.created,
      },
      histories: task.histories,
    }));
  }

  /**
   * Pobiera i konwertuje taski do formatu Jira
   */
  async fetchTasksAsJiraFormat(): Promise<any[]> {
    const tasks = await this.fetchTaskTree();
    return this.convertTasksToJiraFormat(tasks);
  }
}

// Export domyślny dla łatwego importu
export default TaskTreeService;
