export interface PersonData {
  [key: string]: any;
}

export const fetchPersonData = async (
  id: string,
  interval: 'WEEK' | 'MONTH' | 'QUARTER' | 'YEAR' = 'WEEK'
): Promise<PersonData | null> => {
  try {
    console.log(`Fetching person data for ${id} with interval ${interval}...`);

    const response = await fetch(`/api/organization/peoples?authorId=${id}&interval=${interval}`, {
      credentials: 'include',
      headers: { 
        'accept': 'application/json',
        'Content-Type': 'application/json'
      }
    });

    if (response.ok) {
      const contentType = response.headers.get('content-type');
      if (contentType && contentType.includes('application/json')) {
        const personData = await response.json();
        console.log(`Person data for ${id}:`, personData);
        return personData;
      } else {
        console.warn(`Person API for ${id} returned non-JSON content`);
        return null;
      }
    } else {
      console.warn(`Failed to fetch person data for ${id}: ${response.status}`);
      return null;
    }
  } catch (err) {
    console.error(`Error fetching person data for ${id}:`, err);
    return null;
  }
};
