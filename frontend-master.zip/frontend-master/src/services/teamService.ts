export interface TeamMember {
  id: string;
  name: string;
  personData?: any;
}

const fetchPersonDataDirect = async (
  id: string,
  interval: 'WEEK' | 'MONTH' | 'QUARTER' | 'YEAR' = 'WEEK'
): Promise<any | null> => {
  try {
    const url = `/api/work/person?authorId=${id}&interval=${interval}`;
    console.log(`🚀 API CALL: ${url}`);
    console.log(`📋 Fetching person data for ID: ${id} with interval: ${interval}`);

    const response = await fetch(url, {
      credentials: 'include',
      headers: { 
        'accept': 'application/json',
        'Content-Type': 'application/json'
      }
    });

    console.log(`📊 Response status for ${id}: ${response.status}`);
    console.log(`📊 Response headers for ${id}:`, response.headers.get('content-type'));

    if (response.ok) {
      const contentType = response.headers.get('content-type');
      if (contentType && contentType.includes('application/json')) {
        const personData = await response.json();
        console.log(`✅ SUCCESS: Person data received for ${id}:`, personData);
        return personData;
      } else {
        console.warn(`⚠️ Person API for ${id} returned non-JSON content:`, contentType);
        return null;
      }
    } else {
      const errorText = await response.text();
      console.error(`❌ FAILED: Person data fetch for ${id}: ${response.status} - ${errorText}`);
      return null;
    }
  } catch (err) {
    console.error(`💥 ERROR: Exception while fetching person data for ${id}:`, err);
    return null;
  }
};

export interface OrganisationData {
  [key: string]: any;
}

export const fetchOrganisations = async (): Promise<OrganisationData[]> => {
  console.log('Fetching organisations data from /api/organization...');

  const response = await fetch('/api/organization', {
    credentials: 'include',
    headers: { 
      'accept': 'application/json',
      'Content-Type': 'application/json'
    }
  });

  console.log('Organisations response status:', response.status);
  console.log('Organisations response headers:', response.headers.get('content-type'));

  if (!response.ok) {
    const errorText = await response.text();
    console.error('Organisations API error response:', errorText);
    throw new Error(`Failed to fetch organisations data: ${response.status} ${response.statusText}`);
  }

  const contentType = response.headers.get('content-type');
  if (!contentType || !contentType.includes('application/json')) {
    const responseText = await response.text();
    console.error('Organisations API returned non-JSON response:', responseText.substring(0, 200));
    throw new Error(`API returned ${contentType || 'unknown content type'} instead of JSON.`);
  }

  const data = await response.json();
  console.log('Organisations data received:', data);
  return Array.isArray(data) ? data : [data];
};

export const extractUniqueIds = (organisationsData: OrganisationData[]): { ids: string[], memberMap: Map<string, string> } => {
  const uniqueIds = new Set<string>();
  const memberMap = new Map<string, string>();

  console.log('=== DEBUGGING ORGANIZATION DATA ===');
  console.log('Number of organizations received:', organisationsData.length);
  console.log('Full organizations data structure:', JSON.stringify(organisationsData, null, 2));

  console.log('Extracting unique IDs from organisations data (only non-technical members)...');

  organisationsData.forEach((org: any, index: number) => {
    console.log(`\n--- Organisation ${index} ---`);
    console.log('Organization name:', org.name);
    console.log('Organization keys:', Object.keys(org));
    console.log('Full organization object:', org);

    // Check all possible member locations
    if (org.members && Array.isArray(org.members)) {
      console.log(`Found members array with ${org.members.length} members`);
      org.members.forEach((member: any, memberIndex: number) => {
        console.log(`  Member ${memberIndex}:`, member);
        console.log(`  Member keys:`, Object.keys(member));
        console.log(`  ID: ${member.id}, Name: ${member.name}, Technical: ${member.technical}`);

        // Only add member if technical is explicitly false
        if (member.id && member.technical === false) {
          uniqueIds.add(member.id);
          memberMap.set(member.id, member.name);
          console.log(`  ✓ Added member ID: ${member.id} (${member.name}) - technical: false`);
        } else if (member.id && member.technical === true) {
          console.log(`  ✗ Skipped member ID: ${member.id} (${member.name}) - technical: true`);
        } else if (member.id) {
          console.log(`  ✗ Skipped member ID: ${member.id} (${member.name}) - technical field: ${member.technical}`);
        } else {
          console.log(`  ✗ Member has no ID:`, member);
        }
      });
    } else {
      console.log(`  No members array found. Available fields:`, Object.keys(org));
      if (org.members) {
        console.log(`  Members field exists but is not array:`, typeof org.members, org.members);
      }
    }
  });

  const ids = Array.from(uniqueIds);
  console.log(`\n=== EXTRACTION COMPLETE ===`);
  console.log(`Total unique non-technical member IDs extracted: ${ids.length}`);
  console.log('Extracted IDs:', ids);
  console.log('Member ID->Name map:', Array.from(memberMap.entries()));

  return { ids, memberMap };
};

export const fetchTeams = async (interval: 'WEEK' | 'MONTH' | 'QUARTER' | 'YEAR' = 'WEEK'): Promise<any> => {
  try {
    console.log('Starting new teams flow: organisations -> person data...');
    console.log('Interval:', interval);

    // Step 1: Fetch organisations
    const organisationsData = await fetchOrganisations();

    // Step 2: Extract unique IDs with names
    const { ids: uniqueIds, memberMap } = extractUniqueIds(organisationsData);

    if (uniqueIds.length === 0) {
      console.warn('No IDs found in organisations data');
      return { teams: [], members: [] };
    }

    // Step 3: Fetch person data for each unique ID directly from /api/work/person
    console.log(`\n========== Fetching person data directly from /api/work/person for ${uniqueIds.length} unique IDs ==========`);
    console.log('IDs to fetch:', uniqueIds);

    const personDataPromises = uniqueIds.map((id, index) => {
      const memberName = memberMap.get(id) || 'Unknown';
      console.log(`[${index + 1}/${uniqueIds.length}] Direct API call to /api/work/person for: ${memberName} (ID: ${id})`);

      return fetchPersonDataDirect(id, interval)
        .then(data => {
          if (data) {
            console.log(`  ✓ Successfully fetched data for ${memberName} (${id})`);
          } else {
            console.warn(`  ⚠ No data returned for ${memberName} (${id})`);
          }
          return data;
        })
        .catch(err => {
          console.error(`  ✗ Failed to fetch data for ${memberName} (${id}):`, err);
          return null;
        });
    });

    const personDataResults = await Promise.all(personDataPromises);
    console.log('========== Person data fetch complete ==========\n');

    // Step 4: Combine data - use name from organisation, not from personData
    const enrichedMembers = uniqueIds.map((id, index) => ({
      id,
      name: memberMap.get(id) || `User ${id}`,
      personData: personDataResults[index]
    }));

    const successfulMembers = enrichedMembers.filter(m => m.personData !== null);
    const failedMembers = enrichedMembers.filter(m => m.personData === null);

    console.log(`✓ Successfully enriched: ${successfulMembers.length} members`);
    if (failedMembers.length > 0) {
      console.warn(`⚠ Failed to enrich: ${failedMembers.length} members:`, failedMembers.map(m => `${m.name} (${m.id})`));
    }

    return {
      organisations: organisationsData,
      members: successfulMembers,
      failedMembers: failedMembers,
      allIds: uniqueIds,
      memberMap: Object.fromEntries(memberMap)
    };
  } catch (error) {
    console.error('Error in fetchTeams:', error);
    throw error;
  }
};

export const extractUniqueMembers = (teamsData: any): Map<string, string> => {
  const uniqueMembers = new Map<string, string>();

  console.log('Processing teams data for unique members...');

  // Handle new data format from fetchTeams
  if (teamsData.members && Array.isArray(teamsData.members)) {
    teamsData.members.forEach((member: TeamMember) => {
      if (member.id && member.name) {
        uniqueMembers.set(member.id, member.name);
        console.log(`  ✓ Added: id=${member.id}, name=${member.name}`);
      }
    });
  } 
  // Fallback to old format for backward compatibility
  else if (Array.isArray(teamsData)) {
    teamsData.forEach((team: any, teamIndex: number) => {
      console.log(`Team ${teamIndex}:`, team);
      if (team.members && Array.isArray(team.members)) {
        team.members.forEach((member: any, memberIndex: number) => {
          console.log(`  Member ${memberIndex}:`, { id: member.id, name: member.name, fullMember: member });
          if (member.id && member.name) {
            uniqueMembers.set(member.id, member.name);
            console.log(`  ✓ Added: id=${member.id}, name=${member.name}`);
          } else {
            console.warn(`  ✗ Skipped member (missing id or name):`, member);
          }
        });
      } else {
        console.warn(`Team ${teamIndex} has no members array:`, team);
      }
    });
  } else {
    console.error('teamsData is not in expected format:', teamsData);
  }

  console.log('Unique members extracted:', uniqueMembers.size);
  console.log('Unique members Map:', Array.from(uniqueMembers.entries()));
  return uniqueMembers;
};
