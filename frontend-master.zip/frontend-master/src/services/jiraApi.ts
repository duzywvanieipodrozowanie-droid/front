// Jira API interfaces based on Atlassian Jira structure

export interface AvatarUrls {
  "48x48": string;
  "24x24": string;
  "16x16": string;
  "32x32": string;
}

export interface IssueType {
  self: string;
  id: string;
  description: string;
  iconUrl: string;
  name: string;
  subtask: boolean;
  avatarId: number;
  entityId: string;
  hierarchyLevel: number;
}

export interface Project {
  self: string;
  id: string;
  key: string;
  name: string;
  projectTypeKey: string;
  simplified: boolean;
  avatarUrls: AvatarUrls;
}

export interface StatusCategory {
  self: string;
  id: number;
  key: string;
  colorName: string;
  name: string;
}

export interface Status {
  self: string;
  description: string;
  iconUrl: string;
  name: string;
  id: string;
  statusCategory: StatusCategory;
}

export interface Priority {
  self: string;
  iconUrl: string;
  name: string;
  id: string;
}

export interface User {
  self: string;
  accountId: string;
  avatarUrls: AvatarUrls;
  displayName: string;
  active: boolean;
  timeZone: string;
  accountType: string;
}

export interface IssueRestriction {
  issuerestrictions: Record<string, any>;
  shouldDisplay: boolean;
}

export interface Watches {
  self: string;
  watchCount: number;
  isWatching: boolean;
}

export interface Progress {
  progress: number;
  total: number;
}

export interface Votes {
  self: string;
  votes: number;
  hasVoted: boolean;
}

export interface Comment {
  comments: any[];
  self: string;
  maxResults: number;
  total: number;
  startAt: number;
}

export interface Worklog {
  startAt: number;
  maxResults: number;
  total: number;
  worklogs: any[];
}

export interface DescriptionContent {
  type: string;
  version?: number;
  content?: Array<{
    type: string;
    attrs?: Record<string, any>;
    content?: Array<{
      type: string;
      text?: string;
      attrs?: Record<string, any>;
    }>;
  }>;
}

export interface JiraIssueFields {
  statuscategorychangedate: string;
  issuetype: IssueType;
  timespent: number | null;
  project: Project;
  fixVersions: any[];
  aggregatetimespent: number | null;
  statusCategory: StatusCategory;
  resolution: any | null;
  resolutiondate: string | null;
  workratio: number;
  issuerestriction: IssueRestriction;
  watches: Watches;
  lastViewed: string | null;
  created: string;
  priority: Priority;
  labels: string[];
  timeestimate: number | null;
  aggregatetimeoriginalestimate: number | null;
  versions: any[];
  issuelinks: any[];
  assignee: User | null;
  updated: string;
  status: Status;
  components: any[];
  timeoriginalestimate: number | null;
  description: DescriptionContent | null;
  timetracking: Record<string, any>;
  security: any | null;
  attachment: any[];
  aggregatetimeestimate: number | null;
  summary: string;
  creator: User;
  subtasks: any[];
  reporter: User;
  aggregateprogress: Progress;
  environment: any | null;
  duedate: string | null;
  progress: Progress;
  votes: Votes;
  comment: Comment;
  worklog: Worklog;
  // Custom fields - using generic approach for flexibility
  [key: string]: any;
}

export interface JiraIssue {
  expand: string;
  id: string;
  self: string;
  key: string;
  fields: JiraIssueFields;
}

export interface JiraApiResponse {
  issues: JiraIssue[];
  startAt?: number;
  maxResults?: number;
  total?: number;
}

export interface JiraQueryParams {
  startAt?: number;
  maxResults?: number;
  jql?: string;
  fields?: string;
  expand?: string;
  project?: string;
  status?: string;
  assignee?: string;
  issueType?: string;
  priority?: string;
}

export const fetchJiraIssues = async (
  params?: JiraQueryParams
): Promise<JiraApiResponse> => {
  const searchParams = new URLSearchParams();

  if (params?.startAt !== undefined) {
    searchParams.append('startAt', params.startAt.toString());
  }
  if (params?.maxResults !== undefined) {
    searchParams.append('maxResults', params.maxResults.toString());
  }
  if (params?.jql) {
    searchParams.append('jql', params.jql);
  }
  if (params?.fields) {
    searchParams.append('fields', params.fields);
  }
  if (params?.expand) {
    searchParams.append('expand', params.expand);
  }
  if (params?.project) {
    searchParams.append('project', params.project);
  }
  if (params?.status) {
    searchParams.append('status', params.status);
  }
  if (params?.assignee) {
    searchParams.append('assignee', params.assignee);
  }
  if (params?.issueType) {
    searchParams.append('issueType', params.issueType);
  }
  if (params?.priority) {
    searchParams.append('priority', params.priority);
  }

  try {
    const url = `/api/jira//tasks${searchParams.toString() ? `?${searchParams.toString()}` : ''}`;
    console.log('Fetching Jira issues from:', url);

    const response = await fetch(url, {
      method: 'GET',
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Jira API Error Response:', errorText);
      throw new Error(`Failed to fetch Jira issues: ${response.status} ${response.statusText}`);
    }

    const data: JiraApiResponse = await response.json();
    console.log('Jira issues received:', {
      total: data.total,
      issues: data.issues?.length,
      startAt: data.startAt,
      maxResults: data.maxResults
    });

    return data;
  } catch (error) {
    console.error('Error fetching Jira issues:', error);
    throw error;
  }
};

// Helper functions for common Jira operations
export const getIssueById = async (issueId: string): Promise<JiraIssue | null> => {
  try {
    const response = await fetchJiraIssues({
      jql: `id = ${issueId}`,
      maxResults: 1
    });
    return response.issues?.[0] || null;
  } catch (error) {
    console.error(`Error fetching issue ${issueId}:`, error);
    return null;
  }
};

export const getIssuesByProject = async (projectKey: string, maxResults = 50): Promise<JiraApiResponse> => {
  return fetchJiraIssues({
    project: projectKey,
    maxResults
  });
};

export const getIssuesByStatus = async (status: string, maxResults = 50): Promise<JiraApiResponse> => {
  return fetchJiraIssues({
    status,
    maxResults
  });
};

export const getIssuesByAssignee = async (assigneeId: string, maxResults = 50): Promise<JiraApiResponse> => {
  return fetchJiraIssues({
    assignee: assigneeId,
    maxResults
  });
};

// Type guards for safer type checking
export const isJiraIssue = (obj: any): obj is JiraIssue => {
  return obj && typeof obj === 'object' &&
         typeof obj.id === 'string' &&
         typeof obj.key === 'string' &&
         obj.fields && typeof obj.fields === 'object';
};

export const hasAssignee = (issue: JiraIssue): issue is JiraIssue & { fields: { assignee: User } } => {
  return issue.fields.assignee !== null && issue.fields.assignee !== undefined;
};
