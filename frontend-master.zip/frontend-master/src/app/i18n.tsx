import React, { createContext, useContext, useMemo } from 'react';

export type Lang = 'en' | 'pl';

export type LangContextValue = {
  lang: Lang;
  setLang?: (l: Lang) => void;
};

const LangContext = createContext<LangContextValue>({ lang: 'en' });

export function LangProvider({ lang, setLang, children }: React.PropsWithChildren<{ lang: Lang; setLang?: (l: Lang) => void }>) {
  return <LangContext.Provider value={{ lang, setLang }}>{children}</LangContext.Provider>;
}

export function useLang(): LangContextValue {
  return useContext(LangContext);
}

// Simple translation helper with EN/PL dictionary for core UI texts
const dict = {
  en: {
    clickForDetails: 'Click for details',
    back: 'Back',
    backToTeam: 'Back to Team',
    compare: 'Compare',
    commits: 'Commits',
    prs: 'PRs',
    prsCreated: 'PRs Created',
    prsMerged: 'PRs Merged',
    reviews: 'Reviews',
    avgCycleTime: 'Avg Cycle Time',
    projects: 'Projects',
    linesPlusMinus: 'Lines ±',
    unknownDeveloper: 'Unknown developer',
    unknownUser: 'Unknown user',
    refreshing: 'Refreshing data for the selected period…',

    // Pages and widgets (subset)
    overview: 'Overview',
    doraMetrics: 'DORA Metrics',
    team: 'Team',
    settings: 'Settings',
    helpSupport: 'Help & Support',
    localBenchmark: 'Local Benchmark',
    noData: 'No Data',

    // Common navigation and filters
    allTeams: 'All Teams',
    last7d: 'Last 7 days',
    last2w: 'Last 2 weeks',
    last4w: 'Last 4 weeks',
    last3m: 'Last 3 months',
    last6m: 'Last 6 months',

    // Dashboard
    engineeringPerformance: 'Engineering performance',
    prCycleTime: 'PR Cycle Time',
    prThroughput: 'PR Throughput',
    deployFrequency: 'Deploy Frequency',
    failRate: 'Fail Rate',
    hoursPerStage: 'Hours per stage',
    prCycleBreakdown: 'PR Cycle Time Breakdown',

    // Cycle Time Breakdown details
    cycleTimeBreakdown: 'Cycle Time Breakdown',
    coding: 'Coding',
    pickup: 'Pickup',
    review: 'Review',
    merge: 'Merge',
    ofTotal: 'of total',
    vsPrevPeriod: 'vs previous period',
    was: 'was',

    // Common dashboard labels
    prFlow: 'PR Flow',
    recentPRs: 'Recent PRs',
    last24h: 'Last 24h',
    loading: 'Loading…',
    opened: 'Opened',
    merged: 'Merged',
    mergeRate: 'Merge rate',
    dropped: 'dropped',
    investments: 'Investments',
    selectEngineer: 'Select engineer',
    vsLocal: 'vs Local',

    // DORA
    devopsSubtitle: 'DevOps Research & Assessment — software delivery performance',
    leadTimeForChanges: 'Lead Time for Changes',
    changeFailureRate: 'Change Failure Rate',
    meanTimeToRecovery: 'Mean Time to Recovery',

    // Team hierarchy badges
    domain: 'Domain',
    tribe: 'Tribe',
    chapter: 'Chapter',
    squad: 'Squad',
    unit: 'Unit',

    // Developer compare/detail
    developerComparison: 'Developer Comparison',
    developerA: 'Developer A',
    developerB: 'Developer B',
    selectDeveloper: 'Select a developer',
    keyTakeaways: 'Key takeaways from the comparison',
    roleSummary: 'Role and work style summary',
    hours: 'hours',

    // Ratings / common labelss
    ratingElite: 'Elite',
    ratingHigh: 'High',
    ratingMedium: 'Medium',
    ratingLow: 'Low',
    target: 'Target',
    goal: 'Goal',
    deployments: 'Deployments',
    metric: 'Metric',
    doraBenchTitle: 'DORA Performance Benchmarks',
    doraBenchSubtitle: 'How different performance levels compare',
  },
  pl: {
    clickForDetails: 'Kliknij, aby zobaczyć szczegóły',
    back: 'Powrót',
    backToTeam: 'Powrót do Zespołu',
    compare: 'Porównaj',
    commits: 'Commity',
    prs: 'PR-y',
    prsCreated: 'Utworzone PR-y',
    prsMerged: 'Zmergowane PR-y',
    reviews: 'Recenzje',
    avgCycleTime: 'Średni czas cyklu',
    projects: 'Projekty',
    linesPlusMinus: 'Linie ±',
    unknownDeveloper: 'Nieznany deweloper',
    unknownUser: 'Nieznany użytkownik',
    refreshing: 'Odświeżanie danych dla wybranego okresu…',

    // Pages and widgets (subset)
    overview: 'Przegląd',
    doraMetrics: 'Metryki DORA',
    team: 'Zespół',
    settings: 'Ustawienia',
    helpSupport: 'Pomoc i wsparcie',
    localBenchmark: 'Lokalny benchmark',
    noData: 'Brak danych',
    recentPRs: 'Ostatnie PR-y',

    // Common navigation and filters
    allTeams: 'Wszystkie zespoły',
    last7d: 'Ostatnie 7 dni',
    last2w: 'Ostatnie 2 tygodnie',
    last4w: 'Ostatnie 4 tygodnie',
    last3m: 'Ostatnie 3 miesiące',
    last6m: 'Ostatnie 6 miesięcy',

    // Dashboard
    engineeringPerformance: 'Wydajność inżynieryjna',
    prCycleTime: 'Czas cyklu PR',
    prThroughput: 'Przepustowość PR',
    deployFrequency: 'Częstotliwość wdrożeń',
    failRate: 'Wskaźnik awarii',
    hoursPerStage: 'Godziny na etap',
    prCycleBreakdown: 'Podział czasu cyklu PR',

    // Cycle Time Breakdown details
    cycleTimeBreakdown: 'Podział czasu cyklu',
    coding: 'Kodowanie',
    pickup: 'Podjęcie',
    review: 'Przegląd',
    merge: 'Scalenie',
    ofTotal: 'całości',
    vsPrevPeriod: 'względem poprzedniego okresu',
    was: 'było',
    vsLocal: 'wzgl. lokalnego',

    // DORA
    devopsSubtitle: 'DevOps Research & Assessment — wydajność dostarczania oprogramowania',
    leadTimeForChanges: 'Czas realizacji zmian',
    changeFailureRate: 'Wskaźnik nieudanych wdrożeń',
    meanTimeToRecovery: 'Średni czas przywrócenia (MTTR)',

    // Team hierarchy badges
    domain: 'Domena',
    tribe: 'Tribe',
    chapter: 'Rozdział',
    squad: 'Zespół',
    unit: 'Jednostka',

    // Developer compare/detail
    developerComparison: 'Porównanie deweloperów',
    developerA: 'Deweloper A',
    developerB: 'Deweloper B',
    selectDeveloper: 'Wybierz dewelopera',
    keyTakeaways: 'Najważniejsze wnioski z porównania',
    roleSummary: 'Podsumowanie roli i stylu pracy',
    hours: 'godziny',

    // Ratings / common labels
    ratingElite: 'Elitarni',
    ratingHigh: 'Wysoki',
    ratingMedium: 'Średni',
    ratingLow: 'Niski',
    target: 'Cel',
    goal: 'Cel',
    deployments: 'Wdrożenia',
    metric: 'Metryka',
    doraBenchTitle: 'Benchmarki wydajności DORA',
    doraBenchSubtitle: 'Porównanie poziomów wydajności',
  },
} as const;

export function useTr() {
  const { lang } = useLang();
  const d = lang === 'pl' ? (dict.pl as any) : (dict.en as any);
  const t = useMemo(() => (key: keyof typeof dict['en']): string => {
    return d[key] ?? String(key);
  }, [d]);
  return t;
}

// Helper for longer inline strings: pick Polish when available and lang==='pl'
export function usePick() {
  const { lang } = useLang();
  return (en: string, pl: string) => (lang === 'pl' ? pl : en);
}
