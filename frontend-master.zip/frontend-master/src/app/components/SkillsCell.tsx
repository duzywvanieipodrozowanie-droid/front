// Skills column for the Engineers tables: always shows the first two skills
// (each truncated on its own), the rest collapsed into a "+N" badge.
const VISIBLE = 2;

export function SkillsCell({ skills }: { skills?: string[] | null }) {
  const list = Array.isArray(skills) ? skills.filter(Boolean) : [];
  if (list.length === 0) {
    return <span className="text-[13px] text-gray-400">—</span>;
  }
  const visible = list.slice(0, VISIBLE);
  const hidden = list.slice(VISIBLE);
  return (
    <div className="flex flex-wrap items-center gap-1 max-w-[260px]" title={list.join(', ')}>
      {visible.map((skill) => (
        <span
          key={skill}
          className="inline-block max-w-[120px] truncate px-1.5 py-0.5 rounded-md border text-[11px] bg-gray-100 text-gray-700 border-gray-200"
          style={{ fontWeight: 600 }}
        >
          {skill}
        </span>
      ))}
      {hidden.length > 0 && (
        <span className="px-1.5 py-0.5 rounded-md text-[11px] text-gray-500" title={hidden.join(', ')}>
          +{hidden.length}
        </span>
      )}
    </div>
  );
}

export default SkillsCell;
