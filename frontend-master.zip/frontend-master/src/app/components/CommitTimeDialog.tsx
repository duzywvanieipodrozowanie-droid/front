import { useEffect, useMemo, useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import LoadingSpinner from './LoadingSpinner';
import { useLang, usePick } from '../i18n';

// "Commit time" heatmap from /api/metrics/gitlab/commit-heatmap: rows are weeks or months, columns are the days of
// the week split into time slots covering 24h; darker green = more commits. Clicking a cell lists who committed then.

type GroupBy = 'WEEK' | 'MONTH';
type Committer = { name: string; count: number };
type Cell = { period: string; day: number; slot: number; count: number; committers: Committer[] };
type Period = { key: string; from: string; till: string };
type Heatmap = {
  groupBy: GroupBy; slotHours: number; timeZone: string; maxCount: number; totalCommits: number;
  periods: Period[]; cells: Cell[];
};

const SLOT_OPTIONS = [1, 3, 6];
// Explicit hex colors: theme.css remaps Tailwind green/indigo classes to the brand palette.
const GREENS = ['#dcfce7', '#86efac', '#4ade80', '#16a34a', '#14532d'];
const EMPTY = '#f0fdf4';
const EMPTY_WEEKEND = '#f3f4f6';

const segBtn = (on: boolean) => `px-2.5 py-1 text-[12px] ${on
  ? 'bg-emerald-800 text-white'
  : 'bg-white text-gray-700 hover:bg-gray-50 dark:bg-white/5 dark:text-gray-300'}`;

function shade(count: number, max: number): string {
  if (count <= 0 || max <= 0) return EMPTY;
  const idx = Math.min(GREENS.length - 1, Math.floor((count / max) * GREENS.length - 1e-9));
  return GREENS[Math.max(0, idx)];
}

function pad(n: number): string {
  return String(n).padStart(2, '0');
}

export function CommitTimeDialog({ open, onOpenChange, unitId, teamName }: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  unitId?: string | null;
  teamName?: string;
}) {
  const pick = usePick();
  const { lang } = useLang();
  const [groupBy, setGroupBy] = useState<GroupBy>('WEEK');
  const [slotHours, setSlotHours] = useState(3);
  const [data, setData] = useState<Heatmap | null>(null);
  const [loading, setLoading] = useState(false);
  const [failed, setFailed] = useState(false);
  const [selected, setSelected] = useState<Cell | null>(null);

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    const controller = new AbortController();
    async function load() {
      setLoading(true);
      setFailed(false);
      setSelected(null);
      try {
        const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || 'Europe/Warsaw';
        const params = new URLSearchParams({
          interval: groupBy === 'WEEK' ? 'MONTHS_3' : 'MONTHS_12',
          groupBy,
          slotHours: String(slotHours),
          tz,
        });
        if (unitId) params.set('unitId', unitId);
        const res = await fetch(`/api/metrics/gitlab/commit-heatmap?${params.toString()}`, { credentials: 'include', signal: controller.signal });
        if (!res.ok) throw new Error(String(res.status));
        const js = (await res.json()) as Heatmap;
        if (!cancelled) setData(js);
      } catch {
        if (!cancelled) { setData(null); setFailed(true); }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; controller.abort(); };
  }, [open, groupBy, slotHours, unitId]);

  const locale = lang === 'pl' ? 'pl-PL' : 'en-GB';
  const days = lang === 'pl' ? ['Pon', 'Wt', 'Śr', 'Czw', 'Pt', 'Sob', 'Nd'] : ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const slots = data ? 24 / data.slotHours : 24 / slotHours;
  const byKey = useMemo(() => {
    const map = new Map<string, Cell>();
    (data?.cells ?? []).forEach((c) => map.set(`${c.period}|${c.day}|${c.slot}`, c));
    return map;
  }, [data]);

  function periodLabel(p: Period): string {
    const from = new Date(`${p.from}T00:00:00`);
    if (data?.groupBy === 'MONTH') return from.toLocaleDateString(locale, { month: 'short', year: 'numeric' });
    const last = new Date(`${p.till}T00:00:00`);
    last.setDate(last.getDate() - 1);
    return `${from.getDate()}.${pad(from.getMonth() + 1)}–${last.getDate()}.${pad(last.getMonth() + 1)}`;
  }

  function cellTitle(c: Cell, hours: number): string {
    const p = data?.periods.find((x) => x.key === c.period);
    const label = p ? periodLabel(p) : c.period;
    return `${label} · ${days[c.day - 1]} ${pad(c.slot * hours)}:00–${pad((c.slot + 1) * hours)}:00`;
  }

  const gridColumns = `110px repeat(${7 * slots}, minmax(${slots > 8 ? 4 : 10}px, 1fr))`;
  const lateCommits = selected && data && (selected.slot + 1) * data.slotHours > 21;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[1240px] max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex flex-wrap items-center gap-2 pr-8">
            <DialogTitle className="text-[18px]">{pick('Commit time', 'Czas commitów')}</DialogTitle>
            <div className="flex-1" />
            <div className="inline-flex border border-gray-300 dark:border-white/15 rounded-lg overflow-hidden">
              <button className={segBtn(groupBy === 'WEEK')} onClick={() => setGroupBy('WEEK')}>{pick('Weeks', 'Tygodnie')}</button>
              <button className={segBtn(groupBy === 'MONTH')} onClick={() => setGroupBy('MONTH')}>{pick('Months', 'Miesiące')}</button>
            </div>
            <div className="inline-flex border border-gray-300 dark:border-white/15 rounded-lg overflow-hidden">
              {SLOT_OPTIONS.map((h) => (
                <button key={h} className={segBtn(slotHours === h)} onClick={() => setSlotHours(h)}>{h} h</button>
              ))}
            </div>
          </div>
          <DialogDescription className="text-[12px]">
            {teamName && teamName !== 'All Teams' ? `${teamName} · ` : ''}
            {groupBy === 'WEEK' ? pick('last 3 months', 'ostatnie 3 miesiące') : pick('last 12 months', 'ostatnie 12 miesięcy')}
            {data ? ` · ${data.totalCommits} ${pick('commits', 'commitów')}` : ''}
            {' · '}{pick('hours in', 'godziny w strefie')} {data?.timeZone ?? Intl.DateTimeFormat().resolvedOptions().timeZone}
            {' · '}{pick('darker square = more commits', 'ciemniejszy kwadrat = więcej commitów')}
            {' · '}<span className="px-1 rounded bg-amber-100 text-amber-800" style={{ fontWeight: 600 }}>{pick('Sat / Sun', 'Sob / Nd')}</span> = {pick('weekend', 'weekend')}
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="min-h-[240px] flex items-center justify-center"><LoadingSpinner size={20} /></div>
        ) : failed || !data ? (
          <div className="min-h-[120px] flex items-center justify-center text-[13px] text-gray-500">
            {pick('Could not load commit times.', 'Nie udało się pobrać czasów commitów.')}
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-[1fr_250px] gap-4">
            <div className="overflow-x-auto">
              <div className="grid gap-[2px] items-center min-w-[640px]" style={{ gridTemplateColumns: gridColumns }}>
                <div />
                {days.map((d, i) => (
                  <div
                    key={d}
                    className={`text-[11px] text-center rounded py-0.5 ${i > 4 ? 'bg-amber-100 text-amber-800' : 'text-gray-700 dark:text-gray-300'}`}
                    style={{ gridColumn: `span ${slots}`, fontWeight: 700 }}
                  >{d}</div>
                ))}
                <div className="text-[9px] text-gray-400 text-right pr-2">{pick('hour', 'godz.')}</div>
                {days.flatMap((d) => Array.from({ length: slots }, (_, s) => {
                  const hour = s * data.slotHours;
                  const every = Math.max(1, Math.round(6 / data.slotHours));
                  return <div key={`${d}-${s}`} className="text-[9px] text-gray-400 overflow-visible whitespace-nowrap">{s % every === 0 ? pad(hour) : ''}</div>;
                }))}
                {data.periods.map((p) => [
                  <div key={`l-${p.key}`} className="text-[11px] text-gray-700 dark:text-gray-300 text-right pr-2 whitespace-nowrap">{periodLabel(p)}</div>,
                  ...days.flatMap((_, di) => Array.from({ length: slots }, (__, s) => {
                    const cell = byKey.get(`${p.key}|${di + 1}|${s}`);
                    const count = cell?.count ?? 0;
                    const weekend = di > 4;
                    const isSel = selected && cell && selected === cell;
                    return (
                      <button
                        key={`${p.key}-${di}-${s}`}
                        type="button"
                        disabled={!cell}
                        onClick={() => cell && setSelected(cell)}
                        title={cell ? `${cellTitle(cell, data.slotHours)}: ${count}` : undefined}
                        className={`h-5 rounded-[3px] ${cell ? 'cursor-pointer hover:ring-1 hover:ring-gray-500' : 'cursor-default'} ${isSel ? 'ring-2 ring-gray-900 dark:ring-white' : ''}`}
                        style={{
                          backgroundColor: count > 0 ? shade(count, data.maxCount) : (weekend ? EMPTY_WEEKEND : EMPTY),
                          outline: weekend ? '1px solid #fde68a' : undefined,
                        }}
                      />
                    );
                  })),
                ])}
              </div>
              <div className="flex flex-wrap items-center gap-1 text-[11px] text-gray-500 mt-3">
                {pick('fewer', 'mniej')}
                <i className="inline-block w-3.5 h-3.5 rounded-[3px] border border-gray-200" style={{ backgroundColor: EMPTY }} />
                {GREENS.map((c) => <i key={c} className="inline-block w-3.5 h-3.5 rounded-[3px]" style={{ backgroundColor: c }} />)}
                {pick('more', 'więcej')}
                <span className="ml-2">· {pick('max in one square', 'max w jednym kwadracie')}: {data.maxCount}</span>
                <span className="ml-2">· {pick('click a square to see who committed', 'klik w kwadrat → kto commitował w tym przedziale')}</span>
              </div>
            </div>

            <div className="border border-gray-200 dark:border-white/10 rounded-xl p-3 self-start">
              {selected ? (
                <>
                  <div className="text-[13px]" style={{ fontWeight: 700 }}>{cellTitle(selected, data.slotHours)}</div>
                  <div className="text-[11px] text-gray-500 mb-2">
                    {selected.count} {pick('commits', 'commitów')} · {selected.committers.length} {pick('people', 'os.')}
                  </div>
                  {selected.committers.map((c) => (
                    <div key={c.name} className="flex items-center gap-2 my-1.5 text-[12px]">
                      <span className="w-[100px] truncate" title={c.name}>{c.name}</span>
                      <div className="flex-1 h-2 rounded bg-gray-100 dark:bg-white/10 overflow-hidden">
                        <div className="h-full rounded" style={{ width: `${(c.count / selected.committers[0].count) * 100}%`, backgroundColor: '#16a34a' }} />
                      </div>
                      <span className="text-[11px] text-gray-500 w-6 text-right">{c.count}</span>
                    </div>
                  ))}
                  {lateCommits || selected.day > 5 ? (
                    <div className="text-[11px] text-amber-700 mt-2">
                      ⚠ {selected.day > 5 ? pick('Weekend commits', 'Commity w weekend') : pick('Commits after 21:00', 'Commity po 21:00')}
                      {' – '}{pick('possible overtime.', 'możliwe nadgodziny.')}
                    </div>
                  ) : null}
                </>
              ) : (
                <div className="text-[12px] text-gray-500">
                  {pick('Click a square to see who committed in that time slot.', 'Kliknij kwadrat, żeby zobaczyć, kto commitował w tym przedziale.')}
                </div>
              )}
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

export default CommitTimeDialog;
