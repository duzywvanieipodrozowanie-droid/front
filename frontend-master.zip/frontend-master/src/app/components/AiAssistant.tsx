import React, { useEffect, useRef, useState } from 'react';
import { Bot, Mic, MicOff, Send, Sunrise, Square, Volume2, X, Trash2 } from 'lucide-react';
import { useTeam } from '../context/TeamContext';
import { useDateRange } from '../context/DateRangeContext';
import { toInterval } from '../utils/dateRange';
import { useLang, usePick } from '../i18n';

// Chat with the LLM assistant in core (/api/ai/chat). The model reads the application data through tools on the
// backend, with the rights of the logged-in user; the selected unit and period are sent as the default context.

// label: what the chat shows instead of a long prepared question (content is what the model gets)
type ChatMsg = { role: 'user' | 'assistant'; content: string; label?: string; tools?: string[]; error?: boolean };


// Voice: questions by the browser speech recognition, answers read by speech synthesis - both only on the device.
// Nothing that would send the voice or the text to a cloud service is used: recognition runs only with the
// on-device mode (Chrome 139+), and only voices of the operating system (localService) read the answers.
// Minimal typing of the Web Speech API, not in the TypeScript DOM library.
type Recognition = {
  lang: string;
  processLocally?: boolean;
  mode?: string;
  interimResults: boolean;
  continuous: boolean;
  onresult: ((e: { results: ArrayLike<ArrayLike<{ transcript: string }> & { isFinal: boolean }> }) => void) | null;
  onerror: ((e: { error: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
};
type OnDeviceStatus = 'available' | 'downloadable' | 'downloading' | 'unavailable';
type RecognitionCtor = (new () => Recognition) & {
  available?: (options: { langs: string[]; processLocally: boolean }) => Promise<OnDeviceStatus>;
  install?: (options: { langs: string[]; processLocally: boolean }) => Promise<boolean>;
  // earlier drafts of the same API
  availableOnDevice?: (lang: string) => Promise<OnDeviceStatus>;
  installOnDevice?: (lang: string) => Promise<boolean>;
};
const SpeechRecognitionImpl: RecognitionCtor | undefined =
  typeof window !== 'undefined'
    ? ((window as unknown as { SpeechRecognition?: RecognitionCtor; webkitSpeechRecognition?: RecognitionCtor }).SpeechRecognition ??
      (window as unknown as { webkitSpeechRecognition?: RecognitionCtor }).webkitSpeechRecognition)
    : undefined;
const hasSynthesis = typeof window !== 'undefined' && 'speechSynthesis' in window;

async function onDeviceRecognition(lang: string): Promise<OnDeviceStatus> {
  try {
    if (SpeechRecognitionImpl?.available) return await SpeechRecognitionImpl.available({ langs: [lang], processLocally: true });
    if (SpeechRecognitionImpl?.availableOnDevice) return await SpeechRecognitionImpl.availableOnDevice(lang);
  } catch {
    // treated as unavailable
  }
  return 'unavailable';
}

async function installOnDeviceRecognition(lang: string): Promise<boolean> {
  try {
    if (SpeechRecognitionImpl?.install) return await SpeechRecognitionImpl.install({ langs: [lang], processLocally: true });
    if (SpeechRecognitionImpl?.installOnDevice) return await SpeechRecognitionImpl.installOnDevice(lang);
  } catch {
    // treated as not installed
  }
  return false;
}
// "status na początek dnia", "status dnia", "start of the day" ... said to the microphone
const BRIEFING_VOICE = /pocz[aą]t\w* dnia|status\w* dnia|start of (the )?day|daily (status|briefing)/i;

// Markdown and emoji out, so that the voice reads only the words
function speakable(text: string): string {
  return text
    .replace(/\*\*|__|`|#{1,4}\s+/g, '')
    .replace(/^\s*[-*•]\s+/gm, '')
    .replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/gu, '')
    .trim();
}

// Minimal markdown: **bold**, bullet and numbered lines, paragraphs
function renderInline(text: string): React.ReactNode[] {
  return text.split(/(\*\*[^*]+\*\*)/g).map((part, i) =>
    part.startsWith('**') && part.endsWith('**') ? <strong key={i}>{part.slice(2, -2)}</strong> : <React.Fragment key={i}>{part}</React.Fragment>
  );
}

function Markdown({ text }: { text: string }) {
  const lines = text.split('\n');
  return (
    <div className="space-y-1">
      {lines.map((raw, i) => {
        const line = raw.replace(/^#{1,4}\s+/, '');
        if (!line.trim()) return <div key={i} className="h-1" />;
        const bullet = line.match(/^\s*[-*•]\s+(.*)$/);
        if (bullet) return <div key={i} className="flex gap-1.5 pl-1"><span>•</span><span>{renderInline(bullet[1])}</span></div>;
        const numbered = line.match(/^\s*(\d+)[.)]\s+(.*)$/);
        if (numbered) return <div key={i} className="flex gap-1.5 pl-1"><span>{numbered[1]}.</span><span>{renderInline(numbered[2])}</span></div>;
        const heading = raw.match(/^#{1,4}\s+/);
        return <p key={i} className={heading ? 'font-semibold' : undefined}>{renderInline(line)}</p>;
      })}
    </div>
  );
}

export function AiAssistant({ raised = false }: { raised?: boolean }) {
  const { selectedUnitId, selectedTeamName } = useTeam();
  const { dateRange, label: dateRangeLabel } = useDateRange();
  const { lang } = useLang();
  const pick = usePick();
  const [enabled, setEnabled] = useState(false);
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMsg[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const listRef = useRef<HTMLDivElement>(null);
  const [listening, setListening] = useState(false);
  const [speaking, setSpeaking] = useState<number | null>(null);
  const [voiceError, setVoiceError] = useState<string | null>(null);
  const recognitionRef = useRef<Recognition | null>(null);
  const speechLang = lang === 'en' ? 'en-US' : 'pl-PL';
  // a voice of the operating system for the language; none = no reading aloud
  const [localVoice, setLocalVoice] = useState<SpeechSynthesisVoice | null>(null);
  const [recognitionStatus, setRecognitionStatus] = useState<OnDeviceStatus>('unavailable');
  const canSpeak = localVoice !== null;

  useEffect(() => {
    if (!hasSynthesis) return;
    const pickVoice = () =>
      setLocalVoice(window.speechSynthesis.getVoices().find((v) => v.localService && v.lang.replace('_', '-').toLowerCase().startsWith(speechLang.slice(0, 2))) ?? null);
    pickVoice();
    window.speechSynthesis.addEventListener('voiceschanged', pickVoice);
    return () => window.speechSynthesis.removeEventListener('voiceschanged', pickVoice);
  }, [speechLang]);

  useEffect(() => {
    let active = true;
    onDeviceRecognition(speechLang).then((status) => active && setRecognitionStatus(status));
    return () => {
      active = false;
    };
  }, [speechLang]);

  // the voice stops with the chat
  useEffect(() => {
    if (!open) {
      recognitionRef.current?.stop();
      if (hasSynthesis) window.speechSynthesis.cancel();
      setSpeaking(null);
    }
  }, [open]);

  useEffect(() => {
    fetch('/api/ai/status', { credentials: 'include' })
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => setEnabled(Boolean(data?.enabled)))
      .catch(() => setEnabled(false));
  }, []);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, loading]);

  if (!enabled) return null;

  // the core recognizes "start of the day" and loads all the unit's data for it
  const briefing = {
    label: pick('Start-of-day status', 'Status na początek dnia'),
    question: pick(
      'Give me the start-of-day status: overdue or at-risk Jira epics, work items stuck long in one status, open production defects, the quality of the team\'s work, a summary of what to improve and who I should talk to 1:1.',
      'Daj status na początek dnia: przeterminowane lub zagrożone epiki z Jiry, zadania długo stojące w jednym statusie, otwarte defekty produkcyjne, jakość pracy zespołu, podsumowanie co poprawić i z kim porozmawiać 1:1.'
    ),
  };

  const suggestions = [
    pick('What is wrong in this team?', 'Co jest nie tak w tym zespole?'),
    pick('How do we compare with other teams?', 'Jak wypadamy na tle innych zespołów?'),
    pick('Who carries the code review load?', 'Kto dźwiga code review w zespole?'),
    pick('How am I doing this month?', 'Jak mi idzie w tym miesiącu?'),
  ];

  function speak(text: string, index: number) {
    // only an operating system voice: a network voice would send the text out
    if (!localVoice) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(speakable(text));
    utterance.lang = localVoice.lang;
    utterance.voice = localVoice;
    utterance.onend = () => setSpeaking((current) => (current === index ? null : current));
    utterance.onerror = () => setSpeaking(null);
    setSpeaking(index);
    window.speechSynthesis.speak(utterance);
  }

  function stopSpeaking() {
    if (hasSynthesis) window.speechSynthesis.cancel();
    setSpeaking(null);
  }

  async function listen() {
    if (!SpeechRecognitionImpl || loading) return;
    if (listening) {
      recognitionRef.current?.stop();
      return;
    }
    stopSpeaking();
    setVoiceError(null);
    if (recognitionStatus !== 'available') {
      // the language model is downloaded to the device once; the voice itself never leaves it
      setRecognitionStatus('downloading');
      const installed = await installOnDeviceRecognition(speechLang);
      const status = installed ? await onDeviceRecognition(speechLang) : 'unavailable';
      setRecognitionStatus(status);
      if (status !== 'available') {
        setVoiceError(pick('The on-device speech model could not be installed - voice questions are off.', 'Nie udało się zainstalować lokalnego modelu mowy – pytania głosowe są wyłączone.'));
        return;
      }
    }
    const recognition = new SpeechRecognitionImpl();
    recognition.lang = speechLang;
    // on the device only: without it the browser sends the audio to its cloud service
    recognition.processLocally = true;
    recognition.mode = 'ondevice-only';
    recognition.interimResults = true;
    recognition.continuous = false;
    let transcript = '';
    recognition.onresult = (e) => {
      transcript = Array.from(e.results).map((r) => r[0].transcript).join(' ');
      setInput(transcript);
    };
    recognition.onerror = (e) => {
      setVoiceError(
        e.error === 'not-allowed' || e.error === 'service-not-allowed'
          ? pick('No access to the microphone - allow it in the browser.', 'Brak dostępu do mikrofonu – zezwól na niego w przeglądarce.')
          : e.error === 'network' || e.error === 'language-not-supported'
            ? pick('On-device speech recognition is not available for this language.', 'Lokalne rozpoznawanie mowy niedostępne dla tego języka.')
            : e.error === 'no-speech'
              ? pick('Nothing heard - try again.', 'Nic nie usłyszałem – spróbuj jeszcze raz.')
              : `${pick('Speech recognition error', 'Błąd rozpoznawania mowy')}: ${e.error}`
      );
    };
    recognition.onend = () => {
      setListening(false);
      recognitionRef.current = null;
      const said = transcript.trim();
      if (!said) return;
      // a voice question gets a voice answer
      if (BRIEFING_VOICE.test(said)) send(briefing.question, briefing.label, true);
      else send(said, undefined, true);
    };
    recognitionRef.current = recognition;
    setListening(true);
    recognition.start();
  }

  async function send(text: string, label?: string, readAloud = false) {
    const question = text.trim();
    if (!question || loading) return;
    const history: ChatMsg[] = [...messages.filter((m) => !m.error), { role: 'user', content: question }];
    setMessages([...messages, { role: 'user', content: question, label }]);
    setInput('');
    setLoading(true);
    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: history.map(({ role, content }) => ({ role, content })),
          unitId: selectedUnitId,
          interval: toInterval(dateRange),
          lang,
        }),
      });
      const data = await res.json().catch(() => null);
      // core errors come as { error: CODE, content: message }
      if (!res.ok) throw new Error(data?.message || (typeof data?.content === 'string' && data.content) || data?.error || `HTTP ${res.status}`);
      const answer = data?.answer || '…';
      setMessages((prev) => [...prev, { role: 'assistant', content: answer, tools: data?.toolsUsed }]);
      // the answer follows the question just added
      if (readAloud) speak(answer, messages.length + 1);
    } catch (e) {
      setMessages((prev) => [...prev, { role: 'assistant', error: true, content: pick('The assistant failed: ', 'Asystent nie odpowiedział: ') + (e instanceof Error ? e.message : String(e)) }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      {!open && (
        <button
          onClick={() => setOpen(true)}
          title={pick('AI assistant', 'Asystent AI')}
          className={`fixed right-4 ${raised ? 'bottom-20' : 'bottom-4'} z-40 flex items-center gap-2 rounded-full bg-indigo-600 px-4 py-3 text-[13px] font-medium text-white shadow-lg hover:bg-indigo-700 transition-colors`}
        >
          <Bot className="w-4 h-4" />
          <span className="hidden sm:inline">{pick('Ask AI', 'Zapytaj AI')}</span>
        </button>
      )}

      {open && (
        <div className={`fixed right-4 ${raised ? 'bottom-20' : 'bottom-4'} z-50 flex h-[min(640px,calc(100vh-6rem))] w-[min(420px,calc(100vw-2rem))] flex-col overflow-hidden rounded-xl border border-gray-200 bg-white shadow-2xl dark:border-white/10 dark:bg-[#2b2d31]`}>
          <div className="flex items-center justify-between gap-2 border-b border-gray-200 px-4 py-3 dark:border-white/10">
            <div className="flex items-center gap-2 min-w-0">
              <Bot className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
              <div className="min-w-0">
                <div className="text-[13px] font-semibold text-gray-900 dark:text-gray-100">{pick('AI assistant', 'Asystent AI')}</div>
                <div className="truncate text-[11px] text-gray-500 dark:text-gray-400">
                  {selectedUnitId ? selectedTeamName : pick('All teams', 'Wszystkie zespoły')} · {dateRangeLabel}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-1">
              {messages.length > 0 && (
                <button onClick={() => setMessages([])} title={pick('Clear', 'Wyczyść')} className="rounded-md p-1.5 text-gray-500 hover:bg-gray-100 dark:hover:bg-white/5">
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
              <button onClick={() => setOpen(false)} title={pick('Close', 'Zamknij')} className="rounded-md p-1.5 text-gray-500 hover:bg-gray-100 dark:hover:bg-white/5">
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div ref={listRef} className="flex-1 space-y-3 overflow-y-auto px-4 py-3 text-[13px] leading-relaxed">
            {messages.length === 0 && (
              <div className="space-y-3">
                <p className="text-gray-600 dark:text-gray-300">
                  {pick(
                    'Ask about your team, a developer or your own work. The assistant reads the application data you have access to.',
                    'Zapytaj o zespół, konkretnego developera albo swoją pracę. Asystent czyta dane aplikacji, do których masz dostęp.'
                  )}
                </p>
                <div className="flex flex-col gap-1.5">
                  <button
                    onClick={() => send(briefing.question, briefing.label)}
                    className="flex items-center gap-2 rounded-lg border border-indigo-200 bg-indigo-50 px-3 py-2 text-left font-medium text-indigo-700 hover:bg-indigo-100 dark:border-indigo-500/30 dark:bg-indigo-500/10 dark:text-indigo-300 dark:hover:bg-indigo-500/20"
                  >
                    <Sunrise className="w-4 h-4 shrink-0" />
                    {briefing.label}
                  </button>
                  {suggestions.map((s) => (
                    <button key={s} onClick={() => send(s)} className="rounded-lg border border-gray-200 px-3 py-2 text-left text-gray-700 hover:bg-gray-50 dark:border-white/10 dark:text-gray-200 dark:hover:bg-white/5">
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}
            {messages.map((m, i) => (
              <div key={i} className={m.role === 'user' ? 'flex justify-end' : 'flex justify-start'}>
                <div
                  className={`max-w-[90%] rounded-xl px-3 py-2 ${
                    m.role === 'user'
                      ? 'bg-indigo-600 text-white'
                      : m.error
                        ? 'bg-red-50 text-red-700 dark:bg-red-500/10 dark:text-red-300'
                        : 'bg-gray-100 text-gray-800 dark:bg-white/5 dark:text-gray-100'
                  }`}
                >
                  {m.role === 'assistant' && !m.error ? <Markdown text={m.content} /> : <span className="whitespace-pre-wrap">{m.label ?? m.content}</span>}
                  {m.role === 'assistant' && !m.error && (m.tools?.length || canSpeak) ? (
                    <div className="mt-1.5 flex items-center justify-between gap-2 text-[10px] text-gray-400">
                      <span>{m.tools && m.tools.length > 0 ? `${pick('Data', 'Dane')}: ${m.tools.join(', ')}` : ''}</span>
                      {canSpeak && (
                        <button
                          onClick={() => (speaking === i ? stopSpeaking() : speak(m.content, i))}
                          title={speaking === i ? pick('Stop reading', 'Zatrzymaj czytanie') : pick('Read aloud', 'Przeczytaj na głos')}
                          className="rounded p-1 text-gray-500 hover:bg-gray-200 dark:hover:bg-white/10"
                        >
                          {speaking === i ? <Square className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                        </button>
                      )}
                    </div>
                  ) : null}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-start">
                <div className="rounded-xl bg-gray-100 px-3 py-2 text-gray-500 dark:bg-white/5 dark:text-gray-400">
                  {pick('Analyzing data…', 'Analizuję dane…')}
                </div>
              </div>
            )}
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              send(input);
            }}
            className="flex flex-wrap items-end gap-2 border-t border-gray-200 px-3 py-3 dark:border-white/10"
          >
            {voiceError && <div className="w-full text-[11px] text-red-600 dark:text-red-400">{voiceError}</div>}
            {recognitionStatus !== 'unavailable' && (
              <button
                type="button"
                onClick={listen}
                disabled={loading || recognitionStatus === 'downloading'}
                title={listening ? pick('Stop listening', 'Zatrzymaj słuchanie') : pick('Ask by voice (e.g. "start-of-day status")', 'Zapytaj głosem (np. „status na początek dnia”)')}
                className={`rounded-lg p-2.5 disabled:opacity-40 ${listening ? 'animate-pulse bg-red-600 text-white' : 'border border-gray-200 text-gray-600 hover:bg-gray-50 dark:border-white/10 dark:text-gray-300 dark:hover:bg-white/5'}`}
              >
                {listening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </button>
            )}
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  send(input);
                }
              }}
              rows={1}
              placeholder={recognitionStatus === 'downloading' ? pick('Installing the on-device speech model…', 'Instaluję lokalny model mowy…') : listening ? pick('Listening…', 'Słucham…') : pick('Ask a question…', 'Zadaj pytanie…')}
              className="max-h-32 flex-1 resize-none rounded-lg border border-gray-200 bg-white px-3 py-2 text-[13px] text-gray-800 outline-none focus:border-indigo-400 dark:border-white/10 dark:bg-black/20 dark:text-gray-100"
            />
            <button
              type="submit"
              disabled={loading || !input.trim()}
              className="rounded-lg bg-indigo-600 p-2.5 text-white hover:bg-indigo-700 disabled:opacity-40"
              title={pick('Send', 'Wyślij')}
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </>
  );
}
