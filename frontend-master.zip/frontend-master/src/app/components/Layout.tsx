import { Outlet, NavLink, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  Activity,
  Briefcase,
  Users,
  PieChart,
  ChevronDown,
  Menu,
  HelpCircle,
  Settings as SettingsIcon,
  ChevronRight,
  Truck,
  KanbanSquare,
  Gauge,
  GitFork,
  MinusCircle,
  GitPullRequest,
  Rocket,
  CalendarClock,
  Sun,
  Moon,
  Network,
  History,
  LifeBuoy,
  Boxes,
  UserRound,
  PackageCheck,
  Workflow,
  Milestone,
  FlaskConical,
} from 'lucide-react';
import appLogo from '../../assets/onelooklogo.jpeg';
import { useEffect, useState, useMemo, useRef } from 'react';
import { DateRangeContext, DateRangeValue } from '../context/DateRangeContext';
import { TeamContext } from '../context/TeamContext';
import ConfiguratorOverlay from './ConfiguratorOverlay';
import { AiAssistant } from './AiAssistant';
import { DateRangePicker } from './DateRangePicker';
import { rangeLabel } from '../utils/dateRange';
import { LangProvider, useLang, useTr, usePick } from '../i18n';

// background refresh of the logged-in user (/api/user)
const USER_POLL_MS = 15_000;

// menu groups in their order: by the question the pages answer
const NAV_GROUPS = [
  { key: 'overview', en: 'Overview', pl: 'Przegląd' },
  { key: 'team-code', en: 'Team & code', pl: 'Zespół i kod' },
  { key: 'delivery', en: 'Delivery', pl: 'Dostarczanie' },
  { key: 'tests', en: 'Tests', pl: 'Testy' },
  { key: 'operations', en: 'Operations', pl: 'Utrzymanie' },
  { key: 'management', en: 'Management', pl: 'Zarządzanie' },
] as const;
type NavGroup = (typeof NAV_GROUPS)[number]['key'];

const navigation: Array<{ name: string; href: string; icon: typeof LayoutDashboard; end?: boolean; group: NavGroup }> = [
  { name: 'Overview', href: '/', icon: LayoutDashboard, end: true, group: 'overview' },
  { name: 'Product overview', href: '/product', icon: Briefcase, group: 'overview' },
  { name: 'DORA Metrics', href: '/dora', icon: Activity, group: 'overview' },
  { name: 'My Metrics', href: '/my-metrics', icon: UserRound, group: 'overview' },
  // { name: 'Working Agreements', href: '/working-agreements', icon: Handshake },
  // { name: 'Code Quality', href: '/code-quality', icon: Code2 },
  // { name: 'CI/CD', href: '/cicd', icon: Layers },
  { name: 'Team', href: '/team', icon: Users, group: 'team-code' },
  { name: 'GitLab Details', href: '/gitlab-details', icon: GitPullRequest, group: 'team-code' },
  { name: 'Code Impact', href: '/code-impact', icon: Network, group: 'team-code' },
  { name: 'Service Map', href: '/service-map', icon: Boxes, group: 'team-code' },
  { name: 'Architecture (C4)', href: '/architecture', icon: Workflow, group: 'team-code' },
  { name: 'Deliver', href: '/deliver', icon: Rocket, group: 'delivery' },
  { name: 'Task Timeline', href: '/task-timeline', icon: History, group: 'delivery' },
  { name: 'Release', href: '/release', icon: CalendarClock, group: 'delivery' },
  { name: 'Deployments', href: '/deployments', icon: PackageCheck, group: 'delivery' },
  { name: 'Release check', href: '/release-check', icon: FlaskConical, group: 'tests' },
  { name: 'Production support', href: '/production-support', icon: LifeBuoy, group: 'operations' },
  { name: 'Roadmap', href: '/roadmap', icon: Milestone, group: 'management' },
  { name: 'Investments', href: '/investments', icon: PieChart, group: 'management' },
  { name: 'Vendor Assessment', href: '/vendor-assessment', icon: Truck, group: 'management' },
  // { name: 'Benchmark', href: '/benchmark', icon: Target },
];
const NAV_COLLAPSED_KEY = 'nav.collapsedGroups';

// key of a menu page in Settings → Users and access (/api/access): "/" -> "overview", "/gitlab-details" -> "gitlab-details"
const pageKey = (href: string) => (href === '/' ? 'overview' : href.replace(/^\//, '').split('/')[0]);
const PAGE_KEYS = new Set(navigation.map((n) => pageKey(n.href)));

// Teams are now loaded dynamically from /api/organization
// Default to just "All Teams" until loaded

export function Layout() {
  const [showConfigurator, setShowConfigurator] = useState<boolean>(() => {
    try { return localStorage.getItem('configurator.show') === 'true'; } catch { return false; }
  });
  const t = useTr();
  const [appName, setAppName] = useState<string>('OneLook');
  const [dateRange, setDateRange] = useState<DateRangeValue>('Last 4 weeks');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  // The mobile drawer always shows full labels; collapsing applies to the desktop sidebar only.
  const navCollapsed = sidebarCollapsed && !sidebarOpen;
  const [selectedTeam, setSelectedTeam] = useState('All Teams');
  const [teamDropOpen, setTeamDropOpen] = useState(false);
  const [devDropOpen, setDevDropOpen] = useState(false);
  const [langDropOpen, setLangDropOpen] = useState(false);
  const [teams, setTeams] = useState<string[]>(['All Teams']);
  const [teamIdByName, setTeamIdByName] = useState<Record<string, string>>({});
  const [teamTypeByName, setTeamTypeByName] = useState<Record<string, string>>({});
  const [orgAcronym, setOrgAcronym] = useState<string>('AC');
  // Bump this to force organization reload when external pages modify org (e.g., manager added)
  const [orgVersion, setOrgVersion] = useState<number>(0);
  // Language selector (EN/PL)
  const [lang, setLang] = useState<'en' | 'pl'>(() => {
    try {
      const saved = localStorage.getItem('app.lang');
      if (saved === 'en' || saved === 'pl') return saved as 'en' | 'pl';
      const nav = (navigator?.language || navigator?.languages?.[0] || 'en').toLowerCase();
      return nav.startsWith('pl') ? 'pl' : 'en';
    } catch {
      return 'en';
    }
  });
  // Theme (light/dark) with persistence and <html class="dark">
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    try {
      const saved = localStorage.getItem('app.theme');
      if (saved === 'light' || saved === 'dark') return saved as 'light' | 'dark';
      const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
      return prefersDark ? 'dark' : 'light';
    } catch {
      return 'light';
    }
  });
  useEffect(() => {
    try {
      localStorage.setItem('app.theme', theme);
    } catch {}
    try {
      const root = document.documentElement;
      if (theme === 'dark') root.classList.add('dark');
      else root.classList.remove('dark');
    } catch {}
  }, [theme]);
  
  // Derive simple hierarchy meta from team names so user can distinguish parent vs child
  // Heuristic:
  // - If name contains " - ", treat the part before as parent
  // - Else, if it starts with another team's exact name followed by space, treat that other as parent
  const teamMeta = useMemo(() => {
    const list = teams;
    const hasTeam = (n: string) => list.includes(n);
    return list.map((name) => {
      if (name === 'All Teams') {
        return { name, base: name, isParent: false, isChild: false, parent: null as string | null, level: 0 };
      }
      const parts = name.split(' - ');
      const level = Math.max(0, parts.length - 1);
      const parentCandidate = level > 0 ? parts.slice(0, -1).join(' - ') : null;
      const parent = parentCandidate && hasTeam(parentCandidate) ? parentCandidate : null;
      const base = parts[parts.length - 1] || name;
      const isChild = !!parent;
      const isParent = list.some((t) => t !== name && t.startsWith(name + ' - '));
      return { name, base, isParent, isChild, parent, level };
    });
  }, [teams]);
  // Logged-in user data
  const [userName, setUserName] = useState<string | null>(null);
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [userInitials, setUserInitials] = useState<string>('');
  const [userId, setUserId] = useState<string | null>(null);
  // Authorization flags
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [isManager, setIsManager] = useState<boolean>(false);
  // Restrict access to certain menu items (Investments, Vendor Assessment)
  const [canSeeRestricted, setCanSeeRestricted] = useState<boolean>(false);
  // pages the user may open (Settings → Users and access); null = older core without /api/access, the fixed rules apply
  const [allowedPages, setAllowedPages] = useState<string[] | null>(null);
  // Compute fixed width for team selector to fit the longest team name
  const teamButtonWidth = useMemo(() => {
    const padding = 2.5 * 16; // px for left/right padding combined approximated (px)
    const iconAndChevron = 48; // px for Users icon + gap + chevron
    const base = 120; // minimal width
    const longest = teams.reduce((max, t) => Math.max(max, (t || '').length), 0);
    const avgChar = 7; // average character width in px for 12px font
    const computed = padding + iconAndChevron + longest * avgChar;
    const clamped = Math.max(base, Math.min(computed, 480));
    return `${Math.round(clamped)}px`;
  }, [teams]);
  const location = useLocation();
  // menu groups the user collapsed (kept in this browser)
  const [collapsedGroups, setCollapsedGroups] = useState<string[]>(() => {
    try { return JSON.parse(localStorage.getItem(NAV_COLLAPSED_KEY) || '[]'); } catch { return []; }
  });
  const toggleGroup = (key: string) => setCollapsedGroups((list) => {
    const next = list.includes(key) ? list.filter((it) => it !== key) : [...list, key];
    try { localStorage.setItem(NAV_COLLAPSED_KEY, JSON.stringify(next)); } catch { /* private mode */ }
    return next;
  });
  // opening a page expands its group once; the user may collapse it afterwards
  useEffect(() => {
    const active = navigation.find((item) => (item.end ? location.pathname === item.href : location.pathname.startsWith(item.href)));
    if (!active) return;
    setCollapsedGroups((list) => {
      if (!list.includes(active.group)) return list;
      const next = list.filter((it) => it !== active.group);
      try { localStorage.setItem(NAV_COLLAPSED_KEY, JSON.stringify(next)); } catch { /* private mode */ }
      return next;
    });
  }, [location.pathname]);
  const navigate = useNavigate();
  // Developer details context from route state (if present)
  const devState: any = (location.state as any) || {};
  const devEngineers: any[] | null = Array.isArray(devState.engineers) ? devState.engineers : null;
  const devMember: any = devState.member || null;
  const devInterval: string | undefined = typeof devState.interval === 'string' ? devState.interval : undefined;
  const isDevDetails = location.pathname.startsWith('/team/developer');
  const hasEngineers = isDevDetails && Array.isArray(devEngineers) && devEngineers.length > 0;

  // Load branding (name) from localStorage and listen for updates.
  // The logo is fixed (assets/onelooklogo.jpeg) and not configurable.
  useEffect(() => {
    try {
      const storedName = localStorage.getItem('app.brand.name');
      if (storedName && storedName.trim()) setAppName(storedName.trim());
      // Show configurator if flag is set (e.g., after Welcome login)
      if (localStorage.getItem('configurator.show') === 'true') setShowConfigurator(true);
    } catch (_e) {
      // ignore
    }

    const onStorage = (e: StorageEvent) => {
      if (!e.key) return;
      if (e.key === 'app.brand.name' && typeof e.newValue === 'string') {
        setAppName(e.newValue || '');
      }
      if (e.key === 'configurator.show') {
        setShowConfigurator(e.newValue === 'true');
      }
    };

    const onBrandUpdated = (e: Event) => {
      try {
        const detail = (e as CustomEvent).detail || {};
        if (typeof detail.name === 'string') setAppName(detail.name);
      } catch (_e) {
        // ignore
      }
    };

    const onConfiguratorChanged = () => {
      try { setShowConfigurator(localStorage.getItem('configurator.show') === 'true'); } catch {}
    };

    // Listen for external organization changes (e.g., adding manager/unit/member) to refresh teams
    const onOrganizationChanged = () => {
      setOrgVersion((v) => v + 1);
    };

    window.addEventListener('storage', onStorage);
    window.addEventListener('app.brand.updated', onBrandUpdated as EventListener);
    window.addEventListener('configurator.changed', onConfiguratorChanged);
    window.addEventListener('organization.changed', onOrganizationChanged);
    return () => {
      window.removeEventListener('storage', onStorage);
      window.removeEventListener('app.brand.updated', onBrandUpdated as EventListener);
      window.removeEventListener('configurator.changed', onConfiguratorChanged);
      window.removeEventListener('organization.changed', onOrganizationChanged);
    };
  }, []);

  useEffect(() => {
    let cancelled = false;

    // Proceed even if userId is unknown; we'll skip manager-based filtering in that case.
    // This ensures the team hierarchy is visible for all users.
    // (filterByManager(list, userId) returns the full list when userId is falsy)
    if (!userId) {
      // no-op: do not early-return; allow loading organization data below
    }

    async function fetchJson(url: string) {
      try {
        const res = await fetch(url, { credentials: 'include' });
        if (!res.ok) {
          console.warn('[Layout] /api/organization response not OK:', res.status);
          return null;
        }
        const ct = res.headers.get('content-type') || '';
        if (!ct.includes('application/json')) {
          const text = await res.text();
          console.warn('[Layout] /api/organization returned non-JSON content-type:', ct, 'Preview:', (text || '').slice(0, 160));
          return null;
        }
        return await res.json();
      } catch (_e) {
        console.warn('[Layout] Failed to fetch /api/organization:', _e);
        return null;
      }
    }

    function computeAcronymFromName(orgName?: string | null) {
      if (!orgName || typeof orgName !== 'string') return;
      const words = orgName.trim().split(/\s+|-/);
      let acronym = words
        .map((w) => w[0])
        .join('')
        .replace(/[^A-Za-zĄĆĘŁŃÓŚŹŻąćęłńóśźż]/g, '')
        .toUpperCase();
      if (!acronym || acronym.length > 5) {
        acronym = orgName.slice(0, 2).toUpperCase();
      }
      setOrgAcronym(acronym);
    }

    // Normalize strings: trim, lowercase, strip diacritics
    function normalize(s: any): string {
      const str = (typeof s === 'string' ? s : '').trim();
      return str
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .toLowerCase();
    }

    function isTeamType(t: any): boolean {
      const n = normalize(t);
      if (!n) return false;
      // Accept common synonyms: team, squad, zespół (zesp), tribe-team etc.
      return (
        n === 'team' ||
        n.includes('team') ||
        n.includes('squad') ||
        n.includes('zesp') // covers "zespół", "zespol"
      );
    }

    function getChildren(node: any): any[] {
      if (!node || typeof node !== 'object') return [];
      const candidates = [node.units, (node as any).children, (node as any).teams];
      for (const c of candidates) {
        if (Array.isArray(c)) return c as any[];
      }
      return [];
    }

    function readManagerIds(obj: any): string[] {
      try {
        const raw = (obj && (obj.managers ?? obj.managerIds ?? obj.manager_ids)) as any;
        const arr = Array.isArray(raw) ? raw : [];
        return arr.map((v) => String(v)).filter(Boolean);
      } catch {
        return [];
      }
    }

    // Filtracja po menedżerze (opis PL):
    // - Jeśli znamy userId zalogowanego użytkownika oraz elementy mają pole managers (tablica id menedżerów),
    //   to ograniczamy listę zespołów tylko do tych przypisanych do danego menedżera.
    // - Jeżeli userId nie jest znane lub API nie zwraca managers, NIE filtrujemy niczego.
    // - Jeżeli po filtracji wynik byłby pusty (częsty przypadek, gdy backend nie uzupełnia managers),
    //   wracamy do pełnej listy, aby użytkownik wciąż mógł wybrać dowolny zespół.
    function filterByManager<T extends { name: string; id?: string; managers?: string[] }>(list: T[], _userId?: string | null): T[] {
      // Per latest requirement: do not filter the teams dropdown — display exactly as provided by the API
      return list;
    }

    // [PL] Pobieranie i prezentacja danych dla selektora Zespołów (Team)
    // - Skąd pobieramy: najpierw próbujemy /api/admin/organization (nowe API) – zwraca jedno drzewo organizacji z tablicą units[].
    //   Jeśli to się nie powiedzie, stosujemy /api/organization (starsze API), które może zwrócić drzewo lub płaską listę.
    // - Jak budujemy listę: z drzewa wyciągamy jednostki, które mają typ zespołu (team/squad/zespół) i generujemy nazwy hierarchiczne
    //   wykorzystując separator " - " (np. Tribe - Chapter - Squad). Dodajemy też pozycję "All Teams" na górze listy.
    // - Filtracja: jeśli dostępne są przypisania managerów, lista może zostać ograniczona do jednostek zarządzanych przez
    //   zalogowanego użytkownika. Gdy przypisań brak lub nic nie pasuje – pokazujemy pełną listę (brak filtracji).
    // - Selekcja: wybrany zespół jest przechowywany w TeamContext (selectedTeamName oraz selectedUnitId) i wpływa na widoki stron
    //   (np. Dashboard, Team, Dora), które filtrują własne dane po selectedUnitId; wybór "All Teams" oznacza brak filtrowania.
    /*
     * [Teams selector — źródło danych i filtracja]
     *
     * Jak pobieramy listę zespołów (teams):
     * 1) Najpierw próbujemy /api/admin/organization (nowy endpoint) — zwraca pojedyncze drzewo organizacyjne z units[].
     *    - Spłaszczamy drzewo do listy nazw w formacie „A - B - Squad”.
     *    - Budujemy mapy: teamIdByName (name -> unitId) oraz teamTypeByName (name -> typ jednostki: TRIBE/CHAPTER/SQUAD).
     * 2) Jeśli się nie uda, używamy /api/organization (legacy) — dopuszczamy zarówno drzewo jak i tablicę elementów.
     *    - Dla drzewa: również spłaszczamy i wypełniamy mapy.
     *    - Dla tablicy: bierzemy elementy z type „team/squad/zespół/projekt”, deduplikujemy po etykiecie, wypełniamy mapy.
     *
     * Jak prezentujemy listę w selektorze (dropdown):
     * - Zawsze dodajemy pierwszy element „All Teams”.
     * - Dla nazw hierarchicznych pokazujemy strukturę (ikony + wcięcia) i etykietę bazową (ostatni segment nazwy) w przycisku.
     * - Gdy użytkownik wybierze zespół, zapisujemy jego pełną nazwę (np. „A - B - Squad”) jako selectedTeamName.
     * - Równolegle ustawiamy selectedUnitId na unitId z teamIdByName (albo null dla „All Teams”).
     *
     * Czy robimy filtrację czy ładujemy całość?:
     * - Ładujemy pełną listę zespołów z organizacji (całość). Dodatkowo, JEŚLI /api zwraca powiązania managerów (managers/managerIds),
     *   próbujemy przefiltrować listę do jednostek, które mają aktualnego użytkownika jako managera.
     *   Jeśli po filtracji lista byłaby pusta (częsty przypadek przy braku danych managers), wracamy do pełnej listy (bez filtracji).
     *
     * Jak filtrujemy dane na stronach:
     * - Strony/panele (Team, Dashboard, DORA, Investments itp.) odczytują selectedTeamName/selectedUnitId z TeamContext.
     * - Jeśli wybrano „All Teams” => komponenty pokazują metryki dla wszystkich zespołów (bez zawężania zapytań do unitId).
     * - Jeśli wybrano konkretny zespół => komponenty ograniczają widok/zapytania do tej jednostki (np. dodając team lub unitId do parametrów).
     */
    // Ładowanie i prezentacja listy zespołów (PL):
    // - Skąd pobieramy dane:
    //   1) Preferowane: /api/admin/organization — pojedyncze drzewo organizacji (root z units[]),
    //      zawiera id jednostek, typ (np. SQUAD/CHAPTER/TRIBE) i opcjonalnie managers[].
    //   2) Fallback:    /api/organization       — starszy format; może zwrócić drzewo lub płaską tablicę.
    // - Jak przetwarzamy:
    //   • Przechodzimy po drzewie/elementach i budujemy pełną ścieżkę nazw używając separatora " - "
    //     (np. "Domain - Chapter - Squad"), mapując przy tym nazwy → unitId oraz nazwy → typ.
    //   • Wartości type normalizujemy do: TRIBE, CHAPTER, SQUAD (gdy wykryte słowa kluczowe).
    // - Filtracja:
    //   • Jeżeli znamy userId i elementy posiadają managers[], filtrujemy tylko do zespołów przypisanych
    //     danemu menedżerowi. Jeżeli filtr nic nie zwróci, pokazujemy pełną listę (fallback).
    //   • Gdy userId nie jest znane lub managers brak — nie filtrujemy (pokazujemy pełną listę).
    // - Prezentacja w UI:
    //   • Zawsze dodajemy "All Teams" na początek; wybór tej pozycji oznacza brak filtra po unitId.
    //   • W selektorze prezentujemy hierarchię z wcięciami i ikonami w zależności od typu jednostki.
    // - Efekt wyboru:
    //   • selectedTeamName trafia do TeamContext; komponenty (np. /team) przekładają wybór na
    //     parametry zapytań (unitId lub team=name) przy pobieraniu metryk.
    async function loadOrg() {
      try {
        // 1) Try new admin endpoint that returns a single organization tree with units[]
        const adminData = await fetchJson('/api/admin/organization');
        if (adminData && typeof adminData === 'object' && !Array.isArray(adminData)) {
          const root = adminData as any;
          if (root.name) computeAcronymFromName(String(root.name));

          type Flat = { name: string; id?: string; managers?: string[]; type?: string };
          const flat: Flat[] = [];

          function normalizeUnitType(t?: any): string {
            const s = String(t || '').toLowerCase();
            if (!s) return '';
            if (s.includes('tribe')) return 'TRIBE';
            if (s.includes('squad') || s.includes('team') || s.includes('zesp') || s.includes('project')) return 'SQUAD';
            if (s.includes('unit') || s.includes('chapter')) return 'CHAPTER';
            return '';
          }

          const typeByName: Record<string, string> = {};

          function walk(node: any, path: string[]) {
            if (!node || typeof node !== 'object') return;
            const units = Array.isArray(node.units) ? node.units : [];
            for (const u of units) {
              const nm = typeof u?.name === 'string' ? u.name.trim() : '';
              if (!nm) continue;
              const full = [...path, nm].join(' - ');
              const typeNorm = normalizeUnitType(u?.type);
              if (typeNorm) typeByName[full] = typeNorm;
              flat.push({ name: full, id: u?.id != null ? String(u.id) : undefined, managers: readManagerIds(u), type: typeNorm });
              // recurse into nested units
              walk(u, [...path, nm]);
            }
          }

          walk(root, [typeof root.name === 'string' ? String(root.name).trim() : '']);

          const filtered = filterByManager(flat, userId);
          const names = Array.from(new Set(filtered.map(f => f.name))).filter(Boolean);
          const map: Record<string, string> = {};
          const typeMap: Record<string, string> = {};
          filtered.forEach(f => { if (f.id) map[f.name] = f.id; if (f.type) typeMap[f.name] = f.type; });

          if (names.length > 0) {
            const nextTeams = ['All Teams', ...names];
            setTeams(nextTeams);
            setTeamIdByName(map);
            setTeamTypeByName(typeMap);
            if (!nextTeams.includes(selectedTeam)) setSelectedTeam('All Teams');
            return;
          } else {
            // Admin org available but no teams match manager filter -> show only All Teams and do not fallback to legacy
            const nextTeams = ['All Teams'];
            setTeams(nextTeams);
            setTeamIdByName({});
            setTeamTypeByName({});
            if (!nextTeams.includes(selectedTeam)) setSelectedTeam('All Teams');
            return;
          }
        }

        // 2) Fallback to organization endpoint which can be an object tree or an array
        // Try both '/api/organization' and '/organization' for compatibility
        let orgData: any = null;
        try { orgData = await fetchJson('/api/organization'); } catch {}
        if (!orgData) {
          try { orgData = await fetchJson('/organization'); } catch {}
        }
        // Fetch organization once and derive teams from it only (no peoples filtering)

        // If orgData is a tree-like object
        if (orgData && typeof orgData === 'object' && !Array.isArray(orgData)) {
          const tree = orgData as any;
          if (tree.name) {
            computeAcronymFromName(String(tree.name));
          }

          // Derive all team names + map to ids by walking the tree
          type Col = { name: string; id?: string; managers?: string[]; type?: string };
          const collected: Col[] = [];
          const map: Record<string, string> = {};
          const typeMap: Record<string, string> = {};
          function normType(t?: any): string {
            const s = String(t || '').toUpperCase();
            if (s.includes('TRIBE')) return 'TRIBE';
            if (s.includes('SQUAD') || s.includes('TEAM') || s.includes('ZESP') || s.includes('PROJECT')) return 'SQUAD';
            if (s.includes('UNIT') || s.includes('CHAPTER')) return 'CHAPTER';
            return '';
          }
          function collectTeams(node: any, path: string[] = []) {
            if (!node || typeof node !== 'object') return;
            const nm = typeof node.name === 'string' ? node.name.trim() : '';
            const currentPath = nm ? [...path, nm] : [...path];
            if (nm) {
              const full = currentPath.join(' - ');
              const type = normType((node as any).type);
              const entry: Col = { name: full, id: node.id != null ? String(node.id) : undefined, managers: readManagerIds(node), type };
              collected.push(entry);
              if (entry.id) map[full] = entry.id;
              if (type) typeMap[full] = type;
            }
            const kids = getChildren(node);
            kids.forEach((k) => collectTeams(k, currentPath));
          }
          collectTeams(tree, []);
          const filtered = filterByManager(collected, userId);
          const uniqueTeams = Array.from(new Set(filtered.map(f => f.name))).filter(Boolean);
          const nextTeams = ['All Teams', ...uniqueTeams];
          setTeams(nextTeams);
          setTeamIdByName(map);
          setTeamTypeByName(typeMap);
          if (!nextTeams.includes(selectedTeam)) setSelectedTeam('All Teams');
          return;
        }

        // If orgData is an array (can be flat, or array of roots each with units[])
        if (Array.isArray(orgData)) {
          const data = orgData as any[];

          // Common helpers
          function normalizeType(t?: string) {
            const n = (t || '').toLowerCase();
            if (n.includes('tribe') || n.includes('domain')) return 'TRIBE';
            if (n.includes('squad') || n.includes('team') || n.includes('zesp') || n.includes('project')) return 'SQUAD';
            if (n.includes('unit') || n.includes('chapter')) return 'CHAPTER';
            return '';
          }
          type Col = { name: string; id?: string; managers?: string[]; type?: string };
          const flat: Col[] = [];
          const map: Record<string, string> = {};
          const typeMap: Record<string, string> = {};

          const anyHasUnits = data.some((x: any) => Array.isArray(x?.units));

          if (anyHasUnits) {
            // Walk each root item and its nested units, in the given order, without filtering
            function walk(node: any, path: string[]) {
              if (!node || typeof node !== 'object') return;
              const nm = typeof node.name === 'string' ? node.name.trim() : '';
              const currentPath = nm ? [...path, nm] : [...path];
              if (nm) {
                const full = currentPath.join(' - ');
                const id = node?.id != null ? String(node.id) : undefined;
                const type = normalizeType(node?.type);
                const entry: Col = { name: full, id, managers: readManagerIds(node), type };
                flat.push(entry);
                if (id) map[full] = id;
                if (type) typeMap[full] = type;
              }
              const kids = Array.isArray(node.units) ? node.units : [];
              for (const k of kids) walk(k, currentPath);
            }
            for (const root of data) walk(root, []);
          } else {
            // Legacy flat array: attempt to rebuild hierarchy using parentId/linkedTo if present; otherwise keep given order
            type Raw = { id?: string | number; name?: string; parentId?: any; linkedTo?: any; type?: string; managers?: any };
            const items: Raw[] = data.map((x: any) => x || {});

            const byId: Record<string, Raw> = {};
            const childrenOf: Record<string, Raw[]> = {};
            for (const it of items) {
              const id = it?.id != null ? String(it.id) : undefined;
              if (id) byId[id] = it;
            }
            for (const it of items) {
              const pid = (it as any).parentId ?? (it as any).linkedTo;
              const parentId = pid != null ? String(pid) : undefined;
              if (parentId && byId[parentId]) {
                (childrenOf[parentId] ||= []).push(it);
              }
            }

            const hasGraph = Object.keys(childrenOf).length > 0;
            if (hasGraph) {
              const roots = items.filter((it) => {
                const id = it?.id != null ? String(it.id) : undefined;
                const pid = (it as any).parentId ?? (it as any).linkedTo;
                return id && (!pid || !byId[String(pid)]);
              });
              function walkFlat(node: Raw, path: string[]) {
                const nm = typeof node?.name === 'string' ? node.name.trim() : '';
                const currentPath = nm ? [...path, nm] : [...path];
                if (nm) {
                  const full = currentPath.join(' - ');
                  const id = node?.id != null ? String(node.id) : undefined;
                  const type = normalizeType((node as any).type || '');
                  const entry: Col = { name: full, id, managers: readManagerIds(node), type };
                  flat.push(entry);
                  if (id) map[full] = id;
                  if (type) typeMap[full] = type;
                }
                const id = node?.id != null ? String(node.id) : undefined;
                const kids = id ? (childrenOf[id] || []) : [];
                for (const k of kids) walkFlat(k, currentPath);
              }
              for (const r of roots) walkFlat(r, []);
            } else {
              // No relations: keep incoming order, just label by normalized type for badges
              for (const it of items) {
                const nm = String(it.name || '').trim();
                if (!nm) continue;
                const type = normalizeType(it.type || '');
                const id = it?.id != null ? String(it.id) : undefined;
                const label = nm;
                flat.push({ name: label, id, managers: readManagerIds(it), type });
                if (id) map[label] = id;
                if (type) typeMap[label] = type;
              }
            }
          }

          const filtered = filterByManager(flat, userId);
          const names = filtered.map(f => f.name).filter(Boolean);
          const nextTeams = ['All Teams', ...names];
          setTeams(nextTeams);
          setTeamIdByName(map);
          setTeamTypeByName(typeMap);
          if (!nextTeams.includes(selectedTeam)) setSelectedTeam('All Teams');
          return;
        }

        // If nothing usable, keep defaults
      } catch (_e) {
        // Silently ignore; keep defaults
      }
    }

    loadOrg();
    return () => {
      cancelled = true;
    };
  }, [userId, orgVersion]);

  // Derived in the same render as selectedTeam. Syncing it in an effect lagged one render behind, so pages
  // fired requests with the new team name but a stale/null unitId (null = metrics over ALL managed units).
  const selectedUnitId = useMemo<string | null>(() => {
    if (selectedTeam === 'All Teams') return null;
    const id = teamIdByName[selectedTeam];
    return id ? String(id) : null;
  }, [selectedTeam, teamIdByName]);

  // Load current logged-in user (name, email)
  useEffect(() => {
    let cancelled = false;

    function deriveInitials(name?: string | null, email?: string | null) {
      const safe = (s: any) => (typeof s === 'string' ? s : '');
      const n = safe(name).trim();
      if (n) {
        const parts = n.split(/\s+/).filter(Boolean);
        const first = parts[0]?.[0] || '';
        const last = parts.length > 1 ? parts[parts.length - 1]?.[0] : '';
        const res = `${first}${last}`.toUpperCase();
        if (res) return res;
      }
      const em = safe(email).trim();
      if (em) {
        const local = em.split('@')[0] || '';
        const first = local[0] || '';
        const last = local.length > 1 ? local[local.length - 1] : '';
        const res = `${first}${last}`.toUpperCase();
        if (res) return res;
      }
      return 'UU';
    }

    async function fetchJson(url: string) {
      try {
        const res = await fetch(url, { credentials: 'include' });
        if (!res.ok) return null;
        const data = await res.json();
        return data;
      } catch (_e) {
        return null;
      }
    }

    async function loadUser(polling = false) {
      // Fetch user strictly from /api/users as requested
      const [data, access]: any[] = await Promise.all([fetchJson('/api/user'), fetchJson('/api/access')]);
      if (!cancelled && access && Array.isArray(access.pages)) setAllowedPages(access.pages);

      if (cancelled) return;
      // a failed background poll keeps the user loaded before (a network blip must not log them out of the UI)
      if (polling && (!data || typeof data !== 'object')) return;
      if (!data || typeof data !== 'object') {
        // Leave defaults; do not crash
        setUserName(null);
        setUserEmail(null);
        setUserInitials('UU');
        setUserId(null);
        return;
      }

      // Try to map various shapes
      const email =
        data.email ||
        data.mail ||
        data.userEmail ||
        (typeof data.preferred_username === 'string' && data.preferred_username.includes('@')
          ? data.preferred_username
          : undefined) ||
        null;

      const name =
        // Prefer givenName from /api/user as requested
        data.givenName ||
        data.name ||
        data.fullName ||
        (data.given_name && data.family_name
          ? `${data.given_name} ${data.family_name}`
          : undefined) ||
        data.username ||
        data.preferred_username ||
        null;

      const id =
        (data.id != null ? String(data.id) : null) ||
        (data.userId != null ? String(data.userId) : null) ||
        (data.uid != null ? String(data.uid) : null) ||
        null;

      const initials = deriveInitials(name, email);

      setUserName(typeof name === 'string' ? name : null);
      setUserEmail(typeof email === 'string' ? email : null);
      setUserInitials(initials);
      setUserId(id);
      // Set authorization flags
      try {
        const auths = Array.isArray((data as any).authorities) ? (data as any).authorities : [];
        const norm = (s: any) => String(s || '').toUpperCase();
        const hasAdmin = auths.map(norm).includes('ADMIN');
        setIsAdmin(hasAdmin);
        // Manager can come from authorities or grants (e.g., grants.onelook === 'manager')
        const byAuth = auths.map(norm).includes('MANAGER') || auths.map(norm).includes('ROLE_MANAGER');
        const grants = (data as any).grants || {};
        const grantValues = Object.values(grants || {}).map((v: any) => String(v || '').toLowerCase());
        const byGrant = grantValues.includes('manager');
        setIsManager(!!(byAuth || byGrant));
        // Menu visibility for restricted items is based solely on ADMIN authority per requirement
        setCanSeeRestricted(!!hasAdmin);
      } catch (_e) {
        setIsAdmin(false);
        setIsManager(false);
        setCanSeeRestricted(false);
      }
    }

    loadUser();
    // ask /api/user every 15 s in the background (keeps the session alive, picks up changed roles)
    const poll = window.setInterval(() => loadUser(true), USER_POLL_MS);
    return () => {
      cancelled = true;
      window.clearInterval(poll);
    };
  }, []);

  const currentPage = navigation.find((n) =>
    n.end ? location.pathname === n.href : location.pathname.startsWith(n.href)
  );
  // a menu page the user's role does not allow (Settings → Users and access), also when opened by its URL
  const currentKey = pageKey(location.pathname);
  const currentPageBlocked = !!allowedPages && PAGE_KEYS.has(currentKey) && !allowedPages.includes(currentKey);
  const pick = (en: string, pl: string) => (lang === 'pl' ? pl : en);
  const currentPageName = location.pathname.startsWith('/help')
    ? t('helpSupport')
    : location.pathname.startsWith('/settings')
    ? t('settings')
    : currentPage?.name === 'Overview'
    ? t('overview')
    : currentPage?.name === 'DORA Metrics'
    ? t('doraMetrics')
    : currentPage?.name === 'Investments'
    ? t('investments')
    : currentPage?.name === 'Team'
    ? t('team')
    : currentPage?.name === 'GitLab Details'
    ? 'GitLab Details'
    : (currentPage?.name ?? t('overview'));

  // Keep browser tab title in sync with app name and current page
  useEffect(() => {
    try {
      const name = appName || 'OneLook';
      document.title = `${name} — ${currentPageName}`;
    } catch (_e) {
      // ignore
    }
  }, [appName, currentPageName]);

  // Persist language and set <html lang="…">
  useEffect(() => {
    try {
      localStorage.setItem('app.lang', lang);
    } catch {}
    try {
      if (typeof document !== 'undefined') {
        document.documentElement.lang = lang;
      }
    } catch {}
  }, [lang]);

  // Close FAB when route changes or sidebar opens
  // Close the mobile drawer on navigation and when the viewport grows to the desktop layout
  useEffect(() => { setSidebarOpen(false); }, [location.pathname]);
  useEffect(() => {
    const mq = window.matchMedia('(min-width: 1024px)');
    const onChange = () => { if (mq.matches) setSidebarOpen(false); };
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);

  return (
    <LangProvider lang={lang} setLang={setLang}>
    <TeamContext.Provider
      value={{
        selectedTeamName: selectedTeam,
        selectedUnitId,
        teams,
        setSelectedTeamName: setSelectedTeam,
      }}
    >
      <DateRangeContext.Provider value={{ dateRange, setDateRange, label: rangeLabel(dateRange, lang) }}>
        <div className="flex min-h-screen overflow-x-clip bg-[#f6f8fa] dark:bg-black text-gray-900 dark:text-white" style={{ fontFamily: 'Inter, sans-serif' }}>
          {/* Mobile overlay */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 z-40 bg-black/50 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Sidebar */}
        <aside
        id="app-sidebar"
        onClick={(e) => {
          const t = e.target as HTMLElement;
          if (!sidebarOpen && !t.closest('a,button,input,select,textarea,[role=\"button\"]')) {
            setSidebarCollapsed((v) => !v);
          }
        }}
        className={`fixed inset-y-0 left-0 z-50 flex flex-col w-[260px] max-w-[85vw] bg-[#004627] text-white dark:bg-[#0b0d10] dark:text-gray-200 transition-all duration-300
          ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}
          lg:sticky lg:top-0 lg:h-screen lg:max-w-none lg:translate-x-0 ${navCollapsed ? 'lg:w-[72px]' : 'lg:w-[220px]'}
        `}
      >
        {/* Logo + collapse toggle */}
        <div className="flex items-center gap-2 px-3 py-3 border-b border-white/[0.06]">
          <div className="flex items-center gap-2">
            <div className={`flex items-center justify-center ${navCollapsed ? 'w-[40px] h-[40px]' : 'w-[46px] h-[46px]'} rounded-lg bg-transparent overflow-hidden`}>
              <img src={appLogo} alt="App logo" className="w-full h-full object-contain block" />
            </div>
            {!navCollapsed && (
              <span className="text-white text-[17px]" style={{ fontWeight: 700 }}>{appName || 'OneLook'}</span>
            )}
          </div>
        </div>


        {/* Navigation */}
        <nav className={`flex-1 ${navCollapsed ? 'px-1' : 'px-2'} py-3 overflow-y-auto`}>
          {NAV_GROUPS.map((group, groupIndex) => {
            // Visibility rules: the roles of the pages are set in Settings → Users and access (/api/access); without it
            // Deliver, Vendor Assessment, Code Impact and Task Timeline only for ADMIN (canSeeRestricted). My Metrics is for everyone.
            const items = navigation.filter((item) => {
              if (item.group !== group.key) return false;
              if (allowedPages) return allowedPages.includes(pageKey(item.href));
              const restricted = item.name === 'Deliver' || item.name === 'Vendor Assessment'
                || item.name === 'Code Impact' || item.name === 'Task Timeline' || item.name === 'Product overview' || item.name === 'Roadmap';
              return !restricted || canSeeRestricted;
            });
            if (items.length === 0) return null;
            const hasActive = items.some((item) => (item.end ? location.pathname === item.href : location.pathname.startsWith(item.href)));
            const open = navCollapsed || !collapsedGroups.includes(group.key);
            return (
              <div key={group.key} className={groupIndex > 0 ? 'pt-2' : ''}>
                {navCollapsed ? (
                  groupIndex > 0 && <div className="mx-2 mb-2 border-t border-white/10" />
                ) : (
                  <button
                    onClick={() => toggleGroup(group.key)}
                    className="w-full flex items-center justify-between px-4 pt-1 pb-1.5 text-[10.5px] uppercase tracking-wider text-white/50 hover:text-white/80"
                    style={{ fontWeight: 700 }}
                    aria-expanded={open}
                  >
                    <span className="flex items-center gap-1.5">
                      {lang === 'pl' ? group.pl : group.en}
                      {/* a collapsed group still shows that it holds the open page */}
                      {!open && hasActive && <span className="w-1.5 h-1.5 rounded-full bg-[#00C875]" />}
                    </span>
                    {open ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                  </button>
                )}
                {open && (
                  <div className="space-y-0.5">
                    {items.map((item) => (
                      <NavLink
                        key={item.name}
                        to={item.href}
                        end={item.end}
                        onClick={() => setSidebarOpen(false)}
                        className={({ isActive }) =>
                          `flex items-center gap-2.5 px-4 py-2 rounded-lg text-[13px] transition-colors group border ${
                            isActive
                              ? 'bg-[rgba(0,89,50,0.36)] text-white font-semibold border-[#00C875] shadow-[0_0_0_4px_rgba(0,200,117,0.18)] relative dark:bg-white/10 dark:text-white dark:border-white/20 dark:shadow-[0_0_0_4px_rgba(255,255,255,0.08)]'
                              : 'text-white/90 hover:bg-[rgba(0,89,50,0.28)] hover:text-white border-transparent dark:text-gray-200 dark:hover:bg-white/5'
                          }`
                        }
                      >
                        {({ isActive }) => (
                          <>
                            <item.icon
                              className={`w-5 h-5 flex-shrink-0 text-white`}
                            />
                            {!navCollapsed && (
                              <span>
                                {item.name === 'Overview' ? t('overview') :
                                 item.name === 'DORA Metrics' ? t('doraMetrics') :
                                 item.name === 'Investments' ? t('investments') :
                                 item.name === 'Team' ? t('team') : item.name}
                              </span>
                            )}
                            {!navCollapsed && isActive && (<div className="ml-auto w-1.5 h-1.5 rounded-full bg-[#00C875]"></div>)}
                          </>
                        )}
                      </NavLink>
                    ))}
                  </div>
                )}
              </div>
            );
          })}
        </nav>

        {/* Bottom section */}
        <div className="px-2 py-3 border-t border-white/[0.06] space-y-0.5">
          {/* Language + theme live in the top bar from sm up; on phones they move into the drawer */}
          {sidebarOpen && (
            <div className="md:hidden flex items-center gap-2 px-2 pb-2">
              <button
                onClick={() => setLang(lang === 'pl' ? 'en' : 'pl')}
                className="flex-1 flex items-center justify-center gap-1.5 px-2 py-2 rounded-lg border border-white/15 text-[12px] text-white/90 hover:bg-white/5"
                aria-label="Language selector"
              >
                <span className="text-base leading-none">{lang === 'pl' ? '🇵🇱' : '🇬🇧'}</span>
                <span className="uppercase tracking-wide" style={{ fontWeight: 600 }}>{lang}</span>
              </button>
              <button
                onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                className="flex-1 flex items-center justify-center gap-1.5 px-2 py-2 rounded-lg border border-white/15 text-[12px] text-white/90 hover:bg-white/5"
                aria-label="Toggle dark mode"
              >
                {theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
                <span className="uppercase tracking-wide" style={{ fontWeight: 600 }}>{theme === 'dark' ? 'Light' : 'Dark'}</span>
              </button>
            </div>
          )}
          {canSeeRestricted && (
            <NavLink
              to="/settings"
              onClick={() => setSidebarOpen(false)}
              className={({ isActive }) =>
                `w-full flex items-center gap-2.5 px-4 py-3 rounded-lg text-[13px] transition-colors border ${
                  isActive
                    ? 'bg-[rgba(0,89,50,0.36)] text-white font-semibold border-[#00C875] shadow-[0_0_0_4px_rgba(0,200,117,0.18)] relative dark:bg-white/10 dark:text-white dark:border-white/20 dark:shadow-[0_0_0_4px_rgba(255,255,255,0.08)]'
                    : 'text-white/90 hover:bg-[rgba(0,89,50,0.28)] hover:text-white border-transparent dark:text-gray-200 dark:hover:bg-white/5'
                }`
              }
            >
            {({ isActive }) => (
              <>
                <SettingsIcon className={`w-5 h-5 text-white`} />
                {!navCollapsed && <span>{t('settings')}</span>}
                {!navCollapsed && isActive && (<div className="ml-auto w-1.5 h-1.5 rounded-full bg-[#00C875]"></div>)}
              </>
            )}
          </NavLink>
          )}
          <NavLink
            to="/help"
            onClick={() => setSidebarOpen(false)}
            className={({ isActive }) =>
              `w-full flex items-center gap-2.5 px-4 py-3 rounded-lg text-[13px] transition-colors border ${
                isActive
                  ? 'bg-[rgba(0,89,50,0.36)] text-white font-semibold border-[#00C875] shadow-[0_0_0_4px_rgba(0,200,117,0.18)] relative'
                  : 'text-white/90 hover:bg-[rgba(0,89,50,0.28)] hover:text-white border-transparent'
              }`
            }
          >
            {({ isActive }) => (
              <>
                <HelpCircle className={`w-5 h-5 ${isActive ? 'text-indigo-400' : 'text-gray-500'}`} />
                {!navCollapsed && <span>{t('helpSupport')}</span>}
                {!navCollapsed && isActive && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-indigo-400" />}
              </>
            )}
          </NavLink>
        </div>

        {/* User */}
        <div className="px-3 py-3 border-t border-white/[0.06]">
          <div className={`flex items-center ${navCollapsed ? 'justify-center' : 'gap-2.5'}`}>
            <div className="w-7 h-7 rounded-full bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center text-[11px] text-white flex-shrink-0" style={{ fontWeight: 600 }}>
              {userInitials || 'UU'}
            </div>
            {!navCollapsed && (
              <div className="flex-1 min-w-0">
                <p className="text-[12px] text-gray-200 truncate">{userName || t('unknownDeveloper')}</p>
                <p className="text-[11px] text-gray-500 truncate">{userEmail || ''}</p>
              </div>
            )}
          </div>
        </div>

      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-visible">
        {/* Top bar */}
        <header className="sticky top-0 z-30 flex-shrink-0 flex items-center justify-between gap-2 h-12 px-3 sm:px-4 bg-white border-b border-gray-200 dark:bg-black dark:border-white/10">
          <div className="flex items-center gap-2 shrink-0">
            {/* Mobile open drawer */}
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-1.5 -ml-1 rounded-md hover:bg-gray-100 transition-colors dark:hover:bg-white/5"
              aria-label="Open menu"
            >
              <Menu className="w-4 h-4 text-gray-600" />
            </button>
            {/* Brand: logo + name linking to home */}
            {!sidebarOpen && (
              <NavLink to="/" className="flex items-center gap-2 group lg:hidden">
                <div className="w-6 h-6 rounded bg-transparent dark:bg-transparent overflow-hidden flex items-center justify-center">
                  <img src={appLogo} alt="App logo" className="w-full h-full object-contain" />
                </div>
                <span className="text-[13px] text-gray-900 dark:text-white group-hover:text-indigo-600" style={{ fontWeight: 700 }}>{appName || 'OneLook'}</span>
              </NavLink>
            )}
          </div>

          <div className="flex items-center justify-end gap-2 min-w-0">
            {/* Language selector */}
            <div className="relative hidden md:block shrink-0">
              <button
                onClick={() => setLangDropOpen((v) => !v)}
                className="flex items-center gap-1.5 px-2 py-1 rounded-md border border-gray-200 bg-white hover:bg-gray-50 text-[12px] text-gray-700 dark:bg-[#2b2d31] dark:border-white/10 dark:text-gray-200 dark:hover:bg-white/5"
                aria-label="Language selector"
              >
                <span className="text-base leading-none">
                  {lang === 'pl' ? '🇵🇱' : '🇬🇧'}
                </span>
                <span className="uppercase tracking-wide" style={{ fontWeight: 600 }}>{lang}</span>
                <ChevronDown className="w-3.5 h-3.5 text-gray-500" />
              </button>
              {langDropOpen && (
                <div className="absolute right-0 mt-1 z-50 bg-white rounded-xl border border-gray-200 shadow-lg overflow-hidden py-1 w-36 dark:bg-[#2b2d31] dark:border-white/10">
                  <button
                    onClick={() => { setLang('pl'); setLangDropOpen(false); }}
                    className={`w-full text-left px-3 py-2.5 text-[12px] transition-colors flex items-center gap-2 ${lang === 'pl' ? 'bg-indigo-50 text-indigo-900 dark:bg-indigo-500/10 dark:text-indigo-300' : 'hover:bg-gray-50 text-gray-700 dark:hover:bg-white/5 dark:text-gray-200'}`}
                  >
                    <span className="text-lg">🇵🇱</span>
                    <span>Polski</span>
                  </button>
                  <button
                    onClick={() => { setLang('en'); setLangDropOpen(false); }}
                    className={`w-full text-left px-3 py-2.5 text-[12px] transition-colors flex items-center gap-2 ${lang === 'en' ? 'bg-indigo-50 text-indigo-900 dark:bg-indigo-500/10 dark:text-indigo-300' : 'hover:bg-gray-50 text-gray-700 dark:hover:bg-white/5 dark:text-gray-200'}`}
                  >
                    <span className="text-lg">🇬🇧</span>
                    <span>English</span>
                  </button>
                </div>
              )}
            </div>

            {/* Theme toggle */}
            <button
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="hidden md:inline-flex shrink-0 items-center gap-1.5 px-2 py-1 rounded-md border border-gray-200 bg-white hover:bg-gray-50 text-[12px] text-gray-700 dark:bg-[#2b2d31] dark:border-white/10 dark:text-gray-200 dark:hover:bg-white/5"
              aria-label="Toggle dark mode"
              title={theme === 'dark' ? 'Light mode' : 'Dark mode'}
            >
              {theme === 'dark' ? (
                <Sun className="w-4 h-4 text-amber-400" />
              ) : (
                <Moon className="w-4 h-4 text-indigo-500" />
              )}
              <span className="uppercase tracking-wide" style={{ fontWeight: 600 }}>{theme === 'dark' ? 'Light' : 'Dark'}</span>
            </button>

            {/* Team selector moved to top bar */}
            <div className="relative hidden sm:block min-w-0">
              <button
                onClick={() => setTeamDropOpen(!teamDropOpen)}
                className="flex items-center gap-2 max-w-full md:max-w-[320px] xl:max-w-[480px] px-2.5 py-1.5 rounded-md border border-gray-200 bg-white hover:bg-gray-50 text-[12px] text-gray-700 transition-colors dark:bg-[#2b2d31] dark:border-white/10 dark:text-gray-200 dark:hover:bg-white/5"
                style={{ width: teamButtonWidth }}
                aria-label="Team selector"
              >
                <Users className="w-4 h-4 text-gray-500" />
                <span className="truncate flex-1 text-left">{(() => { const base = (teamMeta.find(x => x.name === selectedTeam)?.base) ?? selectedTeam; return base === 'All Teams' ? t('allTeams') : base; })()}</span>
                <ChevronDown className="w-3.5 h-3.5 text-gray-500" />
              </button>
              {teamDropOpen && (
                <div className="absolute right-0 mt-1 z-50 bg-white rounded-xl border border-gray-200 shadow-lg py-1 max-h-80 overflow-y-auto max-w-[calc(100vw-2rem)] dark:bg-[#2b2d31] dark:border-white/10" style={{ minWidth: teamButtonWidth }}>
                  {(() => {
                    const rendered = new Set<string>();

                    const byName: Record<string, typeof teamMeta[number]> = {} as any;
                    teamMeta.forEach((m) => { byName[m.name] = m as any; });

                    const childrenOf: Record<string, typeof teamMeta> = {} as any;
                    teamMeta.forEach((m) => {
                      if (!m.parent) return;
                      (childrenOf[m.parent] ||= []).push(m as any);
                    });

                    const renderItem = (m: any, opts?: { prefixLevel?: number }) => {
                      const name = m.name as string;
                      const isChild = !!m.isChild;
                      const isParent = !!m.isParent && !isChild;
                      const level = Math.max(0, Math.min(6, Number(m.level ?? (name.split(' - ').length - 1))));
                      const isAllTeams = name === 'All Teams';
                      const isEmployee = /employee/i.test(name);
                      const prefixLevel = opts?.prefixLevel ?? (isChild ? level : 0);
                      const indentPx = isChild ? Math.min(72, 8 + prefixLevel * 12) : 0;
                      rendered.add(name);
                      return (
                        <button
                          key={name}
                          onClick={() => { setSelectedTeam(name); setTeamDropOpen(false); }}
                          className={`group w-full flex items-center justify-between gap-2 px-3 py-2.5 text-[12px] transition-colors ${
                            selectedTeam === name ? 'bg-indigo-50 text-indigo-900' : 'hover:bg-gray-50 text-gray-700'
                          }`}
                        >
                          <span className="flex items-center gap-2" style={{ paddingLeft: indentPx }}>
                            {isChild && (
                              <span className="text-gray-300 -ml-1">
                                {Array.from({ length: Math.max(1, prefixLevel) }).map((_, i) => (
                                  <span key={i}>{i === (Math.max(1, prefixLevel) - 1) ? '└─' : '│ '}</span>
                                ))}
                              </span>
                            )}
                            {(() => {
                              if (isEmployee) return <MinusCircle className="w-3.5 h-3.5 text-gray-400" />;
                              const apiType = teamTypeByName[name] as string | undefined;
                              let type = apiType;
                              if (!type) {
                                if (isParent) type = 'TRIBE';
                                else if (isChild && level === 1) type = 'CHAPTER';
                                else if (isChild && level >= 2) type = 'SQUAD';
                              }
                              if (type === 'TRIBE') return <GitFork className="w-3.5 h-3.5 text-gray-500" />;
                              if (type === 'CHAPTER' || type === 'UNIT') return <KanbanSquare className="w-3.5 h-3.5 text-gray-500" />;
                              if (type === 'SQUAD') return <Users className="w-3.5 h-3.5 text-gray-500" />;
                              return isParent ? <GitFork className="w-3.5 h-3.5 text-gray-500" /> : <Users className="w-3.5 h-3.5 text-gray-500" />;
                            })()}
                            <span className={`truncate ${isParent ? 'text-[13px] font-semibold' : 'text-[12px]'}`}>
                              {isAllTeams ? t('allTeams') : (m.base ?? name)}
                            </span>
                          </span>
                          {(() => {
                            const utype = teamTypeByName[name];
                            if (utype === 'TRIBE') {
                              return (
                                <span className="ml-2 px-1.5 py-0.5 rounded-full border text-[10px] bg-indigo-50 text-indigo-700 border-indigo-200 font-semibold">
                                  {t('tribe')}
                                </span>
                              );
                            }
                            if (utype === 'CHAPTER') {
                              return (
                                <span className="ml-2 px-1.5 py-0.5 rounded-full border text-[10px] bg-amber-50 text-amber-700 border-amber-200 font-semibold">
                                  {t('chapter')}
                                </span>
                              );
                            }
                            if (utype === 'UNIT') {
                              return (
                                <span className="ml-2 px-1.5 py-0.5 rounded-full border text-[10px] bg-gray-100 text-gray-600 border-gray-200 font-semibold">
                                  {t('unit')}
                                </span>
                              );
                            }
                            if (utype === 'SQUAD') {
                              return (
                                <span className="ml-2 px-1.5 py-0.5 rounded-full border text-[10px] bg-emerald-50 text-emerald-700 border-emerald-200 font-semibold">
                                  {t('squad')}
                                </span>
                              );
                            }
                            if (isParent) {
                              return (
                                <span className="ml-2 px-1.5 py-0.5 rounded-full border text-[10px] bg-indigo-50 text-indigo-700 border-indigo-200 font-semibold">
                                  {t('tribe')}
                                </span>
                              );
                            }
                            if (!isParent && isChild) {
                              if (level === 1) {
                                return (
                                  <span className="ml-2 px-1.5 py-0.5 rounded-full border text-[10px] bg-amber-50 text-amber-700 border-amber-200 font-semibold">
                                    {t('chapter')}
                                  </span>
                                );
                              }
                              if (level >= 2) {
                                return (
                                  <span className="ml-2 px-1.5 py-0.5 rounded-full border text-[10px] bg-emerald-50 text-emerald-700 border-emerald-200 font-semibold">
                                    {t('squad')}
                                  </span>
                                );
                              }
                            }
                            return null;
                          })()}
                        </button>
                      );
                    };

                    const items: JSX.Element[] = [];

                    const allMeta = teamMeta.find((x) => x.name === 'All Teams');
                    if (allMeta) items.push(renderItem(allMeta, { prefixLevel: 0 }));

                    const domains = teamMeta.filter((m) => m.name !== 'All Teams' && !m.isChild && m.isParent);
                    domains.sort((a, b) => (a.base || a.name).localeCompare(b.base || b.name));

                    for (const d of domains) {
                      items.push(renderItem(d, { prefixLevel: 0 }));

                      const chapters = (childrenOf[d.name] || []).filter((c: any) => (c.level ?? 0) >= 2 || !c.isParent || c.isChild);
                      chapters.sort((a: any, b: any) => (a.base || a.name).localeCompare(b.base || b.name));

                      for (const ch of chapters) {
                        items.push(renderItem(ch, { prefixLevel: 1 }));

                        const squads = (childrenOf[ch.name] || []);
                        squads.sort((a: any, b: any) => (a.base || a.name).localeCompare(b.base || b.name));
                        for (const sq of squads) {
                          items.push(renderItem(sq, { prefixLevel: 2 }));
                        }
                      }
                    }

                    const orphans = teamMeta.filter((m) => m.name !== 'All Teams' && !rendered.has(m.name));
                    orphans.sort((a, b) => (a.base || a.name).localeCompare(b.base || b.name));
                    orphans.forEach((m) => items.push(renderItem(m as any)));

                    return items;
                  })()}
                </div>
              )}
            </div>

            {/* Date range moved to top bar */}
            {/* Mobile: Team selector visible on small screens */}
            <div className="relative sm:hidden min-w-0">
              <button
                onClick={() => setTeamDropOpen(!teamDropOpen)}
                className="flex items-center gap-2 max-w-full px-2 py-1 rounded-md border border-gray-200 bg-white hover:bg-gray-50 text-[12px] text-gray-700 transition-colors dark:bg-[#2b2d31] dark:border-white/10 dark:text-gray-200 dark:hover:bg-white/5"
                aria-label="Team selector (mobile)"
              >
                <Users className="w-4 h-4 text-gray-500" />
                <span className="truncate flex-1 text-left">{(() => { const base = (teamMeta.find(x => x.name === selectedTeam)?.base) ?? selectedTeam; return base === 'All Teams' ? t('allTeams') : base; })()}</span>
                <ChevronDown className="w-3.5 h-3.5 text-gray-500" />
              </button>
              {teamDropOpen && (
                <div className="fixed left-3 right-3 top-12 mt-1 z-50 bg-white rounded-xl border border-gray-200 shadow-lg py-1 max-h-72 overflow-y-auto dark:bg-[#2b2d31] dark:border-white/10">
                  {(() => {
                    const rendered = new Set<string>();

                    const byName: Record<string, typeof teamMeta[number]> = {} as any;
                    teamMeta.forEach((m) => { byName[m.name] = m as any; });

                    const childrenOf: Record<string, typeof teamMeta> = {} as any;
                    teamMeta.forEach((m) => {
                      if (!m.parent) return;
                      (childrenOf[m.parent] ||= []).push(m as any);
                    });

                    const renderItem = (m: any, opts?: { prefixLevel?: number }) => {
                      const name = m.name as string;
                      const isChild = !!m.isChild;
                      const isParent = !!m.isParent && !isChild;
                      const level = Math.max(0, Math.min(6, Number(m.level ?? (name.split(' - ').length - 1))));
                      const isAllTeams = name === 'All Teams';
                      const isEmployee = /employee/i.test(name);
                      const prefixLevel = opts?.prefixLevel ?? (isChild ? level : 0);
                      const indentPx = isChild ? Math.min(64, 6 + prefixLevel * 10) : 0;
                      rendered.add(name);
                      return (
                        <button
                          key={name}
                          onClick={() => { setSelectedTeam(name); setTeamDropOpen(false); }}
                          className={`group w-full flex items-center justify-between gap-2 px-3 py-2 text-[12px] transition-colors ${
                            selectedTeam === name ? 'bg-indigo-50 text-indigo-900' : 'hover:bg-gray-50 text-gray-700'
                          }`}
                        >
                          <span className="flex items-center gap-2" style={{ paddingLeft: indentPx }}>
                            {isChild && (
                              <span className="text-gray-300 -ml-1">
                                {Array.from({ length: Math.max(1, prefixLevel) }).map((_, i) => (
                                  <span key={i}>{i === (Math.max(1, prefixLevel) - 1) ? '└─' : '│ '}</span>
                                ))}
                              </span>
                            )}
                            {(() => {
                              if (isEmployee) return <MinusCircle className="w-3.5 h-3.5 text-gray-400" />;
                              const apiType = teamTypeByName[name] as string | undefined;
                              let type = apiType;
                              if (!type) {
                                if (isParent) type = 'TRIBE';
                                else if (isChild && level === 1) type = 'CHAPTER';
                                else if (isChild && level >= 2) type = 'SQUAD';
                              }
                              if (type === 'TRIBE') return <GitFork className="w-3.5 h-3.5 text-gray-500" />;
                              if (type === 'CHAPTER' || type === 'UNIT') return <KanbanSquare className="w-3.5 h-3.5 text-gray-500" />;
                              if (type === 'SQUAD') return <Users className="w-3.5 h-3.5 text-gray-500" />;
                              return isParent ? <GitFork className="w-3.5 h-3.5 text-gray-500" /> : <Users className="w-3.5 h-3.5 text-gray-500" />;
                            })()}
                            <span className={`truncate ${isParent ? 'text-[13px] font-semibold' : 'text-[12px]'}`}>
                              {isAllTeams ? t('allTeams') : (m.base ?? name)}
                            </span>
                          </span>
                        </button>
                      );
                    };

                    const items: JSX.Element[] = [];

                    const allMeta = teamMeta.find((x) => x.name === 'All Teams');
                    if (allMeta) items.push(renderItem(allMeta, { prefixLevel: 0 }));

                    const domains = teamMeta.filter((m) => m.name !== 'All Teams' && !m.isChild && m.isParent);
                    domains.sort((a, b) => (a.base || a.name).localeCompare(b.base || b.name));

                    for (const d of domains) {
                      items.push(renderItem(d, { prefixLevel: 0 }));

                      const chapters = (childrenOf[d.name] || []).filter((c: any) => (c.level ?? 0) >= 2 || !c.isParent || c.isChild);
                      chapters.sort((a: any, b: any) => (a.base || a.name).localeCompare(b.base || b.name));

                      for (const ch of chapters) {
                        items.push(renderItem(ch, { prefixLevel: 1 }));

                        const squads = (childrenOf[ch.name] || []);
                        squads.sort((a: any, b: any) => (a.base || a.name).localeCompare(b.base || b.name));
                        for (const sq of squads) {
                          items.push(renderItem(sq, { prefixLevel: 2 }));
                        }
                      }
                    }

                    const orphans = teamMeta.filter((m) => m.name !== 'All Teams' && !rendered.has(m.name));
                    orphans.sort((a, b) => (a.base || a.name).localeCompare(b.base || b.name));
                    orphans.forEach((m) => items.push(renderItem(m as any)));

                    return items;
                  })()}
                </div>
              )}
            </div>

            <DateRangePicker value={dateRange} onChange={setDateRange} lang={lang} />
          </div>
        </header>

        {/* Page content */}
        <main className={`flex-1 flex flex-col min-h-0 bg-[#f6f8fa] dark:bg-black ${isDevDetails && hasEngineers ? 'pb-20' : 'pb-0'} lg:pb-0`}>
          <div className="flex-1 min-h-0 w-full overflow-auto">
            {currentPageBlocked ? (
              <div className="p-6">
                <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl p-5 max-w-xl">
                  <p className="text-[14px] text-gray-800 dark:text-gray-100" style={{ fontWeight: 600 }}>{pick('No access', 'Brak dostępu')}</p>
                  <p className="text-[12px] text-gray-500 mt-1">
                    {pick('Your role does not allow this page. An administrator can change it in Settings → Users and access.',
                      'Twoja rola nie pozwala na tę stronę. Administrator może to zmienić w Ustawienia → Użytkownicy i dostęp.')}
                  </p>
                </div>
              </div>
            ) : (
              <Outlet />
            )}
          </div>
        </main>
      </div>

      {/* Bottom toolbar: Developer selector (only on Developer Details) */}
      {isDevDetails && hasEngineers && (
      <div className="fixed inset-x-0 bottom-0 z-30 px-3 pb-[env(safe-area-inset-bottom)]">
        <div className="mx-auto max-w-screen-lg mb-3 flex items-center justify-between gap-2 rounded-xl border border-gray-200 bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/80 px-3 py-2 shadow-lg dark:border-white/10 dark:bg-[#2b2d31]/95 supports-[backdrop-filter]:dark:bg-[#2b2d31]/80">
          {/* Left: Developer selector */}
          <div className="relative">
            <button
              onClick={() => setDevDropOpen(!devDropOpen)}
              className="flex items-center gap-2 max-w-[calc(100vw-3.5rem)] px-2.5 py-1.5 rounded-md border border-gray-200 bg-white hover:bg-gray-50 text-[12px] text-gray-700 transition-colors dark:bg-[#2b2d31] dark:border-white/10 dark:text-gray-200 dark:hover:bg-white/5"
              style={{ width: teamButtonWidth }}
            >
              <Users className="w-4 h-4 text-gray-500" />
              <span className="truncate flex-1 text-left">{(devMember && (devMember.name || devMember.email)) || t('selectEngineer')}</span>
              <ChevronDown className="w-3.5 h-3.5 text-gray-500" />
            </button>
            {devDropOpen && (
              <div className="absolute left-0 bottom-10 z-50 bg-white rounded-xl border border-gray-200 shadow-lg overflow-y-auto max-h-[60vh] max-w-[calc(100vw-3.5rem)] py-1 dark:bg-[#2b2d31] dark:border-white/10" style={{ minWidth: teamButtonWidth }}>
                {devEngineers!.map((eng: any, i: number) => (
                  <button
                    key={(eng.id ?? eng.email ?? eng.name ?? i) as any}
                    onClick={() => {
                      setDevDropOpen(false);
                      navigate('/team/developer', { state: { member: eng, engineers: devEngineers, interval: devInterval } });
                    }}
                    className={`w-full text-left px-3 py-2.5 text-[12px] transition-colors ${
                      (devMember && (devMember.id ?? devMember.email ?? devMember.name)) === (eng.id ?? eng.email ?? eng.name)
                        ? 'bg-indigo-50 text-indigo-900 dark:bg-indigo-500/10 dark:text-indigo-300'
                        : 'hover:bg-gray-50 text-gray-700 dark:hover:bg-white/5 dark:text-gray-200'
                    }`}
                  >
                    {(eng.name || eng.email || 'Unknown') as string}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
      )}


      <ConfiguratorOverlay />
      <AiAssistant raised={Boolean(isDevDetails && hasEngineers)} />
    </div>
        {/* Data advisor disabled per requirement */}
      </DateRangeContext.Provider>
    </TeamContext.Provider>
    </LangProvider>
  );
}
