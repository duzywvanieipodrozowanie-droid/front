import { useEffect, useMemo, useState } from 'react';
import { CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { useLang, usePick } from '../i18n';
import LoadingSpinner from './LoadingSpinner';
import HelpTip from './HelpTip';

type BurnupWeek = { weekStart: string; scopeItems: number; doneItems: number; scopePoints: number; donePoints: number; itemsClosed: number; pointsClosed: number };
type Burnup = { weeks: BurnupWeek[]; scopeItems: number; doneItems: number; scopePoints: number; donePoints: number; unestimated: number; velocityItems: number; velocityPoints: number };

const SCOPE = '#9ca3af';
const DONE = '#059669';
const card = 'bg-white dark:bg-[#121317] rounded-xl border border-gray-200 dark:border-white/10';
const muted = 'text-gray-500 dark:text-gray-400';

/**
 * Burn-up of the unit's work items (stories, tasks, bugs) by week: the scope and what is done, in story points or
 * items, with the velocity of the last full weeks and how many weeks the rest takes at that pace.
 */
export default function TeamBurnup({ unitId }: { unitId: string | null }) {
  const pick = usePick();
  const { lang } = useLang();
  const [weeks, setWeeks] = useState(12);
  const [unit, setUnit] = useState<'points' | 'items'>('points');
  const [data, setData] = useState<Burnup | null>(null);
  const [loading, setLoading] = useState(false);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    const controller = new AbortController();
    const p = new URLSearchParams({ weeks: String(weeks) });
    if (unitId) p.set('unitId', unitId);
    setLoading(true);
    setFailed(false);
    fetch(`/api/metrics/deliver/burnup?${p.toString()}`, { credentials: 'include', signal: controller.signal })
      .then((res) => { if (!res.ok) throw new Error(String(res.status)); return res.json(); })
      .then((json: Burnup) => setData(json))
      .catch((e) => { if (e?.name !== 'AbortError') setFailed(true); })
      .finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
  }, [unitId, weeks]);

  const points = unit === 'points';
  const locale = lang === 'pl' ? 'pl-PL' : 'en-GB';
  const rows = useMemo(() => (data?.weeks ?? []).map((w) => ({
    label: new Date(`${w.weekStart}T00:00:00`).toLocaleDateString(locale, { day: 'numeric', month: 'short' }),
    scope: points ? w.scopePoints : w.scopeItems,
    done: points ? w.donePoints : w.doneItems,
    closed: points ? w.pointsClosed : w.itemsClosed,
  })), [data, points, locale]);

  const scope = data ? (points ? data.scopePoints : data.scopeItems) : 0;
  const done = data ? (points ? data.donePoints : data.doneItems) : 0;
  const velocity = data ? (points ? data.velocityPoints : data.velocityItems) : 0;
  const remaining = Math.max(0, scope - done);
  const weeksLeft = velocity > 0 ? Math.ceil(remaining / velocity) : null;
  const u = points ? 'SP' : pick('items', 'zadań');

  const toggle = <T extends string | number>(value: T, current: T, set: (v: T) => void, label: string) => (
    <button key={String(value)} onClick={() => set(value)}
      className={`px-2 py-0.5 rounded-md border text-[11.5px] ${current === value
        ? 'bg-gray-900 text-white border-gray-900 dark:bg-gray-100 dark:text-gray-900'
        : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50 dark:bg-white/5 dark:text-gray-300 dark:border-white/10'}`}>{label}</button>
  );

  const stat = (label: string, value: string, hint?: string) => (
    <div>
      <div className={`text-[10.5px] uppercase tracking-wide ${muted}`}>{label}</div>
      <div className="text-[18px]" style={{ fontWeight: 700 }}>{value}</div>
      {hint && <div className={`text-[10.5px] ${muted}`}>{hint}</div>}
    </div>
  );

  return (
    <div className={`${card} p-4`}>
      <div className="flex flex-wrap items-center gap-2 mb-3">
        <div className="text-[14px] flex items-center gap-1" style={{ fontWeight: 700 }}>
          {pick('Team burn-up', 'Burn-up zespołu')}
          <HelpTip content={pick(
            'Work items of the unit (stories, tasks, bugs; no epics, sub-tasks, releases or cancelled ones) by week. Scope = open at the start of the period plus created since; Done = moved to a done status (done / live). Velocity = average of the last 6 full weeks.',
            'Zadania unitu (story, taski, bugi; bez epików, sub-tasków, release i anulowanych) tydzień po tygodniu. Zakres = otwarte na początku okresu plus utworzone od tego czasu; Zrobione = przeszły do statusu done / live. Tempo = średnia z ostatnich 6 pełnych tygodni.',
          )} />
        </div>
        <div className="flex-1" />
        <div className="flex gap-1">
          {toggle<'points' | 'items'>('points', unit, setUnit, 'SP')}
          {toggle<'points' | 'items'>('items', unit, setUnit, pick('Items', 'Zadania'))}
        </div>
        <div className="flex gap-1">
          {[12, 26, 52].map((w) => toggle(w, weeks, setWeeks, `${w} ${pick('wk', 'tyg.')}`))}
        </div>
      </div>

      {loading && !data ? (
        <div className="p-8 flex justify-center"><LoadingSpinner size={20} /></div>
      ) : failed ? (
        <div className={`p-4 text-[13px] ${muted}`}>{pick('Could not load the burn-up.', 'Nie udało się pobrać burn-up.')}</div>
      ) : data && (
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_200px] gap-4">
          <div className="h-[240px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={rows} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" strokeOpacity={0.6} vertical={false} />
                <XAxis dataKey="label" tick={{ fontSize: 10, fill: '#9ca3af' }} axisLine={false} tickLine={false} minTickGap={16} />
                <YAxis tick={{ fontSize: 10, fill: '#9ca3af' }} axisLine={false} tickLine={false} allowDecimals={false} width={36} />
                <Tooltip
                  formatter={(v: number, name: string) => [`${v} ${u}`, name]}
                  labelFormatter={(l, payload) => {
                    const closed = payload?.[0]?.payload?.closed;
                    return `${pick('Week of', 'Tydzień od')} ${l}${closed != null ? ` · ${pick('closed', 'zamknięte')} ${closed} ${u}` : ''}`;
                  }}
                />
                <Legend iconType="plainline" wrapperStyle={{ fontSize: 11 }} />
                <Line type="stepAfter" dataKey="scope" name={pick('Scope', 'Zakres')} stroke={SCOPE} strokeWidth={2} strokeDasharray="5 3" dot={false} isAnimationActive={false} />
                <Line type="monotone" dataKey="done" name={pick('Done', 'Zrobione')} stroke={DONE} strokeWidth={2} dot={{ r: 3 }} activeDot={{ r: 5 }} isAnimationActive={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-1 gap-3 content-start">
            {stat(pick('Done / scope', 'Zrobione / zakres'), `${done} / ${scope} ${u}`, scope ? `${Math.round((done * 100) / scope)}%` : undefined)}
            {stat(pick('Velocity', 'Tempo'), `${velocity} ${u} / ${pick('wk', 'tydz.')}`, pick('last 6 full weeks', 'ostatnie 6 pełnych tygodni'))}
            {stat(pick('Remaining', 'Pozostało'), `${remaining} ${u}`,
              weeksLeft != null ? pick(`≈ ${weeksLeft} wk at this pace`, `≈ ${weeksLeft} tyg. przy tym tempie`) : pick('no pace yet', 'brak tempa'))}
            {points && data.unestimated > 0 && stat(pick('Without estimate', 'Bez estymaty'), `${data.unestimated}`,
              pick('items not counted in SP', 'zadań nieliczonych w SP'))}
          </div>
        </div>
      )}
    </div>
  );
}
