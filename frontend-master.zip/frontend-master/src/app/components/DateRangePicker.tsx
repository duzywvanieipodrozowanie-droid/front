import { useEffect, useRef, useState } from 'react';
import { CalendarRange } from 'lucide-react';
import type { DateRangeValue } from '../context/DateRangeContext';
import { PRESET_RANGES, customRange, isoDay, monthRange, parseCustomRange, rangeDays, rangeLabel } from '../utils/dateRange';

const CUSTOM_OPTION = '__custom__';
/** Core takes up to 3 years (Interval.MAX_CUSTOM_DAYS). */
const MAX_DAYS = 3 * 366;

/** Period of the top bar: the presets ending today, or a custom period picked with two dates. */
export function DateRangePicker({ value, onChange, lang }: { value: DateRangeValue; onChange: (value: DateRangeValue) => void; lang: 'en' | 'pl' }) {
  const pick = (en: string, pl: string) => (lang === 'pl' ? pl : en);
  const custom = parseCustomRange(value);
  const [open, setOpen] = useState(false);
  const [from, setFrom] = useState(custom?.from ?? monthRange(1).from);
  const [to, setTo] = useState(custom?.to ?? monthRange(1).to);
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const close = (e: MouseEvent) => { if (boxRef.current && !boxRef.current.contains(e.target as Node)) setOpen(false); };
    const esc = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('mousedown', close);
    document.addEventListener('keydown', esc);
    return () => { document.removeEventListener('mousedown', close); document.removeEventListener('keydown', esc); };
  }, [open]);

  function openCustom() {
    const current = parseCustomRange(value);
    if (current) { setFrom(current.from); setTo(current.to); }
    setOpen(true);
  }

  const today = isoDay(new Date());
  const days = from && to ? rangeDays(customRange(from, to)) : 0;
  const error = !from || !to
    ? pick('Pick both dates', 'Wybierz obie daty')
    : from > to
      ? pick('The start is after the end', 'Początek jest po końcu')
      : days > MAX_DAYS
        ? pick('At most 3 years', 'Maksymalnie 3 lata')
        : null;

  function apply() {
    if (error) return;
    onChange(customRange(from, to));
    setOpen(false);
  }

  const inputCls =
    'w-full rounded-md border border-gray-200 bg-white px-2 py-1.5 text-[12.5px] text-gray-800 outline-none focus:border-indigo-400 dark:border-white/10 dark:bg-black/20 dark:text-gray-100 [color-scheme:light] dark:[color-scheme:dark]';
  const shortcut = 'px-2 py-1 rounded-md border border-gray-200 text-[11.5px] text-gray-700 hover:bg-gray-50 dark:border-white/10 dark:text-gray-300 dark:hover:bg-white/5';

  return (
    <div className="relative shrink-0" ref={boxRef}>
      <select
        value={custom ? CUSTOM_OPTION : value}
        onChange={(e) => (e.target.value === CUSTOM_OPTION ? openCustom() : onChange(e.target.value as DateRangeValue))}
        className="max-w-[230px] text-[12px] text-gray-700 bg-gray-50 border border-gray-200 rounded-md px-2.5 py-1.5 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer dark:text-gray-200 dark:bg-[#2b2d31] dark:border-white/10"
        aria-label={pick('Period', 'Okres')}
      >
        {PRESET_RANGES.map((it) => <option key={it.value} value={it.value}>{lang === 'pl' ? it.pl : it.en}</option>)}
        <option value={CUSTOM_OPTION}>{custom ? rangeLabel(value, lang) : pick('Custom range…', 'Własny zakres…')}</option>
      </select>
      {custom && !open && (
        <button
          onClick={openCustom}
          className="ml-1 align-middle p-1.5 rounded-md text-gray-500 hover:bg-gray-100 dark:hover:bg-white/10"
          title={pick('Change dates', 'Zmień daty')}
          aria-label={pick('Change dates', 'Zmień daty')}
        >
          <CalendarRange className="w-4 h-4" />
        </button>
      )}

      {open && (
        <div className="absolute right-0 mt-2 z-50 w-[300px] rounded-xl border border-gray-200 bg-white p-4 shadow-lg dark:border-white/10 dark:bg-[#1f2024]">
          <div className="text-[13px] text-gray-900 dark:text-gray-100 mb-3" style={{ fontWeight: 700 }}>{pick('Custom range', 'Własny zakres')}</div>
          <div className="flex flex-wrap gap-1.5 mb-3">
            <button className={shortcut} onClick={() => { const m = monthRange(0); setFrom(m.from); setTo(m.to); }}>{pick('This month', 'Ten miesiąc')}</button>
            <button className={shortcut} onClick={() => { const m = monthRange(1); setFrom(m.from); setTo(m.to); }}>{pick('Previous month', 'Poprzedni miesiąc')}</button>
            <button className={shortcut} onClick={() => { const m = monthRange(2); setFrom(m.from); setTo(m.to); }}>{pick('2 months ago', '2 miesiące temu')}</button>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <label className="flex flex-col gap-1 text-[11px] text-gray-500" style={{ fontWeight: 600 }}>
              {pick('From', 'Od')}
              <input type="date" className={inputCls} value={from} max={to || today} onChange={(e) => setFrom(e.target.value)} />
            </label>
            <label className="flex flex-col gap-1 text-[11px] text-gray-500" style={{ fontWeight: 600 }}>
              {pick('To', 'Do')}
              <input type="date" className={inputCls} value={to} min={from} max={today} onChange={(e) => setTo(e.target.value)} />
            </label>
          </div>
          <div className="mt-2 text-[11.5px] min-h-[16px]">
            {error ? <span className="text-red-600">{error}</span> : <span className="text-gray-500">{days} {pick(days === 1 ? 'day' : 'days', days === 1 ? 'dzień' : 'dni')}</span>}
          </div>
          <div className="mt-3 flex justify-end gap-2">
            <button onClick={() => setOpen(false)} className="px-3 py-1.5 rounded-md text-[12.5px] text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-white/10">
              {pick('Cancel', 'Anuluj')}
            </button>
            <button onClick={apply} disabled={!!error} className="px-3 py-1.5 rounded-md text-[12.5px] text-white disabled:opacity-50" style={{ backgroundColor: '#2563eb', fontWeight: 600 }}>
              {pick('Apply', 'Zastosuj')}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default DateRangePicker;
