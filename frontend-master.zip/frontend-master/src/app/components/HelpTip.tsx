import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Info } from 'lucide-react';
import { useTr } from '../i18n';

export type HelpTipProps = {
  title?: string;
  content: string;
  size?: 'sm' | 'md';
  className?: string;
};

type Pos = { top: number; left: number; width?: number } | null;

export default function HelpTip({ title, content, size = 'sm', className }: HelpTipProps) {
  const [open, setOpen] = useState(false);
  const [hover, setHover] = useState(false);
  const rootRef = useRef<HTMLDivElement | null>(null);
  const btnRef = useRef<HTMLButtonElement | null>(null);
  const [hoverPos, setHoverPos] = useState<Pos>(null);
  const [popPos, setPopPos] = useState<Pos>(null);

  // Close on outside click
  useEffect(() => {
    function onDocClick(e: MouseEvent) {
      if (!rootRef.current) return;
      if (!rootRef.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener('click', onDocClick);
    return () => document.removeEventListener('click', onDocClick);
  }, []);

  // Helpers to compute sidebar-safe x coordinate
  const getSidebarRight = () => {
    const el = document.getElementById('app-sidebar');
    if (!el) return 0;
    const rect = el.getBoundingClientRect();
    // If sidebar is translated off-screen, rect.right may be <= 0
    return Math.max(0, Math.round(rect.right));
  };

  function clamp(val: number, min: number, max: number) {
    return Math.max(min, Math.min(max, val));
  }

  const recomputeHover = () => {
    if (!btnRef.current) return;
    const r = btnRef.current.getBoundingClientRect();
    const vw = window.innerWidth || document.documentElement.clientWidth;
    const minLeft = getSidebarRight() + 10; // 10px away from sidebar
    const estWidth = 140; // approximate width of "Click for details"
    const centered = r.left + r.width / 2 - estWidth / 2;
    const left = clamp(centered, minLeft, vw - estWidth - 10);
    const top = Math.max(10, r.top - 8); // render above with slight gap
    setHoverPos({ top, left, width: estWidth });
  };

  const recomputePopover = () => {
    if (!btnRef.current) return;
    const r = btnRef.current.getBoundingClientRect();
    const vw = window.innerWidth || document.documentElement.clientWidth;
    const popW = 288; // w-72 ~ 18rem = 288px
    const minLeft = getSidebarRight() + 10;
    const desiredLeft = r.right - popW; // right-align to button like previous right-0
    const left = clamp(desiredLeft, minLeft, vw - popW - 10);
    const below = r.bottom + 8;
    const top = clamp(below, 8, (window.innerHeight || document.documentElement.clientHeight) - 100);
    setPopPos({ top, left, width: popW });
  };

  // Recompute positions when hover/open changes and on resize/scroll
  useEffect(() => {
    if (hover && !open) {
      recomputeHover();
    }
    if (open) {
      recomputePopover();
    }
    function onScrollOrResize() {
      if (hover && !open) recomputeHover();
      if (open) recomputePopover();
    }
    window.addEventListener('scroll', onScrollOrResize, true);
    window.addEventListener('resize', onScrollOrResize);
    return () => {
      window.removeEventListener('scroll', onScrollOrResize, true);
      window.removeEventListener('resize', onScrollOrResize);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hover, open]);

  const iconSize = size === 'sm' ? 'w-4 h-4' : 'w-5 h-5';

  const t = useTr();
  return (
    <div ref={rootRef} className={`relative inline-flex items-center ${className || ''}`}>
      <button
        ref={btnRef}
        type="button"
        aria-label="Help"
        onClick={() => setOpen((v) => !v)}
        onMouseEnter={() => setHover(true)}
        onMouseLeave={() => setHover(false)}
        className={`p-1 rounded-md border border-transparent hover:border-gray-200 hover:bg-gray-50 text-gray-400`}
      >
        <Info className={`${iconSize}`} />
      </button>

      {/* Hover tooltip (fixed, sidebar-aware) */}
      {(hover && !open) && (
        <div
          className="fixed z-40 whitespace-nowrap bg-white text-gray-700 border border-gray-200 rounded-md px-2 py-1 text-[11px] shadow"
          style={{
            top: (hoverPos?.top ?? 0),
            left: (hoverPos?.left ?? (getSidebarRight() + 10)),
            maxWidth: '60vw'
          }}
        >
          {t('clickForDetails')}
        </div>
      )}

      {/* Click popover (fixed, sidebar-aware) */}
      {open && (
        <div
          className="fixed z-50 bg-white border border-gray-200 rounded-lg shadow-xl p-3"
          style={{
            top: (popPos?.top ?? 0),
            left: (popPos?.left ?? (getSidebarRight() + 10)),
            width: popPos?.width ?? 288,
            maxWidth: '80vw'
          }}
        >
          {title && <div className="text-[12px] text-gray-500 mb-1">{title}</div>}
          <div className="text-[12px] text-gray-800 leading-relaxed whitespace-pre-line">{content}</div>
        </div>
      )}
    </div>
  );
}
