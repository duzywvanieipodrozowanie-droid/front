import { useEffect, useMemo, useState } from 'react';

/**
 * Global setup/configurator overlay shown on top of the whole app after login.
 * - Reads visibility from localStorage key: "configurator.show" ("true" shows)
 * - Saves Organization name under localStorage key: "org.name" and mirrors to "app.brand.name"
 * - Saves License under localStorage key: "org.licence.key"
 * - Uses a lightweight, Tailwind-based stepper (no external UI lib)
 */
export default function ConfiguratorOverlay() {
  const [open, setOpen] = useState<boolean>(() => {
    try {
      return localStorage.getItem('configurator.show') === 'true';
    } catch {
      return false;
    }
  });
  const [active, setActive] = useState<number>(() => {
    try {
      return Number(localStorage.getItem('configurator.step') || '0');
    } catch {
      return 0;
    }
  });
  const [appName, setAppName] = useState<string>(() => {
    try {
      return localStorage.getItem('app.brand.name') || localStorage.getItem('org.name') || 'OneLook';
    } catch {
      return 'OneLook';
    }
  });
  const [licence, setLicence] = useState<string>(() => {
    try { return localStorage.getItem('org.licence.key') || ''; } catch { return ''; }
  });
  const [savedInfo, setSavedInfo] = useState<{ model: string; expiry: string; version: string } | null>(null);
  const nameValid = useMemo(() => appName.trim().length > 0, [appName]);
  const licenceValid = useMemo(() => licence.trim().length > 0, [licence]);
  const bothValid = nameValid && licenceValid;

  useEffect(() => {
    function onStorage(e: StorageEvent) {
      if (e.key === 'configurator.show') {
        setOpen(e.newValue === 'true');
      }
    }
    // Also listen to our custom cross-component event to open immediately in same tab
    function onChanged() {
      try {
        const flag = localStorage.getItem('configurator.show') === 'true';
        setOpen(flag);
      } catch {}
    }
    window.addEventListener('storage', onStorage);
    window.addEventListener('configurator.changed', onChanged as EventListener);
    return () => {
      window.removeEventListener('storage', onStorage);
      window.removeEventListener('configurator.changed', onChanged as EventListener);
    };
  }, []);

  useEffect(() => {
    // Keep state in sync if other parts toggle
    try {
      const flag = localStorage.getItem('configurator.show') === 'true';
      if (flag !== open) setOpen(flag);
    } catch {}
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    try { localStorage.setItem('configurator.step', String(active)); } catch {}
  }, [active]);

  function handleBackdropClick() {
    try {
      localStorage.setItem('configurator.show', 'false');
      window.dispatchEvent(new Event('configurator.changed'));
    } catch {}
    setOpen(false);
  }

  if (!open) return null;

  function finish() {
    try {
      localStorage.setItem('configurator.show', 'false');
      localStorage.setItem('configurator.dismissed', '1');
      window.dispatchEvent(new Event('configurator.changed'));
    } catch {}
    setOpen(false);
  }

  function generateSavedInfo(key: string): { model: string; expiry: string; version: string } {
    const upper = key.toUpperCase();
    let model = 'Core';
    if (upper.includes('ENT')) model = 'Enterprise';
    else if (upper.includes('PRE')) model = 'Premium';
    else if (upper.includes('PRO')) model = 'Premium';
    // expiry +1 year from now
    const d = new Date();
    d.setFullYear(d.getFullYear() + 1);
    const expiry = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
    // pseudo-random version
    const major = 1 + Math.floor(Math.random() * 3);
    const minor = Math.floor(Math.random() * 10);
    const patch = Math.floor(Math.random() * 20);
    const version = `v${major}.${minor}.${patch}`;
    return { model, expiry, version };
  }

  function saveStep1(advance = true) {
    const name = appName.trim();
    const key = licence.trim();
    try {
      if (name) {
        localStorage.setItem('org.name', name);
        localStorage.setItem('app.brand.name', name);
        window.dispatchEvent(new CustomEvent('app.brand.updated', { detail: { name } }));
      }
      localStorage.setItem('org.licence.key', key);
    } catch {}
    setSavedInfo(generateSavedInfo(key));
    if (advance) setActive(1);
  }

  function handleSaveNoAdvance() {
    if (!bothValid) return;
    saveStep1(false);
  }

  function tryBasic() {
    setAppName('Tanuji OneLook');
    setLicence('34FSX-34T4A-9EG6Z-9ILW2-ML2P6');
    // Save and continue
    setTimeout(() => saveStep1(true), 0);
  }

  // Simple stepper UI
  const steps = [
    { label: 'Organization', description: 'Name & License' },
    { label: 'People & tools', description: 'Next' },
    { label: 'Projects', description: 'Finish' },
  ];

  return (
    <div className="fixed inset-0 z-[200]" onClick={handleBackdropClick}>
      {/* Backdrop with subtle blur */}
      <div className="absolute inset-0 bg-black/30 backdrop-blur-sm" />
      <div className="relative z-10 min-h-full w-full flex items-center justify-center p-6" onClick={(e) => e.stopPropagation()}>
        <div className="w-full max-w-4xl bg-white rounded-2xl border border-gray-200 shadow-2xl overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-100 bg-gray-50">
            <h2 className="text-[16px] text-gray-900" style={{ fontWeight: 800 }}>Settings</h2>
            <p className="text-[12px] text-gray-500">Start with the setup below, then connect your tools. All changes are safe to try — you can adjust anytime.</p>
          </div>

          <div className="p-6">
            {/* Stepper header */}
            <ol className="flex items-center gap-6 mb-6">
              {steps.map((s, i) => {
                const done = i < active;
                const current = i === active;
                return (
                  <li key={s.label} className="flex items-center gap-3 cursor-pointer select-none" onClick={() => setActive(i)}>
                    <span className={`flex items-center justify-center w-6 h-6 rounded-full border text-[12px] ${done ? 'bg-indigo-600 border-indigo-600 text-white' : current ? 'bg-white border-indigo-400 text-indigo-600' : 'bg-gray-50 border-gray-300 text-gray-500'}`}
                          style={{ fontWeight: 700 }}>
                      {i + 1}
                    </span>
                    <div className="leading-tight">
                      <div className={`text-[12px] ${current ? 'text-gray-900' : 'text-gray-700'}`} style={{ fontWeight: 700 }}>{s.label}</div>
                      <div className="text-[11px] text-gray-500">{s.description}</div>
                    </div>
                  </li>
                );
              })}
            </ol>

            {/* Steps content */}
            {active === 0 && (
              <div className="grid gap-4 max-w-xl">
                <div>
                  <label className="block text-[12px] text-gray-700 mb-1" style={{ fontWeight: 600 }}>Application name</label>
                  <input
                    value={appName}
                    onChange={(e) => setAppName(e.currentTarget.value)}
                    placeholder="e.g. Acme Corp"
                    className="w-full rounded-md border border-gray-300 px-3 py-2 text-[13px] focus:outline-none focus:ring-2 focus:ring-indigo-200"
                  />
                </div>
                <div>
                  <label className="block text-[12px] text-gray-700 mb-1" style={{ fontWeight: 600 }}>Licence key</label>
                  <input
                    value={licence}
                    onChange={(e) => setLicence(e.currentTarget.value)}
                    placeholder="XXXX-XXXX-XXXX-XXXX"
                    className="w-full rounded-md border border-gray-300 px-3 py-2 text-[13px] focus:outline-none focus:ring-2 focus:ring-indigo-200"
                  />
                </div>
                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    className={`px-4 py-1.5 rounded-md text-[12px] border ${bothValid ? 'bg-white text-gray-800 border-gray-300 hover:bg-gray-50' : 'bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed'}`}
                    disabled={!bothValid}
                    onClick={handleSaveNoAdvance}
                    style={{ fontWeight: 700 }}
                  >
                    Save
                  </button>
                  {savedInfo && (
                    <button
                      className="px-4 py-1.5 rounded-md text-[12px] bg-indigo-600 text-white hover:bg-indigo-700"
                      onClick={() => setActive(1)}
                      style={{ fontWeight: 800 }}
                    >
                      Next
                    </button>
                  )}
                  <button
                    className="px-4 py-1.5 rounded-md text-[12px] bg-indigo-600 text-white hover:bg-indigo-700"
                    onClick={tryBasic}
                    style={{ fontWeight: 800 }}
                  >
                    Try BASIC
                  </button>
                </div>
                {savedInfo && (
                  <div className="mt-3 rounded-md border border-emerald-200 bg-emerald-50 text-emerald-800 px-3 py-2 text-[12px]">
                    <p><span className="font-semibold">Licence model:</span> {savedInfo.model}</p>
                    <p><span className="font-semibold">Valid until:</span> {savedInfo.expiry}</p>
                    <p><span className="font-semibold">App version:</span> {savedInfo.version}</p>
                  </div>
                )}
              </div>
            )}

            {active === 1 && (
              <div>
                <div className="rounded-md border border-gray-200 bg-white p-4">
                  <p className="text-[12px] text-gray-600">You can connect your tools and add people later. Click Next to continue.</p>
                </div>
                <div className="flex items-center justify-between mt-3">
                  <button
                    className="px-4 py-1.5 rounded-md text-[12px] bg-white text-gray-800 border border-gray-300 hover:bg-gray-50"
                    onClick={() => setActive(0)}
                  >
                    Back
                  </button>
                  <button
                    className="px-4 py-1.5 rounded-md text-[12px] bg-indigo-600 text-white hover:bg-indigo-700"
                    onClick={() => setActive(2)}
                  >
                    Next
                  </button>
                </div>
              </div>
            )}

            {active === 2 && (
              <div>
                <div className="h-[50vh] rounded-xl border border-gray-200 overflow-hidden bg-white">
                  {/* Lightweight preview of Settings screen; for full control user can open Settings later */}
                  <iframe title="Settings preview" src="/settings" className="w-full h-full" />
                </div>
                <div className="flex items-center justify-between mt-3">
                  <button
                    className="px-4 py-1.5 rounded-md text-[12px] bg-white text-gray-800 border border-gray-300 hover:bg-gray-50"
                    onClick={() => setActive(1)}
                  >
                    Back
                  </button>
                  <button
                    className="px-4 py-1.5 rounded-md text-[12px] bg-indigo-600 text-white hover:bg-indigo-700"
                    onClick={finish}
                  >
                    Finish
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
