import React, { useEffect, useMemo, useState } from 'react';
import { TrendingDown, TrendingUp, ArrowDownRight, ArrowUpRight } from 'lucide-react';
import { useTeam } from '../context/TeamContext';
import LoadingSpinner from './LoadingSpinner';
import { useNoDataTimeout } from '../hooks/useNoDataTimeout';
import HelpTip from './HelpTip';
import { useTr, usePick } from '../i18n';

export type CtbItem = { value: number; change: number; positive: boolean };

type Props = {
  interval: string;
  team?: string;
  weeks?: number; // optional: number of weeks to consider (reserved for future use)
};

function useCtbTile(endpoints: string[], interval: string, team?: string, unitId?: string | null) {
  const [data, setData] = useState<CtbItem | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();

    async function load() {
      setLoading(true);
      // The backend filters by unitId only (team is ignored); without it, it computes over all managed units.
      // A team is selected but its unitId is not resolved yet -> wait instead of firing that expensive request.
      if (team && !unitId) return;
      try {
        const params = new URLSearchParams({ interval });
        if (unitId) params.set('unitId', unitId);
        let payload: unknown;
        for (const base of endpoints) {
          const url = base.includes('?') ? `${base}&${params.toString()}` : `${base}?${params.toString()}`;
          try {
            const res = await fetch(url, { credentials: 'include', signal: controller.signal });
            if (!res.ok) continue;
            payload = await res.json();
            break;
          } catch (_e) {
            // try next
          }
        }
        if (cancelled) return;
        if (payload && typeof payload === 'object') {
          const p = payload as { value?: unknown; change?: unknown; positive?: unknown };
          const val = Number(p.value);
          const change = Number(p.change);
          const positive = Boolean(p.positive);
          if (Number.isFinite(val) && Number.isFinite(change)) {
            setData({ value: val, change, positive });
          } else {
            // keep as null to avoid showing mock/fallbacks
            setData(null);
          }
        } else {
          // no payload -> keep null to avoid mock/fallbacks
          setData(null);
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    load();
    return () => {
      cancelled = true; controller.abort();
    };
  }, [interval, team, unitId, endpoints.join('|')]);

  return { data, loading } as const;
}

function Tile({ title, item, loading, colorClass, pct, wrapperClass }: { title: string; item: CtbItem | null; loading: boolean; colorClass: string; pct?: number; wrapperClass?: string }) {
  const t = useTr();
  const value = item?.value ?? 0;
  const change = item?.change ?? 0;
  const isDecrease = change < 0;
  const isIncrease = change > 0;
  const trendColor = isDecrease ? 'text-emerald-600' : isIncrease ? 'text-red-500' : 'text-gray-400';
  const pctText = typeof pct === 'number' && isFinite(pct) ? `${pct}% ${t('ofTotal')}` : '—';
  const prevValue = Number.isFinite(value) && Number.isFinite(change) && change !== -100
    ? value / (1 + (change / 100))
    : undefined;
  const prevText = prevValue != null && isFinite(prevValue) ? prevValue.toFixed(1) : null;

  return (
    <div className={`relative p-4 rounded-lg bg-gray-50 border border-gray-100 ${wrapperClass ?? ''}`}>
      <div className={`absolute top-0 left-0 h-1 rounded-t-lg ${colorClass}`} style={{ width: '100%' }} />
      <p className="text-[12px] text-gray-500">{title}</p>
      <div className="flex flex-wrap items-baseline gap-x-2 gap-y-0.5 mt-1">
        <p className="text-[22px] text-gray-900" style={{ fontWeight: 700 }}>{loading ? '—' : `${value}h`}</p>
        <span className={`flex flex-wrap items-center gap-1 text-[12px] ${trendColor}`}>
          {!loading && isDecrease && <ArrowDownRight className="w-3.5 h-3.5" />}
          {!loading && isIncrease && <ArrowUpRight className="w-3.5 h-3.5" />}
          {!loading && !isIncrease && !isDecrease && <TrendingDown className="w-3.5 h-3.5 opacity-30" />}
          <span className="font-semibold">{loading ? '0%' : `${Math.abs(change)}%`}</span>
          {!loading && (
            <span className="text-gray-400">
              {t('vsPrevPeriod')}{prevText ? ` · ${t('was')} ${prevText}h` : ''}
            </span>
          )}
        </span>
      </div>
      <p className="text-[11px] text-gray-500 mt-1" style={{ fontWeight: 600 }}>{pctText}</p>
    </div>
  );
}

export function CycleTimeBreakdown({ interval, team }: Props) {
  const { selectedUnitId } = useTeam();
  const { timedOut, reset } = useNoDataTimeout(180000);

  // Build endpoints as base paths; unitId and interval are passed as query params
  const endpoints = useMemo(() => {
    return {
      Coding: ['/api/metrics/dora/ctb/coding'],
      Review: ['/api/metrics/dora/ctb/review'],
      Pickup: ['/api/metrics/dora/ctb/pickup'],
      Merge: ['/api/metrics/dora/ctb/merge'],
    };
  }, []);

  const coding = useCtbTile(endpoints.Coding, interval, team, selectedUnitId);
  const review = useCtbTile(endpoints.Review, interval, team, selectedUnitId);
  const pickup = useCtbTile(endpoints.Pickup, interval, team, selectedUnitId);
  const merge = useCtbTile(endpoints.Merge, interval, team, selectedUnitId);

  // Reset timeout when filters change
  useEffect(() => {
    reset();
  }, [interval, team, selectedUnitId]);

  // Determine loading and data presence
  const allLoading = coding.loading && review.loading && pickup.loading && merge.loading;
  const anyData = !!(coding.data || review.data || pickup.data || merge.data);

  // Compute total and per-tile percentages
  const values = [coding.data?.value ?? 0, review.data?.value ?? 0, pickup.data?.value ?? 0, merge.data?.value ?? 0];
  const total = values.reduce((s, v) => s + (Number.isFinite(v) ? v : 0), 0);
  const pctOf = (v?: number) => {
    if (!Number.isFinite(total) || total <= 0) return undefined;
    const num = Number(v);
    if (!Number.isFinite(num) || num < 0) return undefined;
    return Math.round((num / total) * 100);
  };

  const t = useTr();
  const pick = usePick();
  if (!anyData) {
    return (
      <div className="bg-white rounded-xl border border-gray-200 p-5 min-h-[120px] flex items-center justify-center">
        {!timedOut ? (
          <LoadingSpinner size={20} />
        ) : (
          <span className="text-[12px] text-gray-500">{t('noData')}</span>
        )}
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl border border-gray-200 p-5">
      <div className="flex items-start gap-2 mb-4">
        <h2 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>{t('cycleTimeBreakdown')}</h2>
        {total > 0 && (
          <span className="ml-auto text-[12px] text-gray-500 whitespace-nowrap">
            {pick('Total = lead time', 'Suma = lead time')}: <b className="text-gray-900">{Math.round(total * 10) / 10}h</b>
          </span>
        )}
        <HelpTip
          size="sm"
          content={pick("Average hours per stage for merge requests merged into main/master in the period: Coding = first commit → MR opened, Pickup = MR opened → first approval, Review = first → last approval, Merge = last approval → merge. The four stages add up to the Lead Time. Percentage under each tile is that stage's share.", "Średnie godziny na etap dla merge requestów zmergowanych do main/master w okresie: Kodowanie = pierwszy commit → otwarcie MR, Podjęcie = otwarcie MR → pierwsza akceptacja, Przegląd = pierwsza → ostatnia akceptacja, Scalenie = ostatnia akceptacja → merge. Suma czterech etapów to Lead Time. Procent pod kartą to udział etapu.")}
        />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <Tile title={t('coding')} item={coding.data} loading={coding.loading} colorClass="bg-purple-700" pct={pctOf(coding.data?.value)} wrapperClass="border-purple-300" />
        <Tile title={t('pickup')} item={pickup.data} loading={pickup.loading} colorClass="bg-orange-600" pct={pctOf(pickup.data?.value)} wrapperClass="border-orange-300" />
        <Tile title={t('review')} item={review.data} loading={review.loading} colorClass="bg-yellow-500" pct={pctOf(review.data?.value)} wrapperClass="border-yellow-300" />
        <Tile title={t('merge')} item={merge.data} loading={merge.loading} colorClass="bg-green-700" pct={pctOf(merge.data?.value)} wrapperClass="border-green-300" />
      </div>
    </div>
  );
}

export default CycleTimeBreakdown;
