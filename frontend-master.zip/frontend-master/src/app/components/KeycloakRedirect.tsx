import { useEffect } from 'react';

/**
 * Simple component that redirects the user to the backend SSO entrypoint.
 * Used as a catch-all route to ensure unknown paths also trigger SSO/login.
 */
export default function KeycloakRedirect() {
  useEffect(() => {
    // Backend route that should initiate Keycloak login flow
    window.location.href = '/api/';
  }, []);

  // Render nothing while redirecting
  return null;
}
