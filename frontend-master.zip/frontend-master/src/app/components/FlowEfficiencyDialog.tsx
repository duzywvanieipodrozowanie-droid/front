import { useEffect, useMemo, useState } from 'react';
import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import LoadingSpinner from './LoadingSpinner';
import { usePick } from '../i18n';

// "Flow efficiency" popup on Overview, from /api/metrics/flow/efficiency: for Jira work items gone LIVE in the period,
// how their time from the first In Progress until Live splits by status into active work and waiting
// (queues before test, blocked, DONE waiting for deployment...). Only work items with a Fix Version count; "Right now"
// shows DONE split into with / without a Fix Version.

type StatusShare = { status: string; active: boolean; days: number; sharePct: number; avgDays: number; items: number };
type CurrentStatus = { status: string; active: boolean; fixVersion?: boolean | null; items: number; avgDaysInStatus: number };
type ItemEfficiency = {
  key: string; summary?: string | null; url?: string | null; type?: string | null;
  efficiencyPct: number; totalDays: number; waitingDays: number;
  longestWaitStatus?: string | null; longestWaitDays?: number | null;
};
type FlowEfficiency = {
  items: number;
  /** Gone Live without a Fix Version: left out of the indicator (older core: absent). */
  itemsWithoutFixVersion?: number;
  avgEfficiencyPct?: number | null;
  activeDays: number;
  waitingDays: number;
  histogram: Array<{ from: number; till: number; count: number }>;
  statuses: StatusShare[];
  bottleneck?: string | null;
  current: CurrentStatus[];
  slowest: ItemEfficiency[];
};

// Explicit hex colors: theme.css remaps Tailwind indigo/green classes to the brand palette.
const ACTIVE = '#10b981';
const WAITING = '#f59e0b';
const STUCK = '#ef4444';
/** A waiting status taking at least this share of the time is flagged as a problem. */
const STUCK_SHARE_PCT = 25;
const card = 'bg-white dark:bg-[#121317] rounded-xl border border-gray-200 dark:border-white/10 p-4';
const muted = 'text-gray-500 dark:text-gray-400';

function fmt(v: number | null | undefined): string {
  if (v == null) return '—';
  return Number.isInteger(v) ? String(v) : v.toFixed(1);
}

function statusColor(s: { active: boolean; sharePct?: number }): string {
  if (s.active) return ACTIVE;
  return (s.sharePct ?? 0) >= STUCK_SHARE_PCT ? STUCK : WAITING;
}

export function FlowEfficiencyDialog({ open, onOpenChange, unitId, interval, teamName, dateRange }: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  unitId?: string | null;
  interval: string;
  teamName?: string;
  dateRange?: string;
}) {
  const pick = usePick();
  const [data, setData] = useState<FlowEfficiency | null>(null);
  const [loading, setLoading] = useState(false);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    const controller = new AbortController();
    async function load() {
      setLoading(true);
      setFailed(false);
      try {
        const params = new URLSearchParams({ interval });
        if (unitId) params.set('unitId', unitId);
        const res = await fetch(`/api/metrics/flow/efficiency?${params.toString()}`, { credentials: 'include', signal: controller.signal });
        if (!res.ok) throw new Error(String(res.status));
        const js = (await res.json()) as FlowEfficiency;
        if (!cancelled) setData(js);
      } catch {
        if (!cancelled) { setData(null); setFailed(true); }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; controller.abort(); };
  }, [open, unitId, interval]);

  const histogram = useMemo(() => (data?.histogram ?? []).map((b) => ({
    label: `${b.from}–${b.till}%`, from: b.from, count: b.count,
  })), [data]);
  const totalDays = (data?.activeDays ?? 0) + (data?.waitingDays ?? 0);
  const activePct = totalDays > 0 ? ((data?.activeDays ?? 0) / totalDays) * 100 : 0;
  const bottleneck = data?.statuses.find((s) => s.status === data.bottleneck);
  const stuck = (data?.statuses ?? []).filter((s) => !s.active && s.sharePct >= STUCK_SHARE_PCT);
  const currentTotal = (data?.current ?? []).reduce((s, c) => s + c.items, 0);
  const withoutFixVersion = data?.itemsWithoutFixVersion ?? 0;
  const currentLabel = (c: CurrentStatus) => c.fixVersion == null ? c.status
    : `${c.status} · ${c.fixVersion ? 'Fix Version' : pick('no Fix Version', 'bez Fix Version')}`;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[1280px] max-h-[92vh] overflow-y-auto bg-gray-50 dark:bg-[#0b0c0f]">
        <DialogHeader>
          <DialogTitle className="text-[18px]">Flow efficiency</DialogTitle>
          <DialogDescription className="text-[12px]">
            {pick('Active vs waiting time of Jira work items gone Live in the period', 'Czas aktywnej pracy vs czekania zadań z Jiry, które weszły na Live w okresie')}
            {teamName && teamName !== 'All Teams' ? ` · ${teamName}` : ''}{dateRange ? ` · ${dateRange}` : ''}
            {' · '}{pick('from the first In Progress until Live', 'od pierwszego In Progress do Live')}
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="min-h-[300px] flex items-center justify-center"><LoadingSpinner size={22} /></div>
        ) : failed || !data ? (
          <div className={`min-h-[160px] flex items-center justify-center text-[13px] ${muted}`}>
            {pick('Could not load flow efficiency data.', 'Nie udało się pobrać danych flow efficiency.')}
          </div>
        ) : data.items === 0 ? (
          <div className={`min-h-[160px] flex items-center justify-center text-[13px] ${muted}`}>
            {pick('No work item with a Fix Version went Live in this period.', 'Żadne zadanie z Fix Version nie weszło na Live w tym okresie.')}
            {withoutFixVersion > 0 ? pick(` (${withoutFixVersion} without a Fix Version left out)`, ` (pominięto ${withoutFixVersion} bez Fix Version)`) : ''}
          </div>
        ) : (
          <div className="space-y-4">
            {/* Headline */}
            <div className="grid grid-cols-1 lg:grid-cols-[0.9fr_1.6fr] gap-4">
              <div className={card}>
                <div className="flex items-end gap-3">
                  <span className="text-[44px] leading-none" style={{ fontWeight: 700, color: '#2563eb' }}>{fmt(data.avgEfficiencyPct)}%</span>
                  <span className={`text-[12px] ${muted} pb-1`}>{pick('average flow efficiency', 'średnie flow efficiency')}</span>
                </div>
                <p className={`text-[12px] ${muted} mt-2`}>
                  {pick(`${data.items} work items with a Fix Version gone Live`, `${data.items} zadań z Fix Version weszło na Live`)}
                  {withoutFixVersion > 0 ? pick(` (${withoutFixVersion} without left out)`, ` (pominięto ${withoutFixVersion} bez)`) : ''}
                  {' · '}{pick('active', 'aktywnie')} {fmt(data.activeDays)} {pick('d', 'dni')}
                  {' · '}{pick('waiting', 'czekanie')} {fmt(data.waitingDays)} {pick('d', 'dni')}
                </p>
                <div className="mt-3 h-3 rounded-full overflow-hidden flex bg-gray-100 dark:bg-white/10">
                  <div style={{ width: `${activePct}%`, backgroundColor: ACTIVE }} />
                  <div style={{ width: `${100 - activePct}%`, backgroundColor: WAITING }} />
                </div>
                <div className="flex justify-between text-[11px] mt-1">
                  <span style={{ color: ACTIVE }}>{pick('Active', 'Aktywnie')} {fmt(activePct)}%</span>
                  <span style={{ color: WAITING }}>{pick('Waiting', 'Czekanie')} {fmt(100 - activePct)}%</span>
                </div>
                {bottleneck && (
                  <div className="mt-4 rounded-lg border px-3 py-2 text-[12px]" style={{ borderColor: '#fecaca', backgroundColor: 'rgba(239,68,68,0.06)' }}>
                    <span style={{ color: STUCK, fontWeight: 600 }}>⚠ {pick('Biggest wait', 'Największe czekanie')}: {bottleneck.status}</span>
                    <span className={muted}> — {fmt(bottleneck.sharePct)}% {pick('of the time', 'czasu')}, {pick('avg', 'średnio')} {fmt(bottleneck.avgDays)} {pick('d per item', 'dni na zadanie')}</span>
                    {bottleneck.status === 'DONE' && (
                      <div className={`${muted} mt-0.5`}>{pick('Work is done but waits for deployment to Live.', 'Praca skończona, ale czeka na wdrożenie na Live.')}</div>
                    )}
                  </div>
                )}
              </div>

              <div className={card}>
                <h3 className="text-[14px]" style={{ fontWeight: 600 }}>{pick('Work items by flow efficiency', 'Zadania wg flow efficiency')}</h3>
                <p className={`text-[12px] ${muted} mb-2`}>{pick('Share of an item\'s time spent in active statuses', 'Udział czasu zadania w statusach aktywnych')}</p>
                <div className="h-44">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={histogram} barCategoryGap={3}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
                      <XAxis dataKey="label" tick={{ fontSize: 10 }} interval={0} />
                      <YAxis allowDecimals={false} tick={{ fontSize: 10 }} width={28} />
                      <Tooltip formatter={(v: number) => [v, pick('items', 'zadań')]} />
                      <Bar dataKey="count" isAnimationActive={false} radius={[3, 3, 0, 0]}>
                        {histogram.map((b) => (
                          <Cell key={b.from} fill={b.from < 20 ? STUCK : b.from < 40 ? WAITING : ACTIVE} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

            {/* Where the time goes, by status */}
            <div className={card}>
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <h3 className="text-[14px]" style={{ fontWeight: 600 }}>{pick('Where the time goes — by status', 'Gdzie ucieka czas — wg statusów')}</h3>
                <div className="flex items-center gap-3 text-[11px]">
                  <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: ACTIVE }} />{pick('active', 'aktywny')}</span>
                  <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: WAITING }} />{pick('waiting', 'czekanie')}</span>
                  <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: STUCK }} />{pick(`waiting ≥ ${STUCK_SHARE_PCT}%`, `czekanie ≥ ${STUCK_SHARE_PCT}%`)}</span>
                </div>
              </div>
              <div className="mt-3 h-8 rounded-md overflow-hidden flex">
                {data.statuses.filter((s) => s.sharePct > 0).map((s) => (
                  <div
                    key={s.status}
                    title={`${s.status}: ${fmt(s.sharePct)}%`}
                    className="h-full flex items-center justify-center text-[10px] text-white overflow-hidden whitespace-nowrap border-r border-white/60"
                    style={{ width: `${s.sharePct}%`, backgroundColor: statusColor(s), fontWeight: 600 }}
                  >
                    {s.sharePct >= 7 ? `${s.status} ${Math.round(s.sharePct)}%` : ''}
                  </div>
                ))}
              </div>
              <table className="w-full mt-4 text-[12px]">
                <thead>
                  <tr className={`text-left ${muted}`}>
                    <th className="py-1.5 font-normal">Status</th>
                    <th className="py-1.5 font-normal">{pick('Type', 'Rodzaj')}</th>
                    <th className="py-1.5 font-normal w-[38%]">{pick('Share of time', 'Udział w czasie')}</th>
                    <th className="py-1.5 font-normal text-right">{pick('Avg per item', 'Średnio na zadanie')}</th>
                    <th className="py-1.5 font-normal text-right">{pick('Items', 'Zadań')}</th>
                  </tr>
                </thead>
                <tbody>
                  {data.statuses.map((s) => (
                    <tr key={s.status} className="border-t border-gray-100 dark:border-white/5">
                      <td className="py-1.5" style={{ fontWeight: 600 }}>{s.status}</td>
                      <td className="py-1.5">
                        <span className="px-1.5 py-0.5 rounded text-[10px]" style={{ color: statusColor(s), backgroundColor: `${statusColor(s)}1a` }}>
                          {s.active ? pick('active', 'aktywny') : pick('waiting', 'czekanie')}
                        </span>
                      </td>
                      <td className="py-1.5">
                        <div className="flex items-center gap-2">
                          <div className="flex-1 h-2 rounded-full bg-gray-100 dark:bg-white/10 overflow-hidden">
                            <div className="h-full rounded-full" style={{ width: `${Math.min(100, s.sharePct)}%`, backgroundColor: statusColor(s) }} />
                          </div>
                          <span className="w-12 text-right tabular-nums">{fmt(s.sharePct)}%</span>
                        </div>
                      </td>
                      <td className="py-1.5 text-right tabular-nums">{fmt(s.avgDays)} {pick('d', 'dni')}</td>
                      <td className="py-1.5 text-right tabular-nums">{s.items}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {stuck.length > 0 && (
                <p className="text-[12px] mt-3" style={{ color: STUCK }}>
                  {pick('Work items get stuck in', 'Zadania utykają w')}: {stuck.map((s) => `${s.status} (${fmt(s.sharePct)}%)`).join(', ')}
                  {stuck.some((s) => s.status === 'DONE') ? pick(' — DONE before Live usually means waiting for deployment.', ' — DONE przed Live zwykle oznacza czekanie na wdrożenie.') : ''}
                </p>
              )}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-[0.8fr_1.2fr] gap-4">
              {/* Right now */}
              <div className={card}>
                <h3 className="text-[14px]" style={{ fontWeight: 600 }}>{pick('Right now', 'Teraz')}</h3>
                <p className={`text-[12px] ${muted} mb-3`}>
                  {pick(`${currentTotal} work items in progress or DONE waiting for Live`, `${currentTotal} zadań w toku lub w DONE czekających na Live`)}
                </p>
                <div className="space-y-2">
                  {data.current.map((c) => (
                    <div key={`${c.status}|${c.fixVersion ?? ''}`} className="flex items-center gap-2 text-[12px]">
                      <span className="w-44 truncate" style={{ fontWeight: 600 }} title={currentLabel(c)}>{currentLabel(c)}</span>
                      <div className="flex-1 h-2 rounded-full bg-gray-100 dark:bg-white/10 overflow-hidden">
                        <div className="h-full rounded-full" style={{ width: `${currentTotal ? (c.items / currentTotal) * 100 : 0}%`, backgroundColor: c.active ? ACTIVE : WAITING }} />
                      </div>
                      <span className="w-8 text-right tabular-nums">{c.items}</span>
                      <span className={`w-24 text-right ${muted}`}>{pick('avg', 'śr.')} {fmt(c.avgDaysInStatus)} {pick('d', 'dni')}</span>
                    </div>
                  ))}
                  {data.current.length === 0 && <div className={`text-[12px] ${muted}`}>{pick('Nothing in progress.', 'Nic w toku.')}</div>}
                </div>
              </div>

              {/* Longest waiting items */}
              <div className={card}>
                <h3 className="text-[14px]" style={{ fontWeight: 600 }}>{pick('Most waiting', 'Najdłużej czekające')}</h3>
                <p className={`text-[12px] ${muted} mb-2`}>{pick('Work items gone Live with the most waiting time', 'Zadania z Live z najdłuższym czasem czekania')}</p>
                <table className="w-full text-[12px]">
                  <thead>
                    <tr className={`text-left ${muted}`}>
                      <th className="py-1 font-normal">{pick('Item', 'Zadanie')}</th>
                      <th className="py-1 font-normal text-right">FE</th>
                      <th className="py-1 font-normal text-right">{pick('Total', 'Razem')}</th>
                      <th className="py-1 font-normal text-right">{pick('Waiting', 'Czekanie')}</th>
                      <th className="py-1 pl-3 font-normal">{pick('Longest wait', 'Najdłużej w')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.slowest.map((i) => (
                      <tr key={i.key} className="border-t border-gray-100 dark:border-white/5">
                        <td className="py-1.5 max-w-[260px]">
                          {i.url ? <a href={i.url} target="_blank" rel="noreferrer" className="text-blue-600 hover:underline" style={{ fontWeight: 600 }}>{i.key}</a> : <span style={{ fontWeight: 600 }}>{i.key}</span>}
                          <span className={`${muted} ml-1.5 truncate inline-block max-w-[170px] align-bottom`}>{i.summary}</span>
                        </td>
                        <td className="py-1.5 text-right tabular-nums" style={{ color: i.efficiencyPct < 20 ? STUCK : i.efficiencyPct < 40 ? WAITING : ACTIVE, fontWeight: 600 }}>{fmt(i.efficiencyPct)}%</td>
                        <td className="py-1.5 text-right tabular-nums">{fmt(i.totalDays)} {pick('d', 'dni')}</td>
                        <td className="py-1.5 text-right tabular-nums">{fmt(i.waitingDays)} {pick('d', 'dni')}</td>
                        <td className="py-1.5 pl-3">{i.longestWaitStatus ? `${i.longestWaitStatus} · ${fmt(i.longestWaitDays)} ${pick('d', 'dni')}` : '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <p className={`text-[11px] ${muted}`}>
              {pick(
                'Active statuses: Analysis, In Progress, In Review, In Test, UAT, In UAT. Every other status between the first In Progress and Live (To Test, Developed, Tested, PO Acceptance, On Hold, Blocked, Done…) counts as waiting. Only work items with a Fix Version count.',
                'Statusy aktywne: Analysis, In Progress, In Review, In Test, UAT, In UAT. Każdy inny status między pierwszym In Progress a Live (To Test, Developed, Tested, PO Acceptance, On Hold, Blocked, Done…) to czekanie. Liczone są tylko zadania z Fix Version.',
              )}
            </p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
