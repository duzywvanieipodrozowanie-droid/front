import React, { useEffect, useRef, useState } from 'react';
import { User, Lock } from 'lucide-react';

export interface ModalLoginProps {
  open: boolean;
  onClose?: () => void;
  onSubmit?: (login: string, password: string) => void;
  title?: string;
  initialLogin?: string;
  initialPassword?: string;
  loginButtonText?: string;
  backgroundImageUrl?: string;
  /**
   * Vertical position for the TOP edge of the login card relative to the viewport height.
   * Example: 52 means top: 52vh
   */
  feetTopVH?: number;
}

/**
 * A fully stylized modal login scene matching the provided reference.
 * - Deep blue night sky with vignette
 * - Warm flashlight cone aiming to top-right
 * - Scattered code-symbol constellations inside the lit area
 * - White rounded card with title, inputs (user + lock icons) and a full-width LOGIN button
 */
export default function ModalLogin({
  open,
  onClose,
  onSubmit,
  title = 'WELCOME',
  initialLogin = '',
  initialPassword = '',
  loginButtonText = 'LOGIN',
  backgroundImageUrl,
  feetTopVH = 56,
}: ModalLoginProps) {
  const [login, setLogin] = useState(initialLogin);
  const [password, setPassword] = useState(initialPassword);
  const dialogRef = useRef<HTMLDivElement>(null);
  const firstInputRef = useRef<HTMLInputElement>(null);
  const [scale, setScale] = useState(1);

  // Compute a viewport-proportional scale so the modal grows/shrinks with screen size
  useEffect(() => {
    function calcScale() {
      const vw = Math.max(window.innerWidth, 320);
      const vh = Math.max(window.innerHeight, 320);
      // Take the tighter constraint between width and height against a comfortable base
      const sW = vw / 1024; // 1024px width -> scale 1
      const sH = vh / 900;  // 900px height -> scale 1
      const s = Math.min(sW, sH);
      // Clamp to keep readability
      const clamped = Math.max(0.7, Math.min(s, 1.25));
      setScale(Number(clamped.toFixed(3)));
    }
    calcScale();
    window.addEventListener('resize', calcScale);
    return () => window.removeEventListener('resize', calcScale);
  }, []);

  useEffect(() => {
    if (open) {
      // Focus the first input when the modal opens
      setTimeout(() => firstInputRef.current?.focus(), 0);
      const keyHandler = (e: KeyboardEvent) => {
        if (e.key === 'Escape') {
          onClose?.();
        }
      };
      window.addEventListener('keydown', keyHandler);
      return () => window.removeEventListener('keydown', keyHandler);
    }
  }, [open, onClose]);

  if (!open) return null;

  function submit(e: React.FormEvent) {
    e.preventDefault();
    onSubmit?.(login, password);
  }

  return (
    <div className="fixed inset-0 z-[300]" role="dialog" aria-modal="true" aria-labelledby="zen-login-title">
      {/* Clickable backdrop without dimming to preserve the background image */}
      <div className="absolute inset-0" onClick={onClose} />

      {/* Background image layer: image reduced in size with dark navy fill around */}
      <div
        aria-hidden
        className="absolute inset-0"
        style={{
          backgroundImage: backgroundImageUrl ? `url(${backgroundImageUrl})` : undefined,
          backgroundRepeat: 'no-repeat',
          backgroundPosition: 'top center',
          // Make the background image smaller and let the rest be filled with deep navy color
          backgroundSize: 'auto 80vh',
          backgroundColor: '#00050b',
        }}
      />

      {/* Positioned login card */}
      <div
        className="absolute z-10 w-full flex justify-center p-4 sm:p-8"
        ref={dialogRef}
        style={{ top: `${feetTopVH}vh`, left: 0, right: 0 }}
      >
        <div className="w-[92%] max-w-md rounded-2xl border border-gray-100 bg-white/95 backdrop-blur-[1px] p-5 text-center shadow-2xl" style={{ transform: `scale(${scale})`, transformOrigin: 'top center' }}>
          <h1 id="zen-login-title" className="text-[#0b1c31] text-[18px]" style={{ fontWeight: 800 }}>
            {title}
          </h1>

          <form onSubmit={submit} className="space-y-3 text-left mt-3">
            <div className="relative">
              <User className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                ref={firstInputRef}
                value={login}
                onChange={(e) => setLogin(e.target.value)}
                className="w-full border border-gray-300 bg-white text-gray-800 rounded-md pl-8 pr-3 py-2 text-[13px] focus:outline-none focus:ring-2 focus:ring-sky-300"
                placeholder="LOGIN"
              />
            </div>
            <div className="relative">
              <Lock className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full border border-gray-300 bg-white text-gray-800 rounded-md pl-8 pr-3 py-2 text-[13px] focus:outline-none focus:ring-2 focus:ring-sky-300"
                placeholder="PASSWORD ••••••••"
              />
            </div>
            <button
              type="submit"
              className="w-full px-4 py-2 text-[12px] rounded-md bg-[#0f2a54] text-white hover:bg-[#143769] transition-colors"
              style={{ fontWeight: 800 }}
            >
              {loginButtonText}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
