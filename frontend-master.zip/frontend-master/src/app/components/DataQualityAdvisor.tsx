import React, { useMemo } from 'react';
import { usePick } from '../i18n';

// Generic shapes reused from GitlabDetails page
export type SiloPair = {
  a: string;
  b: string;
  total: number;
  modules: { name: string; count: number }[];
};

export type ManagerAgg = {
  avgCycleMin: number | null;
  avgPickupMin: number | null;
  avgReviewMin: number | null;
  avgTimeToApproveMin: number | null;
  reviewerSpeed: { email: string; avgApproveMinutes: number; count: number }[];
  reviewLoad: { email: string; count: number }[];
  topModules: { name: string; count: number }[];
  topProjects: { name: string; count: number }[];
  deployDaily: [string, number][];
  deployWeekly: [string, number][];
  stale: any[];
  abandoned: any[];
};

export type SummaryAgg = {
  totalMR: number;
  notApproved: number;
  avgReview: number | null;
} | null;

export type Finding = {
  severity: 'high' | 'medium' | 'low';
  title: string;
  detail: string;
  recommendation: string;
  count?: number;
};

function toList(payload: any): any[] {
  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload?.items)) return payload.items;
  if (Array.isArray(payload?.values)) return payload.values;
  if (Array.isArray(payload?.data)) return payload.data;
  return [];
}

function parseDate(v: any): number | null {
  if (!v) return null;
  const s = typeof v === 'string' || typeof v === 'number' || v instanceof Date ? new Date(v as any) : null;
  const t = s && !isNaN(s.getTime()) ? s.getTime() : null;
  return t;
}

function pct(n: number, d: number): string {
  if (!d) return '0%';
  return `${Math.round((n / d) * 100)}%`;
}

export function DataQualityAdvisor({ data, mgr, summary, siloPairs }: { data: any; mgr: ManagerAgg | null; summary: SummaryAgg; siloPairs: SiloPair[] }) {
  const pick = usePick();

  const advisor = useMemo(() => {
    const findings: Finding[] = [];
    const items = toList(data);
    const total = items.length;

    // Helpers
    const normApprovers = (it: any): string[] => {
      const src = it?.source || {};
      const approvalsRaw = src?.approverEmails ?? it?.approvals ?? it?.approvedBy ?? it?.reviewers ?? it?.reviews ?? [];
      const arr: any[] = Array.isArray(approvalsRaw) ? approvalsRaw : (approvalsRaw == null ? [] : [approvalsRaw]);
      return arr
        .map((v) => (typeof v === 'string' ? v : (v && (v.email || v.name || v.login || v.username)) || ''))
        .map((s) => String(s || '').trim().toLowerCase())
        .filter(Boolean);
    };
    const authorOf = (it: any): string => {
      const src = it?.source || {};
      const authorEmail = typeof src?.authorEmail === 'string' ? src.authorEmail : '';
      const a = (authorEmail || it?.author || it?.createdBy || it?.user || it?.owner || it?.authorId || '').toString();
      return a.toLowerCase();
    };

    let mergedWithoutApprover = 0;
    let selfApprovals = 0;
    let missingTitle = 0;
    let missingUpdatedAt = 0;
    let missingModule = 0;
    let missingProject = 0;
    let badTimestamps = 0; // merged before created, etc.

    let mergedCount = 0;

    for (const it of items as any[]) {
      const src = it?.source || {};
      const title = String(it?.title ?? src?.title ?? '').trim();
      const createdAt = it?.createdAt ?? src?.createdAt ?? it?.created_at ?? src?.created_at;
      const mergedAt = it?.mergedAt ?? src?.mergedAt ?? it?.merged_at ?? src?.merged_at;
      const updatedAt = it?.updatedAt ?? src?.updatedAt ?? it?.updated_at ?? src?.updated_at;
      const approvers = normApprovers(it);
      const author = authorOf(it);

      if (!title) missingTitle++;
      if (!updatedAt) missingUpdatedAt++;

      const moduleName = String((it as any)?.moduleName ?? src?.module ?? '').trim();
      const projectId = String((it as any)?.projectId ?? (src as any)?.projectId ?? (it as any)?.project ?? (it as any)?.project_id ?? '').trim();
      if (!moduleName) missingModule++;
      if (!projectId) missingProject++;

      const cTs = parseDate(createdAt);
      const mTs = parseDate(mergedAt);
      if (mTs != null) mergedCount++;
      if (cTs != null && mTs != null && mTs < cTs) badTimestamps++;

      if (mTs != null && approvers.length === 0) mergedWithoutApprover++;
      if (approvers.length > 0) {
        if (author) {
          for (const a of approvers) {
            if (a && author && a === author) { selfApprovals++; break; }
          }
        }
      }
    }

    // Use mgr and summary for process-quality insights
    const staleCnt = Array.isArray(mgr?.stale) ? mgr!.stale.length : 0;
    const abandonedCnt = Array.isArray(mgr?.abandoned) ? mgr!.abandoned.length : 0;
    const notApproved = typeof summary?.notApproved === 'number' ? (summary!.notApproved as number) : 0;
    const slowReview = typeof mgr?.avgReviewMin === 'number' ? (mgr!.avgReviewMin as number) : null;
    const slowPickup = typeof mgr?.avgPickupMin === 'number' ? (mgr!.avgPickupMin as number) : null;

    // Findings with severities and concrete recs
    if (mergedWithoutApprover > 0) {
      findings.push({
        severity: mergedWithoutApprover / Math.max(1, mergedCount) > 0.3 ? 'high' : 'medium',
        title: pick('Merged without approver', 'Merge bez akceptującego'),
        detail: pick(
          `${mergedWithoutApprover} merged MR(s) have no approver (${pct(mergedWithoutApprover, Math.max(1, mergedCount))} of merged).`,
          `${mergedWithoutApprover} zmergowanych MR-ów nie ma akceptującego (${pct(mergedWithoutApprover, Math.max(1, mergedCount))} z merged).`
        ),
        recommendation: pick(
          'Enforce at least one approval in project settings; set CODEOWNERS and required reviewers.',
          'Wymuś co najmniej jedną akceptację w ustawieniach projektu; dodaj CODEOWNERS i wymaganych reviewerów.'
        ),
        count: mergedWithoutApprover,
      });
    }

    if (selfApprovals > 0) {
      findings.push({
        severity: 'high',
        title: pick('Self-approvals detected', 'Wykryto samoakceptacje'),
        detail: pick(
          `${selfApprovals} MR(s) approved by their author.`,
          `${selfApprovals} MR-y zaakceptowane przez autora.`
        ),
        recommendation: pick(
          'Disable self-approval in repository rules; add branch protection and reviewer rotation.',
          'Zablokuj samoakceptacje w regułach repo; dodaj ochronę gałęzi i rotację reviewerów.'
        ),
        count: selfApprovals,
      });
    }

    if (badTimestamps > 0) {
      findings.push({
        severity: 'medium',
        title: pick('Inconsistent timestamps', 'Niespójne znaczniki czasu'),
        detail: pick(
          `${badTimestamps} MR(s) have mergedAt earlier than createdAt — likely importer bug.`,
          `${badTimestamps} MR-ów ma mergedAt wcześniejsze niż createdAt — prawdopodobnie błąd importu.`
        ),
        recommendation: pick(
          'Verify MR sync job timezones and source fields; normalize dates server-side.',
          'Sprawdź strefy czasowe i mapowanie pól w synchronizacji; normalizuj daty po stronie serwera.'
        ),
        count: badTimestamps,
      });
    }

    if (missingTitle > 0 || missingUpdatedAt > 0) {
      if (missingTitle > 0) {
        findings.push({
          severity: 'low',
          title: pick('Missing titles', 'Brak tytułów'),
          detail: pick(`${missingTitle} MR(s) without title.`, `${missingTitle} MR-ów bez tytułu.`),
          recommendation: pick('Make title required in MR template.', 'Wymuś tytuł w szablonie MR.'),
          count: missingTitle,
        });
      }
      if (missingUpdatedAt > 0) {
        findings.push({
          severity: 'low',
          title: pick('Missing updatedAt', 'Brak updatedAt'),
          detail: pick(`${missingUpdatedAt} MR(s) missing updatedAt.`, `${missingUpdatedAt} MR-ów bez updatedAt.`),
          recommendation: pick('Ensure MR sync includes updatedAt field.', 'Upewnij się, że synchronizacja MR zawiera pole updatedAt.'),
          count: missingUpdatedAt,
        });
      }
    }

    if (missingModule > 0 || missingProject > 0) {
      if (missingModule > 0) {
        findings.push({
          severity: 'medium',
          title: pick('Unassigned module/service', 'Brak przypisanego modułu/serwisu'),
          detail: pick(`${missingModule} MR(s) without module.`, `${missingModule} MR-ów bez modułu.`),
          recommendation: pick('Tag MRs with module via labels or path conventions; enrich during ingestion.', 'Oznaczaj MR-y modułem etykietą lub po ścieżkach; wzbogacaj przy imporcie.'),
          count: missingModule,
        });
      }
      if (missingProject > 0) {
        findings.push({
          severity: 'medium',
          title: pick('Missing project id', 'Brak identyfikatora projektu'),
          detail: pick(`${missingProject} MR(s) without project id.`, `${missingProject} MR-ów bez id projektu.`),
          recommendation: pick('Include projectId in MR payload; map repos to canonical ids.', 'Dodaj projectId w payload MR; zmapuj repo do kanonicznych id.'),
          count: missingProject,
        });
      }
    }

    if (staleCnt > 0) {
      findings.push({
        severity: staleCnt / Math.max(1, total) > 0.15 ? 'high' : 'medium',
        title: pick('Stale MRs', 'Przeterminowane MR-y'),
        detail: pick(
          `${staleCnt} open MR(s) with no update >3 days (${pct(staleCnt, Math.max(1, total))} of current list).`,
          `${staleCnt} otwartych MR-ów bez aktualizacji >3 dni (${pct(staleCnt, Math.max(1, total))} listy).`
        ),
        recommendation: pick(
          'Set SLA for review response; auto-remind authors; auto-close after inactivity threshold.',
          'Ustal SLA na reakcję review; automatyczne przypomnienia; auto-zamykanie po progu braku aktywności.'
        ),
        count: staleCnt,
      });
    }

    if (abandonedCnt > 0) {
      findings.push({
        severity: abandonedCnt / Math.max(1, total) > 0.1 ? 'medium' : 'low',
        title: pick('Abandoned changes', 'Porzucone zmiany'),
        detail: pick(
          `${abandonedCnt} closed without merge (${pct(abandonedCnt, Math.max(1, total))}).`,
          `${abandonedCnt} zamkniętych bez merge (${pct(abandonedCnt, Math.max(1, total))}).`
        ),
        recommendation: pick(
          'Use smaller MRs and early feedback to reduce waste; track reasons for closure.',
          'Stosuj mniejsze MR-y i wczesny feedback, by ograniczyć straty; zbieraj powody zamknięć.'
        ),
        count: abandonedCnt,
      });
    }

    if (notApproved > 0) {
      findings.push({
        severity: 'medium',
        title: pick('MRs without any approver', 'MR-y bez żadnego akceptującego'),
        detail: pick(`${notApproved} MR(s) have empty approver list.`, `${notApproved} MR-ów ma pustą listę akceptujących.`),
        recommendation: pick('Enable auto-assign reviewers and require approvals.', 'Włącz auto-przydział reviewerów i wymagane akceptacje.'),
        count: notApproved,
      });
    }
    if (typeof slowReview === 'number' && slowReview > 1440) {
      findings.push({
        severity: slowReview > 2880 ? 'high' : 'medium',
        title: pick('Slow code reviews', 'Wolne code review'),
        detail: pick(
          `Avg review time ${(slowReview/60).toFixed(1)}${pick('h','godziny')} (>${(1440/60)}${pick('h','godziny')}).`,
          `Śr. czas review ${(slowReview/60).toFixed(1)} godziny (>${(1440/60)} godziny).`
        ),
        recommendation: pick(
          'Set review SLAs, limit WIP, and use parallel reviewers; consider smaller changes.',
          'Ustal SLA na review, ogranicz WIP i stosuj równoległych reviewerów; mniejsze zmiany.'
        ),
      });
    }

    if (typeof slowPickup === 'number' && slowPickup > 720) { // > 12h
      findings.push({
        severity: slowPickup > 1440 ? 'high' : 'medium',
        title: pick('Slow pickup', 'Wolny pickup'),
        detail: pick(
          `Avg pickup ${(slowPickup/60).toFixed(1)}h.`,
          `Śr. pickup ${(slowPickup/60).toFixed(1)}h.`
        ),
        recommendation: pick(
          'Introduce triage rotations and notifications to reduce wait time to first review.',
          'Wprowadź rotację triage i powiadomienia, aby skrócić czas do pierwszej reakcji.'
        ),
      });
    }

    if (siloPairs && siloPairs.length > 0) {
      const strong = siloPairs.filter((p) => p.total >= 4);
      if (strong.length > 0) {
        findings.push({
          severity: strong.length > 2 ? 'medium' : 'low',
          title: pick('Reviewer silos detected', 'Wykryto silosy reviewerów'),
          detail: pick(
            `${strong.length} strong pair(s) mostly review each other.`,
            `${strong.length} silnych par głównie wzajemnie się reviewuje.`
          ),
          recommendation: pick(
            'Broaden reviewer pool, add CODEOWNERS across modules, rotate reviewers.',
            'Poszerz pulę reviewerów, dodaj CODEOWNERS między modułami, rotuj reviewerów.'
          ),
        });
      }
    }

    if (mgr && Array.isArray(mgr.deployWeekly)) {
      const avgWeekly = mgr.deployWeekly.length
        ? mgr.deployWeekly.reduce((a: number, b: any) => a + (b?.[1] || 0), 0) / mgr.deployWeekly.length
        : 0;
      if (avgWeekly < 1) {
        findings.push({
          severity: 'low',
          title: pick('Low deployment frequency', 'Niska częstotliwość wdrożeń'),
          detail: pick(
            `Average <1 deploy/week in observed period.`,
            `Średnio <1 wdrożenie/tydzień w obserwowanym okresie.`
          ),
          recommendation: pick(
            'Increase CI reliability and slice work smaller to ship more often.',
            'Zwiększ niezawodność CI i dziel pracę na mniejsze porcje, by częściej wdrażać.'
          ),
        });
      }
    }

    const order = { high: 0, medium: 1, low: 2 } as const;
    findings.sort((a, b) => (order[a.severity] - order[b.severity]) || (b.count || 0) - (a.count || 0));
    return findings;
  }, [data, mgr, summary, siloPairs, pick]);

  return (
    <section className="bg-white rounded-2xl border border-gray-200 p-5">
      <div className="flex items-start justify-between mb-3">
        <div>
          <h2 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>{pick('Data Quality Advisor', 'Doradca jakości danych')}</h2>
          <p className="text-[12px] text-gray-500 mt-0.5">
            {pick('Automatic checks of MR payload and process signals. Suggestions below help improve data quality and delivery flow.', 'Automatyczne sprawdzenia payloadu MR i sygnałów procesu. Poniższe wskazówki pomogą poprawić jakość danych i przepływ dostarczania.')}
          </p>
        </div>
        <div className="text-[12px] text-gray-500">{pick('Findings', 'Wnioski')}: <span className="text-gray-900 font-semibold">{advisor.length}</span></div>
      </div>

      {advisor.length === 0 ? (
        <div className="p-4 rounded-xl border border-emerald-200 bg-emerald-50 text-emerald-700 text-[13px]" style={{ fontWeight: 500 }}>
          {pick('No critical data issues detected. Keep it up!', 'Brak krytycznych problemów z danymi. Tak trzymać!')}
        </div>
      ) : (
        <ul className="space-y-3">
          {advisor.map((f, idx) => {
            const sevCfg = f.severity === 'high'
              ? { chip: 'bg-red-50 text-red-700 border-red-200', dot: 'bg-red-500', label: pick('High', 'Wysoki') }
              : f.severity === 'medium'
              ? { chip: 'bg-amber-50 text-amber-700 border-amber-200', dot: 'bg-amber-500', label: pick('Medium', 'Średni') }
              : { chip: 'bg-sky-50 text-sky-700 border-sky-200', dot: 'bg-sky-500', label: pick('Low', 'Niski') };
            return (
              <li key={idx} className="rounded-xl border border-gray-100 p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-[11px] ${sevCfg.chip}`} style={{ fontWeight: 700 }}>
                        <span className={`w-1.5 h-1.5 rounded-full ${sevCfg.dot}`} /> {sevCfg.label}
                      </span>
                      <span className="text-[13px] text-gray-900" style={{ fontWeight: 600 }}>{f.title}</span>
                      {typeof f.count === 'number' && (
                        <span className="px-1.5 py-0.5 rounded-full border text-[11px] bg-gray-50 text-gray-600 border-gray-200" style={{ fontWeight: 600 }}>×{f.count}</span>
                      )}
                    </div>
                    <p className="text-[12px] text-gray-700 mb-1.5">{f.detail}</p>
                    <p className="text-[12px] text-gray-600">
                      <span className="text-gray-500">{pick('Recommendation:', 'Rekomendacja:')}</span> <span className="text-gray-800" style={{ fontWeight: 500 }}>{f.recommendation}</span>
                    </p>
                  </div>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}

export default DataQualityAdvisor;
