import { useEffect, useMemo, useState } from 'react';
import {
  Bar, BarChart, CartesianGrid, Line, LineChart, ReferenceLine, ResponsiveContainer, Scatter, ScatterChart, Tooltip, XAxis, YAxis, ZAxis, Cell,
} from 'recharts';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import LoadingSpinner from './LoadingSpinner';
import { useLang, usePick } from '../i18n';

// "Przepływ pracy" (work flow) popup on Overview, from /api/metrics/flow: cycle time percentiles, Monte Carlo
// "how many" forecast, work in progress with its age and weekly pace of starting vs finishing. A work item starts at
// its first in-progress status in Jira and finishes when it goes LIVE (stories/tasks/defects, no sub-tasks/epics).

type Percentile = { pct: number; value: number };
type Bucket = { from: number; till?: number | null; count: number };
type WipItem = { key: string; summary?: string | null; url?: string | null; type?: string | null; status: string; assignee?: string | null; ageDays: number; daysSinceLastMove?: number | null };
type Flow = {
  cycleTime: { finished: number; percentiles: Percentile[]; histogram: Bucket[] };
  forecast: { days: number; sampleDays: number; simulations: number; percentiles: Percentile[]; distribution: Bucket[] };
  wip: { count: number; avgAgeDays: number; olderThanP85: number; noMoveOver14Days: number; perPerson?: number | null; items: WipItem[] };
  pace: Array<{ week: string; started: number; finished: number }>;
};

// Explicit hex colors: theme.css remaps Tailwind indigo/green classes to the brand palette.
const PCT_COLORS: Record<number, string> = { 50: '#ea9a3c', 70: '#eab308', 85: '#2dd4bf', 95: '#0f766e' };
const STARTED = '#3b82f6';
const FINISHED = '#8b5cf6';
const card = 'bg-white dark:bg-[#121317] rounded-xl border border-gray-200 dark:border-white/10 p-4';
const muted = 'text-gray-500 dark:text-gray-400';

function fmtDays(v: number): string {
  return Number.isInteger(v) ? String(v) : v.toFixed(1);
}

export function FlowDialog({ open, onOpenChange, unitId, interval, teamName, dateRange }: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  unitId?: string | null;
  interval: string;
  teamName?: string;
  dateRange?: string;
}) {
  const pick = usePick();
  const { lang } = useLang();
  const [data, setData] = useState<Flow | null>(null);
  const [loading, setLoading] = useState(false);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    const controller = new AbortController();
    async function load() {
      setLoading(true);
      setFailed(false);
      try {
        const params = new URLSearchParams({ interval });
        if (unitId) params.set('unitId', unitId);
        const res = await fetch(`/api/metrics/flow?${params.toString()}`, { credentials: 'include', signal: controller.signal });
        if (!res.ok) throw new Error(String(res.status));
        const js = (await res.json()) as Flow;
        if (!cancelled) setData(js);
      } catch {
        if (!cancelled) { setData(null); setFailed(true); }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; controller.abort(); };
  }, [open, unitId, interval]);

  const locale = lang === 'pl' ? 'pl-PL' : 'en-GB';
  const p85 = data?.cycleTime.percentiles.find((p) => p.pct === 85)?.value;
  const p50 = data?.cycleTime.percentiles.find((p) => p.pct === 50)?.value;

  const histogram = useMemo(() => (data?.cycleTime.histogram ?? []).map((b) => ({
    label: b.till == null ? `${b.from}+` : String(b.from), from: b.from, count: b.count,
  })), [data]);
  const distribution = useMemo(() => (data?.forecast.distribution ?? []).map((b) => ({ from: b.from, count: b.count })), [data]);
  const pace = useMemo(() => (data?.pace ?? []).map((w) => ({
    ...w,
    label: new Date(`${w.week}T00:00:00`).toLocaleDateString(locale, { day: 'numeric', month: 'short' }),
  })), [data, locale]);
  const statuses = useMemo(() => Array.from(new Set((data?.wip.items ?? []).map((i) => i.status))), [data]);
  const wipPoints = useMemo(() => (data?.wip.items ?? []).map((i, idx) => ({
    ...i,
    // spread dots of one status horizontally so they do not overlap
    x: statuses.indexOf(i.status) + 0.15 + ((idx * 37) % 70) / 100,
    y: i.ageDays,
  })), [data, statuses]);

  const startedSum = pace.reduce((s, w) => s + w.started, 0);
  const finishedSum = pace.reduce((s, w) => s + w.finished, 0);
  const wipGrows = startedSum > finishedSum * 1.15;

  function dotColor(age: number): string {
    if (p85 != null && age > p85) return '#ef4444';
    if (p50 != null && age > p50) return '#f59e0b';
    return '#10b981';
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[1280px] max-h-[92vh] overflow-y-auto bg-gray-50 dark:bg-[#0b0c0f]">
        <DialogHeader>
          <DialogTitle className="text-[18px]">{pick('Work flow', 'Przepływ pracy')}</DialogTitle>
          <DialogDescription className="text-[12px]">
            {pick('Jira work items of the unit (stories, tasks, defects; no sub-tasks or epics)', 'Zadania z Jiry jednostki (story, task, defect; bez sub-tasków i epiców)')}
            {teamName && teamName !== 'All Teams' ? ` · ${teamName}` : ''}{dateRange ? ` · ${dateRange}` : ''}
            {' · '}{pick('start = first In Progress, finish = Live', 'start = pierwsze In Progress, koniec = Live')}
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="min-h-[300px] flex items-center justify-center"><LoadingSpinner size={22} /></div>
        ) : failed || !data ? (
          <div className={`min-h-[160px] flex items-center justify-center text-[13px] ${muted}`}>
            {pick('Could not load work flow data.', 'Nie udało się pobrać danych przepływu pracy.')}
          </div>
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-[1.25fr_1.25fr_0.8fr] gap-4">
              <div className={card}>
                <h3 className="text-[14px]" style={{ fontWeight: 600 }}>Cycle time</h3>
                <p className={`text-[12px] ${muted} mb-3`}>{pick('How long did work items finished in the period take?', 'Ile trwało dowiezienie zadań zakończonych w okresie?')}</p>
                {data.cycleTime.finished === 0 ? (
                  <div className={`text-[12px] ${muted}`}>{pick('No work item finished in this period.', 'Brak zakończonych zadań w tym okresie.')}</div>
                ) : (
                  <>
                    <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-[13px] mb-2">
                      {data.cycleTime.percentiles.map((p) => (
                        <div key={p.pct} className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: PCT_COLORS[p.pct] }} />
                          <span>{p.pct}% {pick('in', 'w')} <b>{fmtDays(p.value)} {pick('days', 'dni')}</b> {pick('or less', 'lub szybciej')}</span>
                        </div>
                      ))}
                    </div>
                    <div className="h-28">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={histogram} barCategoryGap={1}>
                          <XAxis dataKey="label" tick={{ fontSize: 9, fill: '#9ca3af' }} axisLine={false} tickLine={false} interval={4} />
                          <YAxis hide />
                          <Tooltip formatter={(v: number) => [v, pick('items', 'zadań')]} labelFormatter={(l) => `${l} ${pick('days', 'dni')}`} />
                          {data.cycleTime.percentiles.map((p) => (
                            <ReferenceLine key={p.pct} x={Math.min(30, Math.floor(p.value)) === 30 ? '30+' : String(Math.floor(p.value))} stroke={PCT_COLORS[p.pct]} strokeDasharray="4 3" strokeWidth={2} />
                          ))}
                          <Bar dataKey="count" fill="#c7d2fe" isAnimationActive={false} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                    <div className={`text-[11px] ${muted}`}>{data.cycleTime.finished} {pick('work items finished in the period', 'zadań zakończonych w okresie')}</div>
                  </>
                )}
              </div>

              <div className={card}>
                <h3 className="text-[14px]" style={{ fontWeight: 600 }}>{pick('"How many?" forecast', '„Ile zrobimy?” – prognoza')}</h3>
                <p className={`text-[12px] ${muted} mb-3`}>
                  {pick(`How many work items are you likely to finish in the next ${data.forecast.days} days?`, `Ile zadań zespół prawdopodobnie skończy w ciągu następnych ${data.forecast.days} dni?`)}
                </p>
                {data.forecast.percentiles.length === 0 ? (
                  <div className={`text-[12px] ${muted}`}>{pick('Not enough finished work items to forecast.', 'Za mało zakończonych zadań, żeby prognozować.')}</div>
                ) : (
                  <>
                    <div className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-[13px] mb-2">
                      {data.forecast.percentiles.map((p) => (
                        <div key={p.pct} className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: PCT_COLORS[p.pct === 95 ? 95 : p.pct === 85 ? 85 : p.pct === 70 ? 70 : 50] }} />
                          <span>{p.pct}% {pick('chance of', 'szans na')} <b>{p.value}</b> {pick('or more', 'lub więcej')}</span>
                        </div>
                      ))}
                    </div>
                    <div className="h-28">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={distribution} barCategoryGap={1}>
                          <XAxis dataKey="from" tick={{ fontSize: 9, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                          <YAxis hide />
                          <Tooltip formatter={(v: number) => [v, pick('simulations', 'symulacji')]} labelFormatter={(l) => `${l}+ ${pick('items', 'zadań')}`} />
                          <Bar dataKey="count" fill="#a7f3d0" isAnimationActive={false} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                    <div className={`text-[11px] ${muted}`}>
                      Monte Carlo: {data.forecast.simulations.toLocaleString(locale)} {pick('simulations from daily throughput of the last', 'symulacji z dziennej przepustowości z ostatnich')} {data.forecast.sampleDays} {pick('days', 'dni')}
                    </div>
                  </>
                )}
              </div>

              <div className={`${card} text-center flex flex-col justify-between`}>
                <div>
                  <h3 className="text-[14px]" style={{ fontWeight: 600 }}>WIP</h3>
                  <p className={`text-[12px] ${muted}`}>{pick('How many work items are in progress now?', 'Ile zadań jest teraz w toku?')}</p>
                </div>
                <div className="text-[44px] my-2" style={{ fontWeight: 700, lineHeight: 1 }}>{data.wip.count}</div>
                <div className="space-y-1.5 text-[12px]">
                  <div>{pick('avg age', 'śr. wiek')}: <b>{fmtDays(data.wip.avgAgeDays)} {pick('days', 'dni')}</b></div>
                  {data.wip.olderThanP85 > 0 && (
                    <div><span className="inline-block px-2 py-0.5 rounded-full bg-red-100 text-red-800 text-[11px]" style={{ fontWeight: 600 }}>
                      {data.wip.olderThanP85} {pick('older than 85% cycle time', 'starszych niż 85% cycle time')}
                    </span></div>
                  )}
                  {data.wip.noMoveOver14Days > 0 && (
                    <div><span className="inline-block px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[11px]" style={{ fontWeight: 600 }}>
                      {data.wip.noMoveOver14Days} &gt; 2 {pick('weeks without a move', 'tyg. bez ruchu')}
                    </span></div>
                  )}
                  {data.wip.perPerson != null && <div className={muted}>WIP / {pick('person', 'osobę')}: <b>{fmtDays(data.wip.perPerson)}</b></div>}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <div className={card}>
                <h3 className="text-[14px]" style={{ fontWeight: 600 }}>{pick('Pace: start vs finish', 'Tempo: start vs koniec')}</h3>
                <p className={`text-[12px] ${muted} mb-2`}>{pick('Are you starting and finishing work at a consistent rate? (weekly)', 'Czy zaczynacie i kończycie pracę w równym tempie? (tygodniowo)')}</p>
                <div className="h-52">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={pace}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                      <XAxis dataKey="label" tick={{ fontSize: 10, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fontSize: 10, fill: '#9ca3af' }} axisLine={false} tickLine={false} allowDecimals={false} width={28} />
                      <Tooltip />
                      <Line type="monotone" dataKey="started" name={pick('Started', 'Rozpoczęte')} stroke={STARTED} strokeWidth={2.5} dot={{ r: 3 }} isAnimationActive={false} />
                      <Line type="monotone" dataKey="finished" name={pick('Finished', 'Zakończone')} stroke={FINISHED} strokeWidth={2.5} dot={{ r: 3 }} isAnimationActive={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex flex-wrap gap-4 text-[11px] text-gray-600 dark:text-gray-300">
                  <span><i className="inline-block w-3 h-[3px] rounded mr-1 align-middle" style={{ backgroundColor: STARTED }} />{pick('Started (→ In Progress)', 'Rozpoczęte (→ In Progress)')}: {startedSum}</span>
                  <span><i className="inline-block w-3 h-[3px] rounded mr-1 align-middle" style={{ backgroundColor: FINISHED }} />{pick('Finished (→ Live)', 'Zakończone (→ Live)')}: {finishedSum}</span>
                  {wipGrows && <span className="text-red-700" style={{ fontWeight: 600 }}>{pick('Starting more than finishing → WIP grows', 'Więcej startów niż końców → WIP rośnie')}</span>}
                </div>
              </div>

              <div className={card}>
                <h3 className="text-[14px]" style={{ fontWeight: 600 }}>{pick('Work item age', 'Wiek zadań w toku')}</h3>
                <p className={`text-[12px] ${muted} mb-2`}>{pick('Which items are stuck? Each dot is a work item; lines are cycle time percentiles.', 'Które zadania utknęły? Każda kropka to zadanie, linie = percentyle cycle time.')}</p>
                {wipPoints.length === 0 ? (
                  <div className={`text-[12px] ${muted}`}>{pick('Nothing in progress.', 'Nic nie jest w toku.')}</div>
                ) : (
                  <div className="h-52">
                    <ResponsiveContainer width="100%" height="100%">
                      <ScatterChart margin={{ top: 8, right: 16, bottom: 8, left: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                        <XAxis type="number" dataKey="x" domain={[0, Math.max(1, statuses.length)]} ticks={statuses.map((_, i) => i + 0.5)}
                          tickFormatter={(v: number) => {
                            const s = statuses[Math.floor(v)];
                            const n = (data.wip.items ?? []).filter((i) => i.status === s).length;
                            return s ? `${s} (${n})` : '';
                          }}
                          tick={{ fontSize: 10, fill: '#6b7280' }} axisLine={false} tickLine={false} />
                        <YAxis type="number" dataKey="y" unit=" d" tick={{ fontSize: 10, fill: '#9ca3af' }} axisLine={false} tickLine={false} width={40} />
                        <ZAxis range={[60, 60]} />
                        {data.cycleTime.percentiles.filter((p) => p.pct !== 70).map((p) => (
                          <ReferenceLine key={p.pct} y={p.value} stroke={PCT_COLORS[p.pct]} strokeDasharray="4 3"
                            label={{ value: `${p.pct}%`, position: 'right', fontSize: 9, fill: PCT_COLORS[p.pct] }} />
                        ))}
                        <Tooltip cursor={false} content={({ payload }) => {
                          const it = payload?.[0]?.payload as (WipItem & { y: number }) | undefined;
                          if (!it) return null;
                          return (
                            <div className="bg-white border border-gray-200 rounded-lg px-2.5 py-1.5 text-[11px] shadow-sm max-w-[260px]">
                              <div style={{ fontWeight: 700 }}>{it.key} · {fmtDays(it.ageDays)} {pick('days', 'dni')}</div>
                              {it.summary && <div className="text-gray-700">{it.summary}</div>}
                              <div className="text-gray-500">{it.status}{it.assignee ? ` · ${it.assignee}` : ''}</div>
                              {it.daysSinceLastMove != null && <div className="text-gray-500">{pick('last move', 'ostatni ruch')}: {fmtDays(it.daysSinceLastMove)} {pick('days ago', 'dni temu')}</div>}
                            </div>
                          );
                        }} />
                        <Scatter data={wipPoints} onClick={(p: any) => { if (p?.url) window.open(p.url, '_blank', 'noopener'); }} cursor="pointer">
                          {wipPoints.map((p) => <Cell key={p.key} fill={dotColor(p.ageDays)} />)}
                        </Scatter>
                      </ScatterChart>
                    </ResponsiveContainer>
                  </div>
                )}
                <div className="flex flex-wrap gap-3 text-[11px] text-gray-600 dark:text-gray-300 mt-1">
                  <span><i className="inline-block w-2.5 h-2.5 rounded-full mr-1 align-middle" style={{ backgroundColor: '#10b981' }} />{pick('normal', 'w normie')}</span>
                  <span><i className="inline-block w-2.5 h-2.5 rounded-full mr-1 align-middle" style={{ backgroundColor: '#f59e0b' }} />{pick('above 50%', 'powyżej 50%')}</span>
                  <span><i className="inline-block w-2.5 h-2.5 rounded-full mr-1 align-middle" style={{ backgroundColor: '#ef4444' }} />{pick('above 85% – check it', 'powyżej 85% – do sprawdzenia')}</span>
                  <span className={muted}>· {pick('click a dot to open it in Jira', 'klik w kropkę → zadanie w Jirze')}</span>
                </div>
              </div>
            </div>

            {data.wip.items.length > 0 && (
              <div className={card}>
                <h3 className="text-[14px] mb-2" style={{ fontWeight: 600 }}>{pick('Oldest work in progress', 'Najstarsze zadania w toku')}</h3>
                <table className="w-full text-[12px]">
                  <thead>
                    <tr className={`text-left ${muted}`}>
                      <th className="py-1 pr-2">{pick('Item', 'Zadanie')}</th><th className="py-1 pr-2">Status</th>
                      <th className="py-1 pr-2">{pick('Assignee', 'Osoba')}</th><th className="py-1 pr-2">{pick('Age', 'Wiek')}</th>
                      <th className="py-1">{pick('Last move', 'Ostatni ruch')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.wip.items.slice(0, 10).map((i) => (
                      <tr key={i.key} className="border-t border-gray-100 dark:border-white/5">
                        <td className="py-1.5 pr-2">
                          {i.url ? <a href={i.url} target="_blank" rel="noopener noreferrer" className="underline" style={{ fontWeight: 600 }}>{i.key}</a> : <b>{i.key}</b>}
                          {i.summary ? <span className={`ml-1.5 ${muted}`}>{i.summary}</span> : null}
                        </td>
                        <td className="py-1.5 pr-2">{i.status}</td>
                        <td className="py-1.5 pr-2">{i.assignee ?? '—'}</td>
                        <td className="py-1.5 pr-2" style={{ color: dotColor(i.ageDays), fontWeight: 700 }}>{fmtDays(i.ageDays)} {pick('d', 'dni')}</td>
                        <td className="py-1.5">{i.daysSinceLastMove != null ? `${fmtDays(i.daysSinceLastMove)} ${pick('d ago', 'dni temu')}` : '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

export default FlowDialog;
