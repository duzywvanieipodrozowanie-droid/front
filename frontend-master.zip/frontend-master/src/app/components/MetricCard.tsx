import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface MetricCardProps {
  title: string;
  value: number;
  unit: string;
  previousValue?: number;
  trend?: 'up' | 'down' | 'stable';
  rating?: 'elite' | 'high' | 'medium' | 'low';
  className?: string;
}

export function MetricCard({
  title,
  value,
  unit,
  previousValue,
  trend,
  rating,
  className = '',
}: MetricCardProps) {
  const getTrendColor = () => {
    if (!trend) return 'text-gray-500';
    
    // For metrics where down is good (lead time, MTTR, failure rate)
    const isDownGood = title.toLowerCase().includes('time') || 
                       title.toLowerCase().includes('failure') ||
                       title.toLowerCase().includes('mttr');
    
    if (trend === 'up') {
      return isDownGood ? 'text-red-500' : 'text-green-500';
    } else if (trend === 'down') {
      return isDownGood ? 'text-green-500' : 'text-red-500';
    }
    return 'text-gray-500';
  };

  const getRatingColor = () => {
    switch (rating) {
      case 'elite':
        return 'bg-green-100 text-green-700 border-green-200';
      case 'high':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'medium':
        return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'low':
        return 'bg-red-100 text-red-700 border-red-200';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const calculateChange = () => {
    if (!previousValue) return null;
    const change = ((value - previousValue) / previousValue) * 100;
    return Math.abs(change).toFixed(1);
  };

  const change = calculateChange();

  return (
    <div className={`bg-white rounded-lg border border-gray-200 p-6 ${className}`}>
      <div className="flex items-start justify-between mb-4">
        <h3 className="text-sm text-gray-600">{title}</h3>
        {rating && (
          <span className={`px-2 py-1 text-xs rounded border ${getRatingColor()}`}>
            {rating.charAt(0).toUpperCase() + rating.slice(1)}
          </span>
        )}
      </div>
      
      <div className="flex items-end justify-between">
        <div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-semibold text-gray-900">{value}</span>
            <span className="text-sm text-gray-500">{unit}</span>
          </div>
          
          {change && trend && (
            <div className={`flex items-center gap-1 mt-2 text-sm ${getTrendColor()}`}>
              {trend === 'up' && <TrendingUp className="w-4 h-4" />}
              {trend === 'down' && <TrendingDown className="w-4 h-4" />}
              {trend === 'stable' && <Minus className="w-4 h-4" />}
              <span>{change}% vs last period</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
