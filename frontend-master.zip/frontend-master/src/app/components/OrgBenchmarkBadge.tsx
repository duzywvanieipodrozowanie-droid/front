import { usePick } from '../i18n';

// "Local benchmark" line under a widget value: how far the selected unit is from the average of all units of the same
// type in the organization (from /api/metrics/benchmark/overview and /api/metrics/benchmark/dora).

export type OrgBenchItem = {
  value?: number | null;
  orgAverage?: number | null;
  unitsWithData?: number;
  diffPct?: number | null;
  better?: boolean | null;
};

export type OrgBenchResponse = {
  unitType?: string | null;
  peerUnits?: number;
  metrics?: Record<string, OrgBenchItem>;
};

export async function fetchOrgBenchmark(page: 'overview' | 'dora', interval: string, unitId?: string | null, signal?: AbortSignal): Promise<OrgBenchResponse | null> {
  const params = new URLSearchParams({ interval });
  if (unitId) params.set('unitId', unitId);
  try {
    const res = await fetch(`/api/metrics/benchmark/${page}?${params.toString()}`, { credentials: 'include', signal });
    if (!res.ok) return null;
    return (await res.json()) as OrgBenchResponse;
  } catch {
    return null;
  }
}

function fmt(n: number): string {
  return Number.isInteger(n) ? String(n) : n.toFixed(1);
}

export function OrgBenchmarkBadge({ item, unit, unitType }: { item?: OrgBenchItem | null; unit?: string; unitType?: string | null }) {
  const pick = usePick();
  if (!item) return null;
  const avg = typeof item.orgAverage === 'number' ? item.orgAverage : null;
  const scope = unitType ? `${pick('avg of all', 'śr. wszystkich')} ${unitType.toLowerCase()}` : pick('org average', 'śr. organizacji');
  const title = pick(
    `Average over ${item.unitsWithData ?? 0} units of this type that have data for this metric, same period.`,
    `Średnia z ${item.unitsWithData ?? 0} jednostek tego typu, które mają dane dla tej miary, w tym samym okresie.`
  );
  if (avg == null || item.diffPct == null) {
    return <div className="text-[11px] text-gray-400 mt-1" title={title}>{pick('No organization average for this period', 'Brak średniej organizacji w tym okresie')}</div>;
  }
  const diff = Number(item.diffPct);
  const color = item.better ? 'text-emerald-700 bg-emerald-50 border-emerald-200' : 'text-red-700 bg-red-50 border-red-200';
  const text = diff === 0
    ? pick('equal to', 'równo ze')
    : `${diff > 0 ? '+' : '−'}${Math.abs(diff)}% ${pick('vs', 'vs')}`;
  return (
    <div className="mt-1.5" title={title}>
      <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full border text-[11px] ${color}`} style={{ fontWeight: 600 }}>
        {item.better ? '▲' : '▼'} {text} {scope}
      </span>
      <span className="text-[11px] text-gray-500 ml-1.5">({pick('avg', 'śr.')} {fmt(avg)}{unit ? ` ${unit}` : ''})</span>
    </div>
  );
}

export default OrgBenchmarkBadge;
