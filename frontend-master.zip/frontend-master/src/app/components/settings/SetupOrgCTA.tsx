import { Cog } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function SetupOrgCTA() {
  const navigate = useNavigate();
  return (
    <section className="bg-white rounded-2xl border border-gray-200 p-4">
      <div className="flex items-center justify-start gap-3">
        <div className="flex-1 min-w-0">
          <h3 className="text-[16px] text-gray-900" style={{ fontWeight: 700 }}>Setup organization</h3>
          <p className="text-[12px] text-gray-500 mt-1">Define units, teams and members to unlock focused dashboards.</p>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <button
              onClick={() => navigate('/settings/organization')}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-[13px] transition-colors shadow-sm"
              style={{ fontWeight: 500 }}
            >
              <Cog className="w-4 h-4" /> Get started
            </button>
            <button
              onClick={() => navigate('/help')}
              className="text-[12px] text-indigo-600 hover:text-indigo-700"
            >
              Learn more
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

export default SetupOrgCTA;
