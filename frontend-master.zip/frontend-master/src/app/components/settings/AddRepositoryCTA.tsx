import { FolderPlus } from 'lucide-react';

export function AddRepositoryCTA() {
  return (
    <section className="bg-white rounded-2xl border border-gray-200 p-4">
      <div className="flex items-center justify-start gap-3">
        <div className="flex-1 min-w-0">
          <h3 className="text-[16px] text-gray-900" style={{ fontWeight: 700 }}>Add repository</h3>
          <p className="text-[12px] text-gray-500 mt-1">Connect a Git repository to start collecting commits, PRs and pipelines.</p>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <button
              className="flex items-center gap-2 px-4 py-2 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 text-gray-700 text-[13px] transition-colors"
              style={{ fontWeight: 500 }}
              onClick={() => {
                // Placeholder action – can be wired to a dedicated route later
                alert('Add repository – coming soon');
              }}
            >
              <FolderPlus className="w-4 h-4" /> Add repository
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

export default AddRepositoryCTA;
