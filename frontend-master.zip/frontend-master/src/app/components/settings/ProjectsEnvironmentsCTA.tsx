import { Boxes } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function ProjectsEnvironmentsCTA() {
  const navigate = useNavigate();
  return (
    <section className="bg-white rounded-2xl border border-gray-200 p-4">
      <div className="flex items-center justify-start gap-3">
        <div className="flex-1 min-w-0">
          <h3 className="text-[16px] text-gray-900" style={{ fontWeight: 700 }}>Projects and environments</h3>
          <p className="text-[12px] text-gray-500 mt-1">Projects of the Service Map and the promotion order of their environments (dev → test → prod).</p>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <button
              onClick={() => navigate('/settings/projects')}
              className="flex items-center gap-2 px-4 py-2 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 text-gray-700 text-[13px] transition-colors"
              style={{ fontWeight: 500 }}
            >
              <Boxes className="w-4 h-4" /> Manage projects
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

export default ProjectsEnvironmentsCTA;
