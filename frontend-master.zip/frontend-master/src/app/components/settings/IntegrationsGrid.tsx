import { Workflow } from 'lucide-react';

// Only keep the requested integrations and show their official logos
import sonarLogo from '../../../assets/sonarqube.svg';

const tiles = [
  { label: 'GitLab', logoUrl: 'https://cdn.simpleicons.org/gitlab/FC6D26' },
  { label: 'Jira', logoUrl: 'https://cdn.simpleicons.org/jira/0052CC' },
  { label: 'SonarQube', logoUrl: sonarLogo },
] as const;

export function IntegrationsGrid() {
  return (
    <section className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
      <div className="flex items-center justify-start gap-3 px-4 py-3 border-b border-gray-100">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-indigo-50 flex items-center justify-center">
            <Workflow className="w-4 h-4 text-indigo-500" />
          </div>
          <div>
            <h2 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>Add integration</h2>
            <p className="text-[11px] text-gray-400">Connect your tools to synchronize knowledge and metrics</p>
          </div>
        </div>
      </div>
      <div className="p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {tiles.map(({ label, logoUrl }) => (
          <button
            key={label}
            className="group flex items-center gap-3 w-full text-left px-4 py-3 rounded-xl border border-gray-200 hover:border-indigo-300 bg-white hover:bg-indigo-50/40 transition-colors"
            aria-label={`Configure ${label} integration`}
          >
            <div className="shrink-0 w-9 h-9 rounded-lg bg-gray-50 group-hover:bg-indigo-100 flex items-center justify-center overflow-hidden">
              <img src={logoUrl} alt={`${label} logo`} className="w-5 h-5 object-contain" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                <div className="text-[13px] text-gray-800" style={{ fontWeight: 600 }}>{label}</div>
                <span className="whitespace-nowrap text-[10px] px-1.5 py-0.5 rounded bg-gray-100 text-gray-600 border border-gray-200">Not connected</span>
              </div>
              <div className="text-[11px] text-gray-400">Click to connect</div>
            </div>
          </button>
        ))}
      </div>
    </section>
  );
}

export default IntegrationsGrid;
