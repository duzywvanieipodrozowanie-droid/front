import { AlertTriangle } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function UnknownCommitersCTA() {
  const navigate = useNavigate();
  return (
    <section className="bg-white rounded-2xl border border-gray-200 p-4">
      <div className="flex items-center justify-start gap-3">
        <div className="flex-1 min-w-0">
          <h3 className="text-[16px] text-gray-900" style={{ fontWeight: 700 }}>Unknown committers</h3>
          <p className="text-[12px] text-gray-500 mt-1">Review authors not mapped to people. Map or ignore to clean up metrics.</p>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <button
              onClick={() => navigate('/settings/unknown-commiters')}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-[13px] transition-colors shadow-sm"
              style={{ fontWeight: 500 }}
            >
              <AlertTriangle className="w-4 h-4" /> Open list
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

export default UnknownCommitersCTA;
