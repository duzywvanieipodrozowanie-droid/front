import { ShieldCheck } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export function UsersAccessCTA() {
  const navigate = useNavigate();
  return (
    <section className="bg-white rounded-2xl border border-gray-200 p-4">
      <div className="flex items-center justify-start gap-3">
        <div className="flex-1 min-w-0">
          <h3 className="text-[16px] text-gray-900" style={{ fontWeight: 700 }}>Users and access</h3>
          <p className="text-[12px] text-gray-500 mt-1">Who is an admin or a developer, and which menu pages each role can open.</p>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <button
              onClick={() => navigate('/settings/access')}
              className="flex items-center gap-2 px-4 py-2 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 text-gray-700 text-[13px] transition-colors"
              style={{ fontWeight: 500 }}
            >
              <ShieldCheck className="w-4 h-4" /> Manage access
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

export default UsersAccessCTA;
