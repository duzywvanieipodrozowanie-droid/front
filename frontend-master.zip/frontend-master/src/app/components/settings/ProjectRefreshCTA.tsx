import { useEffect, useMemo, useState } from 'react';
import { RefreshCw, FolderGit2 } from 'lucide-react';

export function ProjectRefreshCTA() {
  const [projects, setProjects] = useState<string[]>([]);
  const [selected, setSelected] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [status, setStatus] = useState<string>('');
  const [error, setError] = useState<string>('');

  useEffect(() => {
    let cancelled = false;

    function readProjects(node: Record<string, unknown>): string[] {
      const raw = node?.projects ?? node?.projectIds ?? node?.repos ?? node?.repositories;
      return (Array.isArray(raw) ? raw : []).map((v) => String(v ?? '').trim()).filter(Boolean);
    }
    function getChildren(node: Record<string, unknown>): unknown[] {
      const candidates = [node.units, node.children, node.teams];
      for (const c of candidates) if (Array.isArray(c)) return c;
      return [];
    }

    async function fetchJson(url: string) {
      try {
        const res = await fetch(url, { credentials: 'include', headers: { Accept: 'application/json' } });
        if (!res.ok) return null;
        return await res.json();
      } catch {
        return null;
      }
    }

    async function load() {
      const org = await fetchJson('/api/admin/organization');
      if (cancelled) return;
      const set = new Set<string>();
      const visit = (value: unknown) => {
        if (!value || typeof value !== 'object') return;
        const node = value as Record<string, unknown>;
        readProjects(node).forEach((p) => set.add(p));
        getChildren(node).forEach(visit);
      };
      if (org && typeof org === 'object') {
        if (Array.isArray(org)) org.forEach(visit); else visit(org);
      }
      const list = Array.from(set).sort((a, b) => a.localeCompare(b));
      setProjects(list);
      if (list.length > 0) setSelected((prev) => prev && list.includes(prev) ? prev : list[0]);
    }

    load();
    return () => { cancelled = true; };
  }, []);

  const disabled = useMemo(() => !selected || loading, [selected, loading]);

  async function trigger() {
    if (!selected) return;
    setLoading(true); setError(''); setStatus('');
    try {
      const qs = new URLSearchParams();
      qs.set('project', selected);
      qs.set('weeks', '48'); // fixed per requirement
      qs.set('interval', '48weeks'); // used elsewhere in app together with weeks=48
      const res = await fetch(`/api/v1/commit/mr/refresh?${qs.toString()}`, { method: 'PUT', credentials: 'include' });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setStatus('Wywołano odświeżenie MR dla projektu.');
    } catch (e) {
      setError((e instanceof Error && e.message) || 'Błąd wywołania API');
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="bg-white rounded-2xl border border-gray-200 p-4">
      <div className="flex items-center justify-start gap-3">
        <div className="flex-1 min-w-0">
          <h3 className="text-[16px] text-gray-900" style={{ fontWeight: 700 }}>Odśwież MR-y projektu</h3>
          <p className="text-[12px] text-gray-500 mt-1">Wybierz projekt z listy pobranej z /api/admin/organization i uruchom odświeżenie (weeks=48).</p>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <div className="flex flex-1 items-center gap-2 min-w-[180px]">
              <FolderGit2 className="w-4 h-4 text-gray-500" />
              <select
                className="w-full min-w-0 px-3 py-2 rounded-lg border border-gray-200 bg-white text-[13px] text-gray-700"
                value={selected}
                onChange={(e) => setSelected(e.target.value)}
              >
                {projects.length === 0 ? (
                  <option value="" disabled>Brak projektów</option>
                ) : (
                  projects.map((p) => (
                    <option key={p} value={p}>{p}</option>
                  ))
                )}
              </select>
            </div>
            <button
              onClick={trigger}
              disabled={disabled}
              className={`shrink-0 flex items-center gap-2 px-4 py-2 rounded-xl ${disabled ? 'bg-gray-100 text-gray-400 border border-gray-200 cursor-not-allowed' : 'bg-indigo-600 hover:bg-indigo-700 text-white'} text-[13px] transition-colors shadow-sm`}
              style={{ fontWeight: 500 }}
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /> Wywołaj API
            </button>
          </div>
          {status && <p className="text-[12px] text-emerald-600 mt-2">{status}</p>}
          {error && <p className="text-[12px] text-red-600 mt-2">{error}</p>}
        </div>
      </div>
    </section>
  );
}

export default ProjectRefreshCTA;
