import { FolderPlus } from 'lucide-react';

export function AddProjectCTA() {
  return (
    <section className="bg-white rounded-2xl border border-gray-200 p-4">
      <div className="flex items-center justify-start gap-3">
        <div className="flex-1 min-w-0">
          <h3 className="text-[16px] text-gray-900" style={{ fontWeight: 700 }}>Add project</h3>
          <p className="text-[12px] text-gray-500 mt-1">Create a new project space to group related repositories and metrics.</p>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <button
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-[13px] transition-colors shadow-sm"
              style={{ fontWeight: 500 }}
              onClick={() => {
                // Placeholder action – can be wired to a dedicated route later
                alert('Add project – coming soon');
              }}
            >
              <FolderPlus className="w-4 h-4" /> Add project
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

export default AddProjectCTA;
