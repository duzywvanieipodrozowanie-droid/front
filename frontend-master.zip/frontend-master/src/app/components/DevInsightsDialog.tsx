import type { ReactNode } from 'react';
import { GitPullRequest, Timer, Undo2 } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { usePick } from '../i18n';

/** One engineer's GitLab details, from /api/metrics/team/dev-insights. */
export type DevInsights = {
  personId: string;
  pipelines: number;
  failedPipelines: number;
  avgPipelineMinutes: number;
  revertsMade: number;
  commitsReverted: number;
  mrs: number;
  avgMrComments: number;
  avgMrChangedFiles: number;
  mrsWithStats: number;
};

export function formatMinutes(minutes: number | null | undefined): string {
  if (minutes == null || !Number.isFinite(minutes) || minutes <= 0) return '—';
  if (minutes < 60) return `${Math.round(minutes * 10) / 10} min`;
  return `${Math.round((minutes / 60) * 10) / 10} h`;
}

function Stat({ label, value, hint }: { label: string; value: ReactNode; hint?: string }) {
  return (
    <div className="rounded-md bg-gray-50 dark:bg-[#23252b] px-3 py-2">
      <div className="text-[11px] text-gray-500 dark:text-gray-400">{label}</div>
      <div className="text-[16px] text-gray-900 dark:text-gray-100" style={{ fontWeight: 700 }}>{value}</div>
      {hint && <div className="text-[10.5px] text-gray-400 dark:text-gray-500">{hint}</div>}
    </div>
  );
}

function Section({ icon, title, children }: { icon: ReactNode; title: string; children: ReactNode }) {
  return (
    <div>
      <div className="flex items-center gap-1.5 mb-2 text-[13px] text-gray-900 dark:text-gray-100" style={{ fontWeight: 600 }}>
        {icon}{title}
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">{children}</div>
    </div>
  );
}

export function DevInsightsDialog({
  open,
  onOpenChange,
  name,
  mrsCreated,
  mrsMerged,
  insights,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  name: string;
  mrsCreated?: number | null;
  mrsMerged?: number | null;
  insights: DevInsights | null | undefined;
}) {
  const pick = usePick();
  const failedPct = insights && insights.pipelines > 0 ? Math.round((insights.failedPipelines / insights.pipelines) * 100) : null;
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-xl bg-white dark:bg-[#17181c] dark:border-white/10">
        <DialogHeader>
          <DialogTitle className="text-gray-900 dark:text-gray-100">{name}</DialogTitle>
          <DialogDescription className="text-gray-500 dark:text-gray-400">
            {pick('Merge requests, pipelines and reverts from GitLab for the selected period.', 'Merge requesty, pipeline’y i reverty z GitLaba w wybranym okresie.')}
          </DialogDescription>
        </DialogHeader>

        {!insights ? (
          <p className="text-[12px] text-gray-500 dark:text-gray-400">{pick('No GitLab data for this period.', 'Brak danych z GitLaba w tym okresie.')}</p>
        ) : (
          <div className="space-y-4">
            <Section icon={<GitPullRequest className="w-4 h-4 text-blue-500" />} title="Merge requests">
              <Stat label={pick('Created', 'Utworzone')} value={mrsCreated ?? insights.mrs} hint={mrsMerged != null ? `${mrsMerged} ${pick('merged', 'zmergowanych')}` : undefined} />
              <Stat
                label={pick('Avg comments / MR', 'Śr. komentarzy / MR')}
                value={insights.mrsWithStats > 0 ? insights.avgMrComments : '—'}
                hint={pick(`from ${insights.mrsWithStats} MRs with data`, `z ${insights.mrsWithStats} MR-ów z danymi`)}
              />
              <Stat
                label={pick('Avg changed files / MR', 'Śr. zmienionych plików / MR')}
                value={insights.mrsWithStats > 0 ? insights.avgMrChangedFiles : '—'}
                hint={pick('smaller MRs are reviewed faster', 'mniejsze MR-y szybciej przechodzą review')}
              />
            </Section>
            <Section icon={<Timer className="w-4 h-4 text-amber-500" />} title={pick('Pipelines', 'Pipeline’y')}>
              <Stat label={pick('Avg duration', 'Śr. czas trwania')} value={formatMinutes(insights.avgPipelineMinutes)} hint={pick('finished pipelines, incl. queue', 'zakończone, z czasem w kolejce')} />
              <Stat label={pick('Runs', 'Uruchomienia')} value={insights.pipelines} />
              <Stat label={pick('Failed', 'Nieudane')} value={insights.failedPipelines} hint={failedPct != null ? `${failedPct}%` : undefined} />
            </Section>
            <Section icon={<Undo2 className="w-4 h-4 text-red-500" />} title={pick('Reverts', 'Reverty')}>
              <Stat label={pick('Reverts made', 'Wykonane reverty')} value={insights.revertsMade} />
              <Stat label={pick('Own commits reverted', 'Cofnięte własne commity')} value={insights.commitsReverted} hint={pick('by anyone', 'przez kogokolwiek')} />
            </Section>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
