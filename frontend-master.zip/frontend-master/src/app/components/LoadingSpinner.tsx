import React from 'react';

interface LoadingSpinnerProps {
  isDarkMode?: boolean;
  size?: number; // roughly radius; component will scale accordingly
}

const LoadingSpinner: React.FC<LoadingSpinnerProps> = ({ isDarkMode = false, size = 25 }) => {
  const color = isDarkMode ? '#9aa3ff' : '#2730ad';
  const diameter = Math.max(16, size * 2); // px
  const thickness = Math.max(2, Math.round(size / 5)); // px

  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        height: '100%',
        width: '100%',
        position: 'relative',
      }}
    >
      <div
        role="status"
        aria-label="Loading"
        style={{
          width: diameter,
          height: diameter,
          borderRadius: '50%',
          border: `${thickness}px solid rgba(0,0,0,0.1)`,
          borderTopColor: color,
          animation: 'junie-spin 0.8s linear infinite',
        }}
      />
      <style>
        {`@keyframes junie-spin { to { transform: rotate(360deg); } }`}
      </style>
    </div>
  );
};

export default LoadingSpinner;
