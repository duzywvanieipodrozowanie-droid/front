import React, { useEffect, useMemo, useRef, useState } from 'react';

// Lightweight in-browser AI analyst using WebLLM (loaded via global <script> in index.html)
// This component initializes a tiny open model and offers a minimal chat UI.
// It does not require any API keys or backend services.

export type AIAnalystProps = {
  open: boolean;
  onClose: () => void;
  context: string; // textual summary of on-screen data
  title?: string;
};

type ChatMsg = { role: 'system' | 'user' | 'assistant'; content: string };

declare global {
  interface Window {
    webllm?: any;
  }
}

async function waitFor(condition: () => boolean, timeoutMs = 4000, intervalMs = 100): Promise<boolean> {
  const start = Date.now();
  return new Promise((resolve) => {
    const t = setInterval(() => {
      if (condition()) {
        clearInterval(t);
        resolve(true);
      } else if (Date.now() - start > timeoutMs) {
        clearInterval(t);
        resolve(false);
      }
    }, intervalMs);
  });
}

async function loadScriptOnce(src: string, timeoutMs = 12000): Promise<void> {
  // If already present, resolve
  const existing = Array.from(document.scripts).find((s) => s.src === src);
  if (existing) {
    await waitFor(() => typeof (window as any).webllm !== 'undefined', 4000);
    return;
  }
  return new Promise((resolve, reject) => {
    const el = document.createElement('script');
    el.src = src;
    el.async = true;
    let done = false;
    const onLoad = () => {
      if (done) return; done = true;
      resolve();
    };
    const onError = () => {
      if (done) return; done = true;
      reject(new Error('Failed to load ' + src));
    };
    el.addEventListener('load', onLoad);
    el.addEventListener('error', onError);
    document.body.appendChild(el);
    setTimeout(() => {
      if (done) return; done = true;
      reject(new Error('Timeout loading ' + src));
    }, timeoutMs);
  });
}

export default function AIAnalyst({ open, onClose, context, title }: AIAnalystProps) {
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const [progress, setProgress] = useState<string>('');
  const engineRef = useRef<any>(null);
  const [input, setInput] = useState('What insights can you derive from this data?');
  const [loadingRuntime, setLoadingRuntime] = useState(false);
  const [reloadTick, setReloadTick] = useState(0);

  const sysPrompt = useMemo(() => {
    return (
      'You are an analytics co-pilot embedded inside a dashboard. '
      + 'Answer concisely and refer directly to the provided context. '
      + 'Prefer bullet points and quantify findings. '
      + 'If data is missing or uncertain, state the limitation.\n\n'
      + 'Context (dashboard summary):\n' + context
    );
  }, [context]);

  async function ensureRuntimeLoaded(): Promise<boolean> {
    // If present from index.html, just wait briefly for it to initialize
    if (typeof (window as any).webllm !== 'undefined') return true;
    setLoadingRuntime(true);
    setProgress('Loading AI runtime…');

    // Try a short poll first in case the page script is still parsing
    const found = await waitFor(() => typeof (window as any).webllm !== 'undefined', 1500);
    if (found) { setLoadingRuntime(false); return true; }

    // Fallback: dynamically inject from popular CDNs
    const cdnUrls = [
      'https://cdn.jsdelivr.net/npm/@mlc-ai/web-llm/dist/index.min.js',
      'https://unpkg.com/@mlc-ai/web-llm/dist/index.min.js',
      'https://fastly.jsdelivr.net/npm/@mlc-ai/web-llm/dist/index.min.js',
    ];
    let lastErr: any = null;
    for (const url of cdnUrls) {
      try {
        setProgress('Loading AI runtime from CDN…');
        await loadScriptOnce(url, 15000);
        const ok = await waitFor(() => typeof (window as any).webllm !== 'undefined', 2000);
        if (ok) { setLoadingRuntime(false); return true; }
      } catch (e) {
        lastErr = e;
      }
    }
    setLoadingRuntime(false);
    setError('AI runtime not loaded. Please check your connection and try again.');
    console.warn('[AIAnalyst] Failed to load WebLLM runtime', lastErr);
    return false;
  }

  // Initialize engine once when opened
  useEffect(() => {
    if (!open) return;
    if (engineRef.current) return;

    async function init() {
      try {
        if (typeof navigator !== 'undefined' && !(navigator as any).gpu) {
          setError('WebGPU is not available in this browser. Please use a recent Chrome/Edge with WebGPU enabled.');
          return;
        }
        // Ensure runtime present
        const ok = await ensureRuntimeLoaded();
        if (!ok) return;

        const webllm = (window as any).webllm;
        setProgress('Downloading tiny open model…');
        const preferKVCache = true;
        const modelId = 'Qwen2.5-0.5B-Instruct-q4f32_1';
        const engine = await webllm.CreateMLCEngine(modelId, {
          temperature: 0.2,
          top_p: 0.95,
          // on model load progress
          initProgressCallback: (report: any) => {
            if (!report) return;
            const text = typeof report.text === 'string' ? report.text : '';
            const p = typeof report.progress === 'number' ? Math.round(report.progress * 100) : undefined;
            setProgress(p != null ? `${text} (${p}%)` : text);
          },
          wasmProxy: true,
          prefer_kv_cache: preferKVCache,
        });
        engineRef.current = engine;
        setReady(true);
        setError(null);
      } catch (e: any) {
        console.error('[AIAnalyst] init error', e);
        setError('Failed to initialize local AI. ' + (e?.message || ''));
      }
    }

    init();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  async function send() {
    const engine = engineRef.current;
    if (!engine || !input.trim()) return;
    setSending(true);
    setError(null);

    try {
      const messages: ChatMsg[] = [
        { role: 'system', content: sysPrompt },
        { role: 'user', content: input.trim() },
      ];

      // WebLLM chat API
      let resultText = '';
      if (engine.chat?.completions?.create) {
        const out = await engine.chat.completions.create({ messages });
        resultText = out?.choices?.[0]?.message?.content || '';
      } else if (engine.chatCompletion) {
        // older API compatibility
        const out = await engine.chatCompletion(messages);
        resultText = out?.choices?.[0]?.message?.content || '';
      } else if (engine.generate) {
        const out = await engine.generate(input.trim());
        resultText = typeof out === 'string' ? out : (out?.output_text || '');
      }

      if (!resultText) resultText = 'No response produced.';
      setInput(resultText);
    } catch (e: any) {
      console.error('[AIAnalyst] chat error', e);
      setError('Failed to generate response. ' + (e?.message || ''));
    } finally {
      setSending(false);
    }
  }

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex items-end sm:items-center justify-center bg-black/30 p-2 sm:p-6" onClick={(e) => {
      const t = e.target as HTMLElement;
      if (t.classList.contains('z-[9999]')) onClose();
    }}>
      <div className="w-full sm:max-w-[720px] bg-white rounded-xl shadow-2xl border border-gray-200 overflow-hidden" onClick={(e) => e.stopPropagation()}>
        <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between">
          <div>
            <p className="text-[13px] text-gray-500">AI Analyst</p>
            <h3 className="text-[16px] text-gray-900" style={{ fontWeight: 700 }}>{title || 'Ask about this dashboard'}</h3>
          </div>
          <button onClick={onClose} className="p-2 rounded-md hover:bg-gray-100" aria-label="Close">✕</button>
        </div>

        <div className="p-4 space-y-3">
          {!ready && !error && (
            <div className="text-[12px] text-gray-600">{progress || (loadingRuntime ? 'Loading AI runtime…' : 'Initializing local AI runtime…')}</div>
          )}
          {error && (
            <div className="flex items-center justify-between gap-2">
              <div className="text-[12px] text-red-600">{error}</div>
              <button
                className="text-[12px] px-2 py-1 rounded-md border border-gray-300 hover:bg-gray-50"
                onClick={() => { setError(null); setReady(false); engineRef.current = null; setTimeout(() => { if (open) { /* re-init */ } }, 0); }}
              >
                Retry
              </button>
            </div>
          )}

          <div className="text-[12px] text-gray-500 bg-gray-50 rounded-md p-3 border border-gray-100">
            <div className="font-semibold text-gray-700 mb-1">Context</div>
            <pre className="whitespace-pre-wrap text-[12px] leading-5">{context}</pre>
          </div>

          <div className="flex items-start gap-2">
            <textarea
              className="flex-1 min-h-[90px] text-[13px] rounded-md border border-gray-300 p-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask a question about the data…"
              disabled={!ready || sending}
            />
            <button
              onClick={send}
              disabled={!ready || sending || !input.trim()}
              className={`self-stretch px-4 py-2 rounded-md text-white text-[13px] ${sending || !ready ? 'bg-gray-400' : 'bg-indigo-600 hover:bg-indigo-700'}`}
            >
              {sending ? 'Thinking…' : 'Ask'}
            </button>
          </div>

          <div className="text-[11px] text-gray-400">Runs fully in your browser using an open model (no data leaves your device).</div>
        </div>
      </div>
    </div>
  );
}
