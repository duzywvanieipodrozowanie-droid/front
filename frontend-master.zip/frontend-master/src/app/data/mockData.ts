// Mock data for engineering metrics platform (Swarmia-style)

// ─── DORA Metrics ────────────────────────────────────────────────────────────
export const doraMetrics = {
    deploymentFrequency: {
        current: 0.0,
        previous: 0.0,
        unit: 'per week',
        trend: 'up' as const,
        rating: 'elite' as const,
    },
    leadTime: {
        current: 0.0,
        previous: 0 / 0,
        unit: 'hours',
        trend: 'down' as const,
        rating: 'elite' as const,
    },
    changeFailureRate: {
        current: 0.0,
        previous: 0.0,
        unit: '%',
        trend: 'down' as const,
        rating: 'elite' as const,
    },
    mttr: {
        current: 0.0,
        previous: 0.0,
        unit: 'hours',
        trend: 'down' as const,
        rating: 'elite' as const,
    },
};

export const deploymentFrequencyData = [];

export const leadTimeData = [];

export const changeFailureRateData = [];

export const mttrData = [];

// ─── PR & Cycle Time ─────────────────────────────────────────────────────────
export const prCycleTimeData = [];

export const prThroughputData = [];

export const prFunnelData = [];

// ─── Code Quality ─────────────────────────────────────────────────────────────
export const codeQualityMetrics = {
    codeReviewTime: {
        current: 0.0,
        previous: 0.0,
        unit: 'hours',
        trend: 'down' as const,
    },
    prSize: {
        current: 0,
        previous: 0,
        unit: 'lines',
        trend: 'down' as const,
    },
    testCoverage: {
        current: 0,
        previous: 0,
        unit: '%',
        trend: 'up' as const,
    },
    codeChurn: {
        current: 0,
        previous: 0,
        unit: '%',
        trend: 'down' as const,
    },
};

export const testCoverageData = [];

export const prMetricsData = [];

// ─── CI/CD ────────────────────────────────────────────────────────────────────
export const cicdMetrics = {
    buildSuccessRate: {
        current: 0,
        previous: 0,
        unit: '%',
        trend: 'up' as const,
    },
    avgBuildTime: {
        current: 0,
        previous: 0,
        unit: 'min',
        trend: 'down' as const,
    },
    pipelineExecutions: {
        current: 0,
        previous: 0,
        unit: 'per week',
        trend: 'up' as const,
    },
    deploymentSuccess: {
        current: 0,
        previous: 0,
        unit: '%',
        trend: 'up' as const,
    },
};

export const buildTimeData = [];

export const pipelineStatusData = [];

// ─── Team ─────────────────────────────────────────────────────────────────────
export const teamMembers = [];

export const commitActivityData = [];

// ─── Working Agreements ──────────────────────────────────────────────────────
export const workingAgreements = [];

// ─── Overview (Dashboard) ─────────────────────────────────────────────────────
export const overviewMetrics = {
    prCycleTime: {current: 0, previous: 0, unit: 'hours', trend: 'down' as const},
    prThroughput: {current: 0, previous: 0, unit: 'PRs / 4 wks', trend: 'up' as const},
    deploymentFreq: {current: 0, previous: 0, unit: '/ week', trend: 'up' as const},
    changeFailureRate: {current: 0, previous: 0, unit: '%', trend: 'down' as const},
};
