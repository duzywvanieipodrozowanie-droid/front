import { useEffect, useState } from 'react';

// Returns current brand logo URL (data URL or external) configured in Setup Organization.
// Falls back to provided defaultUrl if nothing is configured.
export function useBrandLogo(defaultUrl?: string) {
  const [logo, setLogo] = useState<string>(() => {
    try {
      const stored = localStorage.getItem('app.brand.logo');
      return (stored && stored.trim()) || defaultUrl || '';
    } catch {
      return defaultUrl || '';
    }
  });

  useEffect(() => {
    const onStorage = (e: StorageEvent) => {
      if (e.key === 'app.brand.logo' && typeof e.newValue === 'string') {
        setLogo(e.newValue || (defaultUrl || ''));
      }
    };
    const onBrandUpdated = (e: Event) => {
      try {
        const detail = ((e as CustomEvent).detail || {}) as { logo?: unknown };
        if (typeof detail.logo === 'string') {
          setLogo(detail.logo || (defaultUrl || ''));
        }
      } catch {}
    };
    window.addEventListener('storage', onStorage);
    window.addEventListener('app.brand.updated', onBrandUpdated as EventListener);
    return () => {
      window.removeEventListener('storage', onStorage);
      window.removeEventListener('app.brand.updated', onBrandUpdated as EventListener);
    };
  }, [defaultUrl]);

  return logo;
}

export default useBrandLogo;
