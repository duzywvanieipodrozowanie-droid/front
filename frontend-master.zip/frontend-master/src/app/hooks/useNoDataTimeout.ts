import { useEffect, useRef, useState } from 'react';

/**
 * Returns a boolean `timedOut` that becomes true after `timeoutMs` unless `reset()` is called.
 * Use it to show a "No Data" state if API data hasn't arrived within the timeout window.
 */
export function useNoDataTimeout(timeoutMs: number = 180000) {
  const [timedOut, setTimedOut] = useState(false);
  const timerRef = useRef<number | null>(null);

  const clear = () => {
    if (timerRef.current != null) {
      window.clearTimeout(timerRef.current);
      timerRef.current = null;
    }
  };

  const reset = () => {
    clear();
    setTimedOut(false);
    timerRef.current = window.setTimeout(() => {
      setTimedOut(true);
    }, timeoutMs);
  };

  useEffect(() => {
    // start on mount
    reset();
    return () => clear();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [timeoutMs]);

  return { timedOut, reset } as const;
}
