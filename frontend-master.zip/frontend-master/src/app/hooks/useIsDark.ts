import { useSyncExternalStore } from 'react';

/**
 * Reactively track whether <html> has the `dark` class.
 * Works across toggles by subscribing to class attribute mutations.
 */
export function useIsDark(): boolean {
  // Subscribe to changes on document.documentElement.className using MutationObserver
  const subscribe = (onStoreChange: () => void) => {
    if (typeof document === 'undefined' || typeof MutationObserver === 'undefined') {
      return () => {};
    }
    const target = document.documentElement;
    const obs = new MutationObserver(() => {
      onStoreChange();
    });
    try {
      obs.observe(target, { attributes: true, attributeFilter: ['class'] });
    } catch {
      // no-op
    }
    return () => {
      try { obs.disconnect(); } catch {}
    };
  };

  const getSnapshot = () => {
    if (typeof document === 'undefined') return false;
    return document.documentElement.classList.contains('dark');
  };

  const getServerSnapshot = () => false;

  return useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
}

export default useIsDark;
