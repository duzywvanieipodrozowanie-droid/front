import { useEffect, useState } from 'react';

/**
 * Whether the logged-in user may open a menu page: the roles of the pages are set in Settings → Users and access
 * (/api/access, e.g. Deliver for MANAGER). An older core without /api/access: only ADMIN.
 */
export function usePageAccess(pageKey: string): { loading: boolean; allowed: boolean } {
  const [state, setState] = useState({ loading: true, allowed: false });
  useEffect(() => {
    let cancelled = false;
    const json = (url: string) => fetch(url, { credentials: 'include' }).then((r) => (r.ok ? r.json() : null)).catch(() => null);
    (async () => {
      const access = await json('/api/access');
      let allowed: boolean;
      if (access && Array.isArray(access.pages)) {
        allowed = access.pages.includes(pageKey);
      } else {
        const user = await json('/api/user');
        allowed = Array.isArray(user?.authorities) && user.authorities.includes('ADMIN');
      }
      if (!cancelled) setState({ loading: false, allowed });
    })();
    return () => { cancelled = true; };
  }, [pageKey]);
  return state;
}
