import { createBrowserRouter } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Dashboard } from './pages/Dashboard';
import { DoraMetrics } from './pages/DoraMetrics';
import { Deliver } from './pages/Deliver';
import { MyMetrics } from './pages/MyMetrics';
import { CodeImpact } from './pages/CodeImpact';
import { ServiceMap } from './pages/ServiceMap';
import { ReleaseCheck } from './pages/ReleaseCheck';
import { ArchitectureC4 } from './pages/ArchitectureC4';
import { TaskTimeline } from './pages/TaskTimeline';
// import { WorkingAgreements } from './pages/WorkingAgreements';
import { Investments } from './pages/Investments';
// import { CodeQuality } from './pages/CodeQuality';
// import { CICD } from './pages/CICD';
import { Team } from './pages/Team';
import { DeveloperDetails } from './pages/DeveloperDetails';
// import { DeveloperCompare } from './pages/DeveloperCompare';
// import { Benchmark } from './pages/Benchmark';
import { HelpSupport } from './pages/HelpSupport';
import { Settings } from './pages/SettingsHub';
import { SetupOrganization } from './pages/SetupOrganization';
import { Thresholds } from './pages/Thresholds';
import { ControlTower } from './pages/ControlTower';
import { UnknownCommiters } from './pages/UnknownCommiters';
import { GitlabDetails } from './pages/GitlabDetails';
import { DeploymentDashboard } from './pages/DeploymentDashboard';
import { ProductionSupport } from './pages/ProductionSupport';
import { lazy } from 'react';
const ConfiguratorPage = lazy(() => import('./pages/Configurator').then(m => ({ default: m.Configurator })));
const DeveloperComparePage = lazy(() => import('./pages/DeveloperCompare').then(m => ({ default: m.DeveloperCompare })));
const VendorAssessmentPage = lazy(() => import('./pages/VendorAssessment').then(m => ({ default: m.VendorAssessment })));
const AiAgentSettingsPage = lazy(() => import('./pages/AiAgentSettings').then(m => ({ default: m.AiAgentSettings })));
const ReleasePage = lazy(() => import('./pages/Release').then(m => ({ default: m.Release })));
const UsersAccessPage = lazy(() => import('./pages/UsersAccess').then(m => ({ default: m.UsersAccess })));
const ProductOverviewPage = lazy(() => import('./pages/ProductOverview').then(m => ({ default: m.ProductOverview })));
const RoadmapPage = lazy(() => import('./pages/Roadmap').then(m => ({ default: m.Roadmap })));
const ProjectsEnvironmentsPage = lazy(() => import('./pages/ProjectsEnvironments').then(m => ({ default: m.ProjectsEnvironments })));
import KeycloakRedirect from './components/KeycloakRedirect';

// Root-level auth loader to enforce SSO on any route access
async function authLoader() {
  // Enforce SSO for all routes (including /welcome)
  try {
    const res = await fetch('/api/hc', { credentials: 'include' });
    if (!res.ok) {
      // Not authenticated -> redirect to backend to initiate Keycloak SSO
      window.location.href = '/api/';
    }
  } catch (_e) {
    // Network or other error -> also redirect to SSO entry
    window.location.href = '/api/';
  }
  // Return null; nothing to provide to route components
  return null;
}

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Layout,
    loader: authLoader,
    children: [
      { index: true, Component: Dashboard },
      { path: 'dora', Component: DoraMetrics },
      { path: 'product', Component: ProductOverviewPage },
      { path: 'config', Component: ConfiguratorPage },
      // { path: 'working-agreements', Component: WorkingAgreements },
      { path: 'investments', Component: Investments },
      // { path: 'code-quality', Component: CodeQuality },
      // { path: 'cicd', Component: CICD },
      { path: 'team', Component: Team },
      { path: 'team/developer', Component: DeveloperDetails },
      { path: 'team/compare', Component: DeveloperComparePage },
      { path: 'control-tower', Component: ControlTower },
      // { path: 'benchmark', Component: Benchmark },
      { path: 'settings', Component: Settings },
      { path: 'settings/organization', Component: SetupOrganization },
      { path: 'settings/thresholds', Component: Thresholds },
      { path: 'settings/unknown-commiters', Component: UnknownCommiters },
      { path: 'settings/ai-agent', Component: AiAgentSettingsPage },
      { path: 'settings/access', Component: UsersAccessPage },
      { path: 'settings/projects', Component: ProjectsEnvironmentsPage },
      { path: 'gitlab-details', Component: GitlabDetails },
      { path: 'deliver', Component: Deliver },
      { path: 'roadmap', Component: RoadmapPage },
      { path: 'production-support', Component: ProductionSupport },
      { path: 'vendor-assessment', Component: VendorAssessmentPage },
      { path: 'my-metrics', Component: MyMetrics },
      { path: 'help', Component: HelpSupport },
      { path: 'release', Component: ReleasePage },
      { path: 'deployments', Component: DeploymentDashboard },
      { path: 'code-impact', Component: CodeImpact },
      { path: 'service-map', Component: ServiceMap },
      { path: 'architecture', Component: ArchitectureC4 },
      { path: 'task-timeline', Component: TaskTimeline },
      { path: 'release-check', Component: ReleaseCheck },
      { path: 'krandeployment', Component: DeploymentDashboard },
    ],
  },
  {
    path: '*',
    Component: KeycloakRedirect,
  },
]);
