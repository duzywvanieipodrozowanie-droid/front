import { useMemo, useState } from 'react';
import { Calendar as CalendarPicker } from '../components/ui/calendar';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '../components/ui/dialog';
import { CalendarClock, CheckCircle2, Clock, GitBranch, ListChecks, Rocket, XCircle, Bug, BarChart3, LineChart, Info } from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip as RTooltip,
  BarChart,
  Bar,
  Legend,
  CartesianGrid,
} from 'recharts';
import { usePageAccess } from '../hooks/usePageAccess';

// Release management overview (mock-data based UI)
// - Monthly calendar: click a date to see deployments with microservices, times, JIRAs, type (new/config-only).
// - Summary: planned release cutoff window + last deployed details with status (success/rollback).
// - Dashboard charts: success rate over time; late scope changes (<4h) count; full vs partial delivery; post-release defect delta.

// Types
interface JiraItem { key: string; title: string }
interface ServiceDeploy {
  service: string;
  time: string; // HH:mm
  jiras: JiraItem[];
  kind: 'new-service' | 'config-only' | 'feature';
}
interface DayRelease {
  date: string; // YYYY-MM-DD
  items: ServiceDeploy[];
  status: 'success' | 'rollback' | 'partial';
}

export function Release() {
  // the role of the page: Settings → Users and access
  const { loading: accessLoading, allowed: canOpen } = usePageAccess('release');


  // Mock window: planned release and cut-off
  const planned = {
    name: 'RLS-2026.09.30',
    releaseDate: new Date(new Date().getFullYear(), new Date().getMonth(), 30, 22, 0, 0),
    cutoff: new Date(new Date().getFullYear(), new Date().getMonth(), 28, 18, 0, 0),
  };

  // Mock last deployed summary
  const lastDeployed = {
    at: new Date(new Date().getFullYear(), new Date().getMonth(), 18, 21, 15),
    status: 'success' as 'success' | 'rollback',
    services: ['users', 'payments', 'gateway'],
    jiras: ['PROD-142', 'PAY-88', 'GW-19'],
  };

  // Mock calendar dataset for current month
  const today = new Date();
  const yyyy = today.getFullYear();
  const mm = today.getMonth();

  const dataByDay: Record<string, DayRelease> = useMemo(() => {
    const d = (day: number): string => {
      const m = String(mm + 1).padStart(2, '0');
      const dd = String(day).padStart(2, '0');
      return `${yyyy}-${m}-${dd}`;
    };
    return {
      [d(3)]: {
        date: d(3),
        status: 'success',
        items: [
          { service: 'users', time: '10:05', jiras: [{ key: 'USR-123', title: 'Add 2FA' }], kind: 'feature' },
          { service: 'catalog', time: '10:22', jiras: [{ key: 'CAT-45', title: 'Facet fix' }], kind: 'config-only' },
        ],
      },
      [d(7)]: {
        date: d(7),
        status: 'rollback',
        items: [
          { service: 'payments', time: '12:40', jiras: [{ key: 'PAY-88', title: 'PSD2 tweak' }], kind: 'feature' },
        ],
      },
      [d(11)]: {
        date: d(11),
        status: 'success',
        items: [
          { service: 'gateway', time: '09:30', jiras: [{ key: 'GW-19', title: 'Header normalizer' }], kind: 'new-service' },
          { service: 'orders', time: '11:00', jiras: [{ key: 'ORD-77', title: 'Lock timeout' }], kind: 'feature' },
        ],
      },
      [d(18)]: {
        date: d(18),
        status: 'success',
        items: [
          { service: 'users', time: '20:45', jiras: [{ key: 'USR-141', title: 'Avatar CDN' }], kind: 'config-only' },
          { service: 'pricing', time: '21:10', jiras: [{ key: 'PRC-5', title: 'EU rounding' }], kind: 'feature' },
        ],
      },
      [d(22)]: {
        date: d(22),
        status: 'partial',
        items: [
          { service: 'search', time: '14:05', jiras: [{ key: 'SRCH-12', title: 'Synonyms' }], kind: 'feature' },
        ],
      },
    };
  }, [mm, yyyy]);

  const [selectedDate, setSelectedDate] = useState<Date | undefined>(today);

  // Charts data (weekly buckets)
  const successSeries = [
    { week: 'W30', success: 92, rollback: 8 },
    { week: 'W31', success: 95, rollback: 5 },
    { week: 'W32', success: 88, rollback: 12 },
    { week: 'W33', success: 96, rollback: 4 },
    { week: 'W34', success: 91, rollback: 9 },
    { week: 'W35', success: 97, rollback: 3 },
  ];

  const lateScope = [
    { week: 'W30', late: 1 },
    { week: 'W31', late: 3 },
    { week: 'W32', late: 0 },
    { week: 'W33', late: 2 },
    { week: 'W34', late: 1 },
    { week: 'W35', late: 4 },
  ];

  const fullVsPartial = [
    { kind: 'Full', count: 18, color: '#10b981' },
    { kind: 'Partial', count: 5, color: '#f59e0b' },
  ];

  const defectDelta = [
    { week: 'W30', delta: -12 },
    { week: 'W31', delta: -6 },
    { week: 'W32', delta: 7 },
    { week: 'W33', delta: -15 },
    { week: 'W34', delta: 4 },
    { week: 'W35', delta: -9 },
  ];

  const selectedKey = useMemo(() => {
    const d = selectedDate ?? today;
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    return `${d.getFullYear()}-${m}-${dd}`;
  }, [selectedDate, today]);

  const dayInfo = dataByDay[selectedKey];

  // Build modifiers for calendar day coloring
  const modifiers = useMemo(() => {
    const success: Date[] = [];
    const rollback: Date[] = [];
    const fix: Date[] = [];
    Object.values(dataByDay).forEach((d) => {
      const [y, m, dd] = d.date.split('-').map(Number);
      const date = new Date(y, (m as number) - 1, dd as number);
      const allConfigOnly = d.items.length > 0 && d.items.every(i => i.kind === 'config-only');
      if (d.status === 'rollback') rollback.push(date);
      else if (allConfigOnly) fix.push(date);
      else if (d.status === 'success') success.push(date);
    });
    return { success, rollback, fix } as const;
  }, [dataByDay]);

  const [dialogOpen, setDialogOpen] = useState(false);

  function fmtDateTime(dt: Date): string {
    return dt.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
  }

  if (accessLoading) {
    return (
      <div className="p-6 mx-auto">
        <p className="text-[13px] text-gray-500">Ładowanie…</p>
      </div>
    );
  }
  if (!canOpen) {
    return (
      <div className="p-6 mx-auto">
        <div className="bg-white border border-gray-200 rounded-xl p-5">
          <p className="text-[14px] text-gray-800" style={{ fontWeight: 600 }}>Brak dostępu</p>
          <p className="text-[12px] text-gray-500 mt-1">Twoja rola nie ma dostępu do tego ekranu. Admin może to zmienić w Ustawienia → Użytkownicy i dostęp.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 mx-auto">
      <div className="flex items-center gap-2 mb-4">
        <div className="w-9 h-9 rounded-lg bg-indigo-600 flex items-center justify-center">
          <CalendarClock className="w-5 h-5 text-white" />
        </div>
        <h1 className="text-[20px] text-gray-900" style={{ fontWeight: 700 }}>Release</h1>
      </div>

      {/* Top summary */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-5">
        <div className="bg-white border border-gray-200 rounded-xl p-5">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-gray-500" />
              <span className="text-[12px] text-gray-500 uppercase tracking-wide" style={{ fontWeight: 700 }}>Planned release</span>
            </div>
            <span className="text-[11px] text-gray-400">Cut-off</span>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <div className="text-[14px] text-gray-900" style={{ fontWeight: 700 }}>{planned.name}</div>
              <div className="text-[12px] text-gray-600">Release: {fmtDateTime(planned.releaseDate)}</div>
            </div>
            <div className="text-right">
              <div className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-yellow-50 border border-yellow-200">
                <Clock className="w-3.5 h-3.5 text-yellow-600" />
                <span className="text-[12px] text-yellow-700">{fmtDateTime(planned.cutoff)}</span>
              </div>
              <div className="text-[11px] text-gray-500 mt-1">Deadline for scope changes</div>
            </div>
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-xl p-5">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <Rocket className="w-4 h-4 text-gray-500" />
              <span className="text-[12px] text-gray-500 uppercase tracking-wide" style={{ fontWeight: 700 }}>Last deployed</span>
            </div>
            {lastDeployed.status === 'success' ? (
              <span className="inline-flex items-center gap-1 text-[12px] text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-md">
                <CheckCircle2 className="w-3.5 h-3.5" /> success
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 text-[12px] text-red-700 bg-red-50 border border-red-200 px-2 py-0.5 rounded-md">
                <XCircle className="w-3.5 h-3.5" /> rollback
              </span>
            )}
          </div>
          <div className="flex items-center justify-between">
            <div>
              <div className="text-[13px] text-gray-600">{fmtDateTime(lastDeployed.at)}</div>
              <div className="text-[12px] text-gray-600 mt-1">Services: <span className="text-gray-900" style={{ fontWeight: 600 }}>{lastDeployed.services.join(', ')}</span></div>
              <div className="text-[12px] text-gray-600 mt-1">JIRA: <span className="text-gray-900" style={{ fontWeight: 600 }}>{lastDeployed.jiras.join(', ')}</span></div>
            </div>
            <div className="text-right">
              <div className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-indigo-50 border border-indigo-200">
                <Info className="w-3.5 h-3.5 text-indigo-600" />
                <span className="text-[12px] text-indigo-700">100% rolled out</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Calendar + details */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-5">
        <div className="bg-white border border-gray-200 rounded-xl p-3">
          <CalendarPicker
            mode="single"
            selected={selectedDate}
            onSelect={(d) => { setSelectedDate(d); if (d) { const m = String((d.getMonth()+1)).padStart(2,'0'); const dd = String(d.getDate()).padStart(2,'0'); const key = `${d.getFullYear()}-${m}-${dd}`; if (dataByDay[key]) setDialogOpen(true); } }}
            className="rounded-md"
            modifiers={modifiers as any}
            modifiersClassNames={{
              success: 'bg-emerald-100 text-emerald-900 hover:bg-emerald-200',
              rollback: 'bg-red-100 text-red-900 hover:bg-red-200',
              fix: 'bg-amber-100 text-amber-900 hover:bg-amber-200',
            }}
          />
          <div className="flex items-center gap-3 mt-3 text-[12px] text-gray-600">
            <span className="inline-flex items-center gap-1"><span className="w-3 h-3 rounded-sm bg-emerald-400 inline-block"/> success</span>
            <span className="inline-flex items-center gap-1"><span className="w-3 h-3 rounded-sm bg-red-400 inline-block"/> rollback</span>
            <span className="inline-flex items-center gap-1"><span className="w-3 h-3 rounded-sm bg-amber-400 inline-block"/> fix only</span>
          </div>
        </div>
        <div className="bg-white border border-gray-200 rounded-xl p-5">
          <div className="flex items-center gap-2 mb-3">
            <ListChecks className="w-4 h-4 text-gray-500" />
            <span className="text-[12px] text-gray-500 uppercase tracking-wide" style={{ fontWeight: 700 }}>Deployments on selected day</span>
          </div>
          {!dayInfo ? (
            <div className="text-[13px] text-gray-500">No deployments on this day.</div>
          ) : (
            <div>
              <div className="flex items-center gap-2 mb-2">
                {dayInfo.status === 'success' && <span className="text-[11px] px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">success</span>}
                {dayInfo.status === 'rollback' && <span className="text-[11px] px-1.5 py-0.5 rounded bg-red-50 text-red-700 border border-red-200">rollback</span>}
                {dayInfo.status === 'partial' && <span className="text-[11px] px-1.5 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200">partial</span>}
              </div>
              <ul className="space-y-2">
                {dayInfo.items.map((it, idx) => (
                  <li key={idx} className="border border-gray-200 rounded-lg p-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <GitBranch className="w-4 h-4 text-gray-500" />
                        <span className="text-[13px] text-gray-900" style={{ fontWeight: 700 }}>{it.service}</span>
                      </div>
                      <span className="text-[12px] text-gray-500">{it.time}</span>
                    </div>
                    <div className="text-[12px] text-gray-600 mt-1">JIRA: {it.jiras.map(j => j.key).join(', ')}</div>
                    <div className="mt-1">
                      {it.kind === 'new-service' && <span className="text-[11px] px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200">new service</span>}
                      {it.kind === 'config-only' && <span className="text-[11px] ml-1 px-1.5 py-0.5 rounded bg-slate-50 text-slate-700 border border-slate-200">config only</span>}
                      {it.kind === 'feature' && <span className="text-[11px] ml-1 px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">feature</span>}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      </div>

      {/* Popup with day details */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Release details for {selectedKey}</DialogTitle>
          </DialogHeader>
          {!dayInfo ? (
            <div className="text-[13px] text-gray-500">No deployments on this day.</div>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                {dayInfo.status === 'success' && <span className="text-[12px] px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">success</span>}
                {dayInfo.status === 'rollback' && <span className="text-[12px] px-2 py-0.5 rounded bg-red-50 text-red-700 border border-red-200">rollback</span>}
                {dayInfo.status === 'partial' && <span className="text-[12px] px-2 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200">partial</span>}
              </div>
              <ul className="space-y-2">
                {dayInfo.items.map((it, idx) => (
                  <li key={idx} className="border border-gray-200 rounded-lg p-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <GitBranch className="w-4 h-4 text-gray-500" />
                        <span className="text-[13px] text-gray-900" style={{ fontWeight: 700 }}>{it.service}</span>
                      </div>
                      <span className="text-[12px] text-gray-500">{it.time}</span>
                    </div>
                    <div className="text-[12px] text-gray-600 mt-1">JIRA: {it.jiras.map(j => j.key).join(', ')}</div>
                    <div className="mt-1">
                      {it.kind === 'new-service' && <span className="text-[11px] px-1.5 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200">new service</span>}
                      {it.kind === 'config-only' && <span className="text-[11px] ml-1 px-1.5 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-200">fix (config only)</span>}
                      {it.kind === 'feature' && <span className="text-[11px] ml-1 px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">feature</span>}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Dashboard */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-white border border-gray-200 rounded-xl p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <LineChart className="w-4 h-4 text-gray-500" />
              <span className="text-[12px] text-gray-500 uppercase tracking-wide" style={{ fontWeight: 700 }}>Success vs rollback</span>
            </div>
          </div>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={successSeries} margin={{ left: 10, right: 10, top: 10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#eee" />
                <XAxis dataKey="week" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} domain={[0, 100]} />
                <RTooltip />
                <Legend />
                <Area type="monotone" dataKey="success" stroke="#10b981" fill="#d1fae5" name="Success %" />
                <Area type="monotone" dataKey="rollback" stroke="#ef4444" fill="#fee2e2" name="Rollback %" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-xl p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-gray-500" />
              <span className="text-[12px] text-gray-500 uppercase tracking-wide" style={{ fontWeight: 700 }}>Late scope changes (&lt;4h)</span>
            </div>
          </div>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={lateScope} margin={{ left: 10, right: 10, top: 10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#eee" />
                <XAxis dataKey="week" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} allowDecimals={false} />
                <RTooltip />
                <Bar dataKey="late" name="Releases with late changes" fill="#f59e0b" radius={[4,4,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-xl p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-gray-500" />
              <span className="text-[12px] text-gray-500 uppercase tracking-wide" style={{ fontWeight: 700 }}>Full vs partial delivery</span>
            </div>
          </div>
          <div className="h-56 flex items-end gap-4">
            {fullVsPartial.map((b) => {
              const total = fullVsPartial.reduce((s, x) => s + x.count, 0);
              const pct = Math.round((b.count / total) * 100);
              return (
                <div key={b.kind} className="flex-1 flex flex-col items-center justify-end h-full">
                  <div className="w-12 rounded-t-md" style={{ height: `${pct}%`, backgroundColor: b.color }} />
                  <div className="text-[12px] text-gray-600 mt-2">{b.kind}</div>
                  <div className="text-[12px] text-gray-900" style={{ fontWeight: 700 }}>{pct}%</div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="bg-white border border-gray-200 rounded-xl p-5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Bug className="w-4 h-4 text-gray-500" />
              <span className="text-[12px] text-gray-500 uppercase tracking-wide" style={{ fontWeight: 700 }}>Production defects delta</span>
            </div>
            <div className="text-[11px] text-gray-500">Thresholds: warn &gt; 5%, stable ≤ -10%</div>
          </div>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={defectDelta} margin={{ left: 10, right: 10, top: 10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#eee" />
                <XAxis dataKey="week" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} domain={[ (dataMin: number) => Math.min(-20, dataMin), (dataMax: number) => Math.max(20, dataMax) ]} />
                <RTooltip formatter={(v: number) => `${v}% vs prev period`} />
                <Bar dataKey="delta" name="Defects % change" radius={[4,4,0,0]}>
                  {/* Color logic via function not supported in simple JSX here; map in data color? keep single color and show chips */}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
            <div className="flex items-center gap-2 mt-2">
              <span className="text-[11px] px-1.5 py-0.5 rounded bg-red-50 text-red-700 border border-red-200">&gt; 5% = attention</span>
              <span className="text-[11px] px-1.5 py-0.5 rounded bg-emerald-50 text-emerald-700 border border-emerald-200">≤ -10% = stable</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Release;
