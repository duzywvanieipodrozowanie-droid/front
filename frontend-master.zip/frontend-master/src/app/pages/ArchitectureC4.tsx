import { useEffect, useMemo, useRef, useState } from 'react';
import type { PointerEvent as ReactPointerEvent, ReactNode } from 'react';
import { ChevronRight, ExternalLink, Eye, EyeOff, FileCode2, Group as GroupIcon, Info, Layers, Link2, Network, Pencil, Plus, RotateCcw, Save, Trash2, Undo2, X } from 'lucide-react';
import { usePick } from '../i18n';
import {
  applyEdit, around, darker, emptyEdit, GROUP_COLORS, isEmptyEdit, newId, NODE_COLORS, normalizeEdit, removeNode, textOn, union,
} from './architecture/c4Edit';
import type { AddedEdge, AddedNode, DiagramEdit, EditedEdge, EditedNode, Look, Pos, Rect } from './architecture/c4Edit';

// Architecture (C4) of a project from core /api/architecture: the importer job "architecture" scans the GitLab
// repositories of the project (Spring Boot config and code, Angular environments) and the ArgoCD deploy repository
// (OpenShift values per environment). Every link keeps where it was detected (repo, file, line).
// Levels: 1 context (the system, its users and the external systems), 2 containers, 3 components of a service.
// A C4.md in a repository (format: importer C4-FORMAT.md) names the system and adds persons, external systems,
// container types / descriptions / domains and relations; a relation to "system" is drawn on level 1 only.
// Level 2 starts with the domains of the system (GitLab subgroups or the names of the services) and a domain opens
// only its containers with their neighbours, so a project with many services stays readable.
// The diagrams are laid out automatically (layers by the direction of the links). Without data: a sample model.
// Edit mode lays a hand edit over a diagram (moved boxes, colours, texts, hidden elements, groups, added elements
// and arrows), saved in core per project and diagram for everyone who sees the project (c4Edit.ts).

type Source = { repo?: string | null; file?: string | null; line?: number | null; text?: string | null };
// endpoints: the called endpoints of the target ("GET /orders/{id}") or the paths of a gateway route
type ModelLink = { from: string; to: string; label: string; tech?: string | null; envs: string[] | null; sources: Source[]; endpoints?: string[] };
type Endpoint = { method: string; path: string; handler?: string | null; file: string; line?: number | null };
type Route = { id?: string | null; uri: string; paths: string[]; target?: string | null };
type Component = { id: string; name: string; stereotype: string; package?: string; file: string; lines?: number };
type Container = {
  id: string; name: string; kind: 'service' | 'frontend' | 'database' | 'queue' | 'external' | 'person'; tech?: string | null;
  repo?: string | null; url?: string | null; description?: string | null; applicationName?: string | null; messaging?: string[];
  domain?: string | null;
  endpoints?: Endpoint[]; routes?: Route[];
  components: Component[]; componentLinks: Array<{ from: string; to: string; source: Source }>;
};
type ArchitectureModel = {
  projectId: string; generatedAt?: string; environments: string[]; containers: Container[]; links: ModelLink[];
  // from C4.md: the name and description of the system on level 1
  system?: { name?: string | null; description?: string | null } | null;
};

type Kind = 'person' | 'system' | 'domain' | 'external' | 'container' | 'frontend' | 'database' | 'queue' | 'component';
type Node = {
  id: string; kind: Kind; name: string; tech?: string; description: string; drill?: string; container?: Container; component?: Component;
  members?: Container[];
};
// details: the links between two domains behind one arrow ("order-service → payment-service: Wywołuje API")
type Edge = { from: string; to: string; label: string; tech?: string; sources: Source[]; envs: string[] | null; count: number; endpoints?: string[]; details?: string[] };
type ShownNode = EditedNode<Node>;
type ShownEdge = EditedEdge<Edge>;
type Diagram = {
  key: string; level: 1 | 2 | 3; title: string; scope: string; boundary?: string; boundaryKind?: string; nodes: Node[]; edges: Edge[];
  tiers?: Map<string, number>;
};

const STYLE: Record<Kind, { fill: string; stroke: string; text: string; label: string }> = {
  person: { fill: '#08427b', stroke: '#052e56', text: '#fff', label: 'Person' },
  system: { fill: '#1168bd', stroke: '#0b4884', text: '#fff', label: 'Software System' },
  domain: { fill: '#1f5f9e', stroke: '#164a7c', text: '#fff', label: 'Domain' },
  external: { fill: '#8a8f98', stroke: '#6b7079', text: '#fff', label: 'External System' },
  container: { fill: '#438dd5', stroke: '#3c7fc0', text: '#fff', label: 'Container' },
  frontend: { fill: '#438dd5', stroke: '#3c7fc0', text: '#fff', label: 'Web App' },
  database: { fill: '#438dd5', stroke: '#3c7fc0', text: '#fff', label: 'Database' },
  queue: { fill: '#438dd5', stroke: '#3c7fc0', text: '#fff', label: 'Message Broker' },
  component: { fill: '#85bbf0', stroke: '#5d9bd8', text: '#0b2540', label: 'Component' },
};
const W = 190;
const H = 92;
const COL = 290;
const ROW = 200;
const LEVELS = [
  { level: 1, en: 'System Context', pl: 'Kontekst systemu' },
  { level: 2, en: 'Containers', pl: 'Kontenery' },
  { level: 3, en: 'Components', pl: 'Komponenty' },
  { level: 4, en: 'Code', pl: 'Kod' },
];
const toolBtn = 'inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-gray-200 dark:border-white/10 hover:bg-gray-50 dark:hover:bg-white/5 disabled:opacity-40';
const card = 'bg-white dark:bg-[#121317] rounded-xl border border-gray-200 dark:border-white/10';
const muted = 'text-gray-500 dark:text-gray-400';
const clip = (text: string, max: number) => (text.length > max ? `${text.slice(0, max - 1)}…` : text);

// ---------- sample model (no scan yet) ----------

const src = (repo: string, file: string, line: number, text: string): Source => ({ repo, file, line, text });
const comp = (pkg: string, name: string, stereotype: string, lines: number): Component =>
  ({ id: `${pkg}.${name}`, name, stereotype, package: pkg, file: `src/main/java/${pkg.replace(/\./g, '/')}/${name}.java`, lines });
const PAY = 'src/main/java/pl/fxp/payment';
const SAMPLE: ArchitectureModel = {
  projectId: 'FXP', environments: ['dev', 'test', 'prod'],
  containers: [
    { id: 'web-app', name: 'web-app', kind: 'frontend', tech: 'Angular 17', repo: 'fxp/channels/web-app', components: [], componentLinks: [] },
    {
      id: 'api-gateway', name: 'api-gateway', kind: 'service', tech: 'Spring Cloud Gateway', repo: 'fxp/channels/api-gateway', components: [], componentLinks: [],
      routes: [{ id: 'orders', uri: 'lb://order-service', paths: ['/api/orders/**'], target: 'order-service' }, { id: 'payments', uri: 'lb://payment-service', paths: ['/api/payments/**', '/api/refunds/**'], target: 'payment-service' }],
    },
    { id: 'order-service', name: 'order-service', kind: 'service', tech: 'Spring Boot · Kotlin', repo: 'fxp/orders/order-service', components: [], componentLinks: [] },
    {
      id: 'payment-service', name: 'payment-service', kind: 'service', tech: 'Spring Boot · Java', repo: 'fxp/payments/payment-service', applicationName: 'payments',
      messaging: ['Feign', 'RabbitMQ (odbiera)'],
      endpoints: [
        { method: 'POST', path: '/api/payments/charge', handler: 'charge', file: `${PAY}/api/PaymentController.java`, line: 31 },
        { method: 'GET', path: '/api/payments/{paymentId}', handler: 'get', file: `${PAY}/api/PaymentController.java`, line: 44 },
        { method: 'GET', path: '/api/payments', handler: 'list', file: `${PAY}/api/PaymentController.java`, line: 52 },
        { method: 'POST', path: '/api/refunds', handler: 'refund', file: `${PAY}/api/RefundController.java`, line: 22 },
        { method: 'DELETE', path: '/api/refunds/{id}', handler: 'cancel', file: `${PAY}/api/RefundController.java`, line: 40 },
      ],
      components: [
        comp('pl.fxp.payment.api', 'PaymentController', '@RestController', 214), comp('pl.fxp.payment.api', 'RefundController', '@RestController', 120),
        comp('pl.fxp.payment.domain', 'PaymentService', '@Service', 388), comp('pl.fxp.payment.integration', 'BlikClient', '@FeignClient', 64),
        comp('pl.fxp.payment.persistence', 'PaymentRepository', 'Spring Data', 22), comp('pl.fxp.payment.events', 'OrderCreatedListener', 'Listener', 58),
      ],
      componentLinks: [
        { from: 'pl.fxp.payment.api.PaymentController', to: 'pl.fxp.payment.domain.PaymentService', source: src('fxp/payments/payment-service', `${PAY}/api/PaymentController.java`, 5, 'import pl.fxp.payment.domain.PaymentService') },
        { from: 'pl.fxp.payment.api.RefundController', to: 'pl.fxp.payment.domain.PaymentService', source: src('fxp/payments/payment-service', `${PAY}/api/RefundController.java`, 4, 'import pl.fxp.payment.domain.PaymentService') },
        { from: 'pl.fxp.payment.domain.PaymentService', to: 'pl.fxp.payment.integration.BlikClient', source: src('fxp/payments/payment-service', `${PAY}/domain/PaymentService.java`, 7, 'import pl.fxp.payment.integration.BlikClient') },
        { from: 'pl.fxp.payment.domain.PaymentService', to: 'pl.fxp.payment.persistence.PaymentRepository', source: src('fxp/payments/payment-service', `${PAY}/domain/PaymentService.java`, 8, 'import pl.fxp.payment.persistence.PaymentRepository') },
        { from: 'pl.fxp.payment.events.OrderCreatedListener', to: 'pl.fxp.payment.domain.PaymentService', source: src('fxp/payments/payment-service', `${PAY}/events/OrderCreatedListener.java`, 3, 'import pl.fxp.payment.domain.PaymentService') },
      ],
    },
    { id: 'cart-service', name: 'cart-service', kind: 'service', tech: 'Spring Boot · Java', repo: 'fxp/orders/cart-service', components: [], componentLinks: [] },
    { id: 'db:payments', name: 'payments', kind: 'database', tech: 'PostgreSQL', components: [], componentLinks: [] },
    { id: 'db:orders', name: 'orders', kind: 'database', tech: 'PostgreSQL', components: [], componentLinks: [] },
    { id: 'rabbitmq', name: 'RabbitMQ', kind: 'queue', tech: 'RabbitMQ', components: [], componentLinks: [] },
    { id: 'ext:api.blik.com', name: 'api.blik.com', kind: 'external', tech: 'HTTPS', description: 'System zewnętrzny', components: [], componentLinks: [] },
  ],
  links: [
    { from: 'web-app', to: 'api-gateway', label: 'Wywołuje API (/api)', tech: 'HTTPS/JSON', envs: null, sources: [src('fxp/channels/web-app', 'src/environments/environment.prod.ts', 3, "apiUrl: '/api'")] },
    { from: 'api-gateway', to: 'order-service', label: 'Przekierowuje (gateway)', tech: 'HTTP · Gateway', envs: null, endpoints: ['/api/orders/**'], sources: [src('fxp/channels/api-gateway', 'src/main/resources/application.yml', 12, 'orders: lb://order-service')] },
    { from: 'api-gateway', to: 'payment-service', label: 'Przekierowuje (gateway)', tech: 'HTTP · Gateway', envs: null, endpoints: ['/api/payments/**', '/api/refunds/**'], sources: [src('fxp/channels/api-gateway', 'src/main/resources/application.yml', 16, 'payments: lb://payment-service')] },
    { from: 'order-service', to: 'payment-service', label: 'Wywołuje API', tech: 'REST · Feign', envs: null, endpoints: ['POST /api/payments/charge', 'GET /api/payments/{paymentId}'], sources: [src('fxp/orders/order-service', 'src/main/kotlin/pl/fxp/order/client/PaymentClient.kt', 4, '@FeignClient(name = "payment-service")')] },
    { from: 'order-service', to: 'cart-service', label: 'Wywołuje API', tech: 'REST', envs: ['test', 'prod'], endpoints: ['GET /api/carts/{id}'], sources: [src('fxp/deploy', 'apps/order-service/values-prod.yaml', 21, 'CART_URL: http://cart-service:8080')] },
    { from: 'order-service', to: 'rabbitmq', label: 'publikuje do order.exchange', tech: 'AMQP', envs: null, sources: [src('fxp/orders/order-service', 'src/main/kotlin/pl/fxp/order/domain/OrderService.kt', 41, 'rabbitTemplate.convertAndSend("order.exchange", ...')] },
    { from: 'rabbitmq', to: 'payment-service', label: 'kolejka order.created.q', tech: 'AMQP', envs: null, sources: [src('fxp/payments/payment-service', `${PAY}/events/OrderCreatedListener.java`, 14, '@RabbitListener(queues = "${queue.orders}")')] },
    { from: 'order-service', to: 'db:orders', label: 'Czyta / zapisuje', tech: 'JDBC', envs: null, sources: [src('fxp/orders/order-service', 'src/main/resources/application.yml', 8, 'url: ${DB_URL:jdbc:postgresql://orders-db/orders}')] },
    { from: 'payment-service', to: 'db:payments', label: 'Czyta / zapisuje', tech: 'JDBC', envs: null, sources: [src('fxp/deploy', 'apps/payment-service/values-prod.yaml', 9, 'SPRING_DATASOURCE_URL: jdbc:postgresql://pg-prod/payments')] },
    { from: 'payment-service', to: 'ext:api.blik.com', label: 'Wywołuje', tech: 'HTTPS', envs: null, sources: [src('fxp/payments/payment-service', `${PAY}/integration/BlikClient.java`, 9, '@FeignClient(name = "blik", url = "${blik.url}")')] },
  ],
};

// ---------- diagrams from the model ----------

const kindOf = (c: Container): Kind => (c.kind === 'service' ? 'container' : c.kind);
const visible = (link: { envs: string[] | null }, env: string) => env === 'all' || !link.envs || link.envs.includes(env);

/** Links between the same pair as one arrow: the first two labels, the others counted. */
function mergeEdges(links: Array<Omit<Edge, 'count'>>): Edge[] {
  const byPair = new Map<string, Edge>();
  links.forEach((l) => {
    const key = `${l.from}>${l.to}`;
    const found = byPair.get(key);
    if (found) {
      found.count += 1;
      found.sources = [...found.sources, ...l.sources].slice(0, 8);
      if (l.endpoints?.length) found.endpoints = [...new Set([...(found.endpoints ?? []), ...l.endpoints])];
      if (found.count === 2 && !found.label.includes(l.label)) found.label = `${found.label}; ${l.label}`;
      if (found.envs && l.envs) found.envs = [...new Set([...found.envs, ...l.envs])];
      else found.envs = null;
    } else {
      byPair.set(key, { ...l, count: 1 });
    }
  });
  return [...byPair.values()];
}

// ---------- domains ----------

const ENTRY = 'wejście (web, gateway)';
const SHARED = 'infrastruktura wspólna';
// words of a service name that say nothing about its domain
const GENERIC = new Set(['service', 'services', 'svc', 'ms', 'api', 'app', 'apps', 'backend', 'be', 'frontend', 'fe', 'web', 'ui',
  'server', 'client', 'impl', 'module', 'spring', 'boot', 'v1', 'v2']);
const isApp = (c: Container) => c.kind === 'service' || c.kind === 'frontend';
// outside the system: persons and external systems
const isOutside = (c: Container) => c.kind === 'external' || c.kind === 'person';

/**
 * Domain of every container but the external systems: the domain set by the scan, else the GitLab subgroup under the
 * common group of the project, else the first meaningful word of the service name (web apps and gateways: the entry).
 * A database or a broker goes to the domain of its services, used by several domains: the shared infrastructure.
 */
function domainsOf(model: ArchitectureModel): Map<string, string> {
  const of = new Map<string, string>();
  const apps = model.containers.filter(isApp);
  const paths = apps.map((c) => (c.repo ?? '').split('/').filter(Boolean)).filter((p) => p.length);
  let common = 0;
  while (paths.length && paths.every((p) => p.length > common + 1 && p[common] === paths[0][common])) common++;
  const tokens = (name: string) => name.toLowerCase().split(/[-_.\s]+/).filter((t) => t && !/^\d+$/.test(t));
  // a word in most of the names is the prefix of the project ("fxp-order-service")
  const seen = new Map<string, number>();
  apps.forEach((c) => new Set(tokens(c.name)).forEach((t) => seen.set(t, (seen.get(t) ?? 0) + 1)));
  const prefix = (t: string) => apps.length > 2 && (seen.get(t) ?? 0) > apps.length / 2;
  // "payment" and "payments" are one domain, named by the shorter word
  const byStem = new Map<string, string>();
  const named = (t: string) => {
    const stem = t.replace(/s$/, '');
    const found = byStem.get(stem);
    if (!found || t.length < found.length) byStem.set(stem, t);
    return stem;
  };
  const stemOf = new Map<string, string>();
  apps.forEach((c) => {
    if (c.domain) { of.set(c.id, c.domain); return; }
    const path = (c.repo ?? '').split('/').filter(Boolean);
    if (path.length > common + 1) { of.set(c.id, path[common]); return; }
    if (c.kind === 'frontend' || c.routes?.length) { of.set(c.id, ENTRY); return; }
    const word = tokens(c.name).find((t) => !GENERIC.has(t) && !prefix(t));
    if (word) stemOf.set(c.id, named(word));
    else of.set(c.id, c.name);
  });
  stemOf.forEach((stem, id) => of.set(id, byStem.get(stem)!));
  model.containers.filter((c) => !isApp(c) && !isOutside(c)).forEach((c) => {
    if (c.domain) { of.set(c.id, c.domain); return; }
    const used = new Set(model.links.filter((l) => l.from === c.id || l.to === c.id)
      .map((l) => of.get(l.from === c.id ? l.to : l.from)).filter((d): d is string => !!d));
    of.set(c.id, used.size === 1 ? [...used][0] : SHARED);
  });
  return of;
}

const services = (n: number) =>
  `${n} ${n === 1 ? 'serwis' : n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 12 || n % 100 > 14) ? 'serwisy' : 'serwisów'}`;

/** Domains worth a level of their own: more than one, and fewer than the containers. */
const domainNames = (of: Map<string, string>) => {
  const names = [...new Set(of.values())];
  return names.length > 1 && names.length < of.size ? names : [];
};
const domainOrder = (a: string, b: string) =>
  (a === ENTRY ? -1 : b === ENTRY ? 1 : a === SHARED ? 1 : b === SHARED ? -1 : a.localeCompare(b));

function containerNode(c: Container): Node {
  return {
    id: c.id, kind: kindOf(c), name: c.name, tech: c.tech ?? undefined, container: c,
    description: c.description || c.applicationName || (c.kind === 'database' ? 'Baza danych' : c.kind === 'queue' ? 'Broker wiadomości' : c.repo || ''),
    drill: c.components.length ? `components:${c.id}` : undefined,
  };
}

/** The domains of the system; an arrow between two domains sums up the links of their containers. */
function domainDiagram(model: ArchitectureModel, env: string, project: string, of: Map<string, string>): Diagram {
  const nodes: Node[] = domainNames(of).sort(domainOrder).map((d) => {
    const members = model.containers.filter((c) => of.get(c.id) === d);
    const apps = members.filter(isApp).length;
    return {
      id: `domain:${d}`, kind: 'domain', name: d, members, drill: `domain:${d}`,
      tech: [apps ? services(apps) : '', members.length > apps ? `${members.length - apps} infra` : ''].filter(Boolean).join(' · '),
      description: members.map((m) => m.name).join(', '),
    };
  });
  const byPair = new Map<string, Edge>();
  const nameOf = (id: string) => model.containers.find((c) => c.id === id)?.name ?? id;
  model.links.filter((l) => visible(l, env)).forEach((l) => {
    const a = of.get(l.from);
    const b = of.get(l.to);
    if (!a || !b || a === b) return;
    const key = `${a}>${b}`;
    const detail = `${nameOf(l.from)} → ${nameOf(l.to)}: ${l.label}`;
    const found = byPair.get(key);
    if (!found) {
      byPair.set(key, { from: `domain:${a}`, to: `domain:${b}`, label: l.label, tech: l.tech ?? undefined, sources: l.sources, envs: l.envs, count: 1, details: [detail] });
      return;
    }
    found.details!.push(detail);
    found.label = `${found.details!.length} powiązań`;
    found.sources = [...found.sources, ...l.sources].slice(0, 8);
    if (l.tech && !found.tech?.split(', ').includes(l.tech)) found.tech = found.tech ? `${found.tech}, ${l.tech}` : l.tech;
    found.envs = found.envs && l.envs ? [...new Set([...found.envs, ...l.envs])] : null;
  });
  // persons using the domains, outside the boundary of the system
  const persons = model.containers.filter((c) => c.kind === 'person');
  const personEdges = mergeEdges(model.links.filter((l) => visible(l, env) && persons.some((p) => p.id === l.from) && of.get(l.to))
    .map((l) => ({ from: l.from, to: `domain:${of.get(l.to)}`, label: l.label, tech: l.tech ?? undefined, sources: l.sources, envs: l.envs })));
  const used = new Set(personEdges.map((e) => e.from));
  nodes.unshift(...persons.filter((p) => used.has(p.id)).map(containerNode));
  return { key: 'domains', level: 2, title: project, scope: 'Domains', boundary: project, boundaryKind: 'Software System', nodes, edges: [...personEdges, ...byPair.values()] };
}

/** One domain: its containers and, outside its boundary, the containers of other domains and the external systems it talks to. */
function domainSlice(model: ArchitectureModel, env: string, domain: string, of: Map<string, string>): Diagram {
  const inside = new Set(model.containers.filter((c) => of.get(c.id) === domain).map((c) => c.id));
  const links = model.links.filter((l) => visible(l, env) && (inside.has(l.from) || inside.has(l.to)));
  const nodes: Node[] = model.containers.filter((c) => inside.has(c.id)).map(containerNode);
  const outside = new Map<string, Node>();
  links.forEach((l) => [l.from, l.to].forEach((id) => {
    if (inside.has(id) || outside.has(id)) return;
    const c = model.containers.find((x) => x.id === id);
    if (!c) return;
    const d = of.get(id);
    outside.set(id, { id, kind: c.kind === 'person' ? 'person' : 'external', name: c.name, tech: c.tech ?? undefined, container: c,
      description: d ? `domena: ${d}` : c.description || (c.kind === 'person' ? '' : 'System zewnętrzny'), drill: d ? `domain:${d}` : undefined });
  }));
  const all = [...nodes, ...outside.values()];
  const edges = mergeEdges(links.map((l) => ({ from: l.from, to: l.to, label: l.label, tech: l.tech ?? undefined, sources: l.sources, envs: l.envs, endpoints: l.endpoints })));
  // the neighbours calling the domain above it, the called ones below
  const tiers = containerTiers(all, edges);
  outside.forEach((_, id) => { if (!edges.some((e) => e.to === id)) tiers.set(id, 0); });
  return { key: `domain:${domain}`, level: 2, title: domain, scope: 'Containers', boundary: domain, boundaryKind: 'Domain', nodes: all, edges, tiers };
}

/**
 * The system as one box with its persons (from C4.md, otherwise "Users" when it has a web app) and the external
 * systems; a link of any container of the system is a link of the system.
 */
function contextDiagram(model: ArchitectureModel, env: string, project: string, drill: string): Diagram {
  const externals = model.containers.filter((c) => c.kind === 'external');
  const persons = model.containers.filter((c) => c.kind === 'person');
  const defaultUsers = !persons.length && model.containers.some((c) => c.kind === 'frontend');
  const outside = new Set([...externals, ...persons].map((c) => c.id));
  const services = model.containers.filter((c) => c.kind === 'service' || c.kind === 'frontend').length;
  const nodes: Node[] = [
    ...persons.map((c) => ({ id: c.id, kind: 'person' as Kind, name: c.name, tech: c.tech ?? undefined, description: c.description || '', container: c })),
    ...(defaultUsers ? [{ id: 'users', kind: 'person' as Kind, name: 'Użytkownicy', description: 'Korzystają z aplikacji webowej' }] : []),
    { id: 'system', kind: 'system', name: model.system?.name || project, tech: `${services} serwisów`,
      description: model.system?.description || 'System z repozytoriów GitLab', drill },
    ...externals.map((c) => ({ id: c.id, kind: 'external' as Kind, name: c.name, tech: c.tech ?? undefined, description: c.description || 'System zewnętrzny', container: c })),
  ];
  const end = (id: string) => (outside.has(id) ? id : 'system');
  const links: Array<Omit<Edge, 'count'>> = model.links.filter((l) => visible(l, env) && (outside.has(l.from) || outside.has(l.to)))
    .map((l) => ({ from: end(l.from), to: end(l.to), label: l.label, tech: l.tech ?? undefined, sources: l.sources, envs: l.envs }))
    .filter((l) => l.from !== l.to);
  if (defaultUsers) links.unshift({ from: 'users', to: 'system', label: 'Używają', tech: 'HTTPS', sources: [], envs: null });
  return { key: 'context', level: 1, title: model.system?.name || project, scope: 'System Context', nodes, edges: mergeEdges(links) };
}

function containerDiagram(model: ArchitectureModel, env: string, project: string): Diagram {
  const nodes = model.containers.map(containerNode);
  const edges = mergeEdges(model.links.filter((l) => visible(l, env))
    .map((l) => ({ from: l.from, to: l.to, label: l.label, tech: l.tech ?? undefined, sources: l.sources, envs: l.envs, endpoints: l.endpoints })));
  return { key: 'containers', level: 2, title: project, scope: 'Containers', boundary: project, boundaryKind: 'Software System', nodes, edges, tiers: containerTiers(nodes, edges) };
}

function componentDiagram(model: ArchitectureModel, env: string, containerId: string): Diagram | null {
  const container = model.containers.find((c) => c.id === containerId);
  if (!container) return null;
  const nodes: Node[] = container.components.map((c) => ({
    id: c.id, kind: 'component', name: c.name, tech: c.stereotype, component: c,
    description: `${c.package ?? ''}${c.lines ? ` · ${c.lines} linii` : ''}`,
  }));
  const edges: Array<Omit<Edge, 'count'>> = container.componentLinks.map((l) => ({ from: l.from, to: l.to, label: 'używa', sources: [l.source], envs: null }));
  // links of the container detected in the code of a component (Feign client, listener, publisher) go from that component
  const byFile = new Map(container.components.map((c) => [c.file, c]));
  model.links.filter((l) => visible(l, env) && (l.from === containerId || l.to === containerId)).forEach((l) => {
    const owner = l.sources.map((s) => (s.file ? byFile.get(s.file) : undefined)).find(Boolean);
    if (!owner) return;
    const other = model.containers.find((c) => c.id === (l.from === containerId ? l.to : l.from));
    if (!other) return;
    if (!nodes.some((n) => n.id === other.id)) {
      nodes.push({ id: other.id, kind: other.kind === 'service' || other.kind === 'frontend' ? 'external' : kindOf(other), name: other.name,
        tech: other.tech ?? undefined, description: other.repo || other.description || '', container: other });
    }
    const base = { label: l.label, tech: l.tech ?? undefined, sources: l.sources, envs: l.envs, endpoints: l.endpoints };
    edges.push(l.from === containerId ? { from: owner.id, to: other.id, ...base } : { from: other.id, to: owner.id, ...base });
  });
  return { key: `components:${containerId}`, level: 3, title: container.name, scope: 'Components', boundary: container.name, boundaryKind: 'Container', nodes, edges: mergeEdges(edges) };
}

/** An element / arrow added by hand as a node / edge of the diagram. */
const toNode = (a: AddedNode): Node => ({ id: a.id, kind: (a.kind in STYLE ? a.kind : 'container') as Kind, name: a.name, tech: a.tech, description: a.description ?? '' });
const toEdge = (a: AddedEdge): Edge => ({ from: a.from, to: a.to, label: a.label, tech: a.tech, sources: [], envs: null, count: 1 });
const ADDABLE: Kind[] = ['person', 'system', 'external', 'container', 'frontend', 'database', 'queue', 'component'];

// ---------- automatic layout ----------

/**
 * Containers in fixed tiers, so a project with many services stays wide and short: web apps, entry services
 * (not called by another service, e.g. the gateway), the other services, brokers, databases, external systems.
 */
function containerTiers(nodes: Node[], edges: Edge[]): Map<string, number> {
  const kindOfId = new Map(nodes.map((n) => [n.id, n.kind]));
  const calledByService = new Set(edges.filter((e) => kindOfId.get(e.from) === 'container' && kindOfId.get(e.to) === 'container').map((e) => e.to));
  return new Map(nodes.map((n) => [n.id,
    n.kind === 'person' ? 0 : n.kind === 'frontend' ? 1 : n.kind === 'container' ? (calledByService.has(n.id) ? 3 : 2)
      : n.kind === 'queue' ? 4 : n.kind === 'database' ? 5 : 6]));
}

/** Layers by the direction of the links (longest path, cycles broken) or given tiers; order in a layer by the neighbours. */
function layout(nodes: Node[], edges: Edge[], tiers?: Map<string, number>) {
  const ids = nodes.map((n) => n.id);
  const out = new Map(ids.map((id) => [id, [] as string[]]));
  edges.forEach((e) => { if (out.has(e.from) && out.has(e.to) && e.from !== e.to) out.get(e.from)!.push(e.to); });
  // drop the edges closing a cycle (depth-first back edges)
  const state = new Map<string, number>();
  const dag = new Map(ids.map((id) => [id, [] as string[]]));
  const visit = (id: string) => {
    state.set(id, 1);
    out.get(id)!.forEach((to) => {
      if (state.get(to) === 1) return;
      dag.get(id)!.push(to);
      if (!state.get(to)) visit(to);
    });
    state.set(id, 2);
  };
  const kindRank = (n: Node) => (n.kind === 'person' ? 0 : n.kind === 'frontend' ? 1 : ['system', 'domain', 'container', 'component'].includes(n.kind) ? 2 : 3);
  [...nodes].sort((a, b) => kindRank(a) - kindRank(b)).forEach((n) => { if (!state.get(n.id)) visit(n.id); });
  const rank = new Map(ids.map((id) => [id, tiers?.get(id) ?? 0]));
  for (let pass = 0; !tiers && pass < ids.length; pass++) {
    let changed = false;
    dag.forEach((tos, from) => tos.forEach((to) => {
      if (rank.get(to)! < rank.get(from)! + 1) { rank.set(to, rank.get(from)! + 1); changed = true; }
    }));
    if (!changed) break;
  }
  // external systems in the last row, outside the boundary of the system
  const last = Math.max(0, ...nodes.filter((n) => n.kind !== 'external').map((n) => rank.get(n.id)!)) + 1;
  if (!tiers) nodes.forEach((n) => { if (n.kind === 'external' && edges.some((e) => e.to === n.id)) rank.set(n.id, last); });
  const layers: string[][] = [];
  ids.forEach((id) => { (layers[rank.get(id)!] ??= []).push(id); });
  // wide layers wrap so the diagram stays readable
  const MAX_PER_ROW = 5;
  const rows: string[][] = [];
  layers.filter((l) => l?.length).forEach((layer) => { for (let i = 0; i < layer.length; i += MAX_PER_ROW) rows.push(layer.slice(i, i + MAX_PER_ROW)); });
  const xOf = new Map<string, number>();
  const maxRow = Math.max(1, ...rows.map((r) => r.length));
  const width = Math.max(1000, maxRow * COL + 40);
  rows.forEach((row, r) => {
    if (r > 0) {
      const bary = (id: string) => {
        const near = edges.filter((e) => e.to === id && xOf.has(e.from)).map((e) => xOf.get(e.from)!)
          .concat(edges.filter((e) => e.from === id && xOf.has(e.to)).map((e) => xOf.get(e.to)!));
        return near.length ? near.reduce((a, b) => a + b, 0) / near.length : width / 2;
      };
      row.sort((a, b) => bary(a) - bary(b));
    }
    const span = row.length * COL;
    row.forEach((id, i) => xOf.set(id, (width - span) / 2 + COL / 2 + i * COL));
  });
  const pos = new Map<string, { x: number; y: number }>();
  rows.forEach((row, r) => row.forEach((id) => pos.set(id, { x: xOf.get(id)!, y: 90 + r * ROW })));
  return { pos, width, height: Math.max(320, 90 + (rows.length - 1) * ROW + H / 2 + 60) };
}

/** Point on the border of the box around (cx, cy) in the direction of (tx, ty). */
function border(cx: number, cy: number, tx: number, ty: number, kind: Kind) {
  const dx = tx - cx;
  const dy = ty - cy;
  const hw = W / 2 + 4;
  const hh = (kind === 'person' ? H / 2 + 26 : H / 2) + 4;
  const scale = 1 / Math.max(Math.abs(dx) / hw, Math.abs(dy) / hh, 1e-6);
  return { x: cx + dx * scale, y: cy + dy * scale };
}

function Box({ node, x: cx, y: cy, version, selected, onClick, onPointerDown }: {
  node: ShownNode; x: number; y: number; version?: string; selected: boolean; onClick?: () => void; onPointerDown?: (e: ReactPointerEvent) => void;
}) {
  const st = STYLE[node.kind];
  const fill = node.fill ?? st.fill;
  const text = node.fill ? textOn(node.fill) : st.text;
  const x = cx - W / 2;
  const y = cy - H / 2;
  const stroke = selected ? '#f59e0b' : node.fill ? darker(node.fill) : st.stroke;
  const sw = selected ? 3 : 1.5;
  return (
    <g onClick={onClick} onPointerDown={onPointerDown} opacity={node.hidden ? 0.3 : 1} style={{ cursor: onPointerDown ? 'move' : 'pointer', touchAction: 'none' }}>
      {node.kind === 'person' && <circle cx={cx} cy={y - 14} r={20} fill={fill} stroke={stroke} strokeWidth={sw} />}
      {node.kind === 'database' ? (
        <>
          <path d={`M${x},${y + 10} v${H - 20} a${W / 2},10 0 0,0 ${W},0 v-${H - 20}`} fill={fill} stroke={stroke} strokeWidth={sw} />
          <ellipse cx={cx} cy={y + 10} rx={W / 2} ry={10} fill={fill} stroke={stroke} strokeWidth={sw} />
        </>
      ) : (
        <rect x={x} y={y} width={W} height={H} rx={node.kind === 'queue' ? 30 : 10} fill={fill} stroke={stroke} strokeWidth={sw} />
      )}
      <text x={cx} y={y + 30} textAnchor="middle" fill={text} fontSize={13.5} fontWeight={700}>{clip(node.name, 24)}</text>
      <text x={cx} y={y + 47} textAnchor="middle" fill={text} fontSize={10.5} opacity={0.85}>{clip(`[${st.label}${node.tech ? `: ${node.tech}` : ''}]`, 34)}</text>
      <text x={cx} y={y + 66} textAnchor="middle" fill={text} fontSize={11} opacity={0.95}>{clip(node.description, 32)}</text>
      {version && (
        <g>
          <rect x={x + W - 58} y={y - 10} width={56} height={18} rx={9} fill="#fff" stroke="#10b981" />
          <text x={x + W - 30} y={y + 3} textAnchor="middle" fontSize={10} fontFamily="monospace" fill="#065f46">{clip(version, 9)}</text>
        </g>
      )}
      {node.drill && !onPointerDown && <text x={x + W - 10} y={y + H - 8} textAnchor="end" fill={text} fontSize={10.5} fontWeight={700}>⤵ zoom</text>}
    </g>
  );
}

/** Link to the file in GitLab when the repository is a scanned container with its web URL. */
const METHOD_COLOR: Record<string, string> = { GET: '#2563eb', POST: '#16a34a', PUT: '#d97706', PATCH: '#9333ea', DELETE: '#dc2626' };

/** "GET /orders/{id}" with the method colored; a gateway path ("/api/**") as it is. */
function EndpointText({ value }: { value: string }) {
  const [method, ...rest] = value.split(' ');
  if (!rest.length) return <span className="font-mono text-[11.5px] break-all">{value}</span>;
  return (
    <span className="font-mono text-[11.5px] break-all">
      <span style={{ color: METHOD_COLOR[method] ?? '#6b7280', fontWeight: 700 }}>{method}</span> {rest.join(' ')}
    </span>
  );
}

/** Endpoints of a service with a filter (big services expose hundreds) and a link to the handler in GitLab. */
function EndpointList({ title, items, model, repo }: { title: string; items: Endpoint[]; model: ArchitectureModel; repo?: string | null }) {
  const pick = usePick();
  const [query, setQuery] = useState('');
  const q = query.trim().toLowerCase();
  const shown = items.filter((e) => !q || `${e.method} ${e.path} ${e.handler ?? ''}`.toLowerCase().includes(q));
  return (
    <>
      <div className="mt-3 flex items-center justify-between gap-2 text-[12px]">
        <span style={{ fontWeight: 700 }}>{title}</span>
        <span className={muted}>{items.length}</span>
      </div>
      {items.length > 8 && (
        <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={pick('Filter…', 'Filtruj…')}
          className="mt-1 w-full rounded-md border border-gray-200 dark:border-white/10 bg-transparent px-2 py-1 text-[12px] outline-none" />
      )}
      <ul className="mt-1 space-y-0.5 max-h-56 overflow-y-auto pr-1">
        {shown.map((e, i) => {
          const url = repo ? sourceUrl(model, { repo, file: e.file, line: e.line }) : null;
          const text = <EndpointText value={`${e.method} ${e.path}`} />;
          return (
            <li key={i} title={e.handler ? `${e.handler}() · ${e.file}` : e.file}>
              {url ? <a href={url} target="_blank" rel="noreferrer" className="hover:underline">{text}</a> : text}
            </li>
          );
        })}
      </ul>
    </>
  );
}

function sourceUrl(model: ArchitectureModel, s: Source): string | null {
  const repo = model.containers.find((c) => c.repo && c.repo === s.repo && c.url);
  return repo && s.file ? `${repo.url}/-/blob/HEAD/${s.file}${s.line ? `#L${s.line}` : ''}` : null;
}

// ---------- edit panel ----------

const field = 'mt-0.5 w-full rounded-md border border-gray-200 dark:border-white/10 bg-transparent px-2 py-1 text-[12.5px] outline-none focus:border-blue-400';
const panelBtn = 'inline-flex items-center justify-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-gray-200 dark:border-white/10 text-[12px] hover:bg-gray-50 dark:hover:bg-white/5 disabled:opacity-40';

function Swatches({ colors, value, onPick, onDefault }: { colors: string[]; value?: string; onPick: (c: string) => void; onDefault?: () => void }) {
  const pick = usePick();
  return (
    <div className="mt-1 flex flex-wrap items-center gap-1.5">
      {colors.map((c) => (
        <button key={c} onClick={() => onPick(c)} title={c} className="w-6 h-6 rounded-md border"
          style={{ backgroundColor: c, borderColor: darker(c), outline: value?.toLowerCase() === c ? '2px solid #f59e0b' : undefined, outlineOffset: 1 }} />
      ))}
      <label className="w-6 h-6 rounded-md border border-dashed border-gray-300 dark:border-white/20 overflow-hidden cursor-pointer relative" title={pick('Any colour', 'Dowolny kolor')}>
        <input type="color" value={value ?? '#438dd5'} onChange={(e) => onPick(e.target.value)} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
        <span className="absolute inset-0 flex items-center justify-center text-[13px]">+</span>
      </label>
      {onDefault && (
        <button onClick={onDefault} disabled={!value} className="text-[11.5px] text-blue-600 hover:underline disabled:opacity-40 disabled:no-underline ml-1">{pick('default', 'domyślny')}</button>
      )}
    </div>
  );
}

const Label = ({ children }: { children: ReactNode }) => <div className={`mt-2.5 text-[11.5px] ${muted}`} style={{ fontWeight: 600 }}>{children}</div>;

/** Edit mode: the texts, colour, visibility and groups of the picked elements, the label of a picked arrow. */
function EditPanel({ draft, picked, nodes, edges, byId, onLook, onChange, onPick, onHide, onGroup, onConnect }: {
  draft: DiagramEdit; picked: string[]; nodes: ShownNode[]; edges: ShownEdge[]; byId: Map<string, ShownNode>;
  onLook: (ids: string[], look: Look) => void; onChange: (fn: (d: DiagramEdit) => DiagramEdit) => void; onPick: (ids: string[]) => void;
  onHide: (ids: string[], hide: boolean) => void; onGroup: () => void; onConnect: () => void;
}) {
  const pick = usePick();
  const nodeIds = picked.filter((id) => !id.startsWith('group:') && !id.startsWith('edge:') && byId.has(id));
  const group = draft.groups.find((g) => picked.includes(`group:${g.id}`));
  const edge = edges.find((e) => picked.includes(`edge:${e.key}`));
  const nameOf = (id: string) => byId.get(id)?.name ?? id;

  if (group) {
    const setGroup = (patch: Partial<typeof group>) => onChange((d) => ({ ...d, groups: d.groups.map((g) => (g.id === group.id ? { ...g, ...patch } : g)) }));
    return (
      <div>
        <div className={`text-[11px] uppercase tracking-wider ${muted}`} style={{ fontWeight: 700 }}>{pick('Group', 'Grupa')}</div>
        <Label>{pick('Name', 'Nazwa')}</Label>
        <input value={group.name} onChange={(e) => setGroup({ name: e.target.value })} className={field} autoFocus />
        <Label>{pick('Colour', 'Kolor')}</Label>
        <Swatches colors={GROUP_COLORS} value={group.color} onPick={(color) => setGroup({ color })} />
        <Label>{pick('Elements', 'Elementy')} ({group.members.length})</Label>
        <ul className="mt-1 space-y-0.5">
          {group.members.map((m) => (
            <li key={m} className="flex items-center justify-between gap-2 text-[12px]">
              <button onClick={() => onPick([m])} className="break-all text-left hover:underline" style={{ fontWeight: 600 }}>{nameOf(m)}</button>
              <button onClick={() => setGroup({ members: group.members.filter((x) => x !== m) })} title={pick('Take out of the group', 'Wyjmij z grupy')} className={muted}><X className="w-3.5 h-3.5" /></button>
            </li>
          ))}
        </ul>
        <p className={`mt-2 text-[11.5px] ${muted}`}>{pick('Drag the name of the group to move it with its elements.', 'Przeciągnij nazwę grupy, żeby przesunąć ją razem z elementami.')}</p>
        <button onClick={() => { onChange((d) => ({ ...d, groups: d.groups.filter((g) => g.id !== group.id) })); onPick([]); }} className={`${panelBtn} mt-3 w-full`}>
          <Trash2 className="w-3.5 h-3.5" /> {pick('Ungroup', 'Rozgrupuj')}
        </button>
      </div>
    );
  }

  if (edge) {
    const added = draft.edges.find((a) => a.id === edge.key);
    const setAdded = (patch: Partial<AddedEdge>) => onChange((d) => ({ ...d, edges: d.edges.map((a) => (a.id === edge.key ? { ...a, ...patch } : a)) }));
    return (
      <div>
        <div className={`text-[11px] uppercase tracking-wider ${muted}`} style={{ fontWeight: 700 }}>{pick('Relation', 'Powiązanie')}{added ? ` · ${pick('added', 'dodane')}` : ''}</div>
        <div className="text-[14px] mt-0.5 break-all" style={{ fontWeight: 800 }}>{nameOf(edge.from)} → {nameOf(edge.to)}</div>
        <Label>{pick('Label', 'Opis')}</Label>
        <input value={edge.label} autoFocus className={field}
          onChange={(e) => (added ? setAdded({ label: e.target.value })
            : onChange((d) => ({ ...d, edgeLabels: { ...d.edgeLabels, [edge.key]: e.target.value } })))} />
        {added ? (
          <>
            <Label>{pick('Technology', 'Technologia')}</Label>
            <input value={added.tech ?? ''} onChange={(e) => setAdded({ tech: e.target.value || undefined })} className={field} placeholder="REST, Kafka…" />
            <div className="mt-3 grid grid-cols-2 gap-2">
              <button onClick={() => setAdded({ from: added.to, to: added.from })} className={panelBtn}>⇄ {pick('Reverse', 'Odwróć')}</button>
              <button onClick={() => { onChange((d) => ({ ...d, edges: d.edges.filter((a) => a.id !== edge.key) })); onPick([]); }} className={panelBtn}>
                <Trash2 className="w-3.5 h-3.5" /> {pick('Delete', 'Usuń')}
              </button>
            </div>
          </>
        ) : (
          <div className="mt-3 grid grid-cols-2 gap-2">
            <button onClick={() => onHide([edge.key], !edge.hidden)} className={panelBtn}>
              {edge.hidden ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />} {edge.hidden ? pick('Show', 'Pokaż') : pick('Hide', 'Ukryj')}
            </button>
            <button onClick={() => onChange((d) => { const next = { ...d.edgeLabels }; delete next[edge.key]; return { ...d, edgeLabels: next }; })}
              disabled={draft.edgeLabels[edge.key] === undefined} className={panelBtn}>
              <RotateCcw className="w-3.5 h-3.5" /> {pick('Scanned label', 'Opis ze skanu')}
            </button>
          </div>
        )}
      </div>
    );
  }

  if (nodeIds.length === 1) {
    const n = byId.get(nodeIds[0])!;
    const added = draft.nodes.find((a) => a.id === n.id);
    const look = draft.look[n.id] ?? {};
    const inGroup = draft.groups.find((g) => g.members.includes(n.id));
    return (
      <div>
        <div className={`text-[11px] uppercase tracking-wider ${muted}`} style={{ fontWeight: 700 }}>{STYLE[n.kind].label}{added ? ` · ${pick('added', 'dodany')}` : ''}</div>
        <Label>{pick('Name', 'Nazwa')}</Label>
        <input value={n.name} onChange={(e) => onLook([n.id], { name: e.target.value })} className={field} autoFocus />
        <Label>{pick('Technology', 'Technologia')}</Label>
        <input value={n.tech ?? ''} onChange={(e) => onLook([n.id], { tech: e.target.value })} className={field} />
        <Label>{pick('Description', 'Opis')}</Label>
        <textarea value={n.description} onChange={(e) => onLook([n.id], { description: e.target.value })} className={field} rows={2} />
        {added && (
          <>
            <Label>{pick('Type', 'Typ')}</Label>
            <select value={n.kind} className={field}
              onChange={(e) => onChange((d) => ({ ...d, nodes: d.nodes.map((a) => (a.id === n.id ? { ...a, kind: e.target.value } : a)) }))}>
              {ADDABLE.map((k) => <option key={k} value={k}>{STYLE[k].label}</option>)}
            </select>
          </>
        )}
        <Label>{pick('Colour', 'Kolor')}</Label>
        <Swatches colors={NODE_COLORS} value={n.fill} onPick={(fill) => onLook([n.id], { fill })} onDefault={() => onLook([n.id], { fill: undefined })} />
        {inGroup && (
          <div className="mt-2.5 flex items-center justify-between gap-2 text-[12px]">
            <span><span className={muted}>{pick('Group', 'Grupa')}:</span> <button onClick={() => onPick([`group:${inGroup.id}`])} className="hover:underline" style={{ fontWeight: 600, color: inGroup.color }}>{inGroup.name}</button></span>
            <button onClick={() => onChange((d) => ({ ...d, groups: d.groups.map((g) => (g.id === inGroup.id ? { ...g, members: g.members.filter((m) => m !== n.id) } : g)).filter((g) => g.members.length) }))}
              className="text-blue-600 hover:underline">{pick('take out', 'wyjmij')}</button>
          </div>
        )}
        <div className="mt-3 grid grid-cols-2 gap-2">
          {added ? (
            <button onClick={() => { onChange((d) => removeNode(d, n.id)); onPick([]); }} className={panelBtn}><Trash2 className="w-3.5 h-3.5" /> {pick('Delete', 'Usuń')}</button>
          ) : (
            <button onClick={() => onHide([n.id], !n.hidden)} className={panelBtn}>
              {n.hidden ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />} {n.hidden ? pick('Show', 'Pokaż') : pick('Hide', 'Ukryj')}
            </button>
          )}
          <button onClick={() => onChange((d) => { const next = { ...d.pos }; delete next[n.id]; return { ...d, pos: next }; })} disabled={added !== undefined || !draft.pos[n.id]} className={panelBtn}
            title={pick('Back to the automatic position', 'Z powrotem w automatyczne miejsce')}>
            <RotateCcw className="w-3.5 h-3.5" /> {pick('Position', 'Pozycja')}
          </button>
          {!added && (look.name !== undefined || look.tech !== undefined || look.description !== undefined) && (
            <button onClick={() => onLook([n.id], { name: undefined, tech: undefined, description: undefined })} className={`${panelBtn} col-span-2`}>
              <RotateCcw className="w-3.5 h-3.5" /> {pick('Scanned texts', 'Teksty ze skanu')}
            </button>
          )}
        </div>
      </div>
    );
  }

  if (nodeIds.length > 1) {
    const allHidden = nodeIds.every((id) => byId.get(id)?.hidden);
    const scanned = nodeIds.filter((id) => !draft.nodes.some((a) => a.id === id));
    return (
      <div>
        <div className={`text-[11px] uppercase tracking-wider ${muted}`} style={{ fontWeight: 700 }}>{pick('Picked', 'Zaznaczone')}: {nodeIds.length}</div>
        <ul className="mt-1 space-y-0.5 max-h-40 overflow-y-auto">
          {nodeIds.map((id, i) => <li key={id} className="text-[12px] break-all"><span className={muted}>{i + 1}.</span> <b>{nameOf(id)}</b></li>)}
        </ul>
        <Label>{pick('Colour of all', 'Kolor wszystkich')}</Label>
        <Swatches colors={NODE_COLORS} onPick={(fill) => onLook(nodeIds, { fill })} onDefault={() => onLook(nodeIds, { fill: undefined })}
          value={nodeIds.every((id) => byId.get(id)?.fill === byId.get(nodeIds[0])?.fill) ? byId.get(nodeIds[0])?.fill : undefined} />
        <div className="mt-3 grid grid-cols-2 gap-2">
          <button onClick={onGroup} className={panelBtn}><GroupIcon className="w-3.5 h-3.5" /> {pick('Group', 'Grupuj')}</button>
          <button onClick={onConnect} disabled={nodeIds.length !== 2} className={panelBtn}><Link2 className="w-3.5 h-3.5" /> 1 → 2</button>
          {scanned.length > 0 && (
            <button onClick={() => onHide(scanned, !allHidden)} className={`${panelBtn} col-span-2`}>
              {allHidden ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />} {allHidden ? pick('Show', 'Pokaż') : pick('Hide', 'Ukryj')}
            </button>
          )}
        </div>
      </div>
    );
  }

  const hidden = nodes.filter((n) => n.hidden);
  return (
    <div className="text-[12.5px]">
      <div className="flex gap-2"><Pencil className="w-4 h-4 shrink-0 mt-0.5 text-violet-600" />
        <div style={{ fontWeight: 700 }}>{pick('Editing the diagram', 'Edycja diagramu')}</div>
      </div>
      <ul className={`mt-2 space-y-1 list-disc pl-5 ${muted}`}>
        <li>{pick('Drag the boxes; with several picked they move together.', 'Przeciągaj elementy; kilka zaznaczonych przesuwa się razem.')}</li>
        <li>{pick('Click: pick · Shift+click: pick several.', 'Klik: zaznacz · Shift+klik: zaznacz kilka.')}</li>
        <li>{pick('Several picked → Group (a named, coloured frame); two → Connect with an arrow.', 'Kilka zaznaczonych → Grupuj (nazwana ramka w kolorze); dwa → Połącz strzałką.')}</li>
        <li>{pick('Add your own persons, systems and containers from the toolbar.', 'Własne osoby, systemy i kontenery dodasz z paska nad diagramem.')}</li>
        <li>{pick('Save keeps this diagram for everyone who sees the project, also after a new scan.', 'Zapisz utrwala ten diagram dla wszystkich widzących projekt, także po nowym skanie.')}</li>
      </ul>
      {draft.groups.length > 0 && (
        <>
          <Label>{pick('Groups', 'Grupy')}</Label>
          <div className="mt-1 flex flex-wrap gap-1.5">
            {draft.groups.map((g) => (
              <button key={g.id} onClick={() => onPick([`group:${g.id}`])} className="px-2 py-0.5 rounded-md text-[11.5px]" style={{ backgroundColor: g.color, color: textOn(g.color), fontWeight: 600 }}>{g.name || '—'}</button>
            ))}
          </div>
        </>
      )}
      {hidden.length > 0 && (
        <>
          <Label>{pick('Hidden (faded on the diagram)', 'Ukryte (wyblakłe na diagramie)')}</Label>
          <ul className="mt-1 space-y-0.5">
            {hidden.map((n) => (
              <li key={n.id} className="flex items-center justify-between gap-2 text-[12px]">
                <span className="break-all">{n.name}</span>
                <button onClick={() => onHide([n.id], false)} className="text-blue-600 hover:underline shrink-0">{pick('show', 'pokaż')}</button>
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
}

// ---------- page ----------

export function ArchitectureC4() {
  const pick = usePick();
  const [projects, setProjects] = useState<Array<{ projectId: string; updated: string | null }> | null>(null);
  const [projectId, setProjectId] = useState<string | null>(null);
  const [model, setModel] = useState<ArchitectureModel | null>(null);
  const [sample, setSample] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [versions, setVersions] = useState<Record<string, Record<string, string>>>({});
  const [env, setEnv] = useState('all');
  const [diagramKey, setDiagramKey] = useState('domains');
  const [selected, setSelected] = useState<{ node?: ShownNode; edge?: ShownEdge } | null>(null);
  // hand edits: the saved ones by diagram key, the one being edited (draft) and the elements picked in it
  // (node ids, "group:<id>", "edge:<key>")
  const [edits, setEdits] = useState<Record<string, DiagramEdit>>({});
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState<DiagramEdit | null>(null);
  const [dirty, setDirty] = useState(false);
  const [picked, setPicked] = useState<string[]>([]);
  const [addKind, setAddKind] = useState<Kind>('person');
  const [saveState, setSaveState] = useState<{ busy: boolean; error?: string; savedAt?: string }>({ busy: false });
  const svgRef = useRef<SVGSVGElement>(null);
  const dragged = useRef(false);
  const [frozenView, setFrozenView] = useState<Rect | null>(null);

  useEffect(() => {
    fetch('/api/architecture', { credentials: 'include' })
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error(`HTTP ${r.status}`))))
      .then((list) => { setProjects(list); if (list.length) setProjectId(list[0].projectId); })
      .catch((e) => { setProjects([]); setError(e.message); });
    // versions on the environments from the service map (optional)
    fetch('/api/codemap/modules', { credentials: 'include' })
      .then((r) => (r.ok ? r.json() : []))
      .then((list: Array<{ module: string; envs: Array<{ name: string; tag: string }> | null }>) => {
        const map: Record<string, Record<string, string>> = {};
        (list ?? []).forEach((m) => { if (m?.module) map[m.module] = Object.fromEntries((m.envs ?? []).map((e) => [e.name, e.tag])); });
        setVersions(map);
      })
      .catch(() => undefined);
  }, []);

  useEffect(() => {
    if (!projectId) return;
    setModel(null);
    setEdits({});
    setEditing(false);
    setDraft(null);
    setDirty(false);
    fetch(`/api/architecture/${encodeURIComponent(projectId)}/layouts`, { credentials: 'include' })
      .then((r) => (r.ok ? r.json() : {}))
      .then((saved: Record<string, unknown>) => setEdits(Object.fromEntries(Object.entries(saved ?? {}).map(([k, v]) => [k, normalizeEdit(v)]))))
      .catch(() => undefined);
    fetch(`/api/architecture/${encodeURIComponent(projectId)}`, { credentials: 'include' })
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error(`HTTP ${r.status}`))))
      .then((m: ArchitectureModel) => { setModel(m); setDiagramKey('domains'); setSelected(null); })
      .catch((e) => setError(e.message));
  }, [projectId]);

  const current = sample ? SAMPLE : model;
  const projectName = current?.projectId ?? '';
  const domainOf = useMemo(() => (current ? domainsOf(current) : new Map<string, string>()), [current]);
  const byDomain = domainNames(domainOf).length > 0;
  const level2 = byDomain ? 'domains' : 'containers';
  const diagram = useMemo<Diagram | null>(() => {
    if (!current) return null;
    if (diagramKey === 'context') return contextDiagram(current, env, projectName, level2);
    if (diagramKey.startsWith('components:')) return componentDiagram(current, env, diagramKey.slice('components:'.length));
    if (diagramKey.startsWith('domain:')) return domainSlice(current, env, diagramKey.slice('domain:'.length), domainOf);
    if (diagramKey === 'domains' && byDomain) return domainDiagram(current, env, projectName, domainOf);
    return containerDiagram(current, env, projectName);
  }, [current, env, diagramKey, projectName, domainOf, byDomain, level2]);
  const activeEdit = diagram ? (editing ? draft : edits[diagram.key] ?? null) : null;
  // the automatic layout holds the hidden and the added elements too, so nothing jumps when they are shown or hidden
  // (and it is not laid out again while a box is dragged)
  const addedNodes = activeEdit?.nodes;
  const addedEdges = activeEdit?.edges;
  const placed = useMemo(() => {
    if (!diagram) return null;
    const all = applyEdit(diagram.nodes, diagram.edges, { ...emptyEdit(), nodes: addedNodes ?? [], edges: addedEdges ?? [] }, true, toNode, toEdge);
    return layout(all.nodes, all.edges, diagram.tiers);
  }, [diagram, addedNodes, addedEdges]);
  const shown = useMemo(() => (diagram ? applyEdit(diagram.nodes, diagram.edges, activeEdit, editing, toNode, toEdge) : null), [diagram, activeEdit, editing]);
  const byId = useMemo(() => new Map((shown?.nodes ?? []).map((n) => [n.id, n])), [shown]);
  const pos = useMemo(() => {
    const result = new Map<string, Pos>();
    (shown?.nodes ?? []).forEach((n) => {
      const p = activeEdit?.pos[n.id] ?? placed?.pos.get(n.id);
      if (p) result.set(n.id, p);
    });
    return result;
  }, [shown, activeEdit, placed]);
  const groups = (activeEdit?.groups ?? []).map((g) => {
    const points = g.members.filter((m) => pos.has(m) && (editing || !byId.get(m)?.hidden)).map((m) => pos.get(m)!);
    const hasPerson = g.members.some((m) => byId.get(m)?.kind === 'person');
    const frame = around(points, W, H + (hasPerson ? 36 : 0), 18, 26);
    return frame ? { ...g, frame: hasPerson ? { ...frame, y: frame.y - 18 } : frame } : null;
  }).filter((g): g is NonNullable<typeof g> => !!g);

  const stopEditing = () => { setEditing(false); setDraft(null); setDirty(false); setPicked([]); setSaveState({ busy: false }); };
  const leaveEditing = () => {
    if (!editing) return true;
    if (dirty && !window.confirm(pick('Discard the unsaved changes of this diagram?', 'Odrzucić niezapisane zmiany tego diagramu?'))) return false;
    stopEditing();
    return true;
  };
  const startEditing = () => {
    if (!diagram) return;
    setDraft(structuredClone(edits[diagram.key] ?? emptyEdit()));
    setEditing(true);
    setDirty(false);
    setPicked([]);
    setSelected(null);
    setSaveState({ busy: false });
  };
  const change = (fn: (d: DiagramEdit) => DiagramEdit) => { setDraft((d) => (d ? fn(d) : d)); setDirty(true); };
  const setLook = (ids: string[], look: Look) => change((d) => {
    const next = { ...d.look };
    ids.forEach((id) => {
      const merged: Look = { ...next[id], ...look };
      (Object.keys(merged) as Array<keyof Look>).forEach((k) => { if (merged[k] === undefined) delete merged[k]; });
      if (Object.keys(merged).length) next[id] = merged; else delete next[id];
    });
    return { ...d, look: next };
  });
  const save = async () => {
    if (!diagram || !draft) return;
    const key = diagram.key;
    const empty = isEmptyEdit(draft);
    const keep = () => setEdits((e) => { const next = { ...e }; if (empty) delete next[key]; else next[key] = draft; return next; });
    if (sample) { keep(); setDirty(false); return; }
    setSaveState({ busy: true });
    try {
      const url = `/api/architecture/${encodeURIComponent(projectId ?? projectName)}/layout?diagram=${encodeURIComponent(key)}`;
      const r = await fetch(url, empty
        ? { method: 'DELETE', credentials: 'include' }
        : { method: 'PUT', credentials: 'include', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(draft) });
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      keep();
      setDirty(false);
      setSaveState({ busy: false, savedAt: new Date().toLocaleTimeString(pick('en-GB', 'pl-PL'), { timeStyle: 'short' }) });
    } catch (e) {
      setSaveState({ busy: false, error: (e as Error).message });
    }
  };

  const toSvg = (x: number, y: number): Pos => {
    const svg = svgRef.current;
    const m = svg?.getScreenCTM();
    if (!svg || !m) return { x: 0, y: 0 };
    const p = new DOMPoint(x, y).matrixTransform(m.inverse());
    return { x: p.x, y: p.y };
  };
  /** Drags the boxes (the view stays as it was until the drop); a press without a move is a click. */
  const startDrag = (ev: ReactPointerEvent, ids: string[], onClick: () => void) => {
    ev.stopPropagation();
    ev.preventDefault();
    const start = toSvg(ev.clientX, ev.clientY);
    const from = new Map(ids.filter((id) => pos.has(id)).map((id) => [id, pos.get(id)!]));
    let moved = false;
    setFrozenView(view);
    const move = (e: PointerEvent) => {
      const p = toSvg(e.clientX, e.clientY);
      const dx = p.x - start.x;
      const dy = p.y - start.y;
      if (!moved && Math.hypot(dx, dy) < 4) return;
      moved = true;
      change((d) => {
        const next = { ...d.pos };
        from.forEach((f, id) => { next[id] = { x: Math.round(f.x + dx), y: Math.round(f.y + dy) }; });
        return { ...d, pos: next };
      });
    };
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      setFrozenView(null);
      dragged.current = moved;
      if (!moved) onClick();
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  const isNodeId = (id: string) => !id.startsWith('group:') && !id.startsWith('edge:');
  const pickedNodes = picked.filter(isNodeId);
  const nodeDown = (ev: ReactPointerEvent, n: ShownNode) => {
    const multi = ev.shiftKey || ev.metaKey || ev.ctrlKey;
    const ids = !multi && pickedNodes.includes(n.id) ? pickedNodes : [n.id];
    startDrag(ev, ids, () => setPicked((p) => {
      if (!multi) return [n.id];
      const nodesOnly = p.filter(isNodeId);
      return nodesOnly.includes(n.id) ? nodesOnly.filter((x) => x !== n.id) : [...nodesOnly, n.id];
    }));
  };
  const addNode = () => {
    const id = newId('u:');
    const label = STYLE[addKind].label;
    const centre = view ? { x: Math.round(view.x + view.w / 2), y: Math.round(view.y + Math.min(view.h / 2, 160)) } : { x: 200, y: 120 };
    change((d) => ({ ...d, nodes: [...d.nodes, { id, kind: addKind, name: label, description: '' }], pos: { ...d.pos, [id]: centre } }));
    setPicked([id]);
  };
  const groupPicked = () => {
    const members = pickedNodes;
    if (!members.length) return;
    const id = newId('g');
    change((d) => ({
      ...d,
      groups: [
        ...d.groups.map((g) => ({ ...g, members: g.members.filter((m) => !members.includes(m)) })).filter((g) => g.members.length),
        { id, name: `${pick('Group', 'Grupa')} ${d.groups.length + 1}`, color: GROUP_COLORS[d.groups.length % GROUP_COLORS.length], members },
      ],
    }));
    setPicked([`group:${id}`]);
  };
  const connectPicked = () => {
    if (pickedNodes.length !== 2) return;
    const id = newId('x:');
    change((d) => ({ ...d, edges: [...d.edges, { id, from: pickedNodes[0], to: pickedNodes[1], label: pick('Uses', 'Używa') }] }));
    setPicked([`edge:${id}`]);
  };
  const toggleHidden = (ids: string[], hide: boolean) => change((d) => ({
    ...d, hidden: hide ? [...new Set([...d.hidden, ...ids])] : d.hidden.filter((h) => !ids.includes(h)),
  }));

  const open = (key: string) => {
    if (!leaveEditing()) return;
    setDiagramKey(key);
    setSelected(null);
  };
  const clickNode = (node: ShownNode) => {
    if (selected?.node?.id === node.id && node.drill) open(node.drill);
    else setSelected({ node });
  };
  const componentKey = diagram?.level === 3 ? diagram.key : (() => {
    const first = current?.containers.find((c) => c.components.length);
    return first ? `components:${first.id}` : null;
  })();
  const versionOf = (node: Node) => (env !== 'all' && node.container ? versions[node.container.id]?.[env] : undefined);

  const boundary = (() => {
    if (!diagram?.boundary || !shown) return null;
    // the system boundary holds its containers; a container boundary only its components (added persons and
    // systems stay outside)
    const inner = shown.nodes.filter((n) => !n.hidden && (diagram.level === 3 ? n.kind === 'component' : !['person', 'external'].includes(n.kind))
      && !(n.added && n.kind === 'system')).map((n) => pos.get(n.id)).filter((p): p is Pos => !!p);
    const frame = around(inner, W, H, 22, 4);
    return frame ? { ...frame, h: frame.h + 22 } : null;
  })();
  // the whole drawing: the automatic canvas and whatever was moved out of it
  const view = frozenView ?? (placed ? union([
    { x: 0, y: 0, w: placed.width, h: placed.height },
    around([...pos.values()], W, H + 80, 30),
    boundary, ...groups.map((g) => g.frame),
  ]) : null);

  const envs = ['all', ...(current?.environments ?? [])];
  // the domain of the open diagram: the open domain or the domain of the container of the components
  const openDomain = diagram?.key.startsWith('domain:') ? diagram.key.slice('domain:'.length)
    : diagram?.key.startsWith('components:') && byDomain ? domainOf.get(diagram.key.slice('components:'.length)) : undefined;
  const trail = diagram ? [
    { key: 'context', label: projectName },
    ...(diagram.level >= 2 ? (diagram.key === 'containers'
      ? [{ key: 'containers', label: pick('All containers', 'Wszystkie kontenery') }]
      : [{ key: level2, label: byDomain ? pick('Domains', 'Domeny') : pick('Containers', 'Kontenery') }]) : []),
    ...(openDomain ? [{ key: `domain:${openDomain}`, label: openDomain }] : []),
    ...(diagram.level === 3 ? [{ key: diagram.key, label: diagram.title }] : []),
  ] : [];

  return (
    <div className="p-4 md:p-6 space-y-4 text-gray-900 dark:text-gray-100">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-[22px] flex items-center gap-2" style={{ fontWeight: 800 }}>
            <Network className="w-6 h-6 text-blue-600" /> {pick('Architecture (C4)', 'Architektura (C4)')}
            {sample && <span className="ml-1 text-[11px] px-2 py-0.5 rounded-full bg-amber-100 text-amber-800" style={{ fontWeight: 700 }}>{pick('SAMPLE DATA', 'DANE PRZYKŁADOWE')}</span>}
          </h1>
          <p className={`text-[13px] mt-0.5 ${muted}`}>
            {pick('From the GitLab repositories (Spring Boot, Angular) and the ArgoCD deploy repository (OpenShift)',
              'Z repozytoriów GitLab (Spring Boot, Angular) i repo deploy ArgoCD (OpenShift)')}
            {!sample && model?.generatedAt && ` · ${pick('scanned', 'skan')} ${new Date(model.generatedAt).toLocaleString(pick('en-GB', 'pl-PL'), { dateStyle: 'short', timeStyle: 'short' })}`}
          </p>
        </div>
        {current && (
          <div className="flex flex-wrap items-center gap-2">
            {!sample && (projects?.length ?? 0) > 1 && (
              <select className="rounded-lg border border-gray-200 bg-white px-2.5 py-1.5 text-[12.5px] dark:border-white/10 dark:bg-white/5" value={projectId ?? ''} onChange={(e) => { if (leaveEditing()) setProjectId(e.target.value); }}>
                {projects!.map((p) => <option key={p.projectId} value={p.projectId}>{p.projectId}</option>)}
              </select>
            )}
            <div className="flex rounded-lg border border-gray-200 dark:border-white/10 overflow-hidden text-[12.5px]">
              {envs.map((e) => (
                <button key={e} onClick={() => setEnv(e)} className={`px-3 py-1.5 ${env === e ? 'bg-gray-900 text-white dark:bg-white dark:text-gray-900' : 'bg-white dark:bg-transparent hover:bg-gray-50 dark:hover:bg-white/5'}`}>
                  {e === 'all' ? pick('all envs', 'wszystkie') : e}
                </button>
              ))}
            </div>
            {sample && <button onClick={() => setSample(false)} className="px-3 py-1.5 rounded-lg border border-gray-200 text-[12.5px] dark:border-white/10">{pick('Hide sample', 'Ukryj przykład')}</button>}
          </div>
        )}
      </div>

      {!current && projects !== null && (
        <div className={`${card} p-5 flex gap-3`}>
          <Info className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
          <div className="text-[13px] space-y-2">
            <div style={{ fontWeight: 600 }}>
              {projects.length === 0 ? pick('No project was scanned yet', 'Żaden projekt nie został jeszcze przeskanowany') : pick('Loading…', 'Ładowanie…')}
            </div>
            {projects.length === 0 && (
              <>
                <p className={muted}>{pick('Add "architecture" to ONELOOK_IMPORT of the existing importer job (the same ZS_PROJ_* as the gitlab import):', 'Dopisz "architecture" do ONELOOK_IMPORT istniejącego joba importera (te same ZS_PROJ_* co import gitlab):')}</p>
                <pre className="text-[11.5px] bg-gray-50 dark:bg-white/5 rounded-lg p-2.5 overflow-x-auto">{`ONELOOK_IMPORT=gitlab,architecture             # po przecinku, oba importy w jednym jobie
ZS_PROJ_1="<grupa GitLab>:<projekt OneLook>"     # bez zmian, jak w imporcie gitlab
ARCH_DEPLOY_REPO="deploy/<repo ArgoCD>"          # opcjonalnie: repo albo cała grupa ("deploy"), też poza grupą serwisów`}</pre>
                {error && <p className="text-[12px] text-red-600">{error}</p>}
                <button onClick={() => setSample(true)} className="px-3 py-1.5 rounded-lg text-white text-[12.5px]" style={{ backgroundColor: '#2563eb', fontWeight: 600 }}>
                  {pick('Show a sample', 'Pokaż przykład')}
                </button>
              </>
            )}
          </div>
        </div>
      )}

      {current && diagram && placed && shown && view && (
        <>
          <div className={`${card} px-4 py-3 flex flex-wrap items-center justify-between gap-3`}>
            <div className="flex flex-wrap items-center gap-1.5 text-[13px]">
              {trail.map((t, i) => (
                <span key={t.key} className="inline-flex items-center gap-1.5">
                  {i > 0 && <ChevronRight className={`w-4 h-4 ${muted}`} />}
                  <button onClick={() => open(t.key)} className={t.key === diagram.key ? '' : `${muted} hover:text-gray-900 dark:hover:text-white`} style={{ fontWeight: t.key === diagram.key ? 700 : 500 }}>{t.label}</button>
                </span>
              ))}
            </div>
            <div className="flex gap-1">
              {LEVELS.map((l) => {
                const target = l.level === 1 ? 'context' : l.level === 2 ? level2 : l.level === 3 ? componentKey : null;
                const active = diagram.level === l.level;
                return (
                  <button key={l.level} disabled={!target} onClick={() => target && open(target)}
                          title={l.level === 4 ? pick('Next stage', 'Kolejny etap') : undefined}
                          className={`px-3 py-1.5 rounded-lg text-[12px] border disabled:opacity-40 ${active ? 'bg-blue-50 border-blue-200 text-blue-800 dark:bg-white/10 dark:border-white/20 dark:text-white' : 'border-gray-200 text-gray-600 hover:bg-gray-50 dark:border-white/10 dark:text-gray-300'}`}
                          style={{ fontWeight: active ? 700 : 500 }}>
                    {l.level}. {pick(l.en, l.pl)}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-[1fr_360px] gap-4 items-start">
            <div className={`${card} p-3`}>
              <div className="flex flex-wrap items-center justify-between gap-2 px-2 pb-2">
                <div className="text-[14px] flex items-center gap-2" style={{ fontWeight: 700 }}>
                  [{diagram.scope}] {diagram.title}
                  {!editing && edits[diagram.key] && (
                    <span className="text-[10.5px] px-1.5 py-0.5 rounded-full bg-violet-100 text-violet-800 dark:bg-violet-500/20 dark:text-violet-200" style={{ fontWeight: 700 }}>
                      {pick('edited', 'edytowany')}
                    </span>
                  )}
                </div>
                <div className={`flex items-center gap-3 text-[11.5px] ${muted}`}>
                  {!editing && (
                    <button onClick={startEditing} className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg border border-gray-200 dark:border-white/10 text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-white/5" style={{ fontWeight: 600 }}>
                      <Pencil className="w-3.5 h-3.5" /> {pick('Edit', 'Edytuj')}
                    </button>
                  )}
                  {byDomain && diagram.level === 2 && (
                    <button onClick={() => open(diagram.key === 'containers' ? 'domains' : 'containers')} className="text-blue-600 hover:underline" style={{ fontWeight: 600 }}>
                      {diagram.key === 'containers' ? pick('By domains', 'Po domenach') : pick('All containers at once', 'Wszystkie kontenery naraz')}
                    </button>
                  )}
                  {!editing && pick('Click: details · click again: zoom in', 'Klik: szczegóły · drugi klik: poziom niżej')}
                </div>
              </div>
              {editing && (
                <div className="flex flex-wrap items-center gap-1.5 px-2 pb-2 text-[12px]">
                  <select value={addKind} onChange={(e) => setAddKind(e.target.value as Kind)}
                    className="rounded-lg border border-gray-200 bg-white px-2 py-1 dark:border-white/10 dark:bg-white/5">
                    {ADDABLE.map((k) => <option key={k} value={k}>{STYLE[k].label}</option>)}
                  </select>
                  <button onClick={addNode} className={toolBtn}><Plus className="w-3.5 h-3.5" /> {pick('Add', 'Dodaj')}</button>
                  <span className="w-px h-5 bg-gray-200 dark:bg-white/10 mx-1" />
                  <button onClick={groupPicked} disabled={!pickedNodes.length} className={toolBtn} title={pick('Shift+click to pick several', 'Shift+klik: zaznacz kilka')}>
                    <GroupIcon className="w-3.5 h-3.5" /> {pick('Group', 'Grupuj')}{pickedNodes.length > 0 ? ` (${pickedNodes.length})` : ''}
                  </button>
                  <button onClick={connectPicked} disabled={pickedNodes.length !== 2} className={toolBtn} title={pick('Pick two elements: an arrow from the first to the second', 'Zaznacz dwa elementy: strzałka od pierwszego do drugiego')}>
                    <Link2 className="w-3.5 h-3.5" /> {pick('Connect', 'Połącz')}
                  </button>
                  <span className="flex-1" />
                  {saveState.error && <span className="text-red-600">{pick('Not saved', 'Nie zapisano')}: {saveState.error}</span>}
                  {!dirty && saveState.savedAt && <span className="text-emerald-600">{pick('Saved', 'Zapisano')} {saveState.savedAt}</span>}
                  {dirty && <span className="text-amber-600" style={{ fontWeight: 600 }}>{pick('Unsaved changes', 'Niezapisane zmiany')}</span>}
                  <button onClick={() => { change(() => emptyEdit()); setPicked([]); }} className={toolBtn} title={pick('Drop every change of this diagram (after saving)', 'Usuwa wszystkie zmiany tego diagramu (po zapisie)')}>
                    <RotateCcw className="w-3.5 h-3.5" /> {pick('Automatic', 'Automatyczny')}
                  </button>
                  <button onClick={() => { setDraft(structuredClone(edits[diagram.key] ?? emptyEdit())); setDirty(false); setPicked([]); }} disabled={!dirty} className={toolBtn}>
                    <Undo2 className="w-3.5 h-3.5" /> {pick('Discard', 'Odrzuć')}
                  </button>
                  <button onClick={save} disabled={!dirty || saveState.busy} className="inline-flex items-center gap-1 px-3 py-1 rounded-lg text-white disabled:opacity-40" style={{ backgroundColor: '#2563eb', fontWeight: 600 }}
                    title={sample ? pick('Sample data: kept until the page is reloaded', 'Dane przykładowe: zostaje do przeładowania strony') : undefined}>
                    <Save className="w-3.5 h-3.5" /> {saveState.busy ? pick('Saving…', 'Zapisuję…') : pick('Save', 'Zapisz')}
                  </button>
                  <button onClick={leaveEditing} className={toolBtn}><X className="w-3.5 h-3.5" /> {pick('Done', 'Zakończ')}</button>
                </div>
              )}
              {shown.nodes.length === 0 && !editing ? (
                <div className={`p-6 text-[13px] ${muted}`}>{pick('Nothing found on this level.', 'Na tym poziomie nic nie wykryto.')}</div>
              ) : (
                <svg ref={svgRef} viewBox={`${view.x} ${view.y} ${view.w} ${view.h}`}
                     className={`w-full h-auto bg-[#fafbfc] dark:bg-[#0d0e11] rounded-lg ${editing ? 'ring-2 ring-violet-300 dark:ring-violet-500/40' : ''}`}
                     onClick={(e) => {
                       if (dragged.current) { dragged.current = false; return; }
                       if (editing && e.target === e.currentTarget) setPicked([]);
                     }}>
                  <defs>
                    <marker id="c4arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
                      <path d="M0,0 L10,5 L0,10 z" fill="#6b7280" />
                    </marker>
                  </defs>
                  {boundary && (
                    <g>
                      <rect x={boundary.x} y={boundary.y} width={boundary.w} height={boundary.h} rx={12} fill="none" stroke="#9ca3af" strokeDasharray="8 6" />
                      <text x={boundary.x + 14} y={boundary.y + boundary.h - 10} fontSize={12} fill="#6b7280" fontWeight={700}>
                        {diagram.boundary} [{diagram.boundaryKind}]
                      </text>
                    </g>
                  )}
                  {groups.map((g) => {
                    const active = picked.includes(`group:${g.id}`);
                    const members = g.members.filter((m) => pos.has(m));
                    return (
                      <g key={g.id}>
                        <rect x={g.frame.x} y={g.frame.y} width={g.frame.w} height={g.frame.h} rx={14} fill={g.color} fillOpacity={0.07}
                              stroke={g.color} strokeWidth={active ? 3 : 1.6} strokeDasharray={active ? undefined : '10 5'} />
                        <g onPointerDown={editing ? (ev) => startDrag(ev, members, () => setPicked([`group:${g.id}`])) : undefined}
                           style={{ cursor: editing ? 'move' : 'default', touchAction: 'none' }}>
                          <rect x={g.frame.x} y={g.frame.y} width={Math.min(g.frame.w, 16 + 7.4 * Math.max(4, g.name.length))} height={24} rx={8} fill={g.color} />
                          <text x={g.frame.x + 10} y={g.frame.y + 16.5} fontSize={12} fill={textOn(g.color)} fontWeight={700}>{clip(g.name, 40)}</text>
                        </g>
                      </g>
                    );
                  })}
                  {shown.edges.map((e) => {
                    const a = pos.get(e.from);
                    const b = pos.get(e.to);
                    if (!a || !b) return null;
                    const p1 = border(a.x, a.y, b.x, b.y, byId.get(e.from)!.kind);
                    const p2 = border(b.x, b.y, a.x, a.y, byId.get(e.to)!.kind);
                    const active = editing
                      ? picked.includes(`edge:${e.key}`) || pickedNodes.includes(e.from) || pickedNodes.includes(e.to)
                      : selected?.edge?.key === e.key || selected?.node?.id === e.from || selected?.node?.id === e.to;
                    // an arrow over more than one row bends aside, so it does not run through the boxes between;
                    // its label shows when it is selected (or the box at one of its ends)
                    const long = Math.abs(b.y - a.y) > ROW * 1.2;
                    const bend = long ? (b.x >= a.x ? 1 : -1) * Math.min(170, 70 * Math.abs(b.y - a.y) / ROW) : 0;
                    const path = long
                      ? `M${p1.x},${p1.y} C${p1.x + bend},${p1.y + (p2.y - p1.y) / 3} ${p2.x + bend},${p2.y - (p2.y - p1.y) / 3} ${p2.x},${p2.y}`
                      : `M${p1.x},${p1.y} L${p2.x},${p2.y}`;
                    const mx = (p1.x + p2.x) / 2 + bend * 0.75;
                    const my = (p1.y + p2.y) / 2 - (Math.abs(p1.y - p2.y) < 20 ? 16 : 0);
                    const label = clip(e.label, 26) + (e.count > 2 ? ` +${e.count - 2}` : '');
                    const showLabel = !long || active;
                    return (
                      <g key={e.key} onClick={() => (editing ? setPicked([`edge:${e.key}`]) : setSelected({ edge: e }))} opacity={e.hidden ? 0.3 : 1} style={{ cursor: 'pointer' }}>
                        <title>{`${e.label}${e.tech ? ` [${e.tech}]` : ''}`}</title>
                        <path d={path} fill="none" stroke="transparent" strokeWidth={14} />
                        <path d={path} fill="none" stroke={active ? '#f59e0b' : '#6b7280'} strokeWidth={active ? 2.5 : 1.5} strokeDasharray="6 4" markerEnd="url(#c4arrow)" />
                        {showLabel && (
                          <>
                            <rect x={mx - 70} y={my - 15} width={140} height={e.tech ? 30 : 18} rx={4} fill="#fafbfc" opacity={0.9} />
                            <text x={mx} y={my - 2} textAnchor="middle" fontSize={10.5} fill="#374151" fontWeight={600}>{label}</text>
                            {e.tech && <text x={mx} y={my + 11} textAnchor="middle" fontSize={9.5} fill="#6b7280">[{clip(e.tech, 22)}]{e.envs ? ` ${e.envs.join(',')}` : ''}</text>}
                          </>
                        )}
                      </g>
                    );
                  })}
                  {shown.nodes.map((n) => {
                    const p = pos.get(n.id);
                    if (!p) return null;
                    return editing
                      ? <Box key={n.id} node={n} x={p.x} y={p.y} selected={picked.includes(n.id)} onPointerDown={(ev) => nodeDown(ev, n)} />
                      : <Box key={n.id} node={n} x={p.x} y={p.y} version={versionOf(n)} selected={selected?.node?.id === n.id} onClick={() => clickNode(n)} />;
                  })}
                </svg>
              )}
              <div className="flex flex-wrap items-center gap-3 px-2 pt-3 text-[11.5px]">
                {[...new Set(shown.nodes.map((n) => n.kind))].map((k) => (
                  <span key={k} className="inline-flex items-center gap-1.5">
                    <span className="w-3.5 h-3.5 rounded-sm border" style={{ backgroundColor: STYLE[k].fill, borderColor: STYLE[k].stroke }} />{STYLE[k].label}
                  </span>
                ))}
                <span className={muted}>{pick('environments next to the technology = the link exists only there', 'środowiska przy technologii = powiązanie tylko tam')}</span>
              </div>
            </div>

            <div className={`${card} p-4`}>
              {editing && draft ? (
                <EditPanel draft={draft} picked={picked} nodes={shown.nodes} edges={shown.edges} byId={byId}
                  onLook={setLook} onChange={change} onPick={setPicked} onHide={toggleHidden}
                  onGroup={groupPicked} onConnect={connectPicked} />
              ) : !selected ? (
                <div className={`text-[12.5px] ${muted} flex gap-2`}>
                  <Info className="w-4 h-4 shrink-0 mt-0.5" />
                  {pick('Select an element or an arrow to see where it was detected.', 'Wybierz element albo strzałkę, żeby zobaczyć szczegóły i skąd zostały wykryte.')}
                </div>
              ) : selected.node ? (
                <div>
                  <div className={`text-[11px] uppercase tracking-wider ${muted}`} style={{ fontWeight: 700 }}>{STYLE[selected.node.kind].label}</div>
                  <div className="text-[17px] break-all" style={{ fontWeight: 800 }}>{selected.node.name}</div>
                  {selected.node.tech && <div className={`text-[12px] ${muted}`}>{selected.node.tech}</div>}
                  <p className="text-[13px] mt-2">{selected.node.description}</p>
                  <div className="mt-3 space-y-1 text-[12.5px]">
                    {selected.node.container?.repo && (
                      <div className="flex justify-between gap-3"><span className={muted}>Repo</span>
                        {selected.node.container.url
                          ? <a href={selected.node.container.url} target="_blank" rel="noreferrer" className="text-blue-600 inline-flex items-center gap-1">{selected.node.container.repo}<ExternalLink className="w-3 h-3" /></a>
                          : <span>{selected.node.container.repo}</span>}
                      </div>
                    )}
                    {selected.node.container?.applicationName && <div className="flex justify-between gap-3"><span className={muted}>spring.application.name</span><span className="font-mono">{selected.node.container.applicationName}</span></div>}
                    {!!selected.node.container?.components.length && <div className="flex justify-between gap-3"><span className={muted}>{pick('Components', 'Komponenty')}</span><span>{selected.node.container.components.length}</span></div>}
                    {selected.node.container?.messaging?.length ? <div className="flex justify-between gap-3"><span className={muted}>{pick('Messaging', 'Komunikacja')}</span><span className="text-right">{selected.node.container.messaging.join(', ')}</span></div> : null}
                    {selected.node.component && (
                      <>
                        <div className="flex justify-between gap-3"><span className={muted}>{pick('File', 'Plik')}</span><span className="font-mono text-[11px] text-right break-all">{selected.node.component.file}</span></div>
                        {selected.node.component.lines && <div className="flex justify-between gap-3"><span className={muted}>{pick('Lines', 'Linie')}</span><span>{selected.node.component.lines}</span></div>}
                      </>
                    )}
                    {selected.node.container && Object.entries(versions[selected.node.container.id] ?? {}).map(([e, v]) => (
                      <div key={e} className="flex justify-between"><span className={muted}>{e}</span><span className="font-mono">{v}</span></div>
                    ))}
                  </div>
                  {!!selected.node.members?.length && (
                    <>
                      <div className="mt-3 text-[12px]" style={{ fontWeight: 700 }}>{pick('Containers', 'Kontenery')} ({selected.node.members.length})</div>
                      <ul className="mt-1 space-y-0.5 max-h-56 overflow-y-auto pr-1">
                        {selected.node.members.map((c) => (
                          <li key={c.id} className="text-[12px] flex justify-between gap-3">
                            <span className="break-all" style={{ fontWeight: 600 }}>{c.name}</span>
                            <span className={`${muted} text-right`}>{c.tech ?? STYLE[kindOf(c)].label}</span>
                          </li>
                        ))}
                      </ul>
                    </>
                  )}
                  {!!selected.node.container?.endpoints?.length && (
                    <EndpointList title={pick('Exposed endpoints', 'Wystawione endpointy')} model={current} repo={selected.node.container.repo}
                      items={selected.node.container.endpoints} />
                  )}
                  {!!selected.node.container?.routes?.length && (
                    <>
                      <div className="mt-3 text-[12px]" style={{ fontWeight: 700 }}>{pick('Gateway routes', 'Trasy gatewaya')}</div>
                      <ul className="mt-1 space-y-1">
                        {selected.node.container.routes.map((r, i) => (
                          <li key={i} className="text-[12px]">
                            <span className="font-mono">{r.paths.join(', ') || r.id}</span> → <b>{(r.target && byId.get(r.target)?.name) || r.uri}</b>
                          </li>
                        ))}
                      </ul>
                    </>
                  )}
                  <div className="mt-3 text-[12px]" style={{ fontWeight: 700 }}>{pick('Relations', 'Powiązania')}</div>
                  <ul className="mt-1 space-y-1">
                    {diagram.edges.filter((e) => e.from === selected.node!.id || e.to === selected.node!.id).map((e, i) => (
                      <li key={i} className="text-[12px]">
                        {e.from === selected.node!.id ? '→' : '←'} <b>{byId.get(e.from === selected.node!.id ? e.to : e.from)?.name}</b>: {e.label}
                      </li>
                    ))}
                  </ul>
                  {selected.node.drill && (
                    <button onClick={() => open(selected.node!.drill!)} className="mt-4 w-full inline-flex items-center justify-center gap-2 px-3 py-2 rounded-lg text-white text-[13px]" style={{ backgroundColor: '#2563eb', fontWeight: 600 }}>
                      <Layers className="w-4 h-4" /> {pick('Zoom in', 'Przybliż')}
                    </button>
                  )}
                </div>
              ) : (
                <div>
                  <div className={`text-[11px] uppercase tracking-wider ${muted}`} style={{ fontWeight: 700 }}>{pick('Relation', 'Powiązanie')}</div>
                  <div className="text-[15px] mt-0.5 break-all" style={{ fontWeight: 800 }}>{byId.get(selected.edge!.from)?.name} → {byId.get(selected.edge!.to)?.name}</div>
                  <p className="text-[13px] mt-1">{selected.edge!.label}{selected.edge!.tech ? ` [${selected.edge!.tech}]` : ''}</p>
                  <p className={`text-[12px] ${muted}`}>{selected.edge!.envs ? `${pick('Environments', 'Środowiska')}: ${selected.edge!.envs.join(', ')}` : pick('On every environment (service configuration)', 'Na każdym środowisku (konfiguracja serwisu)')}</p>
                  {!!selected.edge!.details?.length && (
                    <>
                      <div className="mt-3 text-[12px]" style={{ fontWeight: 700 }}>{pick('Links', 'Powiązania')} ({selected.edge!.details.length})</div>
                      <ul className="mt-1 space-y-0.5 max-h-56 overflow-y-auto pr-1">
                        {selected.edge!.details.map((d, i) => <li key={i} className="text-[12px] break-all">{d}</li>)}
                      </ul>
                    </>
                  )}
                  {!!selected.edge!.endpoints?.length && (
                    <>
                      <div className="mt-3 text-[12px]" style={{ fontWeight: 700 }}>
                        {selected.edge!.tech?.includes('Gateway') ? pick('Routed paths', 'Przekierowane ścieżki') : pick('Called endpoints', 'Wywoływane endpointy')}
                      </div>
                      <ul className="mt-1 space-y-0.5">
                        {selected.edge!.endpoints.map((e) => <li key={e}><EndpointText value={e} /></li>)}
                      </ul>
                    </>
                  )}
                  <div className="mt-3 text-[12px]" style={{ fontWeight: 700 }}>{pick('Detected from', 'Wykryte z')}</div>
                  <ul className="mt-1 space-y-2">
                    {selected.edge!.sources.length === 0 && <li className={`text-[12px] ${muted}`}>—</li>}
                    {selected.edge!.sources.map((s, i) => {
                      const url = sourceUrl(current, s);
                      return (
                        <li key={i} className="text-[12px] bg-gray-50 dark:bg-white/5 rounded-lg p-2.5">
                          <div className="flex items-center gap-1.5">
                            <FileCode2 className="w-4 h-4 shrink-0 text-blue-600" />
                            {url
                              ? <a href={url} target="_blank" rel="noreferrer" className="text-blue-600 break-all">{s.repo}: {s.file}{s.line ? `:${s.line}` : ''}</a>
                              : <span className="break-all">{s.repo}: {s.file}{s.line ? `:${s.line}` : ''}</span>}
                          </div>
                          {s.text && <div className="mt-1 font-mono text-[11px] break-all">{s.text}</div>}
                        </li>
                      );
                    })}
                  </ul>
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}

export default ArchitectureC4;
