import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Bot, CheckCircle2, FileUp, PlugZap, Save, XCircle } from 'lucide-react';

// Settings → AI agent: connection of the AI assistant to an OpenAI-compatible model (core /api/admin/ai/*, ADMIN only).
// Secrets (API key, proxy password) are never sent back by the backend: an empty field keeps the stored value.

type SettingsView = {
  enabled: boolean;
  baseUrl: string;
  apiKeySet: boolean;
  apiKeyMasked: string | null;
  model: string;
  toolsEnabled: boolean;
  temperature: number;
  timeoutSeconds: number;
  maxToolRounds: number;
  proxyEnabled: boolean;
  proxyHost: string | null;
  proxyPort: number | null;
  proxyUsername: string | null;
  proxyPasswordSet: boolean;
  nonProxyHosts: string | null;
  caCertificates: string | null;
  // absent when the core predates the TLS settings
  caSubjects?: string[];
  tlsSkipVerify?: boolean;
};

type CertificateInfo = { subject: string; issuer: string; notAfter: string; selfSigned: boolean; pem: string | null };

type TestResult = {
  ok: boolean;
  latencyMs: number;
  reply: string | null;
  models: string[];
  error: string | null;
  // the chain the server presented, when the TLS handshake failed
  serverCertificates?: CertificateInfo[];
  // why the chain is not trusted (wrong CA, missing intermediate, host name), from the core
  tlsHints?: string[];
};

const countCertificates = (pem: string) => (pem.match(/-----BEGIN CERTIFICATE-----/g) ?? []).length;
const commonName = (dn: string) => /CN=([^,]+)/.exec(dn)?.[1] ?? dn;

type FormState = {
  enabled: boolean;
  baseUrl: string;
  apiKey: string;
  clearApiKey: boolean;
  model: string;
  toolsEnabled: boolean;
  temperature: string;
  timeoutSeconds: string;
  maxToolRounds: string;
  proxyEnabled: boolean;
  proxyHost: string;
  proxyPort: string;
  proxyUsername: string;
  proxyPassword: string;
  clearProxyPassword: boolean;
  nonProxyHosts: string;
  caCertificates: string;
  tlsSkipVerify: boolean;
};

function toForm(v: SettingsView): FormState {
  return {
    enabled: v.enabled,
    baseUrl: v.baseUrl ?? '',
    apiKey: '',
    clearApiKey: false,
    model: v.model ?? '',
    toolsEnabled: v.toolsEnabled,
    temperature: String(v.temperature ?? 0.2),
    timeoutSeconds: String(v.timeoutSeconds ?? 120),
    maxToolRounds: String(v.maxToolRounds ?? 5),
    proxyEnabled: v.proxyEnabled,
    proxyHost: v.proxyHost ?? '',
    proxyPort: v.proxyPort != null ? String(v.proxyPort) : '',
    proxyUsername: v.proxyUsername ?? '',
    proxyPassword: '',
    clearProxyPassword: false,
    nonProxyHosts: v.nonProxyHosts ?? '',
    caCertificates: v.caCertificates ?? '',
    tlsSkipVerify: v.tlsSkipVerify ?? false,
  };
}

function toPayload(f: FormState) {
  const num = (s: string) => (s.trim() === '' ? null : Number(s));
  return {
    enabled: f.enabled,
    baseUrl: f.baseUrl.trim(),
    // null keeps the stored secret, '' removes it
    apiKey: f.clearApiKey ? '' : f.apiKey.trim() || null,
    model: f.model.trim(),
    toolsEnabled: f.toolsEnabled,
    temperature: num(f.temperature),
    timeoutSeconds: num(f.timeoutSeconds),
    maxToolRounds: num(f.maxToolRounds),
    proxyEnabled: f.proxyEnabled,
    proxyHost: f.proxyHost.trim(),
    proxyPort: num(f.proxyPort),
    proxyUsername: f.proxyUsername.trim(),
    proxyPassword: f.clearProxyPassword ? '' : f.proxyPassword || null,
    nonProxyHosts: f.nonProxyHosts.trim(),
    // '' removes the stored certificates
    caCertificates: f.caCertificates.trim(),
    tlsSkipVerify: f.tlsSkipVerify,
  };
}

// A certificate file as PEM text: PEM files are taken as they are, binary DER (.cer/.der) is converted.
async function certificateFileToPem(file: File): Promise<string> {
  const bytes = new Uint8Array(await file.arrayBuffer());
  const text = new TextDecoder().decode(bytes);
  if (text.includes('-----BEGIN')) return text.trim();
  let binary = '';
  bytes.forEach((b) => (binary += String.fromCharCode(b)));
  const base64 = btoa(binary).match(/.{1,64}/g)?.join('\n') ?? '';
  return `-----BEGIN CERTIFICATE-----\n${base64}\n-----END CERTIFICATE-----`;
}

async function readError(res: Response): Promise<string> {
  const data = await res.json().catch(() => null);
  // core errors come as { error: CODE, content: message }
  return data?.message || (typeof data?.content === 'string' && data.content) || data?.error || `HTTP ${res.status}`;
}

const inputCls =
  'w-full rounded-lg border border-gray-200 bg-white px-3 py-2 text-[13px] text-gray-800 outline-none focus:border-indigo-400 disabled:bg-gray-50 disabled:text-gray-400 dark:border-white/10 dark:bg-black/20 dark:text-gray-100';

function Field({ label, hint, children }: React.PropsWithChildren<{ label: string; hint?: string }>) {
  return (
    <label className="block">
      <span className="text-[12px] text-gray-700 dark:text-gray-300" style={{ fontWeight: 600 }}>{label}</span>
      <div className="mt-1">{children}</div>
      {hint && <span className="mt-1 block text-[11px] text-gray-500 dark:text-gray-400">{hint}</span>}
    </label>
  );
}

function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <label className="flex items-center gap-2 text-[13px] text-gray-800 dark:text-gray-200 cursor-pointer select-none">
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="h-4 w-4 accent-indigo-600" />
      {label}
    </label>
  );
}

export function AiAgentSettings() {
  const navigate = useNavigate();
  const [view, setView] = useState<SettingsView | null>(null);
  const [form, setForm] = useState<FormState | null>(null);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const [test, setTest] = useState<TestResult | null>(null);

  useEffect(() => {
    fetch('/api/admin/ai/settings', { credentials: 'include' })
      .then(async (res) => {
        if (!res.ok) throw new Error(res.status === 403 ? 'Brak dostępu – ekran tylko dla roli ADMIN.' : await readError(res));
        return res.json();
      })
      .then((v: SettingsView) => {
        setView(v);
        setForm(toForm(v));
      })
      .catch((e) => setLoadError(e instanceof Error ? e.message : String(e)));
  }, []);

  const set = <K extends keyof FormState>(key: K, value: FormState[K]) => setForm((f) => (f ? { ...f, [key]: value } : f));

  // trusts a certificate of the chain shown by the connection test
  function trustServerCertificate(pem: string) {
    setForm((f) => (f ? { ...f, caCertificates: [f.caCertificates.trim(), pem].filter(Boolean).join('\n'), tlsSkipVerify: false } : f));
  }

  // appends the certificates of the chosen files to the field, so a chain can be loaded file by file
  async function loadCertificateFiles(files: FileList | null) {
    if (!files?.length) return;
    const pems = await Promise.all(Array.from(files).map(certificateFileToPem));
    setForm((f) => (f ? { ...f, caCertificates: [f.caCertificates.trim(), ...pems].filter(Boolean).join('\n') } : f));
  }

  async function save() {
    if (!form) return;
    setSaving(true);
    setMessage(null);
    try {
      const res = await fetch('/api/admin/ai/settings', {
        method: 'PUT',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(toPayload(form)),
      });
      if (!res.ok) throw new Error(await readError(res));
      const v: SettingsView = await res.json();
      setView(v);
      setForm(toForm(v));
      setMessage({ ok: true, text: 'Zapisano. Asystent używa nowej konfiguracji od razu.' });
    } catch (e) {
      setMessage({ ok: false, text: 'Nie zapisano: ' + (e instanceof Error ? e.message : String(e)) });
    } finally {
      setSaving(false);
    }
  }

  async function runTest() {
    if (!form) return;
    setTesting(true);
    setTest(null);
    try {
      const res = await fetch('/api/admin/ai/test', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(toPayload(form)),
      });
      if (!res.ok) throw new Error(await readError(res));
      setTest(await res.json());
    } catch (e) {
      setTest({ ok: false, latencyMs: 0, reply: null, models: [], error: e instanceof Error ? e.message : String(e) });
    } finally {
      setTesting(false);
    }
  }

  if (loadError) {
    return (
      <div className="p-6 mx-auto">
        <div className="bg-white border border-gray-200 rounded-xl p-5 dark:bg-[#2b2d31] dark:border-white/10">
          <p className="text-[14px] text-gray-800 dark:text-gray-100" style={{ fontWeight: 600 }}>Nie można wczytać konfiguracji AI</p>
          <p className="text-[12px] text-gray-500 mt-1">{loadError}</p>
        </div>
      </div>
    );
  }

  if (!form || !view) {
    return (
      <div className="p-6 mx-auto">
        <p className="text-[13px] text-gray-500">Ładowanie…</p>
      </div>
    );
  }

  const loadedCertificates = countCertificates(form.caCertificates);
  const certificatesUnsaved = form.caCertificates.trim() !== (view.caCertificates ?? '').trim();
  const section = 'bg-white rounded-2xl border border-gray-200 p-5 space-y-4 dark:bg-[#2b2d31] dark:border-white/10';

  return (
    <div className="p-4 sm:p-6 mx-auto max-w-3xl space-y-4">
      <button onClick={() => navigate('/settings')} className="flex items-center gap-1.5 text-[12px] text-gray-500 hover:text-gray-800 dark:hover:text-gray-200">
        <ArrowLeft className="w-4 h-4" /> Ustawienia
      </button>
      <div className="flex items-start gap-3">
        <Bot className="w-7 h-7 text-indigo-600 mt-0.5" />
        <div>
          <h1 className="text-[22px] text-gray-900 dark:text-gray-100" style={{ fontWeight: 800 }}>Agent AI</h1>
          <p className="text-[13px] text-gray-500 mt-1">
            Połączenie asystenta AI z modelem językowym przez API zgodne z OpenAI (OpenAI, vLLM, llama.cpp, Ollama, LM Studio…).
          </p>
        </div>
      </div>

      <section className={section}>
        <div className="flex items-center justify-between">
          <h2 className="text-[14px] text-gray-900 dark:text-gray-100" style={{ fontWeight: 600 }}>Model</h2>
          <Toggle checked={form.enabled} onChange={(v) => set('enabled', v)} label="Asystent włączony" />
        </div>
        <Field label="Pełny URL API" hint="Adres główny API razem z wersją, np. https://llm.firma.pl/v1 – aplikacja dopisuje /chat/completions.">
          <input className={inputCls} value={form.baseUrl} onChange={(e) => set('baseUrl', e.target.value)} placeholder="https://llm.firma.pl/v1" />
        </Field>
        <Field
          label="API key"
          hint={view.apiKeySet ? `Zapisany klucz: ${view.apiKeyMasked}. Zostaw puste, aby go nie zmieniać.` : 'Brak zapisanego klucza (niepotrzebny dla lokalnych serwerów bez autoryzacji).'}
        >
          <input
            type="password"
            autoComplete="new-password"
            className={inputCls}
            value={form.apiKey}
            disabled={form.clearApiKey}
            onChange={(e) => set('apiKey', e.target.value)}
            placeholder={view.apiKeySet ? '••••••••' : 'sk-…'}
          />
        </Field>
        {view.apiKeySet && <Toggle checked={form.clearApiKey} onChange={(v) => set('clearApiKey', v)} label="Usuń zapisany klucz" />}
        <Field label="Model" hint="Nazwa modelu dokładnie jak na serwerze (lista pojawi się po teście połączenia).">
          <input className={inputCls} value={form.model} onChange={(e) => set('model', e.target.value)} list="ai-models" placeholder="gemma-4" />
          <datalist id="ai-models">
            {(test?.models ?? []).map((m) => <option key={m} value={m} />)}
          </datalist>
        </Field>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Field label="Temperatura" hint="0–2, niżej = bardziej rzeczowo">
            <input type="number" step="0.1" min="0" max="2" className={inputCls} value={form.temperature} onChange={(e) => set('temperature', e.target.value)} />
          </Field>
          <Field label="Timeout (s)" hint="5–600">
            <input type="number" min="5" max="600" className={inputCls} value={form.timeoutSeconds} onChange={(e) => set('timeoutSeconds', e.target.value)} />
          </Field>
          <Field label="Rundy narzędzi" hint="1–10 wywołań danych na pytanie">
            <input type="number" min="1" max="10" className={inputCls} value={form.maxToolRounds} onChange={(e) => set('maxToolRounds', e.target.value)} />
          </Field>
        </div>
        <Toggle checked={form.toolsEnabled} onChange={(v) => set('toolsEnabled', v)} label="Function calling (model sam pobiera dane z aplikacji)" />
        <p className="text-[11px] text-gray-500 -mt-2">
          Wyłącz, jeśli model lub serwer nie obsługuje narzędzi – wtedy dane wybranego zespołu trafiają od razu do promptu.
        </p>
      </section>

      <section className={section}>
        <div className="flex items-center justify-between">
          <h2 className="text-[14px] text-gray-900 dark:text-gray-100" style={{ fontWeight: 600 }}>Proxy</h2>
          <Toggle checked={form.proxyEnabled} onChange={(v) => set('proxyEnabled', v)} label="Łącz przez proxy" />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="sm:col-span-2">
            <Field label="Host proxy">
              <input className={inputCls} disabled={!form.proxyEnabled} value={form.proxyHost} onChange={(e) => set('proxyHost', e.target.value)} placeholder="proxy.firma.pl" />
            </Field>
          </div>
          <Field label="Port">
            <input type="number" min="1" max="65535" className={inputCls} disabled={!form.proxyEnabled} value={form.proxyPort} onChange={(e) => set('proxyPort', e.target.value)} placeholder="3128" />
          </Field>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label="Użytkownik (opcjonalnie)">
            <input className={inputCls} disabled={!form.proxyEnabled} value={form.proxyUsername} onChange={(e) => set('proxyUsername', e.target.value)} autoComplete="off" />
          </Field>
          <Field label="Hasło" hint={view.proxyPasswordSet ? 'Hasło zapisane – zostaw puste, aby nie zmieniać.' : undefined}>
            <input
              type="password"
              autoComplete="new-password"
              className={inputCls}
              disabled={!form.proxyEnabled || form.clearProxyPassword}
              value={form.proxyPassword}
              onChange={(e) => set('proxyPassword', e.target.value)}
              placeholder={view.proxyPasswordSet ? '••••••••' : ''}
            />
          </Field>
        </div>
        {view.proxyPasswordSet && <Toggle checked={form.clearProxyPassword} onChange={(v) => set('clearProxyPassword', v)} label="Usuń zapisane hasło proxy" />}
        <Field label="Bez proxy dla hostów" hint="Oddzielone | lub przecinkiem, * jako wildcard, np. localhost|*.firma.local">
          <input className={inputCls} disabled={!form.proxyEnabled} value={form.nonProxyHosts} onChange={(e) => set('nonProxyHosts', e.target.value)} />
        </Field>
      </section>

      <section className={section}>
        <h2 className="text-[14px] text-gray-900 dark:text-gray-100" style={{ fontWeight: 600 }}>Certyfikaty (TLS)</h2>
        <Field
          label="Certyfikat CA (PEM)"
          hint={
            certificatesUnsaved && loadedCertificates > 0
              ? `W polu: ${loadedCertificates} certyfikat(y) – jeszcze niezapisane. Kliknij „Testuj połączenie”, potem „Zapisz”.`
              : view.caSubjects?.length
                ? `Zapisane, zaufane dodatkowo: ${view.caSubjects.map(commonName).join('; ')}. Wyczyść pole, aby usunąć.`
                : 'Dla serwera https z certyfikatem firmowego CA (błąd „PKIX path building failed”). Wklej certyfikat root/pośredni, można kilka. Publiczne CA działają nadal.'
          }
        >
          <textarea
            className={`${inputCls} font-mono text-[11px] h-32`}
            value={form.caCertificates}
            onChange={(e) => set('caCertificates', e.target.value)}
            placeholder={'-----BEGIN CERTIFICATE-----\nMIID…\n-----END CERTIFICATE-----'}
            spellCheck={false}
          />
        </Field>
        <div className="flex flex-wrap items-center gap-2 -mt-2">
          <label className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 text-gray-700 text-[12px] cursor-pointer transition-colors dark:bg-[#2b2d31] dark:border-white/10 dark:text-gray-200" style={{ fontWeight: 500 }}>
            <FileUp className="w-4 h-4" /> Wczytaj z pliku
            <input
              type="file"
              multiple
              accept=".pem,.crt,.cer,.cert,.der,.txt"
              className="hidden"
              onChange={(e) => {
                void loadCertificateFiles(e.target.files);
                e.target.value = '';
              }}
            />
          </label>
          <span className="text-[11px] text-gray-500 dark:text-gray-400">.pem, .crt, .cer, .der – dopisywane do pola, binarne DER konwertowane automatycznie</span>
        </div>
        <Toggle checked={form.tlsSkipVerify} onChange={(v) => set('tlsSkipVerify', v)} label="Nie weryfikuj certyfikatu TLS (niebezpieczne)" />
        {form.tlsSkipVerify && (
          <p className="text-[11px] text-amber-700 dark:text-amber-400 -mt-2">
            Każdy certyfikat i nazwa hosta będą akceptowane – używaj tylko do testu, potem wklej certyfikat CA i wyłącz tę opcję.
          </p>
        )}
      </section>

      {test && (
        <div className={`rounded-xl border p-4 text-[13px] ${test.ok ? 'border-green-200 bg-green-50 text-green-800 dark:border-green-500/20 dark:bg-green-500/10 dark:text-green-300' : 'border-red-200 bg-red-50 text-red-800 dark:border-red-500/20 dark:bg-red-500/10 dark:text-red-300'}`}>
          <div className="flex items-center gap-2" style={{ fontWeight: 600 }}>
            {test.ok ? <CheckCircle2 className="w-4 h-4" /> : <XCircle className="w-4 h-4" />}
            {test.ok ? `Połączenie działa (${test.latencyMs} ms)` : 'Połączenie nie działa'}
          </div>
          {test.ok && test.reply && <div className="mt-1">Odpowiedź modelu: „{test.reply}”</div>}
          {test.error && <div className="mt-1 break-words">{test.error}</div>}
          {test.tlsHints?.length ? (
            <ul className="mt-2 list-disc pl-5 space-y-1">
              {test.tlsHints.map((hint, i) => <li key={i}>{hint}</li>)}
            </ul>
          ) : test.error && /subject alternative|no name matching|hostname/i.test(test.error) ? (
            <div className="mt-1">Certyfikat serwera nie jest wystawiony na nazwę hosta z URL – użyj w URL nazwy z certyfikatu (lista poniżej) zamiast IP lub aliasu.</div>
          ) : test.error && /PKIX|certificate/i.test(test.error) && (
            <div className="mt-1">
              {loadedCertificates > 0
                ? 'Certyfikat z pola nie pasuje do łańcucha, który przedstawia serwer – wybierz właściwy z listy poniżej (najlepiej root CA).'
                : 'Serwer ma certyfikat, któremu aplikacja nie ufa – wybierz certyfikat z listy poniżej albo wklej certyfikat CA.'}
            </div>
          )}
          {!!test.serverCertificates?.length && (
            <div className="mt-3 space-y-2">
              <div style={{ fontWeight: 600 }}>Łańcuch certyfikatów przedstawiony przez serwer{form.proxyEnabled ? ' (przez proxy)' : ''}:</div>
              {test.serverCertificates.map((c, i) => (
                <div key={i} className="rounded-lg border border-red-200 bg-white/70 p-2 text-[12px] text-gray-800 dark:border-white/10 dark:bg-black/20 dark:text-gray-200">
                  <div style={{ fontWeight: 600 }}>
                    {i === 0 ? 'Serwer' : c.selfSigned ? 'Root CA' : 'Pośredni CA'}: {commonName(c.subject)}
                  </div>
                  <div className="text-gray-500 break-words">Wystawca: {c.issuer}</div>
                  <div className="text-gray-500">Ważny do: {c.notAfter.slice(0, 10)}</div>
                  {c.pem && (
                    <button
                      onClick={() => trustServerCertificate(c.pem as string)}
                      className="mt-1 px-2 py-1 rounded-md border border-gray-200 bg-white hover:bg-gray-50 text-[12px] dark:bg-[#2b2d31] dark:border-white/10"
                      style={{ fontWeight: 500 }}
                    >
                      Użyj tego certyfikatu
                    </button>
                  )}
                </div>
              ))}
              <div className="text-[11px]">
                Zaufaj najwyższemu certyfikatowi z łańcucha (root/pośredni CA), nie certyfikatowi serwera – przetrwa jego odnowienie.
                Upewnij się, że to certyfikat Twojej firmy. Potem „Testuj połączenie” i „Zapisz”.
              </div>
            </div>
          )}
          {test.models?.length > 0 && <div className="mt-1">Modele na serwerze: {test.models.join(', ')}</div>}
        </div>
      )}
      {message && (
        <div className={`text-[13px] ${message.ok ? 'text-green-700 dark:text-green-400' : 'text-red-700 dark:text-red-400'}`}>{message.text}</div>
      )}

      <div className="flex flex-wrap items-center gap-2 pb-6">
        <button
          onClick={runTest}
          disabled={testing || saving}
          className="flex items-center gap-2 px-4 py-2 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 text-gray-700 text-[13px] transition-colors disabled:opacity-50 dark:bg-[#2b2d31] dark:border-white/10 dark:text-gray-200"
          style={{ fontWeight: 500 }}
        >
          <PlugZap className="w-4 h-4" /> {testing ? 'Testuję…' : 'Testuj połączenie'}
        </button>
        <button
          onClick={save}
          disabled={saving || testing}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-[13px] transition-colors disabled:opacity-50"
          style={{ fontWeight: 500 }}
        >
          <Save className="w-4 h-4" /> {saving ? 'Zapisuję…' : 'Zapisz'}
        </button>
      </div>
    </div>
  );
}

export default AiAgentSettings;
