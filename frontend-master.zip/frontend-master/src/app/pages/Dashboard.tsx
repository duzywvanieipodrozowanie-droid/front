import {
  overviewMetrics,
} from '../data/mockData';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';
import { TrendingUp, TrendingDown, Clock, GitMerge, GitPullRequest, Rocket, AlertTriangle, Timer, Workflow, Gauge } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { useDateRange } from '../context/DateRangeContext';
import { useTeam } from '../context/TeamContext';
import LoadingSpinner from '../components/LoadingSpinner';
import { useNoDataTimeout } from '../hooks/useNoDataTimeout';
import HelpTip from '../components/HelpTip';
import { useTr, usePick, useLang } from '../i18n';
import { getIntervalSuffix } from '../utils/intervalUnit';
import { FlowDialog } from '../components/FlowDialog';
import { FlowEfficiencyDialog } from '../components/FlowEfficiencyDialog';
import { OrgBenchmarkBadge, fetchOrgBenchmark, type OrgBenchItem, type OrgBenchResponse } from '../components/OrgBenchmarkBadge';
import { toInterval } from '../utils/dateRange';

function StatCard({
  label,
  value,
  unit,
  previous,
  trend,
  goodDirection = 'up',
  icon: Icon,
  color,
  pctOverride,
  trendOverride,
  bench,
  benchUnit,
  benchUnitType,
  help,
}: {
  label: string;
  value: number | string;
  unit: string;
  previous?: number;
  trend?: 'up' | 'down' | 'stable';
  goodDirection?: 'up' | 'down';
  icon: React.ElementType;
  color: string;
  pctOverride?: number | string | null;
  trendOverride?: 'up' | 'down' | 'stable';
  bench?: OrgBenchItem | null;
  benchUnit?: string;
  benchUnitType?: string | null;
  help?: string;
}) {
  const pctCalc = previous
    ? Math.abs(((Number(value) - previous) / previous) * 100).toFixed(1)
    : null;
  const pct = pctOverride != null ? String(pctOverride) : pctCalc;
  const effTrend = trendOverride ?? trend;
  const isGood = effTrend === goodDirection;
  const trendColor = effTrend === 'stable' ? 'text-gray-400' : isGood ? 'text-emerald-600' : 'text-red-500';

  return (
    <div className="bg-white rounded-xl border border-gray-200 p-5">
      <div className="flex items-start justify-between gap-2 mb-3">
        <span className="min-w-0 break-words text-[12px] text-gray-500 uppercase tracking-wide" style={{ fontWeight: 600, letterSpacing: '0.05em' }}>
          {label}
        </span>
        <div className="flex items-center gap-1.5 shrink-0">
          {help && <HelpTip size="sm" content={help} />}
          <div className={`w-8 h-8 rounded-lg ${color} flex items-center justify-center`}>
            <Icon className="w-4 h-4 text-white" />
          </div>
        </div>
      </div>
      <div className="flex items-baseline flex-wrap gap-1.5 mb-2">
        <span className="text-[28px] text-gray-900" style={{ fontWeight: 700, lineHeight: 1 }}>
          {value}
        </span>
        <span className="text-[13px] text-gray-400">{unit}</span>
      </div>
      {bench !== undefined && <div className="mb-2 -mt-1"><OrgBenchmarkBadge item={bench} unit={benchUnit ?? unit} unitType={benchUnitType} /></div>}
      {pct && effTrend && (
        <div className={`flex flex-wrap items-center gap-1 text-[12px] ${trendColor}`}>
          {effTrend === 'up' ? (
            <TrendingUp className="w-3.5 h-3.5" />
          ) : (
            <TrendingDown className="w-3.5 h-3.5" />
          )}
          <span style={{ fontWeight: 500 }}>{pct}%</span>
          <span className="text-gray-400">vs prev period</span>
        </div>
      )}
    </div>
  );
}

const tooltipStyle = {
  backgroundColor: 'white',
  border: '1px solid #e5e7eb',
  borderRadius: '8px',
  fontSize: '12px',
  boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
};

type OverviewProps = { interval?: string; team?: string };


// PR Throughput "Merged" series; the summary number uses the same color. Inline on purpose:
// theme.css remaps Tailwind indigo classes to brand green with !important.
const MERGED_COLOR = '#6366f1';
export function Dashboard({ interval: intervalProp, team: teamProp }: OverviewProps = {}) {
  const { timedOut, reset } = useNoDataTimeout(180000);
  const [hasData, setHasData] = useState(false);

  const { dateRange, label: dateRangeLabel } = useDateRange();
  const { lang } = useLang();
  const { selectedTeamName, selectedUnitId } = useTeam();

  const derivedInterval = useMemo(() => {
    return toInterval(dateRange, 'WEEKS_1');
  }, [dateRange]);

  // Effective interval and team (props take precedence)
  const interval = useMemo(() => intervalProp ?? derivedInterval, [intervalProp, derivedInterval]);
  const effectiveTeam = useMemo(() => {
    if (teamProp && teamProp !== 'All Teams') return teamProp;
    if (selectedTeamName && selectedTeamName !== 'All Teams') return selectedTeamName;
    return undefined;
  }, [teamProp, selectedTeamName]);

  // Reset timeout and clear hasData on key filters change
  useEffect(() => {
    reset();
    setHasData(false);
  }, [interval, effectiveTeam, selectedUnitId]);

  // Local Benchmark: every widget against the average of all units of the same type in the organization
  // (/api/metrics/benchmark/overview, computed in core for the same period)
  const [localBenchmark, setLocalBenchmark] = useState(false);
  const [bench, setBench] = useState<OrgBenchResponse | null>(null);

  useEffect(() => {
    if (!localBenchmark) { setBench(null); return; }
    const controller = new AbortController();
    fetchOrgBenchmark('overview', interval, selectedUnitId, controller.signal).then((data) => {
      if (!controller.signal.aborted) setBench(data ?? { metrics: {} });
    });
    return () => controller.abort();
  }, [interval, selectedUnitId, localBenchmark]);

  // undefined hides the badge (benchmark off), null shows "no data" while the answer has no such metric
  const benchFor = (key: string): OrgBenchItem | null | undefined =>
    !localBenchmark ? undefined : bench ? (bench.metrics?.[key] ?? null) : undefined;

  // The benchmark effect above reacts to localBenchmark, so the toggle only flips state.
  // "Przepływ pracy" popup (flow metrics from Jira, /api/metrics/flow)
  const [flowOpen, setFlowOpen] = useState(false);
  // "Flow efficiency" popup (active vs waiting time by Jira status, /api/metrics/flow/efficiency)
  const [efficiencyOpen, setEfficiencyOpen] = useState(() => typeof window !== 'undefined' && window.location.hash === '#flow-efficiency');

  const handleToggleLocalBenchmark = () => {
    setLocalBenchmark((v) => !v);
  };

  const [prMetric, setPrMetric] = useState<{ value?: number; change?: number; positive?: boolean; loading: boolean }>(
    { loading: true }
  );

  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    async function load() {
      setPrMetric((s) => ({ ...s, loading: true }));
      try {
        const params = new URLSearchParams({ interval });
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        const res = await fetch(`/api/metrics/pr/c?${params.toString()}`, { credentials: 'include', signal: controller.signal });
        if (!res.ok) throw new Error('Failed');
        const data = await res.json();
        if (cancelled) return;
        const value = typeof data?.value === 'number' ? data.value : undefined;
        const change = typeof data?.change === 'number' ? data.change : undefined;
        const positive = typeof data?.positive === 'boolean' ? data.positive : undefined;
        setPrMetric({ value, change, positive, loading: false });
      } catch (_e) {
        if (cancelled) return;
        setPrMetric({ loading: false });
      }
    }
    load();
    return () => {
      cancelled = true; controller.abort();
    };
  }, [interval, selectedUnitId]);

  const prValue = prMetric.value;
  const prChange = prMetric.change;
  const prTrend: 'up' | 'down' | 'stable' | undefined =
    prChange == null ? undefined : prChange === 0 ? 'stable' : prChange > 0 ? 'up' : 'down';

  // Live PR Throughput metric from API (/api/metrics/pr/t)
  const [prThroughputMetric, setPrThroughputMetric] = useState<{ value?: number; change?: number; positive?: boolean; loading: boolean }>({ loading: true });

  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    async function loadThroughput() {
      setPrThroughputMetric((s) => ({ ...s, loading: true }));
      try {
        const params = new URLSearchParams({ interval });
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        const res = await fetch(`/api/metrics/pr/t?${params.toString()}`, { credentials: 'include', signal: controller.signal });
        if (!res.ok) throw new Error('Failed');
        const data = await res.json();
        if (cancelled) return;
        const value = typeof data?.value === 'number' ? data.value : undefined;
        const change = typeof data?.change === 'number' ? data.change : undefined;
        const positive = typeof data?.positive === 'boolean' ? data.positive : undefined;
        setPrThroughputMetric({ value, change, positive, loading: false });
      } catch (_e) {
        if (cancelled) return;
        setPrThroughputMetric({ loading: false });
      }
    }
    loadThroughput();
    return () => {
      cancelled = true; controller.abort();
    };
  }, [interval, selectedUnitId]);

  const prThroughputValue = prThroughputMetric.value;
  const prThroughputChange = prThroughputMetric.change ?? null;
  const prThroughputTrend: 'up' | 'down' | 'stable' | undefined =
    prThroughputChange == null ? undefined : prThroughputChange === 0 ? 'stable' : prThroughputChange > 0 ? 'up' : 'down';

  // Deployment Frequency from /api/metrics/dora/deployment - the same value as the widget on the DORA screen
  // (Jira release tasks moved to LIVE in the period, each counted once)
  const [deployMetric, setDeployMetric] = useState<{ value?: number; change?: number; positive?: boolean; loading: boolean }>({ loading: true });

  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    async function loadDeploy() {
      setDeployMetric((s) => ({ ...s, loading: true }));
      try {
        const params = new URLSearchParams({ interval });
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        const res = await fetch(`/api/metrics/dora/deployment?${params.toString()}`, { credentials: 'include', signal: controller.signal });
        if (!res.ok) throw new Error('Failed');
        const data = await res.json();
        if (cancelled) return;
        const value = typeof data?.value === 'number' ? data.value : undefined;
        const change = typeof data?.change === 'number' ? data.change : undefined;
        const positive = typeof data?.positive === 'boolean' ? data.positive : undefined;
        setDeployMetric({ value, change, positive, loading: false });
      } catch (_e) {
        if (cancelled) return;
        setDeployMetric({ loading: false });
      }
    }
    loadDeploy();
    return () => {
      cancelled = true; controller.abort();
    };
  }, [interval, selectedUnitId]);

  const deployValue = deployMetric.value;
  const deployChange = deployMetric.change ?? null;
  const deployTrend: 'up' | 'down' | 'stable' | undefined =
    deployChange == null ? undefined : deployChange === 0 ? 'stable' : deployChange > 0 ? 'up' : 'down';

  // Average time from IN PROGRESS to LIVE of the unit's Jira tasks (/api/metrics/dora/inProgressToLive), in hours
  const [inProgressMetric, setInProgressMetric] = useState<{ value?: number; change?: number; loading: boolean }>({ loading: true });

  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    async function loadInProgress() {
      setInProgressMetric((s) => ({ ...s, loading: true }));
      try {
        const params = new URLSearchParams({ interval });
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        const res = await fetch(`/api/metrics/dora/inProgressToLive?${params.toString()}`, { credentials: 'include', signal: controller.signal });
        if (!res.ok) throw new Error('Failed');
        const data = await res.json();
        if (cancelled) return;
        const value = typeof data?.value === 'number' ? data.value : undefined;
        const change = typeof data?.change === 'number' ? data.change : undefined;
        setInProgressMetric({ value, change, loading: false });
      } catch (_e) {
        if (cancelled) return;
        setInProgressMetric({ loading: false });
      }
    }
    loadInProgress();
    return () => {
      cancelled = true; controller.abort();
    };
  }, [interval, selectedUnitId]);

  // shown in days from 2 days up, otherwise in hours
  const inProgressHours = inProgressMetric.value;
  const inProgressInDays = inProgressHours != null && inProgressHours >= 48;
  const inProgressValue = inProgressHours == null ? undefined
    : inProgressInDays ? Math.round((inProgressHours / 24) * 10) / 10 : inProgressHours;
  const inProgressChange = inProgressMetric.change ?? null;
  const inProgressTrend: 'up' | 'down' | 'stable' | undefined =
    inProgressChange == null ? undefined : inProgressChange === 0 ? 'stable' : inProgressChange > 0 ? 'up' : 'down';

  // Build Fail Rate metric from API (/api/metrics/build/failRate)
  const [failMetric, setFailMetric] = useState<{ value?: number; change?: number; positive?: boolean; loading: boolean }>({ loading: true });

  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    async function loadFail() {
      setFailMetric((s) => ({ ...s, loading: true }));
      try {
        const params = new URLSearchParams({ interval });
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        const res = await fetch(`/api/metrics/build/failRate?${params.toString()}`, { credentials: 'include', signal: controller.signal });
        if (!res.ok) throw new Error('Failed');
        const data = await res.json();
        if (cancelled) return;
        const value = typeof data?.value === 'number' ? data.value : undefined;
        const change = typeof data?.change === 'number' ? data.change : undefined;
        const positive = typeof data?.positive === 'boolean' ? data.positive : undefined;
        setFailMetric({ value, change, positive, loading: false });
      } catch (_e) {
        if (cancelled) return;
        setFailMetric({ loading: false });
      }
    }
    loadFail();
    return () => {
      cancelled = true; controller.abort();
    };
  }, [interval, selectedUnitId]);

  const failValue = failMetric.value;
  const failChange = failMetric.change ?? null;
  const failTrend: 'up' | 'down' | 'stable' | undefined =
    failChange == null ? undefined : failChange === 0 ? 'stable' : failChange > 0 ? 'up' : 'down';

  // Recent PRs live data from API (/api/metrics/pr/last)
  type RecentPrCommit = { id: string; title: string; author: string | null };
  type RecentPrItem = { id: string; title: string; author: string; status: 'open' | 'merged' | 'closed' | string; timeAgo: string; mergeTime: string | null; targetBranch: string | null; commits: RecentPrCommit[] };
  const RECENT_PR_COMMITS_SHOWN = 3;
  const [expandedPrs, setExpandedPrs] = useState<Record<string, boolean>>({});
  const [recentLive, setRecentLive] = useState<RecentPrItem[]>([]);
  const [recentLoading, setRecentLoading] = useState<boolean>(false);

  // /api/metrics/pr/last sends durations in hours (previously parsed as a date, which showed thousands of days)
  function formatHours(hours: number): string {
    const min = Math.max(0, Math.round(hours * 60));
    if (min < 1) return 'just now';
    if (min < 60) return `${min}m`;
    if (min < 60 * 24) return `${Math.floor(min / 60)}h`;
    return `${Math.floor(min / (60 * 24))}d`;
  }

  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    async function loadRecent() {
      setRecentLoading(true);
      try {
        const params = new URLSearchParams({ interval });
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        const res = await fetch(`/api/metrics/pr/last?${params.toString()}`, { credentials: 'include', signal: controller.signal });
        if (!res.ok) throw new Error(String(res.status));
        const data = await res.json();
        if (cancelled) return;
        if (Array.isArray(data)) {
          const mapped: RecentPrItem[] = data.map((it: any, idx: number) => ({
            id: String(idx + 1),
            // older backends send the commit `message` instead of the MR `title`, and hours in `commitDate`
            title: String(it?.title ?? String(it?.message ?? '').split('\n')[0]),
            author: String(it?.author ?? ''),
            status: String(it?.state ?? ''),
            timeAgo: (() => {
              const hours = typeof it?.hoursAgo === 'number' ? it.hoursAgo : typeof it?.commitDate === 'number' ? it.commitDate : null;
              if (hours == null) return '';
              const f = formatHours(hours);
              return f === 'just now' ? f : `${f} ago`;
            })(),
            mergeTime: typeof it?.mergeTime === 'number' ? formatHours(it.mergeTime) : null,
            targetBranch: typeof it?.targetBranch === 'string' ? it.targetBranch : null,
            commits: Array.isArray(it?.commits)
              ? it.commits.map((c: any) => ({ id: String(c?.id ?? ''), title: String(c?.title ?? ''), author: c?.authorName ? String(c.authorName) : null }))
              : [],
          }));
          setRecentLive(mapped);
        } else {
          setRecentLive([]);
        }
      } catch (_e) {
        if (cancelled) return;
        setRecentLive([]);
      } finally {
        if (!cancelled) setRecentLoading(false);
      }
    }
    loadRecent();
    return () => { cancelled = true; controller.abort(); };
  }, [interval, selectedUnitId]);

  // PR Cycle Time Breakdown data from API (/api/metrics/pr/chart/t)
  const [cycleChartData, setCycleChartData] = useState<Array<{ week: string; coding: number; pickup?: number; review?: number; merge: number }>>([]);
  const [cycleSum, setCycleSum] = useState<{ coding: number; pickup: number; review: number; merge: number } | null>(null);

  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    async function loadCycleChart() {
      try {
        const params = new URLSearchParams({ interval });
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        const res = await fetch(`/api/metrics/pr/chart/ct?${params.toString()}`, { credentials: 'include', signal: controller.signal });
        if (!res.ok) {
          if (!cancelled) {
            setCycleChartData([]);
            setCycleSum(null);
          }
          return;
        }
        const data = await res.json();
        if (cancelled) return;
        // Backend may return { values: [...], sum: {...} }
        if (data && Array.isArray(data.values)) {
          const mapped = data.values.map((d: any) => ({
            week: String(d?.label ?? ''),
            coding: Number(d?.coding ?? 0),
            pickup: Number(d?.pickup ?? 0),
            review: Number(d?.review ?? 0),
            merge: Number(d?.merge ?? 0),
          }));
          setCycleChartData(mapped);
          const sum = data?.sum || {};
          setCycleSum({
              coding: Number(sum?.coding ?? 0 ),
              pickup: Number(sum?.pickup ?? 0 ),
              review: Number(sum?.review ?? 0 ),
              merge: Number(sum?.merge ?? 0 )
          });
        } else {
          setCycleChartData([]);
          setCycleSum(null);
        }
      } catch (_e) {
        if (cancelled) return;
        setCycleChartData([]);
        setCycleSum(null);
      }
    }
    loadCycleChart();
    return () => {
      cancelled = true; controller.abort();
    };
  }, [interval, selectedUnitId]);

  // PR Throughput chart data from API (/api/metrics/pr/chart/c)
  const [prChartData, setPrChartData] = useState<Array<{ week: string; opened: number; merged: number; developing?: number }>>([]);
  const [prChartSum, setPrChartSum] = useState<{ review?: number | null; opened?: number | null; merged?: number | null; mergedRate?: number | null } | null>(null);

  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    async function loadChart() {
      try {
        const params = new URLSearchParams({ interval });
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        const res = await fetch(`/api/metrics/pr/chart/tp?${params.toString()}`, { credentials: 'include', signal: controller.signal });
        if (!res.ok) {
          if (!cancelled) {
            setPrChartData([]);
            setPrChartSum(null);
          }
          return;
        }
        const data = await res.json();
        if (cancelled) return;
        // Expected shape: { values: [{ startDate, endDate, review, opened, merged, mergedRate }], sum: { review, opened, merged, mergedRate } }
        if (data && Array.isArray(data.values)) {
          const mapped = data.values.map((d: any) => ({
            week: String(d?.startDate ?? ''),
            opened: Number(d?.review ?? 0), // we display this series as "Review"
            developing: Number(d?.opened ?? 0), // we display this series as "Develop"
            merged: Number(d?.merged ?? 0),
          }));
          const sorted = [...mapped].sort((a, b) => new Date(a.week).getTime() - new Date(b.week).getTime());
          setPrChartData(sorted);
          const sum = data?.sum || {};
          setPrChartSum({
            review: typeof sum?.review === 'number' ? sum.review : null,
            opened: typeof sum?.opened === 'number' ? sum.opened : null,
            merged: typeof sum?.merged === 'number' ? sum.merged : null,
            mergedRate: typeof sum?.mergedRate === 'number' ? sum.mergedRate : null,
          });
        } else {
          setPrChartData([]);
          setPrChartSum(null);
        }
      } catch (_e) {
        if (cancelled) return;
        console.warn('[PR Chart] Error loading data');
        setPrChartData([]);
        setPrChartSum(null);
      }
    }
    loadChart();
    return () => {
      cancelled = true; controller.abort();
    };
  }, [interval, selectedUnitId]);

  // PR Flow metrics from API (/api/metrics/pr/flow)
  const [prFlow, setPrFlow] = useState<{
    opened?: number;
    openedDiff?: number;
    merged?: number;
    mergedDiff?: number;
    review?: number;
    reviewDiff?: number;
    loading: boolean;
  }>({ loading: true });

  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    async function loadPrFlow() {
      setPrFlow((s) => ({ ...s, loading: true }));
      try {
        const params = new URLSearchParams({ interval });
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        const res = await fetch(`/api/metrics/pr/flow?${params.toString()}`, { credentials: 'include', signal: controller.signal });
        if (!res.ok) throw new Error('Failed');
        const data = await res.json();
        if (cancelled) return;
        const opened = typeof data?.opened === 'number' ? data.opened : undefined;
        const openedDiff = typeof data?.openedDiff === 'number' ? data.openedDiff : undefined;
        const merged = typeof data?.merged === 'number' ? data.merged : undefined;
        const mergedDiff = typeof data?.mergedDiff === 'number' ? data.mergedDiff : undefined;
        const review = typeof data?.merged === 'number' ? data.review : undefined;
        const reviewDiff = typeof data?.mergedDiff === 'number' ? data.reviewDiff : undefined;
        const openedRateChange = typeof data?.openedRateChange === 'number' ? data.openedRateChange : undefined;
        const mergedRateChange = typeof data?.mergedRateChange === 'number' ? data.mergedRateChange : undefined;
        setPrFlow({ opened, openedDiff, merged, mergedDiff, review, reviewDiff, openedRateChange, mergedRateChange, loading: false });
      } catch (_e) {
        if (cancelled) return;
        setPrFlow((s) => ({ ...s, loading: false }));
      }
    }
    loadPrFlow();
    return () => {
      cancelled = true; controller.abort();
    };
  }, [interval, selectedUnitId]);

  const t = useTr();
  const pick = usePick();
  return (
    <div className="p-4 sm:p-6 mx-auto space-y-6">

      {/* Page header */}
      <div className="flex flex-col gap-2">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="min-w-0">
            <h1 className="text-[20px] text-gray-900" style={{ fontWeight: 700 }}>{t('overview')}</h1>
            <p className="text-[13px] text-gray-500 mt-0.5">{t('engineeringPerformance')} · {selectedTeamName} · {dateRangeLabel}</p>
          </div>
          {/* Actions: Local Benchmark + AI Analyst */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setFlowOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border text-[12px] text-white"
              style={{ backgroundColor: '#065f46', borderColor: '#065f46', fontWeight: 600 }}
            >
              <Workflow className="w-3.5 h-3.5" /> {pick('Work flow', 'Przepływ pracy')}
            </button>
            <button
              onClick={() => setEfficiencyOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border text-[12px] text-white"
              style={{ backgroundColor: '#1d4ed8', borderColor: '#1d4ed8', fontWeight: 600 }}
            >
              <Gauge className="w-3.5 h-3.5" /> Flow efficiency
            </button>
            <button
              onClick={handleToggleLocalBenchmark}
              className={`px-3 py-1.5 rounded-md border text-[12px] transition-colors ${
                localBenchmark ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'
              }`}
            >
              {t('localBenchmark')}
            </button>
          </div>
        </div>
      </div>

      <FlowDialog open={flowOpen} onOpenChange={setFlowOpen} unitId={selectedUnitId} interval={interval} teamName={selectedTeamName} dateRange={dateRangeLabel} />
      <FlowEfficiencyDialog open={efficiencyOpen} onOpenChange={setEfficiencyOpen} unitId={selectedUnitId} interval={interval} teamName={selectedTeamName} dateRange={dateRangeLabel} />

      {/* Global data note */}
      <div className="-mt-2 text-[12px] text-gray-600 flex items-center gap-2">
        <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
        <span>{pick('Data reflects the process up to the moment a change is merged into the first protected branch.','Dane dotyczą procesu do momentu scalenia (merge) do pierwszego chronionego brancha.')}</span>
      </div>
    
      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-5 gap-4">
        <StatCard
          label={t('prCycleTime')}
          value={prValue}
          unit={lang === 'pl' ? 'godziny' : 'h'}
          pctOverride={prChange}
          trendOverride={prTrend}
          goodDirection="down"
          icon={Clock}
          color="bg-indigo-500"
          bench={benchFor('prCycle')}
          benchUnitType={bench?.unitType}
          help={pick(
            'Average time from the first commit of a merge request to its merge into main/master (the same value as Lead Time on the DORA screen). Lower is better; long times often indicate review or pickup delays.',
            'Średni czas od pierwszego commita merge requesta do jego merge\'a do main/master (ta sama wartość co Lead Time na ekranie DORA). Mniej znaczy lepiej; długie czasy często wskazują na opóźnienia w recenzji lub odbiorze.'
          )}
        />
        <StatCard
          label={t('prThroughput')}
          value={prThroughputValue}
          unit={t('prs')}
          pctOverride={prThroughputChange}
          trendOverride={prThroughputTrend}
          goodDirection="up"
          icon={GitMerge}
          color="bg-violet-500"
          bench={benchFor('prThroughput')}
          benchUnitType={bench?.unitType}
          help={pick(
            'Number of pull requests completed in the period. Higher is better; reflects delivery volume (not quality).',
            'Liczba pull requestów zakończonych w danym okresie. Więcej znaczy lepiej; odzwierciedla wolumen dostarczania (nie jakość).'
          )}
        />
        <StatCard
          label={t('deployFrequency')}
          value={deployValue}
          unit={getIntervalSuffix(dateRange, lang)}
          pctOverride={deployChange}
          trendOverride={deployTrend}
          goodDirection="up"
          icon={Rocket}
          color="bg-emerald-500"
          bench={benchFor('deployFreq')}
          benchUnitType={bench?.unitType}
          help={pick(
            'Production deployments in the period, the same value as on the DORA screen: Jira release tasks moved to LIVE, each counted once on the day it went LIVE. Higher indicates smaller, frequent releases which reduce risk.',
            'Liczba wdrożeń na produkcję w okresie, ta sama wartość co na ekranie DORA: zadania typu Release z Jiry przestawione na LIVE, każde liczone raz, w dniu przejścia na LIVE. Wyższa wartość oznacza mniejsze, częstsze wydania, co ogranicza ryzyko.'
          )}
        />
        <StatCard
          label={pick('Build Fail Rate','Wskaźnik nieudanych buildów')}
          value={failValue}
          unit="%"
          pctOverride={failChange}
          trendOverride={failTrend}
          goodDirection="down"
          icon={AlertTriangle}
          color="bg-amber-500"
          bench={benchFor('buildFailRate')}
          benchUnitType={bench?.unitType}
          help={pick(
            'Percentage of deployments that cause incidents or require rollback. Lower is better; aim to reduce change failure rate over time.',
            'Odsetek wdrożeń, które powodują incydenty lub wymagają wycofania. Mniej znaczy lepiej; dąż do obniżania wskaźnika nieudanych wdrożeń w czasie.'
          )}
        />
        <StatCard
          label={pick('In Progress → Live', 'In Progress → Live')}
          value={inProgressValue}
          unit={inProgressInDays ? (lang === 'pl' ? 'dni' : 'days') : (lang === 'pl' ? 'godziny' : 'h')}
          pctOverride={inProgressChange}
          trendOverride={inProgressTrend}
          goodDirection="down"
          icon={Timer}
          color="bg-sky-500"
          bench={benchFor('inProgressToLive')}
          benchUnit={lang === 'pl' ? 'godz.' : 'h'}
          benchUnitType={bench?.unitType}
          help={pick(
            'Average time of Jira tasks (sub-tasks included) that went LIVE in the period, from their first move to In Progress until Live. Calendar time, including waiting for test and release. Lower is better.',
            'Średni czas zadań z Jiry (także podzadań), które w okresie przeszły na LIVE: od pierwszego przejścia na In Progress do Live. Czas kalendarzowy, razem z oczekiwaniem na testy i wydanie. Mniej znaczy lepiej.'
          )}
        />
      </div>


      {/* Charts row */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* PR Cycle Time Breakdown */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex flex-wrap items-start justify-between gap-x-4 gap-y-2 mb-4">
            <div className="flex items-start gap-2">
              <div>
                <h2 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>{t('prCycleBreakdown')}</h2>
                <p className="text-[12px] text-gray-400 mt-0.5">{t('hoursPerStage')} · {dateRangeLabel}</p>
              </div>
              <HelpTip
                size="sm"
                content={pick(
                  'Average hours per stage of merge requests merged into main/master: Coding (first commit → MR opened), Pickup (→ first approval), Review (→ last approval) and Merge (→ merged). The stages add up to the PR Cycle Time / DORA Lead Time. Use this to find bottlenecks.',
                  'Średnia liczba godzin na etap dla merge requestów zmergowanych do main/master: Kodowanie (pierwszy commit → otwarcie MR), Podjęcie (→ pierwsza akceptacja), Przegląd (→ ostatnia akceptacja) i Scalenie (→ merge). Suma etapów to PR Cycle Time / Lead Time z ekranu DORA. Użyj tego widoku, aby znaleźć wąskie gardła.'
                )}
              />
            </div>
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-gray-500">
              {([
                    { label: t('coding'), color: '#2563eb' },
                    { label: t('pickup'), color: '#059669' },
                    { label: t('review'), color: '#f59e0b' },
                    { label: t('merge'), color: '#ef4444' },
                  ]
              ).map((l) => (
                <div key={l.label as string} className="flex items-center gap-1">
                  <div className="w-2 h-2 rounded-sm" style={{ backgroundColor: l.color }} />
                  {l.label}
                </div>
              ))}
            </div>
          </div>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              {cycleChartData && cycleChartData.length > 0 ? (
                <BarChart data={cycleChartData} barSize={28}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                  <XAxis dataKey="week" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} unit={lang === 'pl' ? 'godziny' : 'h'} />
                  <Tooltip contentStyle={tooltipStyle} cursor={{ fill: '#f9fafb' }} />
                    <>
                      <Bar dataKey="coding" stackId="a" fill="#2563eb" name={t('coding')} />
                      <Bar dataKey="pickup" stackId="a" fill="#059669" name={t('pickup')} />
                      <Bar dataKey="review" stackId="a" fill="#f59e0b" name={t('review')} />
                      <Bar dataKey="merge" stackId="a" fill="#ef4444" name={t('merge')} radius={[4, 4, 0, 0]} />
                    </>
                </BarChart>
              ) : (
                <div className="flex items-center justify-center h-full text-gray-400 text-sm">{t('noData')}</div>
              )}
            </ResponsiveContainer>
          </div>
          {/* Cycle time summary row */}
          <div className={`mt-4 grid grid-cols-2 sm:grid-cols-4 gap-x-2 gap-y-3 pt-4 border-t border-gray-100`}>
            {(() => {
              if (cycleSum) {
                const items = [
                  { stage: t('coding'), time: Number(cycleSum.coding || 0) },
                  { stage: t('pickup'), time: Number(cycleSum.pickup || 0) },
                  { stage: t('review'), time: Number(cycleSum.review || 0) },
                  { stage: t('merge'), time: Number(cycleSum.merge || 0) },
                ];
                return items.map((item) => (
                  <div key={item.stage} className="text-center">
                    <p className="text-[18px] text-gray-900" style={{ fontWeight: 700 }}>{item.time.toFixed(1)} {pick('h','godz.')}</p>
                    <p className="text-[11px] text-gray-400 mt-0.5">{item.stage}</p>
                  </div>
                ));
              }
              if (!cycleChartData || cycleChartData.length === 0) {
                const labels = [t('coding'), t('pickup'), t('review'), t('merge')];
                return labels.map((stage) => (
                  <div key={stage as string} className="text-center">
                    <p className="text-[18px] text-gray-400" style={{ fontWeight: 700 }}>{t('noData')}</p>
                    <p className="text-[11px] text-gray-400 mt-0.5">{stage}</p>
                  </div>
                ));
              }
              const n = cycleChartData.length || 1;
              const sums = cycleChartData.reduce((acc: any, cur: any) => ({
                coding: acc.coding + Number(cur?.coding ?? 0),
                pickup: acc.pickup + Number(cur?.pickup ?? 0),
                review: acc.review + Number(cur?.review ?? 0),
                merge: acc.merge + Number(cur?.merge ?? 0),
              }), { coding: 0, pickup: 0, review: 0, merge: 0 });
              const avgs = {
                coding: sums.coding / n,
                pickup: sums.pickup / n,
                review: sums.review / n,
                merge: sums.merge / n,
              };
              const items = [
                { stage: 'Coding', time: avgs.coding },
                { stage: 'Pickup', time: avgs.pickup },
                { stage: 'Review', time: avgs.review },
                { stage: 'Merge', time: avgs.merge },
              ];
              return items.map((item) => (
                <div key={item.stage} className="text-center">
                  <p className="text-[18px] text-gray-900" style={{ fontWeight: 700 }}>{item.time.toFixed(1)} {pick('h','godz.')}</p>
                  <p className="text-[11px] text-gray-400 mt-0.5">{item.stage}</p>
                </div>
              ));
            })()}
          </div>
        </div>

        {/* PR Throughput */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex flex-wrap items-start justify-between gap-x-4 gap-y-2 mb-4">
            <div className="flex items-start gap-2">
              <div>
                <h2 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>{t('prThroughput')}</h2>
                <p className="text-[12px] text-gray-400 mt-0.5">{pick('Pull requests per week', 'Pull requesty na tydzień')} · {dateRangeLabel}</p>
              </div>
              <HelpTip
                size="sm"
                content={"Areas show how many PRs are being worked on, opened for review, and merged each week. Use trends to spot slowdowns or seasonal effects. Higher merged line means more delivered work."}
              />
            </div>
          </div>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              {prChartData && prChartData.length > 0 ? (
                <AreaChart data={prChartData}>
                  <defs>
                    <linearGradient id="gradDeveloping" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#D3D3D3" stopOpacity={0.2} />
                      <stop offset="95%" stopColor="#D3D3D3" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="gradMerged" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={MERGED_COLOR} stopOpacity={0.2} />
                      <stop offset="95%" stopColor={MERGED_COLOR} stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="gradOpened" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.15} />
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                  <XAxis dataKey="week" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={tooltipStyle} />
                  <Legend
                    formatter={(v) => <span className="text-[11px] text-gray-500">{v}</span>}
                    iconSize={8}
                  />
                  <Area type="monotone" dataKey="developing" stroke="#D3D3D3" strokeWidth={2} fill="url(#gradDeveloping)" name={pick('Develop', 'Rozwój')} dot={false} />
                  <Area type="monotone" dataKey="opened" stroke="#10b981" strokeWidth={2} fill="url(#gradOpened)" name={t('opened')} dot={false} />
                  <Area type="monotone" dataKey="merged" stroke={MERGED_COLOR} strokeWidth={2} fill="url(#gradMerged)" name={t('merged')} dot={false} />
                </AreaChart>
              ) : (
                <div className="flex items-center justify-center h-full text-gray-400 text-sm">N/A</div>
              )}
            </ResponsiveContainer>
          </div>
          <div className="mt-4 grid grid-cols-3 gap-2 pt-4 border-t border-gray-100">
            {(() => {
              if (prChartSum) {
                const opened = prChartSum.opened ?? null;
                const merged = prChartSum.merged ?? null;
                const mergedRate = prChartSum.mergedRate ?? null;
                return (
                  <>
                    <div className="text-center">
                      <p className="text-[18px] text-emerald-600" style={{ fontWeight: 700 }}>{opened != null ? opened : 'N/A'}</p>
                      <p className="text-[11px] text-gray-400 mt-0.5">{t('opened')}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-[18px]" style={{ fontWeight: 700, color: MERGED_COLOR }}>{merged != null ? merged : 'N/A'}</p>
                      <p className="text-[11px] text-gray-400 mt-0.5">{t('merged')}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-[18px] text-gray-900" style={{ fontWeight: 700 }}>{mergedRate != null ? `${mergedRate}%` : 'N/A'}</p>
                      <p className="text-[11px] text-gray-400 mt-0.5">{t('mergeRate')}</p>
                    </div>
                  </>
                );
              }
              if (!prChartData || prChartData.length === 0) {
                return (
                  <>
                    <div className="text-center">
                      <p className="text-[18px] text-gray-400" style={{ fontWeight: 700 }}>N/A</p>
                      <p className="text-[11px] text-gray-400 mt-0.5">Review</p>
                    </div>
                    <div className="text-center">
                      <p className="text-[18px] text-gray-400" style={{ fontWeight: 700 }}>N/A</p>
                      <p className="text-[11px] text-gray-400 mt-0.5">Merged</p>
                    </div>
                    <div className="text-center">
                      <p className="text-[18px] text-gray-400" style={{ fontWeight: 700 }}>N/A</p>
                      <p className="text-[11px] text-gray-400 mt-0.5">Merge rate</p>
                    </div>
                  </>
                );
              }
              // Prefer API sum section if provided
              const sum = prChartSum || {} as any;
              const apiReview = typeof sum?.review === 'number' ? sum.review : null;
              const apiMerged = typeof sum?.merged === 'number' ? sum.merged : null;
              const apiMergedRate = typeof sum?.mergedRate === 'number' ? sum.mergedRate : null;

              const totals = prChartData.reduce(
                (acc: { review: number; merged: number }, cur: any) => ({
                  review: acc.review + Number(cur?.opened ?? 0),
                  merged: acc.merged + Number(cur?.merged ?? 0),
                }),
                { review: 0, merged: 0 }
              );

              const reviewTotal = apiReview != null ? apiReview : totals.review;
              const mergedTotal = apiMerged != null ? apiMerged : totals.merged;
              const mergeRate = apiMergedRate != null ? apiMergedRate : (reviewTotal > 0 ? (mergedTotal / reviewTotal) * 100 : 0);

              return (
                <>
                  <div className="text-center">
                    <p className="text-[18px] text-emerald-600" style={{ fontWeight: 700 }}>{reviewTotal}</p>
                    <p className="text-[11px] text-gray-400 mt-0.5">Review</p>
                  </div>
                  <div className="text-center">
                    <p className="text-[18px]" style={{ fontWeight: 700, color: MERGED_COLOR }}>{mergedTotal}</p>
                    <p className="text-[11px] text-gray-400 mt-0.5">Merged</p>
                  </div>
                  <div className="text-center">
                    <p className="text-[18px] text-gray-900" style={{ fontWeight: 700 }}>{mergeRate.toFixed(1)}%</p>
                    <p className="text-[11px] text-gray-400 mt-0.5">Merge rate</p>
                  </div>
                </>
              );
            })()}
          </div>
        </div>
      </div>

      {/* Bottom row */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">

        {/* PR Funnel */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h2 className="text-[14px] text-gray-900 mb-4" style={{ fontWeight: 600 }}>{t('prFlow')}</h2>
          <div className="space-y-2.5">
            {(() => {
              const base = (prFlow.opened != null && prFlow.merged != null)
                ? [
                    { stage: 'Opened', value: Number(prFlow.opened) || 0, color: '#6366f1' },
                    { stage: 'Review', value: Number(prFlow.review) || 0, color: '#6366f1' },
                    { stage: 'Merged', value: Number(prFlow.merged) || 0, color: '#c4b5fd' },
                  ]
                : [] as Array<{ stage: string; value: number; color: string }>;
              return base.map((stage, i) => {
                const denom = (base[0]?.value || 0) + (base[1]?.value || 0) + (base[2]?.value || 1);
                const pct = Math.round(((stage.value || 0) / denom) * 100);
                const dropped = i < base.length - 1 ? Math.max(0, (base[i].value || 0) - (base[i + 1].value || 0)) : 0;
                return (
                  <div key={stage.stage}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[12px] text-gray-600">{stage.stage}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-[12px] text-gray-400">{pct}%</span>
                        <span className="text-[13px] text-gray-800" style={{ fontWeight: 600 }}>{stage.value}</span>
                      </div>
                    </div>
                    <div className="w-full bg-gray-100 rounded-full h-2">
                      <div
                        className="h-2 rounded-full transition-all"
                        style={{ width: `${pct}%`, backgroundColor: stage.color }}
                      />
                    </div>
                    {i < base.length - 1 && (
                      <div className="flex justify-end mt-1">
                        <span className="text-[11px] text-gray-300">
                          -{dropped} dropped
                        </span>
                      </div>
                    )}
                  </div>
                );
              });
            })()}
          </div>
        </div>

        {/* Recent PRs */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex flex-wrap items-start justify-between gap-x-4 gap-y-2 mb-4">
            <h2 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>{t('recentPRs')}</h2>
            {/* the list covers the selected period (it used to say "Last 24h") */}
            <span className="text-[11px] text-gray-400">{dateRangeLabel}</span>
          </div>
          <div className="space-y-3">
            {recentLoading ? (
              <div className="flex items-center justify-center py-8 text-gray-400 text-[12px]">Loading…</div>
            ) : recentLive && recentLive.length > 0 ? (
              recentLive.map((pr) => (
                <div key={pr.id} className="flex items-start gap-2.5 group">
                  <div
                    className={`flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center mt-0.5 ${pr.status === 'merged' ? '' : pr.status === 'closed' ? 'bg-gray-100' : 'bg-emerald-100'}`}
                    style={pr.status === 'merged' ? { backgroundColor: '#ede9fe' } : undefined}
                  >
                    <GitPullRequest
                      className={`w-3 h-3 ${pr.status === 'merged' ? '' : pr.status === 'closed' ? 'text-gray-500' : 'text-emerald-600'}`}
                      style={pr.status === 'merged' ? { color: MERGED_COLOR } : undefined}
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[12px] text-gray-800 truncate group-hover:text-indigo-600 cursor-pointer transition-colors" style={{ fontWeight: 500 }}>
                      {pr.title}
                    </p>
                    <div className="flex items-center gap-2 mt-0.5 min-w-0">
                      <span className="text-[11px] text-gray-400 truncate">{pr.author}</span>
                      <span className="text-[11px] text-gray-300">·</span>
                      <span className="text-[11px] text-gray-400 whitespace-nowrap">{pr.timeAgo}</span>
                      {pr.mergeTime && (
                        <>
                          <span className="text-[11px] text-gray-300">·</span>
                          <span className="text-[11px] text-gray-400 whitespace-nowrap">
                            {pr.status === 'merged'
                              ? pick(`merged after ${pr.mergeTime}`, `zmergowany po ${pr.mergeTime}`)
                              : pick('merged into an unprotected branch', 'zmergowany do niechronionego brancha')}
                          </span>
                        </>
                      )}
                      {pr.targetBranch && (
                        <>
                          <span className="text-[11px] text-gray-300">·</span>
                          <span className="text-[11px] text-gray-400 truncate font-mono">→ {pr.targetBranch}</span>
                        </>
                      )}
                    </div>
                    {pr.commits.length > 0 && (
                      <ul className="mt-1 space-y-0.5">
                        {(expandedPrs[pr.id] ? pr.commits : pr.commits.slice(0, RECENT_PR_COMMITS_SHOWN)).map((c) => (
                          <li key={c.id} className="flex items-baseline gap-1.5 text-[11px] min-w-0" title={c.author ? `${c.title} · ${c.author}` : c.title}>
                            <span className="font-mono text-gray-400 shrink-0">{c.id.slice(0, 7)}</span>
                            <span className="text-gray-600 dark:text-gray-300 truncate">{c.title}</span>
                          </li>
                        ))}
                        {pr.commits.length > RECENT_PR_COMMITS_SHOWN && (
                          <li>
                            <button
                              type="button"
                              className="text-[11px] text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 underline decoration-dotted"
                              onClick={() => setExpandedPrs((m) => ({ ...m, [pr.id]: !m[pr.id] }))}
                            >
                              {expandedPrs[pr.id]
                                ? pick('show less', 'zwiń')
                                : pick(`+${pr.commits.length - RECENT_PR_COMMITS_SHOWN} more commits`, `+${pr.commits.length - RECENT_PR_COMMITS_SHOWN} więcej commitów`)}
                            </button>
                          </li>
                        )}
                      </ul>
                    )}
                  </div>
                  {/* merged uses explicit purple: theme.css remaps Tailwind indigo classes to the brand green */}
                  <div className={`flex-shrink-0 px-1.5 py-0.5 rounded text-[10px] ${
                    pr.status === 'merged'
                      ? ''
                      : pr.status === 'closed'
                        ? 'bg-gray-100 text-gray-600'
                        : 'bg-emerald-50 text-emerald-700'
                  }`} style={{ fontWeight: 500, ...(pr.status === 'merged' ? { backgroundColor: '#ede9fe', color: '#6d28d9' } : {}) }}>
                    {pr.status}
                  </div>
                </div>
              ))
            ) : (
              <div className="flex items-center justify-center py-8 text-gray-400 text-[12px]">No Data</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
