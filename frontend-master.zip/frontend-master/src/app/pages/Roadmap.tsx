import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertTriangle, Briefcase, CheckCircle2, ChevronLeft, ChevronRight, Cpu, Milestone } from 'lucide-react';
import { useTeam } from '../context/TeamContext';
import { useLang, usePick } from '../i18n';
import LoadingSpinner from '../components/LoadingSpinner';
import HelpTip from '../components/HelpTip';
import { usePageAccess } from '../hooks/usePageAccess';

// Roadmap: the unit's epics put on a quarter of the year on the Deliver screen (/api/metrics/roadmap?year=), in two
// sections by the Jira "technical" flag of the epic (not set = business), on a timeline of the year with the progress;
// on the right what is done of each and what needs attention.

type Health = 'NOT_STARTED' | 'ON_TRACK' | 'AT_RISK' | 'OFF_TRACK' | 'DELIVERED' | 'DELIVERED_LATE';
type Epic = {
  key: string; summary?: string | null; status?: string | null; statusDays?: number | null; assignee?: string | null;
  plannedStart?: string | null; actualStart?: string | null; plannedDelivery?: string | null; deliveryDate?: string | null;
  deliveryForecast: boolean; health: Health; delayDays?: number | null; delayReason?: string | null;
  items: number; itemsDone: number; progressPct: number; technical?: boolean | null; quarter?: string | null;
};

// the same limit as Deliver's "In status"
const LONG_IN_STATUS_DAYS = 100;
const card = 'bg-white dark:bg-[#121317] rounded-xl border border-gray-200 dark:border-white/10';
const muted = 'text-gray-500 dark:text-gray-400';
// Explicit hex colors: theme.css remaps Tailwind indigo/green classes to the brand palette.
const HEALTH_COLOR: Record<Health, string> = {
  NOT_STARTED: '#9ca3af', ON_TRACK: '#3b82f6', AT_RISK: '#f97316', OFF_TRACK: '#dc2626', DELIVERED: '#10b981', DELIVERED_LATE: '#f59e0b',
};

const isDone = (e: Epic) => e.health === 'DELIVERED' || e.health === 'DELIVERED_LATE';
const day = (iso?: string | null) => (iso ? new Date(iso.length === 10 ? `${iso}T00:00:00` : iso) : null);
const quarterNo = (q?: string | null) => Number(q?.slice(-1)) || 1;
const quarterStart = (year: number, q: number) => new Date(year, (q - 1) * 3, 1);
const quarterEnd = (year: number, q: number) => new Date(year, q * 3, 0, 23, 59, 59);

function signalText(reason: string, pick: (en: string, pl: string) => string): string {
  const texts: Record<string, [string, string]> = {
    BEHIND_PLAN: ['Behind the plan', 'Za planem'],
    BLOCKED: ['Blocked work items', 'Zablokowane zadania'],
    STALLED: ['No progress for 10+ days', 'Brak postępu od 10+ dni'],
    STUCK_IN_TEST: ['Stuck in test', 'Utknęło w testach'],
    SCOPE_GROWTH: ['Scope is growing', 'Rośnie zakres'],
  };
  const t = texts[reason];
  return t ? pick(t[0], t[1]) : reason;
}

/** Why an epic needs attention, or null. */
function attention(e: Epic, year: number, pick: (en: string, pl: string) => string): string | null {
  if (e.health === 'AT_RISK' || e.health === 'OFF_TRACK') {
    const d = e.delayDays ? ` · +${e.delayDays} ${pick('d', 'dni')}` : '';
    if (e.delayReason === 'START_DELAYED') return pick('Planned start passed, nothing in progress', 'Planowany start minął, nic nie jest w toku') + d;
    if (e.delayReason === 'FORECAST_AFTER_DUE') return pick('Forecast after the planned delivery', 'Prognoza po planowanym dostarczeniu') + d;
    if (e.delayReason && e.delayReason !== 'PAST_DUE') return signalText(e.delayReason, pick) + d;
    return pick('Planned delivery passed', 'Minęła planowana data dostarczenia') + d;
  }
  if (!isDone(e) && quarterEnd(year, quarterNo(e.quarter)) < new Date()) {
    return pick(`Quarter ${e.quarter?.slice(-2)} is over and not delivered`, `Kwartał ${e.quarter?.slice(-2)} minął, a epik nie jest dostarczony`);
  }
  if (!isDone(e) && (e.statusDays ?? 0) > LONG_IN_STATUS_DAYS) {
    return pick(`${e.statusDays} days in status ${e.status ?? ''}`, `${e.statusDays} dni w statusie ${e.status ?? ''}`);
  }
  if (!isDone(e) && !e.plannedDelivery) return pick('No planned delivery date in Jira', 'Brak planowanej daty dostarczenia w Jirze');
  return null;
}

export function Roadmap() {
  const pick = usePick();
  const { lang } = useLang();
  const navigate = useNavigate();
  const { selectedUnitId, selectedTeamName } = useTeam();
  const { loading: accessLoading, allowed: canOpen } = usePageAccess('roadmap');
  const [year, setYear] = useState(() => new Date().getFullYear());
  const [epics, setEpics] = useState<Epic[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    if (!canOpen) return;
    let cancelled = false;
    const controller = new AbortController();
    (async () => {
      setLoading(true);
      setFailed(false);
      try {
        const p = new URLSearchParams({ year: String(year) });
        if (selectedUnitId) p.set('unitId', selectedUnitId);
        const res = await fetch(`/api/metrics/roadmap?${p.toString()}`, { credentials: 'include', signal: controller.signal });
        if (!res.ok) throw new Error(String(res.status));
        const js = await res.json();
        if (!cancelled) setEpics(Array.isArray(js?.epics) ? js.epics : []);
      } catch {
        if (!cancelled) { setEpics(null); setFailed(true); }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; controller.abort(); };
  }, [canOpen, year, selectedUnitId]);

  const business = useMemo(() => (epics ?? []).filter((e) => e.technical !== true), [epics]);
  const technical = useMemo(() => (epics ?? []).filter((e) => e.technical === true), [epics]);
  const attentionList = useMemo(() => (epics ?? []).map((e) => ({ e, why: attention(e, year, pick) }))
    .filter((it): it is { e: Epic; why: string } => !!it.why), [epics, year, pick]);
  const locale = lang === 'pl' ? 'pl-PL' : 'en-GB';
  const fmtDate = (iso?: string | null) => (iso ? day(iso)!.toLocaleDateString(locale, { day: 'numeric', month: 'short' }) : '—');
  const open = (key: string) => navigate(`/deliver?epic=${encodeURIComponent(key)}`);

  if (accessLoading) return <div className="p-6"><LoadingSpinner size={20} /></div>;
  if (!canOpen) {
    return (
      <div className="p-6 mx-auto">
        <div className={`${card} p-5`}>
          <p className="text-[14px] text-gray-800 dark:text-gray-100" style={{ fontWeight: 600 }}>{pick('No access', 'Brak dostępu')}</p>
          <p className={`text-[12px] ${muted} mt-1`}>{pick('Your role has no access to this screen. An admin can change it in Settings → Users and access.', 'Twoja rola nie ma dostępu do tego ekranu. Admin może to zmienić w Ustawienia → Użytkownicy i dostęp.')}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-6 space-y-4 text-gray-900 dark:text-gray-100">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-[22px] flex items-center gap-2" style={{ fontWeight: 800 }}>
            <Milestone className="w-6 h-6 text-blue-600" /> Roadmap
          </h1>
          <p className={`text-[12.5px] ${muted} mt-0.5`}>
            {pick('Epics put on a quarter on the Deliver screen', 'Epiki oznaczone kwartałem na ekranie Deliver')}
            {' · '}{selectedTeamName && selectedTeamName !== 'All Teams' ? selectedTeamName : pick('all your units', 'wszystkie Twoje unity')}
          </p>
        </div>
        <div className="flex items-center gap-1">
          <button onClick={() => setYear((y) => y - 1)} className="p-1.5 rounded-md hover:bg-gray-100 dark:hover:bg-white/10" aria-label={pick('Previous year', 'Poprzedni rok')}>
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="text-[15px] w-12 text-center" style={{ fontWeight: 700 }}>{year}</span>
          <button onClick={() => setYear((y) => y + 1)} className="p-1.5 rounded-md hover:bg-gray-100 dark:hover:bg-white/10" aria-label={pick('Next year', 'Następny rok')}>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {loading && !epics ? (
        <div className={`${card} p-8 flex justify-center`}><LoadingSpinner size={20} /></div>
      ) : failed ? (
        <div className={`${card} p-6 text-[13px] ${muted}`}>{pick('Could not load the roadmap.', 'Nie udało się pobrać roadmapy.')}</div>
      ) : (
        <div className="grid grid-cols-1 xl:grid-cols-[minmax(0,1fr)_300px] gap-4 items-start">
          <div className="space-y-4 min-w-0">
            <Section title={pick('Business epics', 'Epiki biznesowe')} icon={<Briefcase className="w-4 h-4" />} epics={business}
              year={year} fmtDate={fmtDate} onOpen={open} />
            <Section title={pick('Technology epics', 'Epiki technologiczne')} icon={<Cpu className="w-4 h-4" />} epics={technical}
              year={year} fmtDate={fmtDate} onOpen={open} />
          </div>

          <div className="space-y-4">
            <div className={`${card} p-4 space-y-3`}>
              <div className="text-[13px]" style={{ fontWeight: 700 }}>{pick('Completed', 'Ukończone')}</div>
              <DoneBar label={pick('Business', 'Biznesowe')} list={business} />
              <DoneBar label={pick('Technology', 'Technologiczne')} list={technical} />
            </div>
            <div className={`${card} p-4`}>
              <div className="text-[13px] flex items-center gap-1.5" style={{ fontWeight: 700 }}>
                <AlertTriangle className="w-4 h-4 text-amber-500" /> {pick('Needs attention', 'Wymaga uwagi')}
                <span className={`ml-auto text-[12px] ${muted}`}>{attentionList.length}</span>
              </div>
              {attentionList.length === 0 ? (
                <div className={`mt-2 text-[12px] ${muted} flex items-center gap-1.5`}>
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" /> {pick('Nothing at the moment', 'Na razie nic')}
                </div>
              ) : (
                <ul className="mt-2 space-y-2">
                  {attentionList.map(({ e, why }) => (
                    <li key={e.key}>
                      <button onClick={() => open(e.key)} className="w-full text-left rounded-lg px-2 py-1.5 hover:bg-gray-50 dark:hover:bg-white/5">
                        <div className="text-[12px] truncate" style={{ fontWeight: 600 }} title={e.summary ?? ''}>{e.summary || e.key}</div>
                        <div className={`text-[11px] ${muted}`}>
                          {e.key} · {e.technical === true ? pick('technology', 'technologiczny') : pick('business', 'biznesowy')} · {e.quarter?.slice(-2)}
                        </div>
                        <div className="text-[11px] text-red-600 dark:text-red-400">{why}</div>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function DoneBar({ label, list }: { label: string; list: Epic[] }) {
  const done = list.filter(isDone).length;
  const pct = list.length ? Math.round((done * 100) / list.length) : 0;
  return (
    <div>
      <div className="flex justify-between text-[12px]">
        <span>{label}</span>
        <span className={muted}><span className="text-gray-900 dark:text-gray-100" style={{ fontWeight: 700 }}>{done}</span>/{list.length}</span>
      </div>
      <div className="mt-1 h-1.5 rounded-full bg-gray-100 dark:bg-white/10 overflow-hidden">
        <div className="h-full rounded-full" style={{ width: `${pct}%`, backgroundColor: HEALTH_COLOR.DELIVERED }} />
      </div>
    </div>
  );
}

/** Epics of one kind on the timeline of the year: from the start (planned, actual or the quarter's) to the delivery. */
function Section({ title, icon, epics, year, fmtDate, onOpen }: {
  title: string; icon: ReactNode; epics: Epic[]; year: number; fmtDate: (iso?: string | null) => string; onOpen: (key: string) => void;
}) {
  const pick = usePick();
  const { lang } = useLang();
  const from = new Date(year, 0, 1).getTime();
  const till = new Date(year + 1, 0, 1).getTime();
  const pos = (d: Date) => Math.max(0, Math.min(100, ((d.getTime() - from) / (till - from)) * 100));
  const now = new Date();
  const todayPct = now.getFullYear() === year ? pos(now) : null;
  // January to December on the axis, each as long as its days (the quarters start at the darker lines)
  const months = Array.from({ length: 12 }, (_, i) => {
    const left = pos(new Date(year, i, 1));
    return {
      i, left, width: pos(new Date(year, i + 1, 1)) - left,
      name: new Date(year, i, 1).toLocaleDateString(lang === 'pl' ? 'pl-PL' : 'en-GB', { month: 'short' }).replace('.', ''),
    };
  });
  const done = epics.filter(isDone).length;

  return (
    <div className={`${card} overflow-hidden`}>
      <div className="px-4 py-3 border-b border-gray-200 dark:border-white/10 flex items-center gap-2">
        <span className="text-blue-600">{icon}</span>
        <span className="text-[14px]" style={{ fontWeight: 700 }}>{title}</span>
        <span className={`text-[12px] ${muted}`}>· {epics.length} {pick('epics', 'epików')} · {done} {pick('done', 'ukończonych')}</span>
        <span className="ml-auto"><HelpTip size="sm" content={pick(
          'Bar: from the planned start (actual start, or the start of the quarter) to the delivery (planned, forecast, or the end of the quarter); the filled part is the share of the done work items.',
          'Pasek: od planowanego startu (faktycznego lub początku kwartału) do dostarczenia (planowanego, prognozy lub końca kwartału); wypełnienie to odsetek zamkniętych zadań.')} /></span>
      </div>
      {epics.length === 0 ? (
        <div className={`px-4 py-6 text-[12.5px] ${muted}`}>
          {pick('No epics on the roadmap of this year. Set a quarter on the Deliver screen.', 'Brak epików na roadmapie tego roku. Ustaw kwartał na ekranie Deliver.')}
        </div>
      ) : (
        <div className="overflow-x-auto">
          <div className="min-w-[900px]">
            <div className="grid grid-cols-[260px_minmax(0,1fr)_56px] border-b border-gray-100 dark:border-white/5">
              <div />
              <div className="relative h-7">
                {months.map(({ i, left, width, name }) => (
                  <div key={i} className={`absolute inset-y-0 flex items-center justify-center text-[11px] ${muted} ${i > 0 ? `border-l ${i % 3 === 0 ? 'border-gray-300 dark:border-white/20' : 'border-gray-100 dark:border-white/5'}` : ''}`}
                    style={{ left: `${left}%`, width: `${width}%`, fontWeight: 600 }}>{name}</div>
                ))}
              </div>
              <div className={`text-[11px] ${muted} text-right pr-4 py-1.5`}>%</div>
            </div>
            {epics.map((e) => {
              const q = quarterNo(e.quarter);
              const start = day(e.plannedStart) ?? day(e.actualStart) ?? quarterStart(year, q);
              const end = day(e.deliveryDate) ?? day(e.plannedDelivery) ?? quarterEnd(year, q);
              const left = pos(start);
              const width = Math.max(1.5, pos(end < start ? start : end) - left);
              const color = HEALTH_COLOR[e.health];
              return (
                <button key={e.key} onClick={() => onOpen(e.key)}
                  className="w-full grid grid-cols-[260px_minmax(0,1fr)_56px] items-center text-left border-b border-gray-100 dark:border-white/5 hover:bg-gray-50 dark:hover:bg-white/5">
                  <div className="px-4 py-2 min-w-0">
                    <div className="text-[12.5px] truncate" style={{ fontWeight: 600 }} title={e.summary ?? ''}>{e.summary || e.key}</div>
                    <div className={`text-[11px] ${muted} truncate`}>{e.key} · {e.quarter?.slice(-2)}{e.status ? ` · ${e.status}` : ''}</div>
                  </div>
                  <div className="relative h-9">
                    {/* the planned quarter and the quarter lines */}
                    <div className="absolute inset-y-0 bg-blue-50/60 dark:bg-blue-400/5" style={{ left: `${(q - 1) * 25}%`, width: '25%' }} />
                    {months.slice(1).map(({ i, left }) => (
                      <div key={i} className={`absolute inset-y-0 border-l ${i % 3 === 0 ? 'border-gray-200 dark:border-white/10' : 'border-gray-100/70 dark:border-white/[0.03]'}`} style={{ left: `${left}%` }} />
                    ))}
                    {todayPct != null && <div className="absolute inset-y-0 border-l-2 border-red-400/70" style={{ left: `${todayPct}%` }} />}
                    <div className="absolute top-1/2 -translate-y-1/2 h-3.5 rounded-full overflow-hidden"
                      style={{ left: `${left}%`, width: `${width}%`, backgroundColor: `${color}33`, border: `1px solid ${color}` }}
                      title={`${fmtDate(e.plannedStart ?? e.actualStart)} → ${fmtDate(e.deliveryDate ?? e.plannedDelivery)}${e.deliveryForecast ? ` (${pick('forecast', 'prognoza')})` : ''} · ${e.itemsDone}/${e.items}`}>
                      <div className="h-full" style={{ width: `${e.progressPct}%`, backgroundColor: color }} />
                    </div>
                  </div>
                  <div className="pr-4 text-right text-[12px]" style={{ fontWeight: 700, color }}>{e.progressPct}%</div>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
