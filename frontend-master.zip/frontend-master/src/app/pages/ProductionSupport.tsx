import { useEffect, useMemo, useState } from 'react';
import { Bar, CartesianGrid, Cell, ComposedChart, Legend, Line, ResponsiveContainer, Tooltip, XAxis, YAxis, BarChart } from 'recharts';
import { AlertTriangle, CheckCircle2, Clock, Inbox, LifeBuoy, PlayCircle } from 'lucide-react';
import { useDateRange } from '../context/DateRangeContext';
import { useTeam } from '../context/TeamContext';
import { useLang, usePick } from '../i18n';
import LoadingSpinner from '../components/LoadingSpinner';
import { toInterval } from '../utils/dateRange';

// Production support: the unit's production defects from Jira (/api/metrics/production-support) - open vs closed,
// time to close and to pick up, weekly inflow vs outflow, age of what is still open.

type Summary = {
  open: number; openOver30Days: number; reported: number; closed: number; rejected: number;
  avgDaysToClose?: number | null; medianDaysToClose?: number | null; p85DaysToClose?: number | null; avgDaysToStart?: number | null;
};
type Defect = {
  key: string; summary?: string | null; url?: string | null; status?: string | null; priority?: string | null;
  assignee?: string | null; reported?: string | null; ageDays?: number | null; daysInStatus?: number | null;
  closed?: string | null; daysToClose?: number | null;
};
type ProductionSupportData = {
  summary: Summary;
  previous: Summary;
  weeks: Array<{ weekStart: string; reported: number; closed: number; open: number }>;
  aging: Array<{ from: number; till?: number | null; count: number }>;
  byPriority: Array<{ priority: string; open: number; closed: number; avgDaysToClose?: number | null }>;
  open: Defect[];
  recentlyClosed: Defect[];
};

// Explicit hex colors: theme.css remaps Tailwind indigo/green classes to the brand palette.
const REPORTED = '#ef4444';
const CLOSED = '#10b981';
const OPEN_LINE = '#3b82f6';
const AGE_COLORS = ['#10b981', '#eab308', '#f97316', '#ef4444'];
const card = 'bg-white dark:bg-[#121317] rounded-xl border border-gray-200 dark:border-white/10 p-4';
const muted = 'text-gray-500 dark:text-gray-400';

function intervalOf(dateRange: string): string {
  return toInterval(dateRange, 'WEEKS_4');
}

/** Days, or hours below one day. */
function fmtDuration(days: number | null | undefined, pick: (en: string, pl: string) => string): string {
  if (days == null) return '—';
  if (days < 1) return `${Math.round(days * 24)} h`;
  return `${Number.isInteger(days) ? days : days.toFixed(1)} ${pick('d', 'dni')}`;
}

function ageColor(days: number | null | undefined): string {
  if (days == null) return '#6b7280';
  if (days >= 90) return AGE_COLORS[3];
  if (days >= 30) return AGE_COLORS[2];
  if (days >= 7) return AGE_COLORS[1];
  return AGE_COLORS[0];
}

/** Change vs the previous period; lessBetter: a drop is good. */
function Delta({ now, prev, lessBetter }: { now?: number | null; prev?: number | null; lessBetter: boolean }) {
  const pick = usePick();
  if (now == null || prev == null || prev === 0) return null;
  const pct = ((now - prev) / prev) * 100;
  if (Math.abs(pct) < 0.5) return <span className={`text-[11px] ${muted}`}>= {pick('as before', 'jak wcześniej')}</span>;
  const good = lessBetter ? pct < 0 : pct > 0;
  return (
    <span className="text-[11px]" style={{ color: good ? CLOSED : REPORTED, fontWeight: 600 }}>
      {pct > 0 ? '▲' : '▼'} {Math.abs(Math.round(pct))}% <span className={muted} style={{ fontWeight: 400 }}>{pick('vs previous', 'vs poprzedni')}</span>
    </span>
  );
}

function Kpi({ icon: Icon, color, label, value, sub, delta }: {
  icon: typeof Inbox; color: string; label: string; value: string; sub?: React.ReactNode; delta?: React.ReactNode;
}) {
  return (
    <div className={card}>
      <div className="flex items-center gap-2">
        <span className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${color}1a` }}>
          <Icon className="w-4 h-4" style={{ color }} />
        </span>
        <span className={`text-[12px] ${muted}`}>{label}</span>
      </div>
      <div className="text-[26px] mt-2 leading-none" style={{ fontWeight: 700 }}>{value}</div>
      {sub && <div className={`text-[11px] ${muted} mt-1.5`}>{sub}</div>}
      {delta && <div className="mt-1">{delta}</div>}
    </div>
  );
}

export function ProductionSupport() {
  const pick = usePick();
  const { lang } = useLang();
  const { dateRange, label: dateRangeLabel } = useDateRange();
  const { selectedTeamName, selectedUnitId } = useTeam();
  const interval = intervalOf(dateRange);
  const [data, setData] = useState<ProductionSupportData | null>(null);
  const [loading, setLoading] = useState(false);
  const [failed, setFailed] = useState(false);
  const [openSort, setOpenSort] = useState<'age' | 'status'>('age');

  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    async function load() {
      setLoading(true);
      setFailed(false);
      try {
        const params = new URLSearchParams({ interval });
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        const res = await fetch(`/api/metrics/production-support?${params.toString()}`, { credentials: 'include', signal: controller.signal });
        if (!res.ok) throw new Error(String(res.status));
        const js = (await res.json()) as ProductionSupportData;
        if (!cancelled) setData(js);
      } catch {
        if (!cancelled) { setData(null); setFailed(true); }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; controller.abort(); };
  }, [interval, selectedUnitId]);

  const locale = lang === 'pl' ? 'pl-PL' : 'en-GB';
  const fmtDate = (iso?: string | null) => (iso ? new Date(iso).toLocaleDateString(locale, { day: 'numeric', month: 'short', year: 'numeric' }) : '—');
  const weeks = useMemo(() => (data?.weeks ?? []).map((w) => ({
    ...w,
    label: new Date(`${w.weekStart}T00:00:00`).toLocaleDateString(locale, { day: 'numeric', month: 'short' }),
  })), [data, locale]);
  const aging = useMemo(() => (data?.aging ?? []).map((b, i) => ({
    label: b.till == null ? `${b.from}+ ${pick('d', 'dni')}` : `${b.from}–${b.till} ${pick('d', 'dni')}`,
    count: b.count,
    color: AGE_COLORS[i] ?? AGE_COLORS[AGE_COLORS.length - 1],
  })), [data, pick]);
  const openDefects = useMemo(() => {
    const list = [...(data?.open ?? [])];
    if (openSort === 'status') list.sort((a, b) => (a.status ?? '').localeCompare(b.status ?? '') || (b.ageDays ?? 0) - (a.ageDays ?? 0));
    else list.sort((a, b) => (b.ageDays ?? 0) - (a.ageDays ?? 0));
    return list;
  }, [data, openSort]);

  const s = data?.summary;
  const p = data?.previous;
  const closeRate = s && s.reported > 0 ? Math.round((s.closed / s.reported) * 100) : null;

  return (
    <div className="p-4 sm:p-6 space-y-5 text-gray-900 dark:text-gray-100">
      <div>
        <h1 className="text-[20px] text-gray-900 dark:text-white flex items-center gap-2" style={{ fontWeight: 700 }}>
          <LifeBuoy className="w-5 h-5" style={{ color: REPORTED }} /> Production support
        </h1>
        <p className={`text-[13px] ${muted} mt-0.5`}>
          {pick('Production defects from Jira', 'Defekty produkcyjne z Jiry')} · {selectedTeamName} · {dateRangeLabel}
        </p>
      </div>

      {loading ? (
        <div className="min-h-[320px] flex items-center justify-center"><LoadingSpinner size={22} /></div>
      ) : failed || !data || !s || !p ? (
        <div className={`${card} min-h-[160px] flex items-center justify-center text-[13px] ${muted}`}>
          {pick('Could not load production support data.', 'Nie udało się pobrać danych production support.')}
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
            <Kpi
              icon={AlertTriangle} color={REPORTED}
              label={pick('Open now', 'Otwarte teraz')}
              value={String(s.open)}
              sub={s.openOver30Days > 0
                ? <span style={{ color: AGE_COLORS[2] }}>{s.openOver30Days} {pick('older than 30 days', 'starszych niż 30 dni')}</span>
                : pick('none older than 30 days', 'żadne nie starsze niż 30 dni')}
            />
            <Kpi
              icon={Inbox} color="#f97316"
              label={pick('Reported in period', 'Zgłoszone w okresie')}
              value={String(s.reported)}
              sub={`${pick('previous period', 'poprzedni okres')}: ${p.reported}`}
              delta={<Delta now={s.reported} prev={p.reported} lessBetter />}
            />
            <Kpi
              icon={CheckCircle2} color={CLOSED}
              label={pick('Closed in period', 'Zamknięte w okresie')}
              value={String(s.closed)}
              sub={<>
                {closeRate != null ? `${closeRate}% ${pick('of reported', 'zgłoszonych')}` : pick('nothing reported', 'brak zgłoszeń')}
                {s.rejected > 0 ? ` · ${s.rejected} ${pick('rejected', 'odrzuconych')}` : ''}
              </>}
              delta={<Delta now={s.closed} prev={p.closed} lessBetter={false} />}
            />
            <Kpi
              icon={Clock} color="#2563eb"
              label={pick('Avg time to close', 'Średni czas zamknięcia')}
              value={fmtDuration(s.avgDaysToClose, pick)}
              sub={`${pick('median', 'mediana')} ${fmtDuration(s.medianDaysToClose, pick)} · 85% ${pick('within', 'w')} ${fmtDuration(s.p85DaysToClose, pick)}`}
              delta={<Delta now={s.avgDaysToClose} prev={p.avgDaysToClose} lessBetter />}
            />
            <Kpi
              icon={PlayCircle} color="#8b5cf6"
              label={pick('Avg time to pick up', 'Średni czas do podjęcia')}
              value={fmtDuration(s.avgDaysToStart, pick)}
              sub={pick('reported → first In Progress', 'zgłoszenie → pierwsze In Progress')}
              delta={<Delta now={s.avgDaysToStart} prev={p.avgDaysToStart} lessBetter />}
            />
          </div>

          <div className={card}>
            <h3 className="text-[14px]" style={{ fontWeight: 600 }}>{pick('Reported vs closed per week', 'Zgłoszone vs zamknięte tygodniowo')}</h3>
            <p className={`text-[12px] ${muted} mb-2`}>{pick('Line: defects open at the end of the week', 'Linia: defekty otwarte na koniec tygodnia')}</p>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={weeks}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
                  <XAxis dataKey="label" tick={{ fontSize: 11 }} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 11 }} width={30} />
                  <Tooltip />
                  <Legend wrapperStyle={{ fontSize: 12 }} />
                  <Bar dataKey="reported" name={pick('Reported', 'Zgłoszone')} fill={REPORTED} radius={[3, 3, 0, 0]} isAnimationActive={false} />
                  <Bar dataKey="closed" name={pick('Closed', 'Zamknięte')} fill={CLOSED} radius={[3, 3, 0, 0]} isAnimationActive={false} />
                  <Line dataKey="open" name={pick('Open', 'Otwarte')} stroke={OPEN_LINE} strokeWidth={2} dot={{ r: 3 }} isAnimationActive={false} />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className={card}>
              <h3 className="text-[14px]" style={{ fontWeight: 600 }}>{pick('Age of open defects', 'Wiek otwartych defektów')}</h3>
              <p className={`text-[12px] ${muted} mb-2`}>{pick('Days since reported', 'Dni od zgłoszenia')}</p>
              <div className="h-48">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={aging} barCategoryGap={18}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
                    <XAxis dataKey="label" tick={{ fontSize: 11 }} />
                    <YAxis allowDecimals={false} tick={{ fontSize: 11 }} width={30} />
                    <Tooltip formatter={(v: number) => [v, pick('defects', 'defektów')]} />
                    <Bar dataKey="count" radius={[4, 4, 0, 0]} isAnimationActive={false}>
                      {aging.map((b) => <Cell key={b.label} fill={b.color} />)}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className={card}>
              <h3 className="text-[14px]" style={{ fontWeight: 600 }}>{pick('By priority', 'Wg priorytetu')}</h3>
              <p className={`text-[12px] ${muted} mb-2`}>{pick('Open now, closed in the period and their time to close', 'Otwarte teraz, zamknięte w okresie i ich czas zamknięcia')}</p>
              {data.byPriority.length === 0 ? (
                <div className={`text-[12px] ${muted}`}>{pick('No production defects.', 'Brak defektów produkcyjnych.')}</div>
              ) : (
                <table className="w-full text-[12px]">
                  <thead>
                    <tr className={`text-left ${muted}`}>
                      <th className="py-1.5 font-normal">{pick('Priority', 'Priorytet')}</th>
                      <th className="py-1.5 font-normal text-right">{pick('Open', 'Otwarte')}</th>
                      <th className="py-1.5 font-normal text-right">{pick('Closed', 'Zamknięte')}</th>
                      <th className="py-1.5 font-normal text-right">{pick('Avg time to close', 'Śr. czas zamknięcia')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.byPriority.map((r) => (
                      <tr key={r.priority} className="border-t border-gray-100 dark:border-white/5">
                        <td className="py-1.5" style={{ fontWeight: 600 }}>{r.priority}</td>
                        <td className="py-1.5 text-right tabular-nums" style={{ color: r.open > 0 ? REPORTED : undefined }}>{r.open}</td>
                        <td className="py-1.5 text-right tabular-nums" style={{ color: r.closed > 0 ? CLOSED : undefined }}>{r.closed}</td>
                        <td className="py-1.5 text-right tabular-nums">{fmtDuration(r.avgDaysToClose, pick)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>

          <div className={card}>
            <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
              <h3 className="text-[14px]" style={{ fontWeight: 600 }}>{pick('Open production defects', 'Otwarte defekty produkcyjne')} ({openDefects.length})</h3>
              <div className="flex gap-1 text-[11px]">
                {(['age', 'status'] as const).map((k) => (
                  <button
                    key={k}
                    onClick={() => setOpenSort(k)}
                    className={`px-2 py-1 rounded border text-[11px] ${openSort === k ? 'text-white' : 'bg-white dark:bg-transparent text-gray-600 dark:text-gray-300 border-gray-200 dark:border-white/10'}`}
                    style={openSort === k ? { backgroundColor: '#1f2937', borderColor: '#1f2937' } : undefined}
                  >
                    {k === 'age' ? pick('Oldest first', 'Najstarsze') : pick('By status', 'Wg statusu')}
                  </button>
                ))}
              </div>
            </div>
            {openDefects.length === 0 ? (
              <div className={`text-[12px] ${muted}`}>{pick('No open production defects 🎉', 'Brak otwartych defektów produkcyjnych 🎉')}</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-[12px] min-w-[760px]">
                  <thead>
                    <tr className={`text-left ${muted}`}>
                      <th className="py-1.5 font-normal">{pick('Defect', 'Defekt')}</th>
                      <th className="py-1.5 font-normal">Status</th>
                      <th className="py-1.5 font-normal">{pick('Priority', 'Priorytet')}</th>
                      <th className="py-1.5 font-normal">{pick('Assignee', 'Osoba')}</th>
                      <th className="py-1.5 font-normal">{pick('Reported', 'Zgłoszony')}</th>
                      <th className="py-1.5 font-normal text-right">{pick('Age', 'Wiek')}</th>
                      <th className="py-1.5 font-normal text-right">{pick('In status', 'W statusie')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {openDefects.map((d) => (
                      <tr key={d.key} className="border-t border-gray-100 dark:border-white/5">
                        <td className="py-1.5 max-w-[340px]">
                          {d.url ? <a href={d.url} target="_blank" rel="noreferrer" className="text-blue-600 hover:underline" style={{ fontWeight: 600 }}>{d.key}</a> : <span style={{ fontWeight: 600 }}>{d.key}</span>}
                          <span className={`${muted} ml-1.5 truncate inline-block max-w-[250px] align-bottom`}>{d.summary}</span>
                        </td>
                        <td className="py-1.5">{d.status ?? '—'}</td>
                        <td className="py-1.5">{d.priority ?? '—'}</td>
                        <td className="py-1.5">{d.assignee ?? <span style={{ color: REPORTED }}>{pick('unassigned', 'nieprzypisany')}</span>}</td>
                        <td className="py-1.5">{fmtDate(d.reported)}</td>
                        <td className="py-1.5 text-right tabular-nums" style={{ color: ageColor(d.ageDays), fontWeight: 600 }}>{fmtDuration(d.ageDays, pick)}</td>
                        <td className="py-1.5 text-right tabular-nums">{fmtDuration(d.daysInStatus, pick)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          <div className={card}>
            <h3 className="text-[14px] mb-2" style={{ fontWeight: 600 }}>{pick('Recently closed', 'Ostatnio zamknięte')}</h3>
            {data.recentlyClosed.length === 0 ? (
              <div className={`text-[12px] ${muted}`}>{pick('Nothing closed in this period.', 'Nic nie zamknięto w tym okresie.')}</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-[12px] min-w-[700px]">
                  <thead>
                    <tr className={`text-left ${muted}`}>
                      <th className="py-1.5 font-normal">{pick('Defect', 'Defekt')}</th>
                      <th className="py-1.5 font-normal">Status</th>
                      <th className="py-1.5 font-normal">{pick('Priority', 'Priorytet')}</th>
                      <th className="py-1.5 font-normal">{pick('Assignee', 'Osoba')}</th>
                      <th className="py-1.5 font-normal">{pick('Closed', 'Zamknięty')}</th>
                      <th className="py-1.5 font-normal text-right">{pick('Time to close', 'Czas zamknięcia')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.recentlyClosed.map((d) => (
                      <tr key={d.key} className="border-t border-gray-100 dark:border-white/5">
                        <td className="py-1.5 max-w-[340px]">
                          {d.url ? <a href={d.url} target="_blank" rel="noreferrer" className="text-blue-600 hover:underline" style={{ fontWeight: 600 }}>{d.key}</a> : <span style={{ fontWeight: 600 }}>{d.key}</span>}
                          <span className={`${muted} ml-1.5 truncate inline-block max-w-[250px] align-bottom`}>{d.summary}</span>
                        </td>
                        <td className="py-1.5">{d.status ?? '—'}</td>
                        <td className="py-1.5">{d.priority ?? '—'}</td>
                        <td className="py-1.5">{d.assignee ?? '—'}</td>
                        <td className="py-1.5">{fmtDate(d.closed)}</td>
                        <td className="py-1.5 text-right tabular-nums" style={{ fontWeight: 600 }}>{fmtDuration(d.daysToClose, pick)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          <p className={`text-[11px] ${muted}`}>
            {pick(
              'Production defects: Jira issue types Production defect, Production bug, Incident. Closed = Live / Done / Completed / Closed / Resolved (Cancelled / Rejected count as rejected and are left out of time to close).',
              'Defekty produkcyjne: typy zgłoszeń w Jira Production defect, Production bug, Incident. Zamknięty = Live / Done / Completed / Closed / Resolved (Cancelled / Rejected liczone jako odrzucone i pomijane w czasie zamknięcia).',
            )}
          </p>
        </>
      )}
    </div>
  );
}
