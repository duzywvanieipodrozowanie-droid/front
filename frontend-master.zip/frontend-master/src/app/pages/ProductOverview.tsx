import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { CalendarCheck2, Clock, ExternalLink, LifeBuoy, PackageCheck, Rocket, ShieldCheck } from 'lucide-react';
import { useDateRange } from '../context/DateRangeContext';
import { useTeam } from '../context/TeamContext';
import { useLang, usePick } from '../i18n';
import LoadingSpinner from '../components/LoadingSpinner';
import { rangeDays, rangeLabel, toInterval } from '../utils/dateRange';

// Product overview for a product owner: summary data in business terms, without people, commits, merge requests or
// code quality metrics. Epics from core /api/product/epics (the Deliver data without assignees and work items),
// deployments and cycle time from /api/metrics/dora, the split of the work from /api/investment/total, production
// defects from /api/metrics/production-support and what waits for production from the service map
// (/api/codemap/modules: Jira keys between the last two environments). Without data the page shows a sample.

type Health = 'NOT_STARTED' | 'ON_TRACK' | 'AT_RISK' | 'OFF_TRACK' | 'DELIVERED' | 'DELIVERED_LATE';
type Epic = {
  key: string; summary?: string | null; url?: string | null; status?: string | null; plannedDelivery?: string | null;
  deliveryDate?: string | null; deliveryForecast: boolean; health: Health; delayDays?: number | null;
  items: number; itemsDone: number; progressPct: number;
};
type Metric = { value: number; change: number };
type SupportSummary = { open: number; openOver30Days: number; reported: number; closed: number; medianDaysToClose?: number | null };
type Support = { summary: SupportSummary; previous?: SupportSummary | null; byPriority?: Array<{ priority: string; open: number }> };
type CodeMapModule = { projectId: string; module: string; envs: Array<{ name: string; tag?: string | null; diff?: { issues?: string[] | null } | null }> };
type Waiting = { project: string; env: string; issues: string[]; services: number };

type Data = {
  epics: Epic[] | null;
  deployments: Metric | null;
  cycleHours: Metric | null;
  investment: { feature: number; bau: number } | null;
  support: Support | null;
  waiting: Waiting[] | null;
};

// Explicit hex colors: theme.css remaps Tailwind indigo/green classes to the brand palette.
const C = { feature: '#3b82f6', bau: '#14b8a6', good: '#10b981', warn: '#f59e0b', bad: '#ef4444', track: '#e5e7eb' };
const card = 'bg-white dark:bg-[#121317] rounded-xl border border-gray-200 dark:border-white/10';
const muted = 'text-gray-500 dark:text-gray-400';

async function getJson<T>(url: string, signal: AbortSignal): Promise<T | null> {
  try {
    const res = await fetch(url, { credentials: 'include', signal });
    return res.ok ? ((await res.json()) as T) : null;
  } catch {
    return null;
  }
}

const metric = (js: { value?: unknown; change?: unknown } | null): Metric | null =>
  js && typeof js.value === 'number' ? { value: js.value, change: typeof js.change === 'number' ? js.change : 0 } : null;

/** Jira keys that are on the environment before the last one and not yet on the last (production) one, per project. */
function waitingForProduction(modules: CodeMapModule[]): Waiting[] {
  const byProject = new Map<string, Waiting>();
  for (const m of modules) {
    if (!m.envs || m.envs.length < 2) continue;
    const before = m.envs[m.envs.length - 2];
    const issues = before.diff?.issues ?? [];
    if (before.tag === m.envs[m.envs.length - 1].tag || issues.length === 0) continue;
    const w = byProject.get(m.projectId) ?? { project: m.projectId, env: before.name, issues: [], services: 0 };
    w.services += 1;
    issues.forEach((it) => { if (!w.issues.includes(it)) w.issues.push(it); });
    byProject.set(m.projectId, w);
  }
  return [...byProject.values()];
}

const SAMPLE: Data = {
  epics: [
    { key: 'SHOP-120', summary: 'Nowy checkout z BLIK', status: 'In Progress', plannedDelivery: '2026-11-14', deliveryForecast: true, deliveryDate: '2026-11-21', health: 'AT_RISK', delayDays: 7, items: 18, itemsDone: 11, progressPct: 61 },
    { key: 'SHOP-131', summary: 'Program lojalnościowy – etap 1', status: 'In Progress', plannedDelivery: '2026-12-05', deliveryForecast: true, deliveryDate: '2026-11-28', health: 'ON_TRACK', items: 24, itemsDone: 9, progressPct: 38 },
    { key: 'SHOP-102', summary: 'Wyszukiwarka produktów 2.0', status: 'Done', plannedDelivery: '2026-10-10', deliveryForecast: false, deliveryDate: '2026-10-08', health: 'DELIVERED', items: 15, itemsDone: 15, progressPct: 100 },
    { key: 'SHOP-97', summary: 'Faktury PDF w panelu klienta', status: 'Done', plannedDelivery: '2026-09-30', deliveryForecast: false, deliveryDate: '2026-10-06', health: 'DELIVERED_LATE', delayDays: 6, items: 9, itemsDone: 9, progressPct: 100 },
    { key: 'SHOP-140', summary: 'Integracja z kurierem InPost', status: 'To Do', plannedDelivery: '2027-01-15', deliveryForecast: false, health: 'NOT_STARTED', items: 7, itemsDone: 0, progressPct: 0 },
  ],
  deployments: { value: 14, change: 16.7 },
  cycleHours: { value: 6.5 * 24, change: -12 },
  investment: { feature: 68, bau: 32 },
  support: {
    summary: { open: 4, openOver30Days: 1, reported: 6, closed: 7, medianDaysToClose: 2.5 },
    previous: { open: 5, openOver30Days: 1, reported: 8, closed: 6, medianDaysToClose: 3.1 },
    byPriority: [{ priority: 'High', open: 1 }, { priority: 'Medium', open: 2 }, { priority: 'Low', open: 1 }],
  },
  waiting: [{ project: 'shop', env: 'test', issues: ['SHOP-118', 'SHOP-121', 'SHOP-125', 'SHOP-133'], services: 3 }],
};

function useProductData(unitId: string | null, interval: string) {
  const [data, setData] = useState<Data | null>(null);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    const controller = new AbortController();
    const { signal } = controller;
    const params = new URLSearchParams({ interval });
    if (unitId) params.set('unitId', unitId);
    const qs = params.toString();
    setLoading(true);
    Promise.all([
      getJson<{ epics?: Epic[] }>(`/api/product/epics?${qs}`, signal),
      getJson<{ value?: unknown; change?: unknown }>(`/api/metrics/dora/deployment?${qs}`, signal),
      getJson<{ value?: unknown; change?: unknown }>(`/api/metrics/dora/inProgressToLive?${qs}`, signal),
      getJson<{ percent?: { bau?: number | null; feature?: number | null } }>(`/api/investment/total?${qs}`, signal),
      getJson<Support>(`/api/metrics/production-support?${qs}`, signal),
      getJson<CodeMapModule[]>('/api/codemap/modules', signal),
    ]).then(([epics, deployments, cycle, investment, support, modules]) => {
      if (signal.aborted) return;
      const percent = investment?.percent;
      setData({
        epics: Array.isArray(epics?.epics) ? epics!.epics! : null,
        deployments: metric(deployments),
        cycleHours: metric(cycle),
        investment: percent && (percent.bau != null || percent.feature != null) ? { bau: percent.bau ?? 0, feature: percent.feature ?? 0 } : null,
        support: support?.summary ? support : null,
        waiting: Array.isArray(modules) ? waitingForProduction(modules) : null,
      });
      setLoading(false);
    });
    return () => controller.abort();
  }, [unitId, interval]);
  return { data, loading };
}

type Stability = 'STABLE' | 'WATCH' | 'PROBLEMS';

/** One word instead of failure rates: production defects reported now vs the previous period and the old open ones. */
function stabilityOf(support: Support | null): Stability | null {
  if (!support) return null;
  const now = support.summary;
  const before = support.previous?.reported ?? now.reported;
  if (now.openOver30Days > 3 || now.reported > Math.max(2, before * 1.5)) return 'PROBLEMS';
  if (now.reported > before || now.openOver30Days > 0) return 'WATCH';
  return 'STABLE';
}

function Trend({ change, lessBetter = false }: { change: number; lessBetter?: boolean }) {
  if (!change) return null;
  const good = lessBetter ? change < 0 : change > 0;
  return (
    <span className="text-[11.5px]" style={{ color: good ? C.good : C.bad, fontWeight: 600 }}>
      {change > 0 ? '↑' : '↓'} {Math.abs(Math.round(change))}%
    </span>
  );
}

function Tile({ icon: Icon, label, value, hint, children }: { icon: typeof Rocket; label: string; value: string; hint?: string; children?: ReactNode }) {
  return (
    <div className={`${card} p-4`}>
      <div className={`flex items-center gap-2 text-[12px] ${muted}`}><Icon className="w-4 h-4" />{label}</div>
      <div className="mt-2 flex items-baseline gap-2">
        <span className="text-[26px] text-gray-900 dark:text-white" style={{ fontWeight: 700 }}>{value}</span>
        {children}
      </div>
      {hint && <div className={`mt-1 text-[11.5px] ${muted}`}>{hint}</div>}
    </div>
  );
}

function HealthBadge({ epic }: { epic: Epic }) {
  const pick = usePick();
  const d = epic.delayDays ?? 0;
  const map: Record<Health, [string, string]> = {
    OFF_TRACK: [`${pick('Off track', 'Poza planem')}${d ? ` · +${d} ${pick('d', 'dni')}` : ''}`, 'bg-red-100 text-red-800 border-red-300'],
    AT_RISK: [`${pick('At risk', 'Zagrożony')}${d ? ` · +${d} ${pick('d', 'dni')}` : ''}`, 'bg-orange-50 text-orange-700 border-orange-200'],
    ON_TRACK: [pick('On track', 'Zgodnie z planem'), 'bg-emerald-50 text-emerald-700 border-emerald-200'],
    NOT_STARTED: [pick('Not started', 'Nierozpoczęty'), 'bg-gray-100 text-gray-600 border-gray-200'],
    DELIVERED: [pick('Delivered', 'Dostarczony'), 'bg-emerald-50 text-emerald-800 border-emerald-300'],
    DELIVERED_LATE: [`${pick('Late', 'Z opóźnieniem')}${d ? ` · +${d} ${pick('d', 'dni')}` : ''}`, 'bg-amber-50 text-amber-800 border-amber-200'],
  };
  const [label, cls] = map[epic.health];
  return <span className={`inline-block px-2 py-0.5 rounded-full border text-[11px] whitespace-nowrap ${cls}`} style={{ fontWeight: 700 }}>{label}</span>;
}

export function ProductOverview() {
  const pick = usePick();
  const { lang } = useLang();
  const { dateRange } = useDateRange();
  const { selectedUnitId, selectedTeamName } = useTeam();
  const interval = useMemo(() => toInterval(dateRange, 'MONTHS_1'), [dateRange]);
  const { data: live, loading } = useProductData(selectedUnitId ?? null, interval);

  // no live data at all (core without these endpoints or no unit): the layout with sample values
  const sample = !!live && !live.epics && !live.deployments && !live.support && !live.investment;
  const data = sample ? SAMPLE : live;
  const locale = lang === 'pl' ? 'pl-PL' : 'en-GB';
  const fmtDate = (iso?: string | null) => (iso ? new Date(`${iso.slice(0, 10)}T00:00:00`).toLocaleDateString(locale, { day: 'numeric', month: 'short' }) : '—');

  const epics = data?.epics ?? [];
  const periodStart = useMemo(() => new Date(Date.now() - rangeDays(dateRange) * 86_400_000).toISOString().slice(0, 10), [dateRange]);
  const delivered = epics.filter((e) => (e.health === 'DELIVERED' || e.health === 'DELIVERED_LATE') && (sample || (e.deliveryDate ?? '') >= periodStart));
  const onTime = delivered.filter((e) => e.health === 'DELIVERED').length;
  const open = epics.filter((e) => e.health !== 'DELIVERED' && e.health !== 'DELIVERED_LATE');
  const atRisk = open.filter((e) => e.health === 'AT_RISK' || e.health === 'OFF_TRACK').length;
  const stability = stabilityOf(data?.support ?? null);
  const stabilityView: Record<Stability, [string, string, string]> = {
    STABLE: [pick('Stable', 'Stabilnie'), C.good, pick('fewer or as many production issues as before', 'tyle samo lub mniej problemów na produkcji niż wcześniej')],
    WATCH: [pick('Watch', 'Uwaga'), C.warn, pick('more new production issues than before or an issue open over 30 days', 'więcej nowych zgłoszeń niż wcześniej albo zgłoszenie otwarte ponad 30 dni')],
    PROBLEMS: [pick('Problems', 'Problemy'), C.bad, pick('clearly more production issues or long open ones', 'wyraźnie więcej problemów albo długo otwarte zgłoszenia')],
  };
  const cycleDays = data?.cycleHours ? data.cycleHours.value / 24 : null;
  const support = data?.support ?? null;
  const waiting = data?.waiting ?? [];
  const waitingIssues = waiting.reduce((n, w) => n + w.issues.length, 0);

  return (
    <div className="p-4 sm:p-6 space-y-5 text-gray-900 dark:text-gray-100">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-[22px] text-gray-900 dark:text-white" style={{ fontWeight: 700 }}>{pick('Product overview', 'Przegląd produktu')}</h1>
          <p className={`text-[13px] ${muted}`}>
            {selectedTeamName || pick('All units', 'Wszystkie unity')} · {rangeLabel(dateRange, lang === 'pl' ? 'pl' : 'en')}
          </p>
        </div>
        {sample && (
          <span className="px-2.5 py-1 rounded-full text-[11.5px] bg-amber-50 text-amber-800 border border-amber-200" style={{ fontWeight: 600 }}>
            {pick('Sample data – no data of the unit yet', 'Dane przykładowe – brak jeszcze danych unitu')}
          </span>
        )}
      </div>

      {loading && !data ? <LoadingSpinner /> : (
        <>
          {/* 1. headline tiles */}
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3">
            <Tile icon={CalendarCheck2} label={pick('Delivered initiatives', 'Dostarczone inicjatywy')} value={String(delivered.length)}
              hint={delivered.length ? pick(`${onTime} of ${delivered.length} on time`, `${onTime} z ${delivered.length} na czas`) : pick('none in the period', 'brak w okresie')} />
            <Tile icon={Clock} label={pick('Time to deliver a task', 'Czas dostarczenia zadania')}
              value={cycleDays == null ? '—' : `${cycleDays.toFixed(cycleDays < 10 ? 1 : 0)} ${pick('d', 'dni')}`}
              hint={pick('from start of work to production', 'od rozpoczęcia pracy do produkcji')}>
              {data?.cycleHours && <Trend change={data.cycleHours.change} lessBetter />}
            </Tile>
            <Tile icon={Rocket} label={pick('Releases to production', 'Wydania na produkcję')} value={data?.deployments ? String(Math.round(data.deployments.value)) : '—'}
              hint={pick('vs the previous period', 'względem poprzedniego okresu')}>
              {data?.deployments && <Trend change={data.deployments.change} />}
            </Tile>
            <div className={`${card} p-4`}>
              <div className={`flex items-center gap-2 text-[12px] ${muted}`}><ShieldCheck className="w-4 h-4" />{pick('Production stability', 'Stabilność produkcji')}</div>
              {stability ? (
                <>
                  <div className="mt-2 flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full" style={{ backgroundColor: stabilityView[stability][1] }} />
                    <span className="text-[22px] text-gray-900 dark:text-white" style={{ fontWeight: 700 }}>{stabilityView[stability][0]}</span>
                  </div>
                  <div className={`mt-1 text-[11.5px] ${muted}`}>{stabilityView[stability][2]}</div>
                </>
              ) : <div className="mt-2 text-[22px] text-gray-400">—</div>}
            </div>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
            {/* 2. epic progress */}
            <section className={`${card} p-5 xl:col-span-2`}>
              <div className="flex items-center justify-between gap-2 mb-3">
                <h2 className="text-[15px] text-gray-900 dark:text-white" style={{ fontWeight: 700 }}>{pick('Initiatives', 'Inicjatywy')}</h2>
                <span className={`text-[12px] ${muted}`}>
                  {pick(`${open.length} in progress · ${atRisk} at risk`, `${open.length} w toku · ${atRisk} zagrożone`)}
                </span>
              </div>
              {epics.length === 0 ? (
                <p className={`text-[13px] ${muted}`}>{pick('No epics of the unit in Jira this year.', 'Brak epików unitu w Jirze w tym roku.')}</p>
              ) : (
                <div className="divide-y divide-gray-100 dark:divide-white/5">
                  {epics.map((e) => (
                    <div key={e.key} className="py-3 grid grid-cols-12 items-center gap-3">
                      <div className="col-span-12 md:col-span-4 min-w-0">
                        <div className="text-[13.5px] text-gray-900 dark:text-gray-100 truncate" style={{ fontWeight: 600 }}>{e.summary || e.key}</div>
                        <div className={`text-[11.5px] ${muted} flex items-center gap-1`}>
                          {e.url ? <a href={e.url} target="_blank" rel="noreferrer" className="hover:underline inline-flex items-center gap-0.5">{e.key}<ExternalLink className="w-3 h-3" /></a> : e.key}
                          {e.status && <span>· {e.status}</span>}
                        </div>
                      </div>
                      <div className="col-span-7 md:col-span-3 flex items-center gap-2">
                        <div className="flex-1 h-2 rounded-full overflow-hidden" style={{ backgroundColor: C.track }}>
                          <div className="h-full rounded-full" style={{ width: `${e.progressPct}%`, backgroundColor: e.health === 'AT_RISK' || e.health === 'OFF_TRACK' ? C.warn : C.good }} />
                        </div>
                        <span className={`text-[11.5px] ${muted} w-9 text-right`}>{e.progressPct}%</span>
                      </div>
                      <div className={`col-span-5 md:col-span-2 text-[11.5px] ${muted} leading-tight`}>
                        <div>{pick('Plan', 'Plan')}: <span className="text-gray-800 dark:text-gray-200">{fmtDate(e.plannedDelivery)}</span></div>
                        <div>{e.deliveryForecast || !e.deliveryDate ? pick('Forecast', 'Prognoza') : pick('Delivered', 'Dostarczono')}: <span className="text-gray-800 dark:text-gray-200">{fmtDate(e.deliveryDate)}</span></div>
                      </div>
                      <div className="col-span-12 md:col-span-3 md:text-right"><HealthBadge epic={e} /></div>
                    </div>
                  ))}
                </div>
              )}
            </section>

            <div className="space-y-4">
              {/* 3. where the work goes */}
              <section className={`${card} p-5`}>
                <h2 className="text-[15px] text-gray-900 dark:text-white mb-3" style={{ fontWeight: 700 }}>{pick('Where the work goes', 'Na co idzie praca')}</h2>
                {data?.investment ? (
                  <>
                    <div className="flex h-3 rounded-full overflow-hidden">
                      <div style={{ width: `${data.investment.feature}%`, backgroundColor: C.feature }} />
                      <div style={{ width: `${data.investment.bau}%`, backgroundColor: C.bau }} />
                    </div>
                    <div className="mt-3 space-y-1.5 text-[12.5px]">
                      <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: C.feature }} />{pick('New features (development)', 'Nowe funkcje (rozwój)')}<b className="ml-auto">{data.investment.feature}%</b></div>
                      <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: C.bau }} />{pick('Maintenance (BAU)', 'Utrzymanie (BAU)')}<b className="ml-auto">{data.investment.bau}%</b></div>
                    </div>
                  </>
                ) : <p className={`text-[13px] ${muted}`}>{pick('No data for the period.', 'Brak danych za okres.')}</p>}
              </section>

              {/* 4. waiting for production */}
              <section className={`${card} p-5`}>
                <div className="flex items-center gap-2 mb-3">
                  <PackageCheck className="w-4 h-4 text-gray-500" />
                  <h2 className="text-[15px] text-gray-900 dark:text-white" style={{ fontWeight: 700 }}>{pick('Waiting for production', 'Czeka na produkcję')}</h2>
                  <span className="ml-auto text-[12px] text-gray-900 dark:text-white" style={{ fontWeight: 700 }}>{waitingIssues}</span>
                </div>
                {waiting.length === 0 ? (
                  <p className={`text-[13px] ${muted}`}>{pick('Nothing waiting – production is up to date.', 'Nic nie czeka – produkcja jest aktualna.')}</p>
                ) : waiting.map((w) => (
                  <div key={w.project} className="mb-2 last:mb-0">
                    <div className={`text-[11.5px] ${muted} mb-1`}>{pick(`${w.project}: ready on ${w.env}`, `${w.project}: gotowe na ${w.env}`)}</div>
                    <div className="flex flex-wrap gap-1.5">
                      {w.issues.map((k) => (
                        <span key={k} className="px-2 py-0.5 rounded-md text-[11.5px] bg-blue-50 text-blue-800 border border-blue-100 dark:bg-blue-500/10 dark:text-blue-200 dark:border-blue-500/20" style={{ fontWeight: 600 }}>{k}</span>
                      ))}
                    </div>
                  </div>
                ))}
              </section>

              {/* 5. production support */}
              <section className={`${card} p-5`}>
                <div className="flex items-center gap-2 mb-3">
                  <LifeBuoy className="w-4 h-4 text-gray-500" />
                  <h2 className="text-[15px] text-gray-900 dark:text-white" style={{ fontWeight: 700 }}>{pick('Production issues', 'Zgłoszenia produkcyjne')}</h2>
                </div>
                {support ? (
                  <div className="grid grid-cols-3 gap-2 text-center">
                    <div><div className="text-[20px] text-gray-900 dark:text-white" style={{ fontWeight: 700 }}>{support.summary.open}</div><div className={`text-[11px] ${muted}`}>{pick('open', 'otwarte')}</div></div>
                    <div><div className="text-[20px] text-gray-900 dark:text-white" style={{ fontWeight: 700 }}>{support.summary.reported}</div><div className={`text-[11px] ${muted}`}>{pick('new in period', 'nowe w okresie')}</div></div>
                    <div><div className="text-[20px] text-gray-900 dark:text-white" style={{ fontWeight: 700 }}>{support.summary.medianDaysToClose != null ? `${Number(support.summary.medianDaysToClose).toFixed(1)} ${pick('d', 'dni')}` : '—'}</div><div className={`text-[11px] ${muted}`}>{pick('typical fix time', 'typowy czas naprawy')}</div></div>
                  </div>
                ) : <p className={`text-[13px] ${muted}`}>{pick('No data for the period.', 'Brak danych za okres.')}</p>}
              </section>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
