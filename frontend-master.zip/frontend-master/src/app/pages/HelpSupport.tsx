import React from 'react';
import { HelpCircle, Rocket, Clock, AlertTriangle, Wrench, ChevronLeft, ChevronRight } from 'lucide-react';
import { useTr, usePick } from '../i18n';

export function HelpSupport() {
  const t = useTr();
  const pick = usePick();
  const slides = React.useMemo(
    () => [
      {
        id: 'overview',
        title: pick('Overview dashboard','Pulpit przeglądowy'),
        points: [
          'What you see: a high-level snapshot of product health and delivery pace.',
          'Key values: summary KPIs, recent trends and alerts that may require action.',
          'When a metric goes up: faster feedback loops if deployments/throughput rise; be cautious if incidents rise too.',
          'When a metric goes down: slower delivery if deploys drop or queues grow; investigate blockers early.',
        ],
      },
      {
        id: 'dora',
        title: pick('DORA Metrics','Metryki DORA'),
        points: [
          'What you see: 4 core metrics — Deployment Frequency, Lead Time for Changes, Change Failure Rate, MTTR.',
          'Delivery speed: faster when Deployment Frequency goes up and Lead Time/MTTR/Failure Rate go down.',
          'Increase vs decrease: higher failure rate or MTTR slows safe delivery; lower lead time accelerates value flow.',
          'Tip: compare against Local Benchmark (Chapter/Tribe/Domain/Company) to set realistic targets.',
        ],
      },
      {
        id: 'investments',
        title: 'Investments (where time goes)',
        points: [
          'What you see: share of effort across features, bug fixes, tech debt, maintenance, docs per team.',
          'Delivery speed: sustained feature flow needs a healthy investment in quality and tech debt control.',
          'Increase vs decrease: rising tech-debt share can hurt speed later; balanced mix keeps flow predictable.',
          'Action: adjust quarterly allocation if bug-fix or incident work starts crowding out features.',
        ],
      },
      {
        id: 'team',
        title: 'Team view',
        points: [
          'What you see: team-specific metrics and comparisons across the organization.',
          'Delivery speed: spot bottlenecks (queues, long reviews) that stretch lead time.',
          'Increase vs decrease: shorter review/queue times speed up flow; rising WIP indicates risk of slowdown.',
          'Action: use working agreements (small PRs, stricter WIP limits) to restore flow.',
        ],
      },
      {
        id: 'help',
        title: 'Help & Support',
        points: [
          'What you see: how to report issues, roadmap highlights, and this guided tutorial.',
          'Delivery speed: faster resolutions when incidents are reported with steps, context and screenshots.',
          'Increase vs decrease: more actionable reports = lower MTTR over time.',
          'Action: contact support.',
        ],
      },
    ],
    []
  );

  const [index, setIndex] = React.useState(0);
  const max = slides.length - 1;
  const go = (to: number) => setIndex(Math.max(0, Math.min(max, to)));
  const next = () => go(index + 1);
  const prev = () => go(index - 1);

  const onKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'ArrowRight') next();
    if (e.key === 'ArrowLeft') prev();
  };

  return (
    <div className="p-4 sm:p-6 space-y-4">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-[20px] text-gray-900" style={{ fontWeight: 700 }}>{t('helpSupport')}</h1>
          <p className="text-[13px] text-gray-500 mt-0.5">{pick('Find how to report an issue, what is planned next, and a step‑by‑step tutorial for reading our metrics.','Znajdziesz tu informacje jak zgłaszać problemy, co planujemy dalej oraz krótki poradnik czytania naszych metryk krok po kroku.')}</p>
        </div>
        <div className="hidden sm:flex items-center gap-2 px-2 py-1 rounded-md border border-gray-200 bg-white">
          <HelpCircle className="w-4 h-4 text-indigo-600" />
          <span className="text-[12px] text-gray-700" style={{ fontWeight: 600 }}>Support</span>
        </div>
      </div>

      {/* Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Issue reporting */}
        <div className="bg-white rounded-xl border border-gray-200 p-5 flex flex-col gap-3">
          <h2 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>How to report an issue</h2>
          <p className="text-[13px] text-gray-600">Please email us with details so we can help quickly.</p>
          <ol className="list-decimal pl-4 space-y-1 text-[13px] text-gray-700">
            <li>Briefly describe the problem and the expected behavior.</li>
            <li>Add reproduction steps and screenshots if possible.</li>
            <li>Include context (browser, date/time, team/scope).</li>
          </ol>
          <div className="text-[12px] text-gray-500 mt-1">Contact support through your standard internal channel.</div>
        </div>

        {/* Roadmap */}
        <div className="bg-white rounded-xl border border-gray-200 p-5 flex flex-col gap-3">
          <h2 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>What’s planned (roadmap)</h2>
          <ul className="space-y-2 text-[13px] text-gray-700">
            <li className="flex items-start gap-2"><span className="mt-0.5 text-indigo-400">→</span> New data source integrations (Jira, GitLab, SonarQube).</li>
            <li className="flex items-start gap-2"><span className="mt-0.5 text-indigo-400">→</span> Custom team benchmarks and goals.</li>
            <li className="flex items-start gap-2"><span className="mt-0.5 text-indigo-400">→</span> Improved report export (PDF/CSV) and scheduling.</li>
            <li className="flex items-start gap-2"><span className="mt-0.5 text-indigo-400">→</span> Cross-team trend views and correlation analysis.</li>
          </ul>
          <div className="text-[12px] text-gray-500">Have an idea? Contact your local support channel.</div>
        </div>
      </div>


      {/* Tutorial with carousel (last row) */}
      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <div className="flex items-start gap-3 mb-2">
          <div>
            <h2 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>Tutorial: reading the metrics</h2>
            <p className="text-[13px] text-gray-600">A guide screen by screen — what you can read, key values, and what increases/decreases mean.</p>
          </div>
        </div>

        {/* Carousel */}
        <div
          className="relative select-none"
          role="region"
          aria-roledescription="carousel"
          aria-label="Help tutorial carousel"
          tabIndex={0}
          onKeyDown={onKeyDown}
        >
          {/* Slide */}
          <div className="p-4 rounded-lg bg-gray-50 border border-gray-100 min-h-[160px]">
            <div className="text-[13px] text-gray-900 mb-1" style={{ fontWeight: 700 }}>{slides[index].title}</div>
            <ul className="list-disc pl-5 space-y-1 text-[12px] text-gray-700">
              {slides[index].points.map((p, i) => (
                <li key={i}>{p}</li>
              ))}
            </ul>

            {/* Extra visuals for DORA metrics */}
            {slides[index].id === 'dora' && (
              <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {/* Deployment Frequency */}
                <div className="p-3 rounded-lg border border-indigo-100 bg-indigo-50/50">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-6 h-6 rounded-md bg-indigo-500 flex items-center justify-center">
                      <Rocket className="w-3.5 h-3.5 text-white" />
                    </div>
                    <div className="text-[12px] text-gray-800" style={{ fontWeight: 700 }}>Deploys</div>
                  </div>
                  <div className="h-2 w-full bg-white rounded-full border border-indigo-100 overflow-hidden">
                    <div className="h-full bg-indigo-500" style={{ width: '70%' }} />
                  </div>
                  <div className="mt-1 text-[11px] text-indigo-700">Up is better</div>
                </div>

                {/* Lead Time */}
                <div className="p-3 rounded-lg border border-violet-100 bg-violet-50/50">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-6 h-6 rounded-md bg-violet-500 flex items-center justify-center">
                      <Clock className="w-3.5 h-3.5 text-white" />
                    </div>
                    <div className="text-[12px] text-gray-800" style={{ fontWeight: 700 }}>Lead Time</div>
                  </div>
                  <div className="h-2 w-full bg-white rounded-full border border-violet-100 overflow-hidden">
                    <div className="h-full bg-violet-500" style={{ width: '30%' }} />
                  </div>
                  <div className="mt-1 text-[11px] text-violet-700">Lower is better</div>
                </div>

                {/* Change Failure Rate */}
                <div className="p-3 rounded-lg border border-amber-100 bg-amber-50/50">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-6 h-6 rounded-md bg-amber-500 flex items-center justify-center">
                      <AlertTriangle className="w-3.5 h-3.5 text-white" />
                    </div>
                    <div className="text-[12px] text-gray-800" style={{ fontWeight: 700 }}>Failure Rate</div>
                  </div>
                  <div className="h-2 w-full bg-white rounded-full border border-amber-100 overflow-hidden">
                    <div className="h-full bg-amber-500" style={{ width: '10%' }} />
                  </div>
                  <div className="mt-1 text-[11px] text-amber-700">Lower is better</div>
                </div>

                {/* MTTR */}
                <div className="p-3 rounded-lg border border-emerald-100 bg-emerald-50/50">
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-6 h-6 rounded-md bg-emerald-500 flex items-center justify-center">
                      <Wrench className="w-3.5 h-3.5 text-white" />
                    </div>
                    <div className="text-[12px] text-gray-800" style={{ fontWeight: 700 }}>MTTR</div>
                  </div>
                  <div className="h-2 w-full bg-white rounded-full border border-emerald-100 overflow-hidden">
                    <div className="h-full bg-emerald-500" style={{ width: '25%' }} />
                  </div>
                  <div className="mt-1 text-[11px] text-emerald-700">Lower is better</div>
                </div>
              </div>
            )}
          </div>

          {/* Controls */}
          <div className="mt-3 flex items-center justify-between">
            <button
              onClick={prev}
              disabled={index === 0}
              className={`inline-flex items-center gap-1 px-2 py-1 rounded-md border text-[12px] transition-colors ${
                index === 0 ? 'bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed' : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'
              }`}
              aria-label="Previous slide"
            >
              <ChevronLeft className="w-3.5 h-3.5" /> Prev
            </button>
            <div className="flex items-center gap-1" aria-label="Slide indicators">
              {slides.map((_, i) => (
                <button
                  key={i}
                  onClick={() => go(i)}
                  aria-label={`Go to slide ${i + 1}`}
                  className={`w-2.5 h-2.5 rounded-full ${i === index ? 'bg-indigo-600' : 'bg-gray-300 hover:bg-gray-400'}`}
                />
              ))}
            </div>
            <button
              onClick={next}
              disabled={index === max}
              className={`inline-flex items-center gap-1 px-2 py-1 rounded-md border text-[12px] transition-colors ${
                index === max ? 'bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed' : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'
              }`}
              aria-label="Next slide"
            >
              Next <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="mt-2 text-[11px] text-gray-500">Tip: use Left/Right arrows to navigate.</div>
        </div>
      </div>
    </div>
  );
}

export default HelpSupport;
