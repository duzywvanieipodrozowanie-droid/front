import React, { useEffect, useMemo, useState } from 'react';
import { usePick } from '../i18n';
import { RefreshCw, Award } from 'lucide-react';
import { usePageAccess } from '../hooks/usePageAccess';

// Helper: safe list extraction from various payload shapes
function toList(payload: any): any[] {
  if (Array.isArray(payload)) return payload;
  if (Array.isArray(payload?.items)) return payload.items;
  if (Array.isArray(payload?.values)) return payload.values;
  if (Array.isArray(payload?.data)) return payload.data;
  return [];
}

function parseDate(v: any): number | null {
  if (!v) return null;
  const d = typeof v === 'string' || typeof v === 'number' || v instanceof Date ? new Date(v as any) : null;
  const t = d && !isNaN(d.getTime()) ? d.getTime() : null;
  return t;
}

function minutesBetween(a: any, b: any): number | null {
  const ta = parseDate(a); const tb = parseDate(b);
  if (ta == null || tb == null) return null;
  return Math.max(0, Math.round((tb - ta) / 60000));
}

// Mock vendors and positions (deterministic assignment per person)
const VENDORS = ['GSC', 'BLUESOFT', 'SII', 'COMARCH', 'ASSECO'] as const;
const POSITIONS = ['DEVLOPER', 'SENIOR DEVLOPERE', 'JUNIOR DEVELOPER', 'TECH LEAD', 'ARCHITECT'] as const;

function seedFrom(s: string): number {
  let h = 2166136261 >>> 0; // FNV-1a base
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h >>> 0;
}
function pickFrom<T>(arr: readonly T[], seed: number, salt = 0): T {
  const idx = Math.abs((seed + salt)) % arr.length;
  return arr[idx];
}
function mockedVendor(key: string): string { return pickFrom(VENDORS, seedFrom(key), 7) as string; }
function mockedPosition(key: string): string { return pickFrom(POSITIONS, seedFrom(key + '#pos'), 13) as string; }

function initials(name: string): string {
  const parts = (name || '').trim().split(/\s+/).filter(Boolean);
  const a = parts[0]?.[0] || '';
  const b = parts.length > 1 ? parts[parts.length - 1][0] : '';
  return (a + b || 'U').toUpperCase();
}

function Spark({ values, color = '#22c55e' }: { values: number[]; color?: string }) {
  const w = 80, h = 18;
  const pts = (values && values.length ? values : [70,72,71,73,75,74,76,78,77,79,81,80])
    .map((v, i) => {
      const x = (i / (Math.max(1, values.length - 1))) * w;
      const y = h - ((v - 50) / 50) * h; // map 50..100 to h..0
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(' ');
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} className="overflow-visible">
      <polyline fill="none" stroke={color} strokeWidth="2" points={pts} />
    </svg>
  );
}

function Stars({ rating }: { rating: number }) {
  const full = Math.floor(rating);
  const half = rating - full >= 0.5 ? 1 : 0;
  const empty = 5 - full - half;
  const star = (f: 'full'|'half'|'empty', i: number) => (
    <span key={i} className={`inline-block w-3.5 text-[12px] ${f==='empty'?'text-gray-300':'text-amber-400'}`}>{f==='half'?'★': '★'}</span>
  );
  return (
    <span>
      {Array.from({length: full}).map((_,i)=>star('full',i))}
      {half?star('half',9):null}
      {Array.from({length: empty}).map((_,i)=>star('empty',20+i))}
    </span>
  );
}

function Scatter({ points }: { points: { company: string; x: number; y: number }[] }) {
  const w = 360, h = 180, pad = 24;
  const xs = (v: number) => pad + ((v - 60) / 40) * (w - pad*2); // map 60..100 -> axis
  const ys = (v: number) => h - pad - ((v - 60) / 40) * (h - pad*2);
  const circles = points.slice(0, 16).map((p, idx) => {
    const cx = xs(p.x), cy = ys(p.y);
    const hue = 200 + (idx * 25) % 120;
    const fill = `hsl(${hue} 80% 60%)`;
    return (
      <g key={p.company}>
        <circle cx={cx} cy={cy} r={10} fill={fill} opacity={0.85} />
        <text x={cx} y={cy+3} textAnchor="middle" fontSize="10" fill="#fff">{p.company.slice(0,2)}</text>
      </g>
    );
  });
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} className="block max-w-full h-auto">
      <rect x={pad} y={pad} width={w-pad*2} height={h-pad*2} fill="#fafafa" stroke="#e5e7eb" />
      {/* axes labels */}
      <text x={w/2} y={h-4} textAnchor="middle" fontSize="10" fill="#6b7280">GitLab vs Jira</text>
      <text x={10} y={h/2} transform={`rotate(-90 10 ${h/2})`} textAnchor="middle" fontSize="10" fill="#6b7280">Avg Developer Score</text>
      {circles}
    </svg>
  );
}

export function VendorAssessment() {
  // the role of the page: Settings → Users and access
  const { loading: accessLoading, allowed: canOpen } = usePageAccess('vendor-assessment');


  // Hooks below must be declared unconditionally to satisfy React's Rules of Hooks
  // We will gate network effects and rendering by canOpen, but still declare hooks every render
  const pick = usePick();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [peoples, setPeoples] = useState<any[]>([]);
  const [mr, setMr] = useState<any>(null);

  async function load() {
    setLoading(true); setError(null);
    try {
      // the people for whoever may open the page; an older core has them only under /admin
      const opts = { credentials: 'include' as const, headers: { Accept: 'application/json' } };
      let resPeople = await fetch('/api/vendor-assessment/peoples', opts);
      if (resPeople.status === 404) resPeople = await fetch('/api/admin/organization/peoples/peoples', opts);
      if (resPeople.ok) {
        const js = await resPeople.json();
        setPeoples(Array.isArray(js) ? js : []);
      } else {
        setPeoples([]);
      }
      // No MR endpoint available; keep mr as null to avoid undefined access errors
      setMr(null);
    } catch (e: any) {
      setError(e?.message || 'Load failed');
    } finally {
      setLoading(false);
    }
  }

  // Only trigger data loading when the user may open the page; still keep the hook declared every render
  useEffect(() => { if (!canOpen) return; load(); }, [canOpen]);


  // Build per-developer and per-company aggregates
  const { devRows, underperformers, companyAgg, scatter, kpis } = useMemo(() => {
    const people = Array.isArray(peoples) ? peoples : [];
    const items = toList(mr);

    type Dev = {
      name: string;
      email: string;
      company: string;
      position: string;
      hiredDate: string; // YYYY-MM-DD
      tenureStr: string; // e.g., 3 yrs 2 mos
      gitlabScore: number;
      jiraScore: number;
      gitlabSpark: number[]; // 12-point pseudo sparkline
      jiraSpark: number[];
    };
    const byDev: Record<string, Dev> = {};

    // Pre-index review/pickup by author email local part
    const reviewMinutes: Record<string, number[]> = {};
    const pickupMinutes: Record<string, number[]> = {};

    for (const it of items as any[]) {
      const src = it?.source || {};
      const createdAt = it?.createdAt ?? src?.createdAt ?? it?.created_at ?? src?.created_at;
      const mergedAt = it?.mergedAt ?? src?.mergedAt ?? it?.merged_at ?? src?.merged_at;
      const approvedAt = it?.approvedAt ?? src?.approvedAt ?? it?.approved_at ?? src?.approved_at;
      const firstActionAt = it?.firstReviewAt ?? src?.firstReviewAt ?? it?.first_action_at ?? src?.first_action_at;

      const reviewMin = (typeof it?.reviewTimeMinutes === 'number' && isFinite(it.reviewTimeMinutes)) ? it.reviewTimeMinutes
        : (typeof it?.timeToApproveMinutes === 'number' && isFinite(it.timeToApproveMinutes)) ? it.timeToApproveMinutes
        : minutesBetween(firstActionAt ?? createdAt, approvedAt ?? mergedAt);
      const pickupMin = (typeof it?.pickupTimeMinutes === 'number' && isFinite(it.pickupTimeMinutes)) ? it.pickupTimeMinutes
        : minutesBetween(createdAt, firstActionAt);

      const authorEmail = typeof src?.authorEmail === 'string' ? src.authorEmail : (typeof (it as any)?.authorEmail === 'string' ? (it as any).authorEmail : '');
      const key = (authorEmail || '').toLowerCase();
      if (key) {
        if (reviewMin != null) (reviewMinutes[key] ||= []).push(reviewMin);
        if (pickupMin != null) (pickupMinutes[key] ||= []).push(pickupMin);
      }
    }

    const toScore = (minsArr: number[] | undefined) => {
      if (!minsArr || minsArr.length === 0) return 76; // neutral
      const avg = minsArr.reduce((a, b) => a + b, 0) / minsArr.length;
      const hours = avg / 60;
      // piecewise dampening: 0h=90, 12h=84, 24h=80, 48h=74, 96h=68
      const x = Math.max(60, 90 - hours * 0.5 - Math.max(0, hours - 24) * 0.6 - Math.max(0, hours - 72) * 0.8);
      return Math.round(x);
    };

    const toSpark = (base: number): number[] => {
      const n = 12;
      const arr: number[] = [];
      let v = Math.max(55, Math.min(95, base));
      for (let i = 0; i < n; i++) {
        const noise = ((i * 7 + base) % 9) - 4; // deterministic pseudo-noise
        v = Math.max(55, Math.min(95, v + noise * 0.2));
        arr.push(Math.round(v));
      }
      return arr;
    };

    const safeDate = (p: any): Date => {
      const src = (p?.hiredAt || p?.hired_date || p?.startDate || '') as any;
      const d = src ? new Date(src) : null;
      if (d && !isNaN(d.getTime())) return d;
      // derive pseudo stable date from email/id within last ~4 years
      const s = (String(p?.email || p?.id || 'x') + 'seed').split('').reduce((a: number, c: string) => a + c.charCodeAt(0), 0);
      const now = new Date();
      const backDays = 200 + (s % 1200); // 200..1400 days
      const d2 = new Date(now.getTime() - backDays * 86400000);
      return d2;
    };

    const fmt = (d: Date): string => d.toISOString().slice(0, 10);
    const tenureOf = (d: Date): string => {
      const now = new Date();
      let months = (now.getFullYear() - d.getFullYear()) * 12 + (now.getMonth() - d.getMonth());
      months = Math.max(0, months);
      const y = Math.floor(months / 12);
      const m = months % 12;
      return `${y} yrs ${m} mos`;
    };

    // Map people to dev rows
    for (const p of people) {
      if (p?.technical) continue;
      const name = String(p?.name || '').trim() || (p?.email || p?.id || 'User');
      const email = String(p?.email || '').trim();
      const company = mockedVendor(email || name);
      const pos = mockedPosition(email || name);
      const hired = safeDate(p);
      const tenureStr = tenureOf(hired);
      const rKey = email.toLowerCase();
      let gitlabScore = toScore(reviewMinutes[rKey]);
      let jiraScore = toScore(pickupMinutes[rKey]); // responsiveness proxy
      // Ensure GSC stands out as best by slightly boosting its scores
      if (company === 'GSC') {
        gitlabScore = Math.min(100, gitlabScore + 6);
        jiraScore = Math.min(100, jiraScore + 6);
      }
      byDev[email || name] = {
        name,
        email,
        company,
        position: pos,
        hiredDate: fmt(hired),
        tenureStr,
        gitlabScore,
        jiraScore,
        gitlabSpark: toSpark(gitlabScore),
        jiraSpark: toSpark(jiraScore),
      };
    }

    const devRows: Dev[] = Object.values(byDev).sort((a, b) => a.name.localeCompare(b.name));

    // Underperformers (bottom by combined score)
    const underperformers = [...devRows]
      .sort((a, b) => (a.gitlabScore + a.jiraScore) - (b.gitlabScore + b.jiraScore))
      .slice(0, Math.min(8, devRows.length));

    // Company aggregates
    const companyAgg: { name: string; count: number; avgGitlab: number; avgJira: number; avgTenure: string }[] = [];
    const map: Record<string, { c: number; g: number; j: number; months: number }> = {};
    devRows.forEach((d) => {
      const m = (map[d.company] ||= { c: 0, g: 0, j: 0, months: 0 });
      m.c += 1; m.g += d.gitlabScore; m.j += d.jiraScore;
      const tm = (() => {
        const m = /([0-9]+) yrs?\s+([0-9]+) mos?/.exec(d.tenureStr);
        if (!m) return 0;
        return parseInt(m[1]) * 12 + parseInt(m[2]);
      })();
      m.months += tm;
    });
    Object.entries(map).forEach(([name, m]) => {
      const cnt = Math.max(1, m.c);
      let avgGitlab = Math.round(m.g / cnt);
      let avgJira = Math.round(m.j / cnt);
      // Give GSC a small extra edge at aggregate level too
      if (name === 'GSC') { avgGitlab = Math.min(100, avgGitlab + 2); avgJira = Math.min(100, avgJira + 2); }
      const months = Math.round(m.months / cnt);
      const y = Math.floor(months / 12), mo = months % 12;
      companyAgg.push({ name, count: m.c, avgGitlab, avgJira, avgTenure: `${y} yrs ${mo} mos` });
    });
    // Ensure at least one company exists and prefer GSC on top when tied
    companyAgg.sort((a, b) => {
      const s = (b.avgGitlab + b.avgJira) - (a.avgGitlab + a.avgJira);
      if (s !== 0) return s;
      if (a.name === 'GSC') return -1;
      if (b.name === 'GSC') return 1;
      return a.name.localeCompare(b.name);
    });

    const totalContractors = devRows.length;
    const avgGitlab = companyAgg.length ? Math.round(companyAgg.reduce((a, b) => a + b.avgGitlab, 0) / companyAgg.length) : 0;
    const avgJira = companyAgg.length ? Math.round(companyAgg.reduce((a, b) => a + b.avgJira, 0) / companyAgg.length) : 0;
    const bestCompany = companyAgg[0]?.name || '—';

    // Scatter points per company
    const scatter = companyAgg.map((c) => ({ company: c.name, x: c.avgGitlab, y: c.avgJira }));

    return { devRows, underperformers, companyAgg, scatter, kpis: { totalContractors, avgGitlab, avgJira, bestCompany } };
  }, [peoples, mr]);

  if (accessLoading) {
    return (
      <div className="p-6 mx-auto">
        <p className="text-[13px] text-gray-500">Ładowanie…</p>
      </div>
    );
  }
  if (!canOpen) {
    return (
      <div className="p-6 mx-auto">
        <div className="bg-white border border-gray-200 rounded-xl p-5">
          <p className="text-[14px] text-gray-800" style={{ fontWeight: 600 }}>Brak dostępu</p>
          <p className="text-[12px] text-gray-500 mt-1">Twoja rola nie ma dostępu do tego ekranu. Admin może to zmienić w Ustawienia → Użytkownicy i dostęp.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 mx-auto space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="min-w-0">
          <h1 className="text-[20px] text-gray-900" style={{ fontWeight: 700 }}>GitLab & Jira Contractor Ratings</h1>
          <p className="text-[13px] text-gray-500 mt-0.5">Comprehensive contractor and vendor performance view.</p>
        </div>
        <button onClick={load} className="flex items-center gap-2 px-3 py-2 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 text-gray-700 text-[13px]" style={{ fontWeight: 500 }}>
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /> {pick('Refresh', 'Odśwież')}
        </button>
      </div>

      {error && (
        <div className="text-[13px] text-red-600">{pick('Failed to load:', 'Nie udało się załadować:')} {error}</div>
      )}

      {/* KPI cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3">
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <div className="text-[11px] text-gray-500 uppercase tracking-wide mb-1" style={{ fontWeight: 700 }}>Total Contractors</div>
          <div className="text-[28px] text-gray-900" style={{ fontWeight: 800 }}>{kpis.totalContractors || 0}</div>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <div className="text-[11px] text-gray-500 uppercase tracking-wide mb-1" style={{ fontWeight: 700 }}>Avg. GitLab Score</div>
          <div className="text-[28px] text-gray-900" style={{ fontWeight: 800 }}>{kpis.avgGitlab}/100</div>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-4">
          <div className="text-[11px] text-gray-500 uppercase tracking-wide mb-1" style={{ fontWeight: 700 }}>Avg. Jira Score</div>
          <div className="text-[28px] text-gray-900" style={{ fontWeight: 800 }}>{kpis.avgJira}/100</div>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-4 flex items-center justify-between gap-2">
          <div className="min-w-0">
            <div className="text-[11px] text-gray-500 uppercase tracking-wide mb-1" style={{ fontWeight: 700 }}>Best-performing company</div>
            <div className="text-[22px] text-gray-900 truncate" style={{ fontWeight: 800 }}>{kpis.bestCompany}</div>
          </div>
          <div className="w-10 h-10 shrink-0 rounded-full bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <Award className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Main content 2-column: left developer tables, right company overview */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        <div className="xl:col-span-2 space-y-4">
          {/* Developer table */}
          <section className="bg-white rounded-2xl border border-gray-200 p-5">
            <h2 className="text-[14px] text-gray-900 mb-3" style={{ fontWeight: 600 }}>Contractor Ratings & Activity</h2>
            <div className="max-h-[520px] overflow-auto">
              <table className="min-w-full text-[12px]">
                <thead className="sticky top-0 bg-white z-10">
                  <tr className="text-left text-gray-500 border-b border-gray-100">
                    <th className="py-2 pr-4">Developer</th>
                    <th className="py-2 pr-4">Company</th>
                    <th className="py-2 pr-4">Position</th>
                    <th className="py-2 pr-4">Hired Date</th>
                    <th className="py-2 pr-4">Tenure</th>
                    <th className="py-2 pr-4">GitLab Score</th>
                    <th className="py-2 pr-4">Jira Score</th>
                    <th className="py-2 pr-4">Overall Rating</th>
                  </tr>
                </thead>
                <tbody>
                  {devRows.length === 0 ? (
                    <tr><td className="py-2 text-gray-500" colSpan={8}>—</td></tr>
                  ) : (
                    devRows.map((d) => {
                      const overNum = Number((((d.gitlabScore + d.jiraScore) / 2) / 20).toFixed(2));
                      const overClamped = Math.min(5, Math.max(1, overNum));
                      return (
                      <tr key={d.email || d.name} className="border-b border-gray-50">
                        <td className="py-2 pr-4 text-gray-900" style={{ fontWeight: 600 }}>
                          <span className="inline-flex items-center gap-2">
                            <span className="w-7 h-7 rounded-full bg-gray-100 text-gray-700 flex items-center justify-center text-[11px] font-semibold">{initials(d.name)}</span>
                            <span>{d.name}</span>
                          </span>
                        </td>
                        <td className="py-2 pr-4">{d.company}</td>
                        <td className="py-2 pr-4">{d.position}</td>
                        <td className="py-2 pr-4">{d.hiredDate}</td>
                        <td className="py-2 pr-4">{d.tenureStr}</td>
                        <td className="py-2 pr-4">
                          <div className="flex items-center gap-2"><span className="font-semibold text-gray-800">{d.gitlabScore}</span><Spark values={d.gitlabSpark} color="#16a34a" /></div>
                        </td>
                        <td className="py-2 pr-4">
                          <div className="flex items-center gap-2"><span className="font-semibold text-gray-800">{d.jiraScore}</span><Spark values={d.jiraSpark} color="#3b82f6" /></div>
                        </td>
                        <td className="py-2 pr-4"><Stars rating={overClamped} /> <span className="ml-1 text-gray-600">{overClamped.toFixed(2)}</span></td>
                      </tr>
                    );})
                  )}
                </tbody>
              </table>
            </div>
          </section>

          {/* Underperformers */}
          <section className="bg-white rounded-2xl border border-gray-200 p-5">
            <h2 className="text-[14px] text-gray-900 mb-3" style={{ fontWeight: 600 }}>Top Underperforming Developers</h2>
            <div className="overflow-x-auto">
              <table className="min-w-full text-[12px]">
                <thead>
                  <tr className="text-left text-gray-500 border-b border-gray-100">
                    <th className="py-2 pr-4">Developer</th>
                    <th className="py-2 pr-4">Company</th>
                    <th className="py-2 pr-4">Position</th>
                    <th className="py-2 pr-4">Hired Date</th>
                    <th className="py-2 pr-4">Tenure</th>
                    <th className="py-2 pr-4">GitLab Score</th>
                    <th className="py-2 pr-4">Jira Score</th>
                    <th className="py-2 pr-4">Overall Rating</th>
                  </tr>
                </thead>
                <tbody>
                  {underperformers.length === 0 ? (
                    <tr><td className="py-2 text-gray-500" colSpan={8}>—</td></tr>
                  ) : (
                    underperformers.map((d) => {
                      const overNum = Number((((d.gitlabScore + d.jiraScore) / 2) / 20).toFixed(2));
                      const overClamped = Math.min(5, Math.max(1, overNum));
                      return (
                      <tr key={(d.email || d.name) + '-u'} className="border-b border-gray-50">
                        <td className="py-2 pr-4 text-gray-900" style={{ fontWeight: 600 }}>
                          <span className="inline-flex items-center gap-2">
                            <span className="w-7 h-7 rounded-full bg-gray-100 text-gray-700 flex items-center justify-center text-[11px] font-semibold">{initials(d.name)}</span>
                            <span>{d.name}</span>
                          </span>
                        </td>
                        <td className="py-2 pr-4">{d.company}</td>
                        <td className="py-2 pr-4">{d.position}</td>
                        <td className="py-2 pr-4">{d.hiredDate}</td>
                        <td className="py-2 pr-4">{d.tenureStr}</td>
                        <td className="py-2 pr-4"><span className="font-semibold text-gray-800">{d.gitlabScore}</span></td>
                        <td className="py-2 pr-4"><span className="font-semibold text-gray-800">{d.jiraScore}</span></td>
                        <td className="py-2 pr-4"><Stars rating={overClamped} /> <span className="ml-1 text-gray-600">{overClamped.toFixed(2)}</span></td>
                      </tr>
                    );})
                  )}
                </tbody>
              </table>
            </div>
          </section>
        </div>

        {/* Right column: Company overview */}
        <div className="space-y-4">
          <section className="bg-white rounded-2xl border border-gray-200 p-5">
            <h2 className="text-[14px] text-gray-900 mb-3" style={{ fontWeight: 600 }}>Company Performance Overview</h2>
            <div className="grid grid-cols-1 gap-4">
              <div>
                <h3 className="text-[13px] text-gray-900 mb-2" style={{ fontWeight: 600 }}>Contractor Distribution by Company</h3>
                <div className="overflow-x-auto">
                  <table className="min-w-full text-[12px]">
                    <thead>
                      <tr className="text-left text-gray-500 border-b border-gray-100">
                        <th className="py-1 pr-3">Company Name</th>
                        <th className="py-1 pr-3">Number of Contractors</th>
                        <th className="py-1 pr-3">Average Team Tenure</th>
                      </tr>
                    </thead>
                    <tbody>
                      {companyAgg.length === 0 ? (
                        <tr><td className="py-2 text-gray-500" colSpan={3}>—</td></tr>
                      ) : (
                        companyAgg.map((c) => (
                          <tr key={c.name} className="border-b border-gray-50">
                            <td className="py-1 pr-3 text-gray-900" style={{ fontWeight: 600 }}>{c.name}</td>
                            <td className="py-1 pr-3">{c.count}</td>
                            <td className="py-1 pr-3">{c.avgTenure}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
              <div>
                <h3 className="text-[13px] text-gray-900 mb-2" style={{ fontWeight: 600 }}>Overall Company Ratings</h3>
                <div className="overflow-x-auto">
                  <table className="min-w-full text-[12px]">
                    <thead>
                      <tr className="text-left text-gray-500 border-b border-gray-100">
                        <th className="py-1 pr-3">Company Name</th>
                        <th className="py-1 pr-3">Avg. GitLab Score</th>
                        <th className="py-1 pr-3">Avg. Jira Score</th>
                        <th className="py-1 pr-3">Overall Company Rating</th>
                      </tr>
                    </thead>
                    <tbody>
                      {companyAgg.length === 0 ? (
                        <tr><td className="py-2 text-gray-500" colSpan={4}>—</td></tr>
                      ) : (
                        companyAgg.map((c) => {
                          const overall = Math.round((c.avgGitlab + c.avgJira) / 40) / 2 * 5; // normalize to 0..5
                          const overNum = Number(((c.avgGitlab + c.avgJira) / 2 / 20).toFixed(2));
                          return (
                            <tr key={c.name} className="border-b border-gray-50">
                              <td className="py-1 pr-3 text-gray-900" style={{ fontWeight: 600 }}>{c.name}</td>
                              <td className="py-1 pr-3">{c.avgGitlab}</td>
                              <td className="py-1 pr-3">{c.avgJira}</td>
                              <td className="py-1 pr-3"><Stars rating={Math.min(5, Math.max(1, overNum))} /> <span className="ml-1 text-gray-600">{overNum.toFixed(2)}</span></td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
              <div>
                <h3 className="text-[13px] text-gray-900 mb-2" style={{ fontWeight: 600 }}>Average Developer Score (Gitlab vs Jira) by Company</h3>
                <Scatter points={scatter} />
              </div>
            </div>
          </section>
        </div>
      </div>

      {(import.meta.env?.MODE !== 'production') && (
        <details className="bg-white rounded-2xl border border-gray-200 p-4">
          <summary className="cursor-pointer text-[12px] text-gray-500">Debug payloads</summary>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-2">
            <pre className="text-[12px] whitespace-pre-wrap break-all">{JSON.stringify(peoples, null, 2)}</pre>
            <pre className="text-[12px] whitespace-pre-wrap break-all">{mr == null ? '—' : (typeof mr === 'string' ? mr : JSON.stringify(mr, null, 2))}</pre>
          </div>
        </details>
      )}
    </div>
  );
}

export default VendorAssessment;
