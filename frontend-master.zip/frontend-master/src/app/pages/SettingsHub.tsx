import { useEffect, useState } from 'react';
import { ThresholdsCTA } from '../components/settings/ThresholdsCTA';
import { IntegrationsGrid } from '../components/settings/IntegrationsGrid';
import { SetupOrgCTA } from '../components/settings/SetupOrgCTA';
import { AddProjectCTA } from '../components/settings/AddProjectCTA';
import { AddRepositoryCTA } from '../components/settings/AddRepositoryCTA';
import { UnknownCommitersCTA } from '../components/settings/UnknownCommitersCTA';
import { ProjectRefreshCTA } from '../components/settings/ProjectRefreshCTA';
import { CommitRefreshCTA } from '../components/settings/CommitRefreshCTA';
import { AiAgentCTA } from '../components/settings/AiAgentCTA';
import { UsersAccessCTA } from '../components/settings/UsersAccessCTA';
import { ProjectsEnvironmentsCTA } from '../components/settings/ProjectsEnvironmentsCTA';

export function Settings() {
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const res = await fetch('/api/user', { credentials: 'include' });
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const js = await res.json();
        const auths: string[] = Array.isArray(js?.authorities) ? js.authorities : [];
        const norm = (s: unknown) => String(s || '').toUpperCase();
        if (!cancelled) setIsAdmin(auths.map(norm).includes('ADMIN'));
      } catch {
        if (!cancelled) setIsAdmin(false);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, []);

  if (loading) {
    return (
      <div className="p-6 mx-auto">
        <p className="text-[13px] text-gray-500">Ładowanie…</p>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="p-6 mx-auto">
        <div className="bg-white border border-gray-200 rounded-xl p-5">
          <p className="text-[14px] text-gray-800" style={{ fontWeight: 600 }}>Brak dostępu</p>
          <p className="text-[12px] text-gray-500 mt-1">Ekran Ustawienia jest dostępny tylko dla użytkowników z rolą ADMIN.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 mx-auto space-y-4">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-[22px] text-gray-900" style={{ fontWeight: 800 }}>Settings</h1>
          <p className="text-[13px] text-gray-500 mt-1">Start with the setup below, then connect your tools. All changes are safe to try — you can adjust anytime.</p>
        </div>
      </div>

      {/* Getting started: actions in one row on large screens */}
      <section className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 items-stretch">
        <SetupOrgCTA />
        <ThresholdsCTA />
        <AddProjectCTA />
        <AddRepositoryCTA />
        <UnknownCommitersCTA />
        <ProjectRefreshCTA />
        <CommitRefreshCTA />
        <AiAgentCTA />
        <UsersAccessCTA />
        <ProjectsEnvironmentsCTA />
      </section>

      {/* Preferences placeholder to improve discoverability */}
      <section className="bg-white rounded-2xl border border-gray-200 p-5">
        <h2 className="text-[14px] text-gray-900 mb-1" style={{ fontWeight: 600 }}>Preferences</h2>
        <p className="text-[12px] text-gray-500">Organization-wide defaults (coming soon): notifications, time zone, working days.</p>
      </section>

      {/* Integrations section */}
      <IntegrationsGrid />
    </div>
  );
}

export default Settings;
