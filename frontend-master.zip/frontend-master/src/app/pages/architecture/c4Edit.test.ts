import { describe, expect, it } from 'vitest';
import { applyEdit, around, darker, emptyEdit, isEmptyEdit, normalizeEdit, removeNode, textOn, union } from './c4Edit';

type N = { id: string; name: string; tech?: string; description: string; kind: string };
type E = { from: string; to: string; label: string; tech?: string };
const nodes: N[] = [
  { id: 'a', name: 'order-service', description: 'orders', kind: 'container' },
  { id: 'b', name: 'payment-service', description: 'payments', kind: 'container' },
];
const edges: E[] = [{ from: 'a', to: 'b', label: 'Wywołuje API' }];
const toNode = (a: { id: string; kind: string; name: string; tech?: string; description?: string }): N =>
  ({ id: a.id, kind: a.kind, name: a.name, tech: a.tech, description: a.description ?? '' });
const toEdge = (a: { from: string; to: string; label: string; tech?: string }): E => ({ from: a.from, to: a.to, label: a.label, tech: a.tech });

describe('c4 edit', () => {
  it('lays texts, colours, added elements and arrows over the diagram', () => {
    const edit = {
      ...emptyEdit(),
      look: { a: { name: 'Zamówienia', fill: '#16a34a' } },
      nodes: [{ id: 'u1', kind: 'person', name: 'Klient' }],
      edges: [{ id: 'x1', from: 'u1', to: 'a', label: 'Składa zamówienie' }],
      edgeLabels: { 'a>b': 'Płaci' },
    };
    const shown = applyEdit(nodes, edges, edit, false, toNode, toEdge);
    expect(shown.nodes.map((n) => n.name)).toEqual(['Zamówienia', 'payment-service', 'Klient']);
    expect(shown.nodes[0].fill).toBe('#16a34a');
    expect(shown.nodes[2].added).toBe(true);
    expect(shown.edges.map((e) => `${e.key}:${e.label}`)).toEqual(['a>b:Płaci', 'x1:Składa zamówienie']);
  });

  it('leaves out hidden elements and their arrows, keeps them marked while editing', () => {
    const edit = { ...emptyEdit(), hidden: ['b'] };
    expect(applyEdit(nodes, edges, edit, false, toNode, toEdge)).toMatchObject({ nodes: [{ id: 'a' }], edges: [] });
    const editing = applyEdit(nodes, edges, edit, true, toNode, toEdge);
    expect(editing.nodes[1].hidden).toBe(true);
    expect(editing.edges).toHaveLength(1);
  });

  it('removes an added element with its arrows and hides a scanned one, both leave their groups', () => {
    const edit = {
      ...emptyEdit(),
      nodes: [{ id: 'u1', kind: 'person', name: 'Klient' }],
      edges: [{ id: 'x1', from: 'u1', to: 'a', label: '' }],
      groups: [{ id: 'g', name: 'G', color: '#2563eb', members: ['u1', 'a'] }],
    };
    const once = removeNode(edit, 'u1');
    expect(once.nodes).toEqual([]);
    expect(once.edges).toEqual([]);
    expect(once.hidden).toEqual([]);
    expect(once.groups[0].members).toEqual(['a']);
    const twice = removeNode(once, 'a');
    expect(twice.hidden).toEqual(['a']);
    expect(twice.groups).toEqual([]);
  });

  it('reads a broken edit from the server as far as it goes', () => {
    const edit = normalizeEdit({ pos: { a: { x: 10, y: 20 }, b: { x: 'no' } }, hidden: ['a', 3], groups: [{ id: 'g', members: ['a'] }, { name: 'x' }], look: 5 });
    expect(edit.pos).toEqual({ a: { x: 10, y: 20 } });
    expect(edit.hidden).toEqual(['a']);
    expect(edit.groups).toHaveLength(1);
    expect(isEmptyEdit(normalizeEdit(null))).toBe(true);
  });

  it('picks a readable text colour and a darker border', () => {
    expect(textOn('#08427b')).toBe('#fff');
    expect(textOn('#85bbf0')).toBe('#0b2540');
    expect(darker('#ffffff', 0.5)).toBe('#808080');
  });

  it('puts a frame around boxes', () => {
    expect(around([{ x: 100, y: 100 }, { x: 300, y: 200 }], 190, 92, 10, 20)).toEqual({ x: -5, y: 24, w: 410, h: 232 });
    expect(union([{ x: 0, y: 0, w: 10, h: 10 }, null, { x: -5, y: 5, w: 10, h: 20 }])).toEqual({ x: -5, y: 0, w: 15, h: 25 });
  });
});
