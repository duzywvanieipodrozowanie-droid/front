// Hand edits of an Architecture (C4) diagram, saved in core per project and diagram (/api/architecture/{p}/layout):
// positions of the boxes, colours and texts, hidden elements and arrows, groups, the elements and arrows added by
// the user. The scanned model stays as it is; the edit is laid over the automatic diagram.

export type Pos = { x: number; y: number };
export type Look = { fill?: string; name?: string; tech?: string; description?: string };
export type Group = { id: string; name: string; color: string; members: string[] };
export type AddedNode = { id: string; kind: string; name: string; tech?: string; description?: string };
export type AddedEdge = { id: string; from: string; to: string; label: string; tech?: string };
export type DiagramEdit = {
  pos: Record<string, Pos>;
  look: Record<string, Look>;
  // node ids and the keys of the automatic arrows ("from>to")
  hidden: string[];
  groups: Group[];
  nodes: AddedNode[];
  edges: AddedEdge[];
  // label of an automatic arrow by its key
  edgeLabels: Record<string, string>;
};

export const emptyEdit = (): DiagramEdit => ({ pos: {}, look: {}, hidden: [], groups: [], nodes: [], edges: [], edgeLabels: {} });

const isObject = (v: unknown): v is Record<string, unknown> => !!v && typeof v === 'object' && !Array.isArray(v);
const str = (v: unknown) => (typeof v === 'string' ? v : undefined);

/** An edit from the server, missing or broken parts dropped. */
export function normalizeEdit(raw: unknown): DiagramEdit {
  const edit = emptyEdit();
  if (!isObject(raw)) return edit;
  if (isObject(raw.pos)) {
    Object.entries(raw.pos).forEach(([id, p]) => {
      if (isObject(p) && Number.isFinite(p.x) && Number.isFinite(p.y)) edit.pos[id] = { x: p.x as number, y: p.y as number };
    });
  }
  if (isObject(raw.look)) {
    Object.entries(raw.look).forEach(([id, l]) => {
      if (!isObject(l)) return;
      const look: Look = { fill: str(l.fill), name: str(l.name), tech: str(l.tech), description: str(l.description) };
      Object.keys(look).forEach((k) => look[k as keyof Look] === undefined && delete look[k as keyof Look]);
      if (Object.keys(look).length) edit.look[id] = look;
    });
  }
  if (Array.isArray(raw.hidden)) edit.hidden = raw.hidden.filter((h): h is string => typeof h === 'string');
  if (Array.isArray(raw.groups)) {
    edit.groups = raw.groups.filter(isObject).filter((g) => str(g.id) && Array.isArray(g.members)).map((g) => ({
      id: g.id as string, name: str(g.name) ?? '', color: str(g.color) ?? GROUP_COLORS[0],
      members: (g.members as unknown[]).filter((m): m is string => typeof m === 'string'),
    }));
  }
  if (Array.isArray(raw.nodes)) {
    edit.nodes = raw.nodes.filter(isObject).filter((n) => str(n.id) && str(n.kind)).map((n) => ({
      id: n.id as string, kind: n.kind as string, name: str(n.name) ?? '', tech: str(n.tech), description: str(n.description),
    }));
  }
  if (Array.isArray(raw.edges)) {
    edit.edges = raw.edges.filter(isObject).filter((e) => str(e.id) && str(e.from) && str(e.to)).map((e) => ({
      id: e.id as string, from: e.from as string, to: e.to as string, label: str(e.label) ?? '', tech: str(e.tech),
    }));
  }
  if (isObject(raw.edgeLabels)) {
    Object.entries(raw.edgeLabels).forEach(([k, v]) => { if (typeof v === 'string') edit.edgeLabels[k] = v; });
  }
  return edit;
}

export const isEmptyEdit = (e: DiagramEdit) =>
  !Object.keys(e.pos).length && !Object.keys(e.look).length && !e.hidden.length && !e.groups.length
  && !e.nodes.length && !e.edges.length && !Object.keys(e.edgeLabels).length;

export const edgeKey = (e: { from: string; to: string }) => `${e.from}>${e.to}`;
export const newId = (prefix: string) => `${prefix}${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;

/** Removes a node added by the user with its arrows, or hides a scanned one; either way it leaves its groups. */
export function removeNode(edit: DiagramEdit, id: string): DiagramEdit {
  const added = edit.nodes.some((n) => n.id === id);
  return {
    ...edit,
    nodes: edit.nodes.filter((n) => n.id !== id),
    edges: added ? edit.edges.filter((e) => e.from !== id && e.to !== id) : edit.edges,
    hidden: added || edit.hidden.includes(id) ? edit.hidden : [...edit.hidden, id],
    groups: edit.groups.map((g) => ({ ...g, members: g.members.filter((m) => m !== id) })).filter((g) => g.members.length),
  };
}

type BaseNode = { id: string; name: string; tech?: string; description: string };
type BaseEdge = { from: string; to: string; label: string; tech?: string };
export type EditedNode<N> = N & { fill?: string; hidden?: boolean; added?: boolean };
export type EditedEdge<E> = E & { key: string; hidden?: boolean; added?: boolean };

/**
 * The automatic diagram with the edit laid over it: texts and colours, the added elements and arrows, hidden ones
 * left out (kept and marked when {@code keepHidden}, to show them faded while editing). An arrow to an element
 * that is not there is left out.
 */
export function applyEdit<N extends BaseNode, E extends BaseEdge>(
  nodes: N[], edges: E[], edit: DiagramEdit | null, keepHidden: boolean,
  toNode: (added: AddedNode) => N, toEdge: (added: AddedEdge) => E,
): { nodes: Array<EditedNode<N>>; edges: Array<EditedEdge<E>> } {
  if (!edit) return { nodes, edges: edges.map((e) => ({ ...e, key: edgeKey(e) })) };
  const hidden = new Set(edit.hidden);
  const styled = (n: N, added: boolean): EditedNode<N> => {
    const look = edit.look[n.id] ?? {};
    return {
      ...n, added: added || undefined, hidden: hidden.has(n.id) || undefined, fill: look.fill,
      name: look.name ?? n.name, tech: look.tech ?? n.tech, description: look.description ?? n.description,
    };
  };
  const all = [...nodes.map((n) => styled(n, false)), ...edit.nodes.map((a) => styled(toNode(a), true))]
    .filter((n) => keepHidden || !n.hidden);
  const ids = new Set(all.map((n) => n.id));
  const shownEdges: Array<EditedEdge<E>> = [
    ...edges.map((e) => {
      const key = edgeKey(e);
      return { ...e, key, label: edit.edgeLabels[key] ?? e.label, hidden: hidden.has(key) || undefined };
    }),
    ...edit.edges.map((a) => ({ ...toEdge(a), key: a.id, added: true })),
  ];
  return { nodes: all, edges: shownEdges.filter((e) => ids.has(e.from) && ids.has(e.to) && (keepHidden || !e.hidden)) };
}

// ---------- colours ----------

export const NODE_COLORS = ['#08427b', '#1168bd', '#438dd5', '#85bbf0', '#8a8f98', '#0f766e', '#16a34a', '#ca8a04', '#ea580c', '#dc2626', '#9333ea', '#db2777'];
export const GROUP_COLORS = ['#2563eb', '#16a34a', '#d97706', '#dc2626', '#9333ea', '#0891b2', '#6b7280'];

const rgb = (hex: string) => {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim());
  if (!m) return null;
  const n = parseInt(m[1], 16);
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
};

/** White or dark text, whichever reads better on the fill. */
export function textOn(fill: string): string {
  const c = rgb(fill);
  if (!c) return '#fff';
  const [r, g, b] = c.map((v) => { const s = v / 255; return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4; });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b > 0.4 ? '#0b2540' : '#fff';
}

/** The fill a bit darker, for the border. */
export function darker(fill: string, factor = 0.78): string {
  const c = rgb(fill);
  if (!c) return fill;
  return `#${c.map((v) => Math.round(v * factor).toString(16).padStart(2, '0')).join('')}`;
}

// ---------- geometry ----------

export type Rect = { x: number; y: number; w: number; h: number };

/** The rectangle around boxes of size w x h centred at the points, with a margin and room for a header on top. */
export function around(points: Pos[], w: number, h: number, margin: number, header = 0): Rect | null {
  if (!points.length) return null;
  const xs = points.map((p) => p.x);
  const ys = points.map((p) => p.y);
  const x = Math.min(...xs) - w / 2 - margin;
  const y = Math.min(...ys) - h / 2 - margin - header;
  return { x, y, w: Math.max(...xs) - Math.min(...xs) + w + 2 * margin, h: Math.max(...ys) - Math.min(...ys) + h + 2 * margin + header };
}

/** The smallest rectangle holding all of them. */
export function union(rects: Array<Rect | null>): Rect | null {
  const all = rects.filter((r): r is Rect => !!r);
  if (!all.length) return null;
  const x = Math.min(...all.map((r) => r.x));
  const y = Math.min(...all.map((r) => r.y));
  return { x, y, w: Math.max(...all.map((r) => r.x + r.w)) - x, h: Math.max(...all.map((r) => r.y + r.h)) - y };
}
