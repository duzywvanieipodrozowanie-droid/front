import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { useSearchParams } from 'react-router-dom';
import { ArrowLeft, Bug, CalendarClock, ChevronDown, ChevronRight, ExternalLink, GitBranch, Grid2x2, ListChecks, Rocket, Search, Target, Users } from 'lucide-react';
import { useDateRange } from '../context/DateRangeContext';
import { useTeam } from '../context/TeamContext';
import { useLang, usePick } from '../i18n';
import LoadingSpinner from '../components/LoadingSpinner';
import HelpTip from '../components/HelpTip';
import TeamBurnup from '../components/TeamBurnup';
import { toInterval } from '../utils/dateRange';
import { usePageAccess } from '../hooks/usePageAccess';

// Deliver: the unit's initiatives (Jira epics) from /api/metrics/deliver/epics with planned vs actual dates and
// delivery health; clicking one opens its details (/api/metrics/deliver/epics/{key}) with the work items on a timeline.
// Planned dates come from Jira "Target start" / "Target end", actual start = first work item in progress,
// first code = first commit mentioning the epic or its items, delivery = epic done (or a forecast: remaining story points at the last 4 weeks' pace).

type Health = 'NOT_STARTED' | 'ON_TRACK' | 'AT_RISK' | 'OFF_TRACK' | 'DELIVERED' | 'DELIVERED_LATE';
type Phase = 'BACKLOG' | 'ANALYSIS' | 'CODING' | 'REVIEW' | 'TEST' | 'WAITING' | 'DONE';
type EpicSummary = {
  key: string; summary?: string | null; url?: string | null; status?: string | null; statusSince?: string | null; statusDays?: number | null;
  assignee?: string | null; plannedStart?: string | null; actualStart?: string | null; firstCode?: string | null; plannedDelivery?: string | null;
  deliveryDate?: string | null; deliveryForecast: boolean; health: Health; delayDays?: number | null; delayReason?: string | null;
  items: number; itemsDone: number; progressPct: number;
  // technical as marked here (technicalMarked) or the Jira field (null = not set: business); the roadmap quarter (2026-Q3, null = none)
  technical?: boolean | null; technicalMarked?: boolean; quarter?: string | null;
  // the parent of the epic: an initiative in SAP (name, status and assignee from newer imports)
  parentKey?: string | null; parentSummary?: string | null; parentStatus?: string | null; parentAssignee?: string | null;
  // progressPct weighted by phase; expectedPct from the plan (planned start -> due); work per stage in %; warning signals
  expectedPct?: number | null; breakdown?: Breakdown | null; signals?: string[] | null;
};
type Breakdown = { live: number; done: number; test: number; dev: number; todo: number; blocked: number };

// the worst health first: a SAP initiative shows the worst of its epics
const HEALTH_ORDER: Health[] = ['OFF_TRACK', 'AT_RISK', 'NOT_STARTED', 'ON_TRACK', 'DELIVERED_LATE', 'DELIVERED'];
const GROUP_BY_SAP_KEY = 'deliver.groupBySap';
/** The Jira link of another issue, from the link of the epic (…/browse/EPIC-1 -> …/browse/SAP-1). */
const browseUrl = (epicUrl: string | null | undefined, key: string) => (epicUrl && epicUrl.includes('/browse/') ? `${epicUrl.split('/browse/')[0]}/browse/${key}` : null);
type Segment = { phase: Phase; status?: string | null; from: string; till: string };
type Item = {
  key: string; summary?: string | null; url?: string | null; type?: string | null; status?: string | null; phase: Phase;
  assignee?: string | null; parentKey?: string | null; storyPoints?: number | null; started?: string | null; finished?: string | null;
  phaseDays: Partial<Record<Phase, number>>; segments: Segment[]; commits: number;
};
type Stats = {
  stories: number; storiesDone: number; subtasks: number; subtasksDone: number; defects: number; defectsOpen: number;
  commits: number; commitsLast7Days: number; commitsPerWeek: number[]; storyPoints: number; storyPointsDone: number; people: number;
};
type EpicDetail = { epic: EpicSummary; projectId: string; stats: Stats; timelineFrom: string; timelineTill: string; items: Item[] };

// Days the epic has been in its current status; over 100 is flagged red.
const LONG_IN_STATUS_DAYS = 100;
function StatusDays({ days }: { days?: number | null }) {
  const pick = usePick();
  if (days == null) return <span>—</span>;
  return (
    <span className={days > LONG_IN_STATUS_DAYS ? 'text-red-600' : 'text-gray-900 dark:text-gray-100'} style={{ fontWeight: days > LONG_IN_STATUS_DAYS ? 700 : 600 }}>
      {days} {pick(days === 1 ? 'day' : 'days', 'dni')}
    </span>
  );
}

// Explicit hex colors: theme.css remaps Tailwind indigo/green classes to the brand palette.
const PHASES: Array<{ key: Phase; color: string; en: string; pl: string; hintEn: string; hintPl: string }> = [
  { key: 'ANALYSIS', color: '#8b5cf6', en: 'Preparation', pl: 'Przygotowanie', hintEn: 'Analysis · Refinement', hintPl: 'Analiza · Refinement' },
  { key: 'CODING', color: '#3b82f6', en: 'Code', pl: 'Kod', hintEn: 'In Progress · Developed', hintPl: 'In Progress · Developed' },
  { key: 'REVIEW', color: '#f59e0b', en: 'Review', pl: 'Review', hintEn: 'Code review', hintPl: 'Code review' },
  { key: 'TEST', color: '#10b981', en: 'Test', pl: 'Test', hintEn: 'In Test · UAT', hintPl: 'In Test · UAT' },
  { key: 'WAITING', color: '#a78bfa', en: 'Ready to deploy', pl: 'Gotowe do wdrożenia', hintEn: 'Waiting for release', hintPl: 'Czeka na wydanie' },
];
const PHASE_COLOR: Record<string, string> = Object.fromEntries(PHASES.map((p) => [p.key, p.color]));

const card = 'bg-white dark:bg-[#121317] rounded-xl border border-gray-200 dark:border-white/10';
const muted = 'text-gray-500 dark:text-gray-400';

function intervalOf(dateRange: string): string {
  return toInterval(dateRange, 'MONTHS_3');
}

// warning signals of an epic in progress (from the backend), long and short texts
const SIGNALS: Record<string, [string, string]> = {
  BEHIND_PLAN: ['Progress is more than 10 pp behind where the plan (planned start → due) says it should be', 'Postęp jest o ponad 10 pp za tym, gdzie powinien być wg planu (planowany start → termin)'],
  BLOCKED: ['A work item is on hold or blocked', 'Któreś zadanie jest wstrzymane lub zablokowane'],
  STALLED: ['No status change of its work items for 10 days', 'Od 10 dni żadne zadanie nie zmieniło statusu'],
  STUCK_IN_TEST: ['A work item has been in test for more than 10 days', 'Któreś zadanie jest w testach dłużej niż 10 dni'],
  SCOPE_GROWTH: ['Work items added in the last 14 days are 20%+ of the scope', 'Zadania dodane w ostatnich 14 dniach to 20%+ zakresu'],
};
const SIGNAL_SHORT: Record<string, [string, string]> = {
  BLOCKED: ['blocked', 'blokada'], STALLED: ['stalled', 'zastój'], STUCK_IN_TEST: ['stuck in test', 'utknęło w testach'], SCOPE_GROWTH: ['scope +', 'zakres +'],
};

function HealthBadge({ epic }: { epic: EpicSummary }) {
  const pick = usePick();
  const { lang } = useLang();
  const d = epic.delayDays ?? 0;
  const map: Record<Health, [string, string]> = {
    OFF_TRACK: [`${pick('Off track', 'Poza planem')}${d ? ` · +${d} ${pick('d', 'dni')}` : ''}`, 'bg-red-100 text-red-800 border-red-300'],
    AT_RISK: [`${pick('At risk', 'Zagrożony')}${d ? ` · +${d} ${pick('d', 'dni')}` : ''}`, 'bg-orange-50 text-orange-700 border-orange-200'],
    ON_TRACK: [pick('On track', 'Zgodnie z planem'), 'bg-emerald-50 text-emerald-700 border-emerald-200'],
    NOT_STARTED: [pick('Not started', 'Nierozpoczęty'), 'bg-gray-100 text-gray-600 border-gray-200'],
    DELIVERED: [pick('Delivered', 'Dostarczony'), 'bg-emerald-50 text-emerald-800 border-emerald-300'],
    DELIVERED_LATE: [`${pick('Delivered late', 'Dostarczony z opóźnieniem')} · +${d} ${pick('d', 'dni')}`, 'bg-amber-50 text-amber-800 border-amber-200'],
  };
  const [label, cls] = map[epic.health];
  const reasons: Record<string, [string, string]> = {
    START_DELAYED: ['Planned start has passed and no work item is in progress', 'Planowany start minął, a żadne zadanie nie jest w toku'],
    PAST_DUE: ['Planned delivery date has passed', 'Minęła planowana data dostarczenia'],
    FORECAST_AFTER_DUE: ['At the current pace the forecast delivery is after the planned date', 'Przy obecnym tempie prognoza dostarczenia wypada po planowanej dacie'],
    DELIVERED_AFTER_DUE: ['Delivered after the planned date', 'Dostarczony po planowanej dacie'],
    NO_PLAN: ['No planned delivery date in Jira (Due date)', 'Brak planowanej daty dostarczenia w Jirze (Due date)'],
    ...SIGNALS,
  };
  const text = (code: string) => (reasons[code] ? pick(reasons[code][0], reasons[code][1]) : code);
  const signals = (epic.signals ?? []).filter((s) => s !== epic.delayReason);
  const title = [epic.delayReason ? text(epic.delayReason) : null, ...signals.map(text)].filter(Boolean).join('\n');
  return (
    <span className="inline-flex items-center gap-1" title={title || undefined}>
      <span className={`inline-block px-2 py-0.5 rounded-full border text-[11px] whitespace-nowrap ${cls}`} style={{ fontWeight: 700 }}>
        {label}
      </span>
      {(epic.signals ?? []).length > 0 && (
        <span className="text-[10.5px] text-orange-700 dark:text-orange-300 whitespace-nowrap">
          {(epic.signals ?? []).map((s) => SIGNAL_SHORT[s]?.[lang === 'pl' ? 1 : 0] ?? s).join(' · ')}
        </span>
      )}
    </span>
  );
}

/** Roadmap quarter of the epic (Management → Roadmap): Q1–Q4 of this year, or none. */
function QuarterSelect({ epic, onChange }: { epic: EpicSummary; onChange: (quarter: string | null) => Promise<void> }) {
  const pick = usePick();
  const [saving, setSaving] = useState(false);
  const year = new Date().getFullYear();
  const options = ['Q1', 'Q2', 'Q3', 'Q4'].map((q) => `${year}-${q}`);
  // a quarter of another year stays selectable
  if (epic.quarter && !options.includes(epic.quarter)) options.unshift(epic.quarter);
  const label = (q: string) => (q.startsWith(`${year}-`) ? q.slice(5) : q.replace('-', ' '));
  return (
    <select value={epic.quarter ?? ''} disabled={saving} onClick={(e) => e.stopPropagation()}
      onChange={async (e) => { setSaving(true); try { await onChange(e.target.value || null); } finally { setSaving(false); } }}
      title={pick('Quarter of the roadmap (Management → Roadmap)', 'Kwartał roadmapy (Zarządzanie → Roadmap)')}
      className={`rounded-md border px-1.5 py-0.5 text-[11.5px] bg-white dark:bg-white/5 outline-none ${epic.quarter
        ? 'border-blue-300 text-blue-700 dark:border-blue-400/40 dark:text-blue-300' : 'border-gray-200 text-gray-500 dark:border-white/10'}`}
      style={{ fontWeight: epic.quarter ? 700 : 400 }}>
      <option value="">—</option>
      {options.map((q) => <option key={q} value={q}>{label(q)}</option>)}
    </select>
  );
}

/** Business or technical epic for the roadmap; without a mark here the Jira "technical" field decides. */
function TechnicalSelect({ epic, onChange }: { epic: EpicSummary; onChange: (technical: boolean) => Promise<void> }) {
  const pick = usePick();
  const [saving, setSaving] = useState(false);
  const technical = epic.technical === true;
  return (
    <select value={technical ? 'tech' : 'biz'} disabled={saving} onClick={(e) => e.stopPropagation()}
      onChange={async (e) => { setSaving(true); try { await onChange(e.target.value === 'tech'); } finally { setSaving(false); } }}
      title={epic.technicalMarked ? pick('Marked here', 'Oznaczone tutaj') : pick('From the Jira "technical" field (not set = business)', 'Z pola Jira „technical” (puste = biznesowy)')}
      className={`rounded-md border px-1.5 py-0.5 text-[11.5px] bg-white dark:bg-white/5 outline-none ${technical
        ? 'border-violet-300 text-violet-700 dark:border-violet-400/40 dark:text-violet-300' : 'border-gray-200 text-gray-600 dark:border-white/10 dark:text-gray-300'}`}
      style={{ fontWeight: epic.technicalMarked ? 700 : 400 }}>
      <option value="biz">{pick('Business', 'Biznesowy')}</option>
      <option value="tech">{pick('Technical', 'Techniczny')}</option>
    </select>
  );
}

// stages of the weighted progress, in the order drawn on the bar
const STAGES: Array<{ key: keyof Breakdown; color: string; en: string; pl: string }> = [
  { key: 'live', color: '#047857', en: 'Live', pl: 'Na produkcji' },
  { key: 'done', color: '#34d399', en: 'Done (not live)', pl: 'Done (nie na produkcji)' },
  { key: 'test', color: '#60a5fa', en: 'In test', pl: 'W testach' },
  { key: 'dev', color: '#a78bfa', en: 'In development', pl: 'W developmencie' },
  { key: 'blocked', color: '#f97316', en: 'Blocked', pl: 'Zablokowane' },
];

/**
 * Progress of an epic: weighted by phase (pct), its work per stage as segments when known, and a tick where the plan
 * says it should be today.
 */
function ProgressBar({ pct, done, total, breakdown, expected }: {
  pct: number; done: number; total: number; breakdown?: Breakdown | null; expected?: number | null;
}) {
  const pick = usePick();
  const title = [
    `${pick('Progress', 'Postęp')} ${pct}%${expected != null ? ` · ${pick('plan', 'plan')} ${expected}%` : ''}`,
    ...(breakdown ? STAGES.filter((s) => breakdown[s.key] > 0).map((s) => `${pick(s.en, s.pl)}: ${breakdown[s.key]}%`) : []),
    `${pick('Done', 'Zrobione')} ${done}/${total}`,
  ].join('\n');
  return (
    <div className="flex items-center gap-2 min-w-[130px]" title={title}>
      <div className="relative flex-1 h-2 rounded-full bg-gray-100 dark:bg-white/10">
        <div className="absolute inset-0 flex gap-[2px] rounded-full overflow-hidden">
          {breakdown
            ? STAGES.filter((s) => breakdown[s.key] > 0).map((s) => (
              <div key={s.key} className="h-full" style={{ width: `${breakdown[s.key]}%`, backgroundColor: s.color }} />
            ))
            : <div className="h-full" style={{ width: `${pct}%`, backgroundColor: '#10b981' }} />}
        </div>
        {expected != null && (
          <div className="absolute -top-1 -bottom-1 w-[2px] bg-gray-900 dark:bg-gray-100 rounded" style={{ left: `calc(${expected}% - 1px)` }} />
        )}
      </div>
      <span className="text-[11px] whitespace-nowrap" style={{ fontWeight: 700 }}>{pct}%</span>
      <span className={`text-[11px] ${muted} whitespace-nowrap`}>{done}/{total}</span>
    </div>
  );
}

export function Deliver() {
  const pick = usePick();
  const { lang } = useLang();
  const { dateRange } = useDateRange();
  const { selectedUnitId, selectedTeamName } = useTeam();
  const interval = useMemo(() => intervalOf(dateRange), [dateRange]);
  const [params, setParams] = useSearchParams();
  const selectedKey = params.get('epic');

  // the role of the page: Settings → Users and access
  const { loading: accessLoading, allowed: canOpen } = usePageAccess('deliver');
  const [epics, setEpics] = useState<EpicSummary[] | null>(null);
  const [listLoading, setListLoading] = useState(false);
  const [listFailed, setListFailed] = useState(false);
  const [detail, setDetail] = useState<EpicDetail | null>(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [detailError, setDetailError] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const [healthFilter, setHealthFilter] = useState<Health | 'ALL'>('ALL');


  useEffect(() => {
    if (!canOpen) return;
    let cancelled = false;
    const controller = new AbortController();
    async function load() {
      setListLoading(true);
      setListFailed(false);
      try {
        const p = new URLSearchParams({ interval });
        if (selectedUnitId) p.set('unitId', selectedUnitId);
        const res = await fetch(`/api/metrics/deliver/epics?${p.toString()}`, { credentials: 'include', signal: controller.signal });
        if (!res.ok) throw new Error(String(res.status));
        const js = await res.json();
        if (!cancelled) setEpics(Array.isArray(js?.epics) ? js.epics : []);
      } catch {
        if (!cancelled) { setEpics(null); setListFailed(true); }
      } finally {
        if (!cancelled) setListLoading(false);
      }
    }
    load();
    return () => { cancelled = true; controller.abort(); };
  }, [canOpen, interval, selectedUnitId]);

  useEffect(() => {
    if (!canOpen || !selectedKey) { setDetail(null); return; }
    let cancelled = false;
    const controller = new AbortController();
    async function load() {
      setDetailLoading(true);
      setDetailError(null);
      try {
        const p = new URLSearchParams();
        if (selectedUnitId) p.set('unitId', selectedUnitId);
        const res = await fetch(`/api/metrics/deliver/epics/${encodeURIComponent(selectedKey!)}?${p.toString()}`, { credentials: 'include', signal: controller.signal });
        if (res.status === 404) throw new Error('404');
        if (!res.ok) throw new Error(String(res.status));
        const js = (await res.json()) as EpicDetail;
        if (!cancelled) setDetail(js);
      } catch (e: any) {
        if (!cancelled) { setDetail(null); setDetailError(e?.message === '404' ? 'notFound' : 'failed'); }
      } finally {
        if (!cancelled) setDetailLoading(false);
      }
    }
    load();
    return () => { cancelled = true; controller.abort(); };
  }, [canOpen, selectedKey, selectedUnitId]);

  const [quarterError, setQuarterError] = useState(false);
  const setQuarter = async (key: string, quarter: string | null) => {
    setQuarterError(false);
    const p = new URLSearchParams();
    if (selectedUnitId) p.set('unitId', selectedUnitId);
    try {
      const res = await fetch(`/api/metrics/deliver/epics/${encodeURIComponent(key)}/quarter?${p.toString()}`, {
        method: 'PUT', credentials: 'include', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ quarter }),
      });
      if (!res.ok) throw new Error(String(res.status));
      setEpics((list) => (list ?? []).map((e) => (e.key === key ? { ...e, quarter } : e)));
    } catch {
      setQuarterError(true);
    }
  };

  const setTechnical = async (key: string, technical: boolean) => {
    setQuarterError(false);
    const p = new URLSearchParams();
    if (selectedUnitId) p.set('unitId', selectedUnitId);
    try {
      const res = await fetch(`/api/metrics/deliver/epics/${encodeURIComponent(key)}/technical?${p.toString()}`, {
        method: 'PUT', credentials: 'include', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ technical }),
      });
      if (!res.ok) throw new Error(String(res.status));
      setEpics((list) => (list ?? []).map((e) => (e.key === key ? { ...e, technical, technicalMarked: true } : e)));
    } catch {
      setQuarterError(true);
    }
  };

  // epics under their SAP initiative (the parent in Jira), expanded on a click
  const [groupBySap, setGroupBySap] = useState(() => { try { return localStorage.getItem(GROUP_BY_SAP_KEY) !== 'false'; } catch { return true; } });
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const toggleGroupBySap = (on: boolean) => {
    setGroupBySap(on);
    try { localStorage.setItem(GROUP_BY_SAP_KEY, String(on)); } catch { /* private mode */ }
  };
  const toggleExpanded = (key: string) => setExpanded((set) => {
    const next = new Set(set);
    if (next.has(key)) next.delete(key); else next.add(key);
    return next;
  });

  const locale = lang === 'pl' ? 'pl-PL' : 'en-GB';
  const fmtDate = (iso?: string | null) => (iso ? new Date(iso.length === 10 ? `${iso}T00:00:00` : iso).toLocaleDateString(locale, { day: 'numeric', month: 'short', year: 'numeric' }) : '—');

  const counts = useMemo(() => {
    const c: Record<Health, number> = { OFF_TRACK: 0, AT_RISK: 0, ON_TRACK: 0, NOT_STARTED: 0, DELIVERED: 0, DELIVERED_LATE: 0 };
    (epics ?? []).forEach((e) => { c[e.health]++; });
    return c;
  }, [epics]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return (epics ?? []).filter((e) => (healthFilter === 'ALL' || e.health === healthFilter)
      && (!q || e.key.toLowerCase().includes(q) || (e.summary ?? '').toLowerCase().includes(q)
        || (e.parentKey ?? '').toLowerCase().includes(q) || (e.parentSummary ?? '').toLowerCase().includes(q)
        || (e.parentAssignee ?? '').toLowerCase().includes(q)));
  }, [epics, query, healthFilter]);

  // SAP initiative -> its epics (filtered); epics without a parent last
  const sapGroups = useMemo(() => {
    const byParent = new Map<string, EpicSummary[]>();
    filtered.forEach((e) => byParent.set(e.parentKey ?? '', [...(byParent.get(e.parentKey ?? '') ?? []), e]));
    const min = (list: Array<string | null | undefined>) => list.filter(Boolean).sort()[0] ?? null;
    const max = (list: Array<string | null | undefined>) => list.filter(Boolean).sort().reverse()[0] ?? null;
    return [...byParent.entries()].map(([key, list]) => {
      const items = list.reduce((n, e) => n + e.items, 0);
      const itemsDone = list.reduce((n, e) => n + e.itemsDone, 0);
      const worst = [...list].sort((a, b) => HEALTH_ORDER.indexOf(a.health) - HEALTH_ORDER.indexOf(b.health))[0];
      const allDone = list.every((e) => e.health === 'DELIVERED' || e.health === 'DELIVERED_LATE');
      return {
        key, list, worst, items, itemsDone, pct: items ? Math.round(list.reduce((n, e) => n + e.progressPct * e.items, 0) / items) : 0,
        summary: list.find((e) => e.parentSummary)?.parentSummary ?? null,
        status: list.find((e) => e.parentStatus)?.parentStatus ?? null,
        assignee: list.find((e) => e.parentAssignee)?.parentAssignee ?? null,
        url: key ? browseUrl(list.find((e) => e.url)?.url, key) : null,
        plannedStart: min(list.map((e) => e.plannedStart)), actualStart: min(list.map((e) => e.actualStart)),
        firstCode: min(list.map((e) => e.firstCode)), plannedDelivery: max(list.map((e) => e.plannedDelivery)),
        deliveryDate: max(list.map((e) => e.deliveryDate)), forecast: !allDone && list.some((e) => e.deliveryForecast),
        quarters: [...new Set(list.map((e) => e.quarter).filter(Boolean) as string[])].sort(),
        technical: list.filter((e) => e.technical === true).length,
      };
    }).sort((a, b) => (a.key ? 0 : 1) - (b.key ? 0 : 1)
      || HEALTH_ORDER.indexOf(a.worst.health) - HEALTH_ORDER.indexOf(b.worst.health) || a.key.localeCompare(b.key));
  }, [filtered]);

  if (accessLoading) {
    return <div className="p-6"><LoadingSpinner size={20} /></div>;
  }
  if (!canOpen) {
    return (
      <div className="p-6 mx-auto">
        <div className={`${card} p-5`}>
          <p className="text-[14px] text-gray-800" style={{ fontWeight: 600 }}>{pick('No access', 'Brak dostępu')}</p>
          <p className={`text-[12px] ${muted} mt-1`}>{pick('Your role has no access to this screen. An admin can change it in Settings → Users and access.', 'Twoja rola nie ma dostępu do tego ekranu. Admin może to zmienić w Ustawienia → Użytkownicy i dostęp.')}</p>
        </div>
      </div>
    );
  }

  if (selectedKey) {
    return (
      <EpicDetailView
        detail={detail} loading={detailLoading} error={detailError} epicKey={selectedKey}
        onBack={() => { params.delete('epic'); setParams(params, { replace: false }); }}
        fmtDate={fmtDate} locale={locale}
      />
    );
  }

  const filterBtn = (h: Health | 'ALL', label: string, n?: number) => (
    <button
      key={h}
      onClick={() => setHealthFilter(h)}
      className={`px-2.5 py-1 rounded-md border text-[12px] ${healthFilter === h
        ? 'bg-gray-900 text-white border-gray-900 dark:bg-gray-100 dark:text-gray-900'
        : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50 dark:bg-white/5 dark:text-gray-300 dark:border-white/10'}`}
    >{label}{n != null ? ` (${n})` : ''}</button>
  );

  return (
    <div className="p-4 sm:p-6 space-y-4 text-gray-900 dark:text-gray-100">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-[20px]" style={{ fontWeight: 700 }}>Deliver</h1>
          <p className={`text-[12px] ${muted} mt-0.5`}>
            {pick('Initiatives (Jira epics): plan vs reality', 'Inicjatywy (epiki z Jiry): plan a rzeczywistość')}
            {' · '}{selectedTeamName && selectedTeamName !== 'All Teams' ? selectedTeamName : pick('all your units', 'wszystkie Twoje unity')}
            {' · '}{pick('epics since', 'epiki od')} 1.01.{new Date().getFullYear()}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {([
          ['OFF_TRACK', pick('Off track', 'Poza planem'), '#b91c1c'],
          ['AT_RISK', pick('At risk', 'Zagrożone'), '#ea580c'],
          ['ON_TRACK', pick('On track', 'Zgodnie z planem'), '#059669'],
          ['NOT_STARTED', pick('Not started', 'Nierozpoczęte'), '#6b7280'],
          ['DELIVERED', pick('Delivered this year', 'Dostarczone w tym roku'), '#065f46'],
        ] as Array<[Health, string, string]>).map(([h, label, color]) => (
          <button key={h} onClick={() => setHealthFilter(healthFilter === h ? 'ALL' : h)}
            className={`${card} p-3 text-left hover:border-gray-400 ${healthFilter === h ? 'ring-2 ring-gray-900 dark:ring-white' : ''}`}>
            <div className={`text-[11px] uppercase tracking-wide ${muted}`}>{label}</div>
            <div className="text-[24px]" style={{ fontWeight: 700, color }}>
              {h === 'DELIVERED' ? counts.DELIVERED + counts.DELIVERED_LATE : counts[h]}
            </div>
          </button>
        ))}
      </div>

      <TeamBurnup unitId={selectedUnitId} />

      <div className={`${card} overflow-hidden`}>
        <div className="px-4 py-3 border-b border-gray-200 dark:border-white/10 flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-2 flex-1 min-w-[200px]">
            <Search className="w-4 h-4 text-gray-400" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} className="outline-none text-[13px] w-full bg-transparent"
              placeholder={pick('Search epics…', 'Szukaj epików…')} />
          </div>
          <label className="inline-flex items-center gap-1.5 text-[12px] cursor-pointer mr-1">
            <input type="checkbox" className="accent-blue-600" checked={groupBySap} onChange={(e) => toggleGroupBySap(e.target.checked)} />
            {pick('Group by SAP', 'Grupuj po SAP')}
          </label>
          {groupBySap && (
            <button className={`text-[12px] ${muted} hover:underline mr-1`}
              onClick={() => setExpanded(expanded.size > 0 ? new Set() : new Set(sapGroups.map((g) => g.key)))}>
              {expanded.size > 0 ? pick('Collapse all', 'Zwiń wszystkie') : pick('Expand all', 'Rozwiń wszystkie')}
            </button>
          )}
          <div className="flex flex-wrap gap-1">
            {filterBtn('ALL', pick('All', 'Wszystkie'), epics?.length)}
            {filterBtn('OFF_TRACK', pick('Off track', 'Poza planem'), counts.OFF_TRACK)}
            {filterBtn('AT_RISK', pick('At risk', 'Zagrożone'), counts.AT_RISK)}
            {filterBtn('ON_TRACK', pick('On track', 'Zgodnie z planem'), counts.ON_TRACK)}
            {filterBtn('NOT_STARTED', pick('Not started', 'Nierozpoczęte'), counts.NOT_STARTED)}
          </div>
        </div>
        {quarterError && (
          <div className="px-4 py-2 text-[12px] text-red-600 border-b border-gray-200 dark:border-white/10">
            {pick('Could not save the change.', 'Nie udało się zapisać zmiany.')}
          </div>
        )}
        {listLoading && !epics ? (
          <div className="p-8 flex justify-center"><LoadingSpinner size={20} /></div>
        ) : listFailed ? (
          <div className={`p-6 text-[13px] ${muted}`}>{pick('Could not load epics.', 'Nie udało się pobrać epików.')}</div>
        ) : filtered.length === 0 ? (
          <div className={`p-6 text-[13px] ${muted}`}>{pick('No epics for this unit this year.', 'Brak epików dla tej jednostki w tym roku.')}</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-[12px] min-w-[1250px]">
              <thead>
                <tr className={`text-left ${muted} border-b border-gray-200 dark:border-white/10`}>
                  <th className="px-4 py-2">{groupBySap ? pick('SAP initiative / epic', 'Inicjatywa SAP / epik') : pick('Initiative (epic)', 'Inicjatywa (epik)')}</th>
                  <th className="px-2 py-2">
                    <span className="inline-flex items-center gap-1">{pick('Type', 'Typ')}
                      <HelpTip size="sm" content={pick('Business or technical epic: the section of the roadmap. Without a mark here the Jira "technical" field decides (not set = business).', 'Epik biznesowy albo techniczny: sekcja roadmapy. Bez oznaczenia tutaj decyduje pole Jira „technical” (puste = biznesowy).')} /></span>
                  </th>
                  <th className="px-2 py-2">
                    <span className="inline-flex items-center gap-1">{pick('Quarter', 'Kwartał')}
                      <HelpTip size="sm" content={pick('Epics with a quarter are on the roadmap (Management → Roadmap).', 'Epiki z kwartałem trafiają na roadmapę (Zarządzanie → Roadmap).')} /></span>
                  </th>
                  <th className="px-2 py-2">{pick('Progress', 'Postęp')}</th>
                  <th className="px-2 py-2">
                    <span className="inline-flex items-center gap-1">{pick('Estimated start', 'Planowany start')}
                      <HelpTip size="sm" content={pick('Jira "Target start" of the epic.', 'Pole „Target start” epika w Jirze.')} /></span>
                  </th>
                  <th className="px-2 py-2">
                    <span className="inline-flex items-center gap-1">{pick('Actual start', 'Faktyczny start')}
                      <HelpTip size="sm" content={pick('First move of the epic or any of its work items to a working status (In Progress, Review, Test…).', 'Pierwsze przejście epika lub któregoś z jego zadań do statusu pracy (In Progress, Review, Test…).')} /></span>
                  </th>
                  <th className="px-2 py-2">
                    <span className="inline-flex items-center gap-1">{pick('First code', 'Pierwszy kod')}
                      <HelpTip size="sm" content={pick('First GitLab commit mentioning the epic or one of its work items.', 'Pierwszy commit w GitLabie z kluczem epika lub któregoś z jego zadań.')} /></span>
                  </th>
                  <th className="px-2 py-2">
                    <span className="inline-flex items-center gap-1">{pick('Planned delivery', 'Planowane dostarczenie')}
                      <HelpTip size="sm" content={pick('Jira "Target end" of the epic.', 'Pole „Target end” epika w Jirze.')} /></span>
                  </th>
                  <th className="px-2 py-2">
                    <span className="inline-flex items-center gap-1">{pick('Delivery date', 'Data dostarczenia')}
                      <HelpTip size="sm" content={pick('When the epic was done; for open epics a forecast: remaining story points at the pace of the last 4 weeks.', 'Kiedy epik został zamknięty; dla otwartych prognoza: pozostałe story pointy w tempie z ostatnich 4 tygodni.')} /></span>
                  </th>
                  <th className="px-2 py-2">
                    <span className="inline-flex items-center gap-1">{pick('In status', 'W statusie')}
                      <HelpTip size="sm" content={pick(`Days since the epic moved into its current Jira status; red above ${LONG_IN_STATUS_DAYS} days.`, `Ile dni epik jest w obecnym statusie w Jirze; na czerwono powyżej ${LONG_IN_STATUS_DAYS} dni.`)} /></span>
                  </th>
                  <th className="px-2 py-2">{pick('Status', 'Status')}</th>
                </tr>
              </thead>
              <tbody>
                {(groupBySap ? sapGroups : [{ key: '-', list: filtered }]).flatMap((g) => {
                  const rows = !groupBySap || expanded.has(g.key) || query.trim() ? g.list.map((e) => epicRow(e, groupBySap)) : [];
                  if (!groupBySap || !('worst' in g)) return rows;
                  const open = expanded.has(g.key) || !!query.trim();
                  return [
                    <tr key={`sap:${g.key}`} className="border-b border-gray-200 dark:border-white/10 bg-gray-50/70 dark:bg-white/[0.03] hover:bg-gray-100 dark:hover:bg-white/5 cursor-pointer"
                      onClick={() => toggleExpanded(g.key)}>
                      <td className="px-4 py-2.5 max-w-[340px]">
                        <div className="flex items-center gap-1.5">
                          {open ? <ChevronDown className="w-4 h-4 shrink-0" /> : <ChevronRight className="w-4 h-4 shrink-0" />}
                          <div className="min-w-0">
                            <div className="truncate" style={{ fontWeight: 700 }} title={g.summary ?? ''}>
                              {g.key ? (g.summary || g.key) : pick('Without a SAP initiative', 'Bez inicjatywy SAP')}
                            </div>
                            <div className={`text-[11px] ${muted}`}>
                              {g.key ? (g.url ? <a href={g.url} target="_blank" rel="noopener noreferrer" onClick={(e) => e.stopPropagation()} className="underline">{g.key}</a> : g.key) : null}
                              {g.key ? ' · ' : ''}{g.status ? `${g.status} · ` : ''}{g.assignee ? `${g.assignee} · ` : ''}{g.list.length} {pick(g.list.length === 1 ? 'epic' : 'epics', 'epików')}
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className={`px-2 py-2.5 text-[11.5px] ${muted}`}>{g.technical ? `${g.technical} ${pick('technical', 'techn.')}` : '—'}</td>
                      <td className="px-2 py-2.5 text-[11.5px]" style={{ fontWeight: 700 }}>{g.quarters.map((q) => q.slice(5)).join(', ') || <span className={muted}>—</span>}</td>
                      <td className="px-2 py-2.5"><ProgressBar pct={g.pct} done={g.itemsDone} total={g.items} /></td>
                      <td className="px-2 py-2.5 whitespace-nowrap">{fmtDate(g.plannedStart)}</td>
                      <td className="px-2 py-2.5 whitespace-nowrap">{fmtDate(g.actualStart)}</td>
                      <td className="px-2 py-2.5 whitespace-nowrap">{fmtDate(g.firstCode)}</td>
                      <td className="px-2 py-2.5 whitespace-nowrap">{fmtDate(g.plannedDelivery)}</td>
                      <td className="px-2 py-2.5 whitespace-nowrap">
                        {fmtDate(g.deliveryDate)}
                        {g.forecast && g.deliveryDate ? <span className={`ml-1 text-[10.5px] ${muted}`}>({pick('forecast', 'prognoza')})</span> : null}
                      </td>
                      <td className="px-2 py-2.5" />
                      <td className="px-2 py-2.5"><HealthBadge epic={g.worst} /></td>
                    </tr>,
                    ...rows,
                  ];
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );

  function epicRow(e: EpicSummary, nested: boolean) {
    return (
                  <tr key={e.key} className="border-b border-gray-100 dark:border-white/5 hover:bg-gray-50 dark:hover:bg-white/5 cursor-pointer"
                    onClick={() => { params.set('epic', e.key); setParams(params); }}>
                    <td className={`${nested ? 'pl-10' : 'pl-4'} pr-4 py-2.5 max-w-[340px]`}>
                      <div className="truncate" style={{ fontWeight: 600 }} title={e.summary ?? ''}>{e.summary || e.key}</div>
                      <div className={`text-[11px] ${muted}`}>{e.key}{e.status ? ` · ${e.status}` : ''}{e.assignee ? ` · ${e.assignee}` : ''}</div>
                    </td>
                    <td className="px-2 py-2.5"><TechnicalSelect epic={e} onChange={(t) => setTechnical(e.key, t)} /></td>
                    <td className="px-2 py-2.5"><QuarterSelect epic={e} onChange={(q) => setQuarter(e.key, q)} /></td>
                    <td className="px-2 py-2.5"><ProgressBar pct={e.progressPct} done={e.itemsDone} total={e.items} breakdown={e.breakdown} expected={e.expectedPct} /></td>
                    <td className="px-2 py-2.5 whitespace-nowrap">{fmtDate(e.plannedStart)}</td>
                    <td className="px-2 py-2.5 whitespace-nowrap">{fmtDate(e.actualStart)}</td>
                    <td className="px-2 py-2.5 whitespace-nowrap">{fmtDate(e.firstCode)}</td>
                    <td className="px-2 py-2.5 whitespace-nowrap">{fmtDate(e.plannedDelivery)}</td>
                    <td className="px-2 py-2.5 whitespace-nowrap">
                      {fmtDate(e.deliveryDate)}
                      {e.deliveryForecast && e.deliveryDate ? <span className={`ml-1 text-[10.5px] ${muted}`}>({pick('forecast', 'prognoza')})</span> : null}
                    </td>
                    <td className="px-2 py-2.5 whitespace-nowrap" title={e.status ?? ''}><StatusDays days={e.statusDays} /></td>
                    <td className="px-2 py-2.5"><HealthBadge epic={e} /></td>
                  </tr>
    );
  }
}

function Kpi({ icon, label, value, sub, pct, tone = 'indigo', children }: {
  icon: ReactNode; label: string; value: ReactNode; sub?: ReactNode; pct?: number; tone?: 'indigo' | 'rose'; children?: ReactNode;
}) {
  const iconBg = tone === 'rose' ? 'bg-rose-100 text-rose-600' : 'bg-indigo-100 text-indigo-600';
  const bar = tone === 'rose' ? '#e11d48' : '#10b981';
  return (
    <div className="flex items-center gap-3">
      <div className={`w-9 h-9 rounded-lg ${iconBg} flex items-center justify-center shrink-0`}>{icon}</div>
      <div className="flex-1 min-w-0">
        <div className={`text-[12px] ${muted}`}>{label}</div>
        <div className="flex flex-wrap items-end justify-between gap-x-2">
          <div className="text-[22px]" style={{ fontWeight: 700 }}>{value}</div>
          {sub ? <div className={`text-[11.5px] ${muted} whitespace-nowrap`}>{sub}</div> : null}
        </div>
        {pct != null && (
          <div className="mt-1.5 flex items-center gap-2">
            <div className="flex-1 h-1.5 rounded-full bg-gray-100 dark:bg-white/10 overflow-hidden">
              <div className="h-full rounded-full" style={{ width: `${Math.max(0, Math.min(100, pct))}%`, backgroundColor: bar }} />
            </div>
            <div className={`text-[11px] ${muted}`}>{pct}%</div>
          </div>
        )}
        {children}
      </div>
    </div>
  );
}

function EpicDetailView({ detail, loading, error, epicKey, onBack, fmtDate, locale }: {
  detail: EpicDetail | null; loading: boolean; error: string | null; epicKey: string; onBack: () => void;
  fmtDate: (iso?: string | null) => string; locale: string;
}) {
  const pick = usePick();
  const [query, setQuery] = useState('');
  const [hideSubtasks, setHideSubtasks] = useState(false);

  const back = (
    <button onClick={onBack} className="inline-flex items-center gap-1.5 text-[12px] text-gray-600 hover:text-gray-900 dark:text-gray-300">
      <ArrowLeft className="w-4 h-4" /> {pick('All initiatives', 'Wszystkie inicjatywy')}
    </button>
  );
  if (loading && !detail) return <div className="p-6 space-y-4">{back}<div className={`${card} p-8 flex justify-center`}><LoadingSpinner size={20} /></div></div>;
  if (error || !detail) {
    return (
      <div className="p-6 space-y-4">
        {back}
        <div className={`${card} p-5 text-[13px] ${muted}`}>
          {error === 'notFound'
            ? pick(`Epic ${epicKey} is not in the projects of the selected unit.`, `Epika ${epicKey} nie ma w projektach wybranej jednostki.`)
            : pick('Could not load the epic.', 'Nie udało się pobrać epika.')}
        </div>
      </div>
    );
  }

  const { epic, stats } = detail;
  const from = new Date(detail.timelineFrom).getTime();
  const till = new Date(detail.timelineTill).getTime();
  const span = Math.max(1, till - from);
  const pos = (iso: string | Date) => Math.max(0, Math.min(100, ((new Date(iso).getTime() - from) / span) * 100));
  const todayPct = pos(new Date());
  const duePct = epic.plannedDelivery ? pos(`${epic.plannedDelivery}T23:59:59`) : null;

  // month/week ticks for the axis
  const ticks: Array<{ pct: number; label: string }> = [];
  const days = span / 86400000;
  const step = days > 120 ? 30 : days > 45 ? 14 : 7;
  for (let t = new Date(from); t.getTime() <= till; t = new Date(t.getTime() + step * 86400000)) {
    ticks.push({ pct: pos(t), label: t.toLocaleDateString(locale, { day: 'numeric', month: 'short' }) });
  }

  const q = query.trim().toLowerCase();
  const items = detail.items.filter((i) => (!hideSubtasks || !i.parentKey || i.parentKey === epic.key)
    && (!q || i.key.toLowerCase().includes(q) || (i.summary ?? '').toLowerCase().includes(q)));
  const inProgress = detail.items.filter((i) => i.phase !== 'DONE' && i.phase !== 'BACKLOG').length;
  const todo = detail.items.filter((i) => i.phase === 'BACKLOG').length;
  const doneCount = detail.items.filter((i) => i.phase === 'DONE').length;
  const durationDays = epic.actualStart
    ? Math.round(((epic.deliveryDate && !epic.deliveryForecast ? new Date(`${epic.deliveryDate}T00:00:00`).getTime() : Date.now()) - new Date(epic.actualStart).getTime()) / 86400000)
    : null;
  const maxWeek = Math.max(1, ...stats.commitsPerWeek);
  const spPct = stats.storyPoints ? Math.round((stats.storyPointsDone / stats.storyPoints) * 100) : undefined;

  const dateCell = (label: string, value: ReactNode, help?: string) => (
    <div>
      <div className={`text-[11px] ${muted} inline-flex items-center gap-1`}>{label}{help ? <HelpTip size="sm" content={help} /> : null}</div>
      <div className="text-[13px]" style={{ fontWeight: 600 }}>{value}</div>
    </div>
  );

  return (
    <div className="p-4 sm:p-6 space-y-4 text-gray-900 dark:text-gray-100">
      {back}
      <div className={`${card} p-4 space-y-4`}>
        <div className="flex flex-wrap items-start gap-3">
          <div className="w-10 h-10 shrink-0 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center"><Rocket className="w-5 h-5" /></div>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
              <h1 className="text-[20px]" style={{ fontWeight: 700 }}>{epic.summary || epic.key}</h1>
              <HealthBadge epic={epic} />
            </div>
            <div className={`text-[12px] ${muted} flex flex-wrap items-center gap-x-3 gap-y-1 mt-0.5`}>
              {epic.url ? <a href={epic.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 underline">{epic.key}<ExternalLink className="w-3 h-3" /></a> : <span>{epic.key}</span>}
              {epic.status ? <span>{epic.status}{epic.statusDays != null ? <> · <StatusDays days={epic.statusDays} /> {pick('in status', 'w statusie')}</> : null}</span> : null}
              {epic.assignee ? <span className="inline-flex items-center gap-1"><Users className="w-3.5 h-3.5" />{epic.assignee}</span> : null}
              <span className="inline-flex items-center gap-1"><Users className="w-3.5 h-3.5" />{stats.people} {pick('people on items', 'osób w zadaniach')}</span>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-6 gap-4 pt-3 border-t border-gray-100 dark:border-white/5">
          {dateCell(pick('Estimated start', 'Planowany start'), fmtDate(epic.plannedStart))}
          {dateCell(pick('Actual start', 'Faktyczny start'), fmtDate(epic.actualStart))}
          {dateCell(pick('First code', 'Pierwszy kod'), fmtDate(epic.firstCode))}
          {dateCell(pick('Planned delivery', 'Planowane dostarczenie'), fmtDate(epic.plannedDelivery))}
          {dateCell(
            epic.deliveryForecast ? pick('Forecast delivery', 'Prognoza dostarczenia') : pick('Delivery date', 'Data dostarczenia'),
            fmtDate(epic.deliveryDate),
            epic.deliveryForecast ? pick('Remaining story points (items without an estimate count as the average) at the pace of the last 4 weeks; the pace since the actual start when nothing was closed recently.', 'Pozostałe story pointy (zadania bez estymaty liczone jako średnia) w tempie z ostatnich 4 tygodni; gdy ostatnio nic nie zamknięto - tempo od faktycznego startu.') : undefined,
          )}
          {dateCell(pick('Delay', 'Opóźnienie'),
            epic.delayDays ? <span className="text-red-600">+{epic.delayDays} {pick('days', 'dni')}</span>
              : <span className="text-emerald-600">{epic.plannedDelivery ? pick('none', 'brak') : pick('no plan', 'brak planu')}</span>)}
        </div>
      </div>

      <div className={`${card} p-4`}>
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-5">
          <Kpi icon={<ListChecks className="w-5 h-5" />} label={pick('Stories / tasks', 'Story / taski')} value={stats.stories}
            sub={`${stats.storiesDone} ${pick('done', 'gotowe')}`} pct={stats.stories ? Math.round((stats.storiesDone / stats.stories) * 100) : 0} />
          <Kpi icon={<Grid2x2 className="w-5 h-5" />} label="Sub-tasks" value={stats.subtasks}
            sub={`${stats.subtasksDone} ${pick('done', 'gotowe')}`} pct={stats.subtasks ? Math.round((stats.subtasksDone / stats.subtasks) * 100) : 0} />
          <Kpi icon={<Bug className="w-5 h-5" />} tone="rose" label={pick('Defects', 'Defekty')} value={stats.defects}
            sub={`${stats.defectsOpen} ${pick('open', 'otwartych')}`} pct={stats.defects ? Math.round((stats.defectsOpen / stats.defects) * 100) : 0} />
          <Kpi icon={<GitBranch className="w-5 h-5" />} label={pick('Commits', 'Commity')} value={stats.commits}
            sub={<span className="text-emerald-600">+{stats.commitsLast7Days} {pick('this week', 'w tym tyg.')}</span>}>
            <div className="flex items-end gap-0.5 h-6 mt-1" title={pick('Commits per week, last 8 weeks', 'Commity tygodniowo, ostatnie 8 tygodni')}>
              {stats.commitsPerWeek.map((n, i) => (
                <div key={i} className="flex-1 rounded-sm" style={{ height: `${Math.max(8, (n / maxWeek) * 100)}%`, backgroundColor: n ? '#6366f1' : '#e5e7eb' }} />
              ))}
            </div>
          </Kpi>
          <Kpi icon={<Target className="w-5 h-5" />} tone="rose" label="Story points" value={`${stats.storyPointsDone} / ${stats.storyPoints}`}
            sub={pick('done / total', 'gotowe / razem')} pct={spPct} />
        </div>
      </div>

      <div className={`${card} overflow-hidden`}>
        <div className="px-4 py-3 border-b border-gray-200 dark:border-white/10 flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 flex-1 min-w-[200px]">
            <Search className="w-4 h-4 text-gray-400" />
            <input value={query} onChange={(e) => setQuery(e.target.value)} className="outline-none text-[13px] w-full bg-transparent"
              placeholder={pick('Search work items…', 'Szukaj zadań…')} />
          </div>
          <label className="inline-flex items-center gap-1.5 text-[12px] text-gray-600 dark:text-gray-300">
            <input type="checkbox" checked={hideSubtasks} onChange={(e) => setHideSubtasks(e.target.checked)} /> {pick('Hide sub-tasks', 'Ukryj sub-taski')}
          </label>
          <div className="flex flex-wrap gap-3 text-[11px] text-gray-600 dark:text-gray-300">
            {PHASES.map((p) => (
              <span key={p.key} className="inline-flex items-center gap-1" title={pick(p.hintEn, p.hintPl)}>
                <i className="inline-block w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: p.color }} />{pick(p.en, p.pl)}
              </span>
            ))}
          </div>
        </div>
        <div className="overflow-x-auto">
          <div className="min-w-[1000px]">
            <div className="grid grid-cols-[320px_1fr_110px] border-b border-gray-200 dark:border-white/10 text-[11px]">
              <div className={`px-4 py-2 ${muted}`}>{pick('Work item', 'Zadanie')}</div>
              <div className="relative h-8">
                {ticks.map((t, i) => (
                  <span key={i} className={`absolute top-2 -translate-x-1/2 ${muted} whitespace-nowrap`} style={{ left: `${t.pct}%` }}>{t.label}</span>
                ))}
              </div>
              <div className={`px-2 py-2 ${muted}`}>{pick('Status', 'Status')}</div>
            </div>
            <div className="relative">
              <div className="absolute inset-y-0 left-[320px] right-[110px] pointer-events-none">
                {ticks.map((t, i) => <div key={i} className="absolute inset-y-0 w-px bg-gray-100 dark:bg-white/5" style={{ left: `${t.pct}%` }} />)}
                {duePct != null && (
                  <div className="absolute inset-y-0" style={{ left: `${duePct}%` }}>
                    <div className="w-px h-full" style={{ backgroundColor: '#dc2626' }} />
                    <span className="absolute top-0 -translate-x-1/2 px-1.5 rounded text-[10px] text-white whitespace-nowrap" style={{ backgroundColor: '#dc2626' }}>{pick('Planned', 'Plan')}</span>
                  </div>
                )}
                <div className="absolute inset-y-0" style={{ left: `${todayPct}%` }}>
                  <div className="w-px h-full" style={{ backgroundColor: '#6366f1' }} />
                  <span className="absolute bottom-0 -translate-x-1/2 px-1.5 rounded text-[10px] text-white whitespace-nowrap" style={{ backgroundColor: '#6366f1' }}>{pick('Today', 'Dziś')}</span>
                </div>
              </div>
              {items.length === 0 ? (
                <div className={`px-4 py-6 text-[12px] ${muted}`}>{pick('No work items under this epic.', 'Brak zadań pod tym epikiem.')}</div>
              ) : items.map((i) => {
                const sub = !!i.parentKey && i.parentKey !== epic.key;
                const phaseTitle = PHASES.filter((p) => i.phaseDays[p.key]).map((p) => `${pick(p.en, p.pl)}: ${i.phaseDays[p.key]} ${pick('d', 'dni')}`).join(' · ');
                return (
                  <div key={i.key} className="grid grid-cols-[320px_1fr_110px] items-center border-b border-gray-100 dark:border-white/5 hover:bg-gray-50/60 dark:hover:bg-white/[0.03]">
                    <div className={`px-4 py-2 min-w-0 ${sub ? 'pl-9' : ''}`}>
                      <div className="flex items-center gap-1.5 min-w-0">
                        <span className={`shrink-0 px-1.5 rounded text-[10px] border ${/bug|defect/i.test(i.type ?? '') ? 'bg-rose-50 text-rose-700 border-rose-200' : sub ? 'bg-gray-50 text-gray-600 border-gray-200' : 'bg-emerald-50 text-emerald-700 border-emerald-200'}`} style={{ fontWeight: 600 }}>{i.type ?? '—'}</span>
                        <span className="truncate text-[12.5px]" style={{ fontWeight: sub ? 400 : 600 }} title={i.summary ?? ''}>{i.summary || i.key}</span>
                      </div>
                      <div className={`text-[11px] ${muted} truncate`}>
                        {i.url ? <a href={i.url} target="_blank" rel="noopener noreferrer" className="underline">{i.key}</a> : i.key}
                        {i.assignee ? ` · ${i.assignee}` : ''}{i.storyPoints ? ` · ${i.storyPoints} SP` : ''}{i.commits ? ` · ${i.commits} ${pick('commits', 'commitów')}` : ''}
                      </div>
                    </div>
                    <div className="relative h-7" title={phaseTitle || undefined}>
                      {i.segments.map((s, idx) => {
                        const left = pos(s.from);
                        const width = Math.max(0.6, pos(s.till) - left);
                        return (
                          <div key={idx} className="absolute top-1.5 h-4 rounded-sm" style={{ left: `${left}%`, width: `${width}%`, backgroundColor: PHASE_COLOR[s.phase] ?? '#9ca3af' }}
                            title={`${s.status ?? s.phase}: ${new Date(s.from).toLocaleDateString(locale)} → ${new Date(s.till).toLocaleDateString(locale)}`} />
                        );
                      })}
                      {i.finished && (
                        <div className="absolute top-1 -translate-x-1/2 w-5 h-5 rounded-full flex items-center justify-center text-white text-[10px]"
                          style={{ left: `${pos(i.finished)}%`, backgroundColor: '#059669' }} title={`${pick('Done', 'Gotowe')}: ${new Date(i.finished).toLocaleDateString(locale)}`}>✓</div>
                      )}
                    </div>
                    <div className="px-2 py-2">
                      <span className={`inline-block px-2 py-0.5 rounded-full text-[10.5px] border whitespace-nowrap ${i.phase === 'DONE' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : i.phase === 'BACKLOG' ? 'bg-gray-50 text-gray-600 border-gray-200' : 'bg-blue-50 text-blue-700 border-blue-200'}`}
                        style={{ fontWeight: 600 }}>{i.status ?? i.phase}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
        <div className="px-4 py-3 bg-gray-50 dark:bg-white/[0.03] text-[12px] text-gray-600 dark:text-gray-300 grid grid-cols-2 md:grid-cols-4 gap-2">
          <div className="inline-flex items-center gap-1"><CalendarClock className="w-3.5 h-3.5" />{pick('Duration', 'Czas trwania')} <b className="text-gray-900 dark:text-gray-100">{durationDays != null ? `${durationDays} ${pick('days', 'dni')}` : '—'}</b></div>
          <div>{pick('Done', 'Gotowe')} <b className="text-gray-900 dark:text-gray-100">{doneCount}</b></div>
          <div>{pick('In progress', 'W toku')} <b className="text-gray-900 dark:text-gray-100">{inProgress}</b></div>
          <div>{pick('To do', 'Do zrobienia')} <b className="text-gray-900 dark:text-gray-100">{todo}</b></div>
        </div>
      </div>
    </div>
  );
}

export default Deliver;
