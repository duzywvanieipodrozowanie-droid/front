import { useEffect, useState, type CSSProperties, type ReactNode } from 'react';
import { useSearchParams } from 'react-router-dom';
import { ExternalLink, Search } from 'lucide-react';
import { usePick } from '../i18n';
import LoadingSpinner from '../components/LoadingSpinner';

// Full path of one Jira task from /api/metrics/task-timeline?key=...: time in workflow phases (Jira status history),
// commits with the task key, linked merge requests with approvals and pipelines, and one chronological timeline.

type Phase = 'BACKLOG' | 'ANALYSIS' | 'CODING' | 'REVIEW' | 'TEST' | 'WAITING' | 'DONE';
type TimelineEvent = { at: string | null; source: 'JIRA' | 'GITLAB'; kind: string; title: string; detail?: string | null; phase: Phase };
type StatusChange = { from: string; to: string; author?: string | null; at: string; hoursInFrom: number; toPhase: Phase };
type Pipeline = { status: string; minutes?: number | null; failedBefore: number };
type MergeRequestInfo = {
  id: string; title?: string | null; repository: string; targetBranch?: string | null; targetBranchProtected?: boolean | null; state?: string | null;
  author?: string | null; createdAt?: string | null; mergedAt?: string | null; firstCommitAt?: string | null; pickupHours?: number | null; reviewHours?: number | null;
  comments?: number | null; changedFiles?: number | null; approvals: Array<{ name: string; at?: string | null }>; pipeline?: Pipeline | null;
};
type CommitInfo = { id: string; title?: string | null; author?: string | null; repository: string; date: string; additions?: number | null; deletions?: number | null; mergeCommit: boolean };
type Timeline = {
  key: string; projectId: string; summary?: string | null; type?: string | null; priority?: string | null; status?: string | null; url?: string | null;
  assignee?: string | null; creator?: string | null; parentKey?: string | null; sprints: string[]; created: string; doneAt?: string | null; leadTimeHours: number;
  phases: Array<{ phase: Phase; hours: number; statuses: string[] }>; firstCommitAt?: string | null; mergedAt?: string | null; codeCycleHours?: number | null;
  pickupHours?: number | null; reviewHours?: number | null; pipeline?: Pipeline | null; events: TimelineEvent[]; statusChanges: StatusChange[];
  mergeRequests: MergeRequestInfo[]; commits: CommitInfo[];
};

// Explicit hex colors: theme.css remaps Tailwind indigo classes to brand green.
const PHASE_COLORS: Record<Phase, string> = {
  BACKLOG: '#cbd5e1', ANALYSIS: '#3b82f6', CODING: '#a855f7', REVIEW: '#f59e0b', TEST: '#10b981', WAITING: '#94a3b8', DONE: '#059669',
};
const PHASE_ORDER: Phase[] = ['BACKLOG', 'ANALYSIS', 'CODING', 'REVIEW', 'TEST', 'WAITING'];

const card = 'bg-white dark:bg-[#121317] rounded-xl border border-gray-200 dark:border-white/10';
const muted = 'text-gray-500 dark:text-gray-400';
const th = 'text-left py-1.5 pr-3 text-[11px] uppercase tracking-wide text-gray-500 dark:text-gray-400';

function fmtDuration(hours?: number | null): string {
  if (hours == null || !Number.isFinite(hours)) return '—';
  if (hours < 1) return `${Math.round(hours * 60)} min`;
  if (hours < 24) return `${Math.round(hours * 10) / 10} h`;
  return `${Math.round((hours / 24) * 10) / 10} d`;
}

function fmtDate(value?: string | null, withTime = true): string {
  if (!value) return '—';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleString(undefined, withTime
    ? { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }
    : { day: 'numeric', month: 'short', year: 'numeric' });
}

function Badge({ children, className, style }: { children: ReactNode; className?: string; style?: CSSProperties }) {
  return <span className={`inline-block px-1.5 py-0.5 rounded text-[10.5px] whitespace-nowrap ${className ?? ''}`} style={{ fontWeight: 700, ...style }}>{children}</span>;
}

function Kpi({ label, value, hint }: { label: string; value: ReactNode; hint?: ReactNode }) {
  return (
    <div className={`${card} p-4`}>
      <div className={`text-[12px] ${muted}`}>{label}</div>
      <div className="text-[20px] text-gray-900 dark:text-gray-100 mt-0.5" style={{ fontWeight: 700 }}>{value}</div>
      {hint && <div className="text-[11px] text-gray-400 dark:text-gray-500">{hint}</div>}
    </div>
  );
}

export function TaskTimeline() {
  const pick = usePick();
  const [params, setParams] = useSearchParams();
  const key = (params.get('key') ?? '').trim().toUpperCase();
  const [input, setInput] = useState(key);
  const [data, setData] = useState<Timeline | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<'notFound' | 'noAccess' | 'noEndpoint' | 'forbidden' | 'failed' | null>(null);
  const [errorProjects, setErrorProjects] = useState<string[]>([]);

  const phaseLabel = (p: Phase) => ({
    BACKLOG: pick('Backlog', 'Backlog'), ANALYSIS: pick('Analysis', 'Analiza'), CODING: pick('Coding', 'Kodowanie'), REVIEW: pick('Review', 'Review'),
    TEST: pick('Testing', 'Testy'), WAITING: pick('Waiting for release', 'Czeka na wdrożenie'), DONE: pick('Done', 'Gotowe'),
  }[p]);

  // fixed event titles come from the backend in English; translate them by kind
  const eventTitle = (e: TimelineEvent) => {
    switch (e.kind) {
      case 'CREATED': return pick('Task created', 'Zadanie utworzone');
      case 'FIRST_COMMIT': return pick('First commit', 'Pierwszy commit');
      case 'APPROVED': return e.title === 'First approval' ? pick('First approval', 'Pierwsza akceptacja') : pick('Approval', 'Akceptacja');
      default: return e.title;
    }
  };

  useEffect(() => { setInput(key); }, [key]);

  useEffect(() => {
    if (!key) { setData(null); setError(null); return; }
    let cancelled = false;
    const controller = new AbortController();
    (async () => {
      setLoading(true);
      setError(null);
      try {
        const res = await fetch(`/api/metrics/task-timeline?key=${encodeURIComponent(key)}`, { credentials: 'include', signal: controller.signal });
        if (res.status === 404) {
          // the backend explains its own 404; a 404 without that body means the endpoint itself is missing (old core)
          const body = await res.json().catch(() => null) as { error?: string; projectIds?: string[] } | null;
          if (!cancelled) {
            setData(null);
            setErrorProjects(body?.projectIds ?? []);
            setError(body?.error === 'TASK_NOT_FOUND' ? 'notFound' : body?.error === 'NO_PROJECT_ACCESS' ? 'noAccess' : 'noEndpoint');
          }
          return;
        }
        if (res.status === 403) { if (!cancelled) { setData(null); setError('forbidden'); } return; }
        if (!res.ok) throw new Error(String(res.status));
        const js = await res.json();
        if (!cancelled) setData(js as Timeline);
      } catch {
        if (!cancelled) { setData(null); setError('failed'); }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; controller.abort(); };
  }, [key]);

  const submit = () => {
    const next = input.trim().toUpperCase();
    if (next) setParams({ key: next });
  };

  const phases = data ? PHASE_ORDER.map((p) => data.phases.find((x) => x.phase === p)).filter((x): x is NonNullable<typeof x> => !!x && x.hours > 0) : [];
  const phaseTotal = phases.reduce((a, p) => a + p.hours, 0);
  const visibleCommits = data?.commits.filter((c) => !c.mergeCommit) ?? [];

  return (
    <div className="p-4 sm:p-6 space-y-4 text-gray-900 dark:text-gray-100">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-[20px]" style={{ fontWeight: 700 }}>Task Timeline</h1>
          <p className={`text-[12px] ${muted} mt-0.5`}>{pick('Full path of a task: Jira → code → review → merge → testing → production', 'Pełna droga zadania: Jira → kod → review → merge → testy → produkcja')}</p>
        </div>
        <form className="flex items-center gap-2" onSubmit={(e) => { e.preventDefault(); submit(); }}>
          <div className="relative">
            <Search className="w-4 h-4 text-gray-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={pick('Jira key, e.g. MOB-91', 'Numer Jira, np. MOB-91')}
              className="pl-8 pr-3 py-2 w-64 rounded-lg border border-gray-200 dark:border-white/10 bg-white dark:bg-[#17181c] text-[13px] font-mono outline-none focus:border-gray-400"
            />
          </div>
          <button type="submit" className="px-3.5 py-2 rounded-lg text-[12px] bg-gray-900 text-white dark:bg-gray-100 dark:text-gray-900" style={{ fontWeight: 600 }}>{pick('Show', 'Pokaż')}</button>
        </form>
      </div>

      {!key ? (
        <div className={`${card} p-6 text-[12.5px] ${muted}`}>{pick('Enter a Jira key to see how the task went through analysis, coding, review, testing and release.', 'Wpisz numer Jira, żeby zobaczyć, jak zadanie przeszło przez analizę, kodowanie, review, testy i wdrożenie.')}</div>
      ) : loading && !data ? (
        <div className={`${card} p-6 min-h-[160px] flex items-center justify-center`}><LoadingSpinner size={20} /></div>
      ) : error === 'forbidden' ? (
        <div className={`${card} p-6 text-[12.5px] ${muted}`}>{pick('Your role has no access to this screen. An admin can change it in Settings → Users and access.', 'Twoja rola nie ma dostępu do tego ekranu. Admin może to zmienić w Ustawienia → Użytkownicy i dostęp.')}</div>
      ) : error === 'notFound' ? (
        <div className={`${card} p-6 text-[12.5px] ${muted}`}>{pick(`Task ${key} is not in the database - it has not been imported from Jira yet.`, `Zadania ${key} nie ma w bazie - nie zostało jeszcze zaimportowane z Jiry.`)}</div>
      ) : error === 'noAccess' ? (
        <div className={`${card} p-6 text-[12.5px] ${muted}`}>{pick(`Task ${key} belongs to project ${errorProjects.join(', ')}, which is not assigned to any unit you manage.`, `Zadanie ${key} należy do projektu ${errorProjects.join(', ')}, który nie jest przypisany do żadnej jednostki, którą zarządzasz.`)}</div>
      ) : error === 'noEndpoint' ? (
        <div className={`${card} p-6 text-[12.5px] ${muted}`}>{pick('The backend does not provide /metrics/task-timeline - deploy the current core version.', 'Backend nie udostępnia /metrics/task-timeline - wgraj aktualną wersję core.')}</div>
      ) : error || !data ? (
        <div className={`${card} p-6 text-[12.5px] ${muted}`}>{pick('Could not load the task.', 'Nie udało się wczytać zadania.')}</div>
      ) : (
        <>
          {/* Header */}
          <div className={`${card} p-5`}>
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <span className={`font-mono text-[12px] ${muted}`}>{data.key}</span>
                  {data.type && <Badge style={{ backgroundColor: '#ede9fe', color: '#6d28d9' }}>{data.type}</Badge>}
                  {data.priority && <Badge className="bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-400">{data.priority}</Badge>}
                  {data.status && <Badge className={data.doneAt ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-400' : 'bg-gray-100 text-gray-700 dark:bg-[#2a2c33] dark:text-gray-300'}>{data.status}</Badge>}
                  {data.url && <a href={data.url} target="_blank" rel="noreferrer" className={`inline-flex items-center gap-1 text-[11.5px] ${muted} hover:underline`}><ExternalLink className="w-3.5 h-3.5" />Jira</a>}
                </div>
                <div className="text-[17px] mt-1.5" style={{ fontWeight: 700 }}>{data.summary || '—'}</div>
                <div className={`text-[12px] ${muted} mt-1`}>
                  {pick('Assignee', 'Assignee')}: <b className="text-gray-900 dark:text-gray-100">{data.assignee || '—'}</b>
                  {data.parentKey && <> · {pick('Parent', 'Rodzic')}: <span className="font-mono">{data.parentKey}</span></>}
                  {data.sprints.length > 0 && <> · {data.sprints.join(', ')}</>}
                  {' · '}{data.projectId}
                </div>
              </div>
              <div className="text-right">
                <div className={`text-[12px] ${muted}`}>{data.doneAt ? pick('Lead time (created → done)', 'Lead time (utworzenie → done)') : pick('In progress for', 'W toku od')}</div>
                <div className="text-[28px]" style={{ fontWeight: 800 }}>{fmtDuration(data.leadTimeHours)}</div>
                <div className="text-[11.5px] text-gray-400">{fmtDate(data.created)} → {data.doneAt ? fmtDate(data.doneAt) : pick('now', 'teraz')}</div>
              </div>
            </div>

            <div className={`mt-4 text-[12px] ${muted}`}>{pick('Time in phases', 'Czas w fazach')}</div>
            {phaseTotal > 0 ? (
              <>
                <div className="mt-1.5 flex h-8 rounded-lg overflow-hidden">
                  {phases.map((p) => (
                    <div
                      key={p.phase}
                      title={`${phaseLabel(p.phase)}: ${fmtDuration(p.hours)} (${p.statuses.join(', ')})`}
                      className="flex items-center justify-center text-white text-[11px] whitespace-nowrap overflow-hidden px-1"
                      style={{ width: `${(p.hours / phaseTotal) * 100}%`, backgroundColor: PHASE_COLORS[p.phase], fontWeight: 700 }}
                    >
                      {(p.hours / phaseTotal) > 0.08 ? `${phaseLabel(p.phase)} ${fmtDuration(p.hours)}` : ''}
                    </div>
                  ))}
                </div>
                <div className="mt-2.5 flex flex-wrap gap-x-4 gap-y-1">
                  {phases.map((p) => (
                    <span key={p.phase} className="inline-flex items-center gap-1.5 text-[12px] text-gray-700 dark:text-gray-300">
                      <span className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: PHASE_COLORS[p.phase] }} />
                      {phaseLabel(p.phase)} {fmtDuration(p.hours)}
                      <span className="text-gray-400">({p.statuses.join(', ')})</span>
                    </span>
                  ))}
                </div>
              </>
            ) : (
              <div className={`text-[12px] ${muted} mt-1`}>{pick('No status history.', 'Brak historii statusów.')}</div>
            )}
          </div>

          {/* KPIs */}
          <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
            <Kpi label={pick('First commit', 'Pierwszy commit')} value={fmtDate(data.firstCommitAt, false)} hint={data.firstCommitAt ? fmtDate(data.firstCommitAt) : pick('no commits with this key', 'brak commitów z tym kluczem')} />
            <Kpi label={pick('Code cycle time', 'Cycle time kodu')} value={fmtDuration(data.codeCycleHours)} hint={pick('first commit → merge', 'pierwszy commit → merge')} />
            <Kpi label="Pickup time" value={fmtDuration(data.pickupHours)} hint={pick('MR opened → first approval', 'MR otwarty → pierwsza akceptacja')} />
            <Kpi label="Review time" value={fmtDuration(data.reviewHours)} hint={pick('first approval → merge', 'pierwsza akceptacja → merge')} />
            <Kpi label={pick('Merged to protected branch', 'Merge do chronionego brancha')} value={fmtDate(data.mergedAt, false)} hint={data.mergedAt ? fmtDate(data.mergedAt) : pick('not merged yet', 'jeszcze nie zmergowane')} />
            <Kpi
              label="Pipeline"
              value={data.pipeline?.minutes != null ? `${data.pipeline.minutes} min` : data.pipeline?.status ?? '—'}
              hint={data.pipeline ? `${data.pipeline.status}${data.pipeline.failedBefore > 0 ? pick(` · ${data.pipeline.failedBefore} failed before`, ` · ${data.pipeline.failedBefore} nieudane wcześniej`) : ''}` : pick('merge commit pipeline', 'pipeline merge commita')}
            />
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-[1.1fr_1fr] gap-4 items-start">
            {/* Timeline */}
            <div className={`${card} p-5`}>
              <h2 className="text-[14px] mb-3" style={{ fontWeight: 600 }}>{pick('Timeline', 'Oś czasu')}</h2>
              <div className="relative ml-2">
                <div className="absolute left-[7px] top-1 bottom-1 w-0.5 bg-gray-200 dark:bg-[#2a2c33]" />
                {data.events.map((e, i) => (
                  <div key={i} className="relative pl-7 pb-3.5 last:pb-0">
                    <span className="absolute left-0 top-0.5 w-4 h-4 rounded-full border-[3px] border-white dark:border-[#121317]" style={{ backgroundColor: PHASE_COLORS[e.phase] ?? '#6b7280' }} />
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <span className="text-[12.5px]" style={{ fontWeight: 600 }}>{eventTitle(e)}</span>
                        <Badge className="ml-1.5 align-[1px]" style={e.source === 'JIRA' ? { backgroundColor: '#dbeafe', color: '#1d4ed8' } : { backgroundColor: '#ffedd5', color: '#c2410c' }}>{e.source === 'JIRA' ? 'JIRA' : 'GITLAB'}</Badge>
                        {e.detail && <div className={`text-[11.5px] ${muted} mt-0.5 break-words`}>{e.detail}</div>}
                      </div>
                      <span className="text-[11px] text-gray-400 whitespace-nowrap">{fmtDate(e.at)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-4 min-w-0">
              {/* Merge requests */}
              <div className={`${card} p-5`}>
                <h2 className="text-[14px] mb-2" style={{ fontWeight: 600 }}>{pick('Merge requests', 'Merge requesty')} ({data.mergeRequests.length})</h2>
                {data.mergeRequests.length === 0 ? (
                  <div className={`text-[12px] ${muted}`}>{pick('No merge requests with this key in the title or merge commit.', 'Brak merge requestów z tym kluczem w tytule lub merge commicie.')}</div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-[12px] min-w-[560px]">
                      <thead><tr className="border-b border-gray-100 dark:border-white/10">
                        <th className={th}>MR</th><th className={th}>{pick('Target', 'Do brancha')}</th><th className={th}>{pick('Approvals', 'Akceptacje')}</th><th className={th}>Review</th><th className={th}>Status</th>
                      </tr></thead>
                      <tbody className="divide-y divide-gray-100 dark:divide-white/5">
                        {data.mergeRequests.map((mr) => (
                          <tr key={`${mr.repository}/${mr.id}`} className="align-top">
                            <td className="py-2 pr-3">
                              <div className="font-mono text-[11.5px]">{mr.id}</div>
                              <div className={`text-[11px] ${muted}`}>{mr.repository}</div>
                              {mr.title && <div className="text-[11px] text-gray-700 dark:text-gray-300 max-w-[220px] truncate" title={mr.title}>{mr.title}</div>}
                            </td>
                            <td className="py-2 pr-3 font-mono text-[11.5px]">{mr.targetBranch ?? '—'}{mr.targetBranchProtected ? ' 🔒' : ''}</td>
                            <td className="py-2 pr-3">
                              {mr.approvals.length === 0 ? '—' : mr.approvals.map((a, i) => (
                                <div key={i}>{a.name}{a.at && <span className="text-gray-400"> ({fmtDate(a.at)})</span>}</div>
                              ))}
                              {mr.comments != null && <div className="text-[11px] text-gray-400">{mr.comments} {pick('comments', 'komentarzy')}</div>}
                            </td>
                            <td className="py-2 pr-3 whitespace-nowrap">{fmtDuration(mr.reviewHours)}</td>
                            <td className="py-2">
                              <Badge
                                className={mr.state === 'merged' ? '' : mr.state === 'closed' ? 'bg-gray-100 text-gray-600 dark:bg-[#2a2c33] dark:text-gray-300' : 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-400'}
                                style={mr.state === 'merged' ? { backgroundColor: '#ede9fe', color: '#6d28d9' } : undefined}
                              >{mr.state ?? '—'}</Badge>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* Commits */}
              <div className={`${card} p-5`}>
                <h2 className="text-[14px] mb-2" style={{ fontWeight: 600 }}>{pick('Commits', 'Commity')} ({visibleCommits.length})</h2>
                {visibleCommits.length === 0 ? (
                  <div className={`text-[12px] ${muted}`}>{pick('No commits with this key in the message (only the default branch is imported).', 'Brak commitów z tym kluczem w opisie (importowany jest tylko domyślny branch).')}</div>
                ) : (
                  <div className="overflow-x-auto max-h-[360px] overflow-y-auto">
                    <table className="w-full text-[12px] min-w-[560px]">
                      <thead><tr className="border-b border-gray-100 dark:border-white/10">
                        <th className={th}>Commit</th><th className={th}>{pick('Message', 'Opis')}</th><th className={th}>{pick('Author', 'Autor')}</th><th className={th}>Repo</th><th className={th}>±</th>
                      </tr></thead>
                      <tbody className="divide-y divide-gray-100 dark:divide-white/5">
                        {visibleCommits.map((c) => (
                          <tr key={`${c.repository}/${c.id}`}>
                            <td className="py-1.5 pr-3 font-mono text-[11.5px]" title={`${c.id} · ${fmtDate(c.date)}`}>{c.id.slice(0, 8)}</td>
                            <td className="py-1.5 pr-3 max-w-[240px] truncate" title={c.title ?? ''}>{c.title ?? '—'}</td>
                            <td className="py-1.5 pr-3 whitespace-nowrap">{c.author ?? '—'}</td>
                            <td className="py-1.5 pr-3">{c.repository}</td>
                            <td className="py-1.5 whitespace-nowrap"><span className="text-emerald-600">+{c.additions ?? 0}</span> <span className="text-red-600">−{c.deletions ?? 0}</span></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* Status history */}
              <div className={`${card} p-5`}>
                <h2 className="text-[14px] mb-2" style={{ fontWeight: 600 }}>{pick('Status history (Jira)', 'Historia statusów (Jira)')}</h2>
                {data.statusChanges.length === 0 ? (
                  <div className={`text-[12px] ${muted}`}>{pick('No status changes.', 'Brak zmian statusu.')}</div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-[12px] min-w-[480px]">
                      <thead><tr className="border-b border-gray-100 dark:border-white/10">
                        <th className={th}>{pick('Change', 'Zmiana')}</th><th className={th}>{pick('By', 'Kto')}</th><th className={th}>{pick('When', 'Kiedy')}</th><th className={th}>{pick('Time in status', 'Czas w statusie')}</th>
                      </tr></thead>
                      <tbody className="divide-y divide-gray-100 dark:divide-white/5">
                        {data.statusChanges.map((s, i) => (
                          <tr key={i}>
                            <td className="py-1.5 pr-3">
                              <span className="inline-block w-2 h-2 rounded-full mr-1.5" style={{ backgroundColor: PHASE_COLORS[s.toPhase] }} />
                              {s.from} → {s.to}
                            </td>
                            <td className="py-1.5 pr-3 whitespace-nowrap">{s.author ?? '—'}</td>
                            <td className="py-1.5 pr-3 whitespace-nowrap">{fmtDate(s.at)}</td>
                            <td className="py-1.5 whitespace-nowrap">{fmtDuration(s.hoursInFrom)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
                <div className="text-[11px] text-gray-400 mt-2">{pick('Phases are mapped from Jira status names (configurable with zenstage.task-timeline.phases); Review = pickup + review time of the merge requests from GitLab.', 'Fazy są mapowane z nazw statusów Jiry (konfigurowalne: zenstage.task-timeline.phases); Review = suma czasu pickup + review merge requestów z GitLaba.')}</div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

export default TaskTimeline;
