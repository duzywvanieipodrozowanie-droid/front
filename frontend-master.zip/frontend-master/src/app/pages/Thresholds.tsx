import { useState } from 'react';
import { SlidersHorizontal, ChevronLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

type Direction = 'above' | 'below';

interface DoraThreshold {
  key: string;
  name: string;
  unit: string; // display unit
  min: number;
  max: number;
  step: number;
  value: number;
  direction: Direction;
  hint?: string;
}

export function Thresholds() {
  const navigate = useNavigate();

  const [globalPolicy, setGlobalPolicy] = useState<'immediate' | 'consecutive'>('immediate');
  const [consecutiveCount, setConsecutiveCount] = useState<number>(3);

  const [items, setItems] = useState<DoraThreshold[]>([
    {
      key: 'df',
      name: 'Deployment Frequency',
      unit: '/week',
      min: 0,
      max: 50,
      step: 1,
      value: 5,
      direction: 'below',
      hint: 'Alert when weekly deployments drop below the threshold.',
    },
    {
      key: 'lt',
      name: 'Lead Time for Changes',
      unit: 'days',
      min: 0,
      max: 30,
      step: 0.5,
      value: 3,
      direction: 'above',
      hint: 'Alert when lead time exceeds the threshold.',
    },
    {
      key: 'cfr',
      name: 'Change Failure Rate',
      unit: '%',
      min: 0,
      max: 100,
      step: 1,
      value: 20,
      direction: 'above',
      hint: 'Alert when failure rate exceeds the threshold percentage.',
    },
    {
      key: 'mttr',
      name: 'Mean Time to Restore',
      unit: 'hours',
      min: 0,
      max: 72,
      step: 1,
      value: 4,
      direction: 'above',
      hint: 'Alert when time to restore exceeds the threshold.',
    },
  ]);

  function updateValue(key: string, next: Partial<DoraThreshold>) {
    setItems((prev) =>
      prev.map((it) =>
        it.key === key
          ? {
              ...it,
              ...next,
              value:
                next.value !== undefined
                  ? Math.min(it.max, Math.max(it.min, Number.isFinite(next.value) ? (next.value as number) : it.value))
                  : it.value,
            }
          : it
      )
    );
  }

  function adjust(key: string, delta: number) {
    const it = items.find((i) => i.key === key);
    if (!it) return;
    const raw = it.value + delta * it.step;
    const snapped = Math.round(raw / it.step) * it.step;
    updateValue(key, { value: Number(snapped.toFixed(4)) });
  }

  function reset() {
    // Reset to initial defaults defined above
    setItems((prev) => prev.map((it) => ({ ...it, value: it.value, direction: it.direction })));
    setGlobalPolicy('immediate');
    setConsecutiveCount(3);
  }

  function save() {
    // No backend specified; in a real app, POST to API.
    // For now, we can optionally store to localStorage to persist across reloads.
    try {
      const payload = { policy: globalPolicy, consecutive: consecutiveCount, thresholds: items };
      localStorage.setItem('dora-thresholds', JSON.stringify(payload));
      // simple visual feedback via alert; could be replaced with a toast lib later
      // eslint-disable-next-line no-alert
      alert('Thresholds saved');
    } catch {}
  }

  return (
    <div className="p-4 sm:p-6 space-y-5">
      {/* Header with Back */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-col items-start gap-2 sm:flex-row sm:items-center sm:gap-3 min-w-0">
          <button
            onClick={() => navigate('/settings')}
            className="shrink-0 flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-gray-200 text-[12px] text-gray-600 hover:bg-gray-50 transition-colors"
            aria-label="Back to Settings"
          >
            <ChevronLeft className="w-4 h-4 text-gray-500" /> Back
          </button>
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-indigo-50 flex items-center justify-center">
              <SlidersHorizontal className="w-4 h-4 text-indigo-600" />
            </div>
            <div>
              <h1 className="text-[20px] text-gray-900" style={{ fontWeight: 700 }}>Setup your thresholds</h1>
              <p className="text-[13px] text-gray-500 mt-0.5">Configure alerting rules for DORA metrics.</p>
            </div>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button onClick={reset} className="px-3 py-2 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 text-[13px] text-gray-700">Reset</button>
          <button onClick={save} className="px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white text-[13px]" style={{ fontWeight: 500 }}>Save</button>
        </div>
      </div>

      {/* Global alerting policy */}
      <section className="bg-white rounded-2xl border border-gray-200 p-5">
        <h2 className="text-[14px] text-gray-900 mb-3" style={{ fontWeight: 600 }}>When to alert</h2>
        <div className="flex flex-wrap items-center gap-3 text-[13px]">
          <label className="inline-flex items-center gap-2">
            <input
              type="radio"
              className="accent-indigo-600"
              name="policy"
              checked={globalPolicy === 'immediate'}
              onChange={() => setGlobalPolicy('immediate')}
            />
            <span className="text-gray-700">Immediately when a metric breaches its threshold</span>
          </label>
          <label className="inline-flex items-center gap-2">
            <input
              type="radio"
              className="accent-indigo-600"
              name="policy"
              checked={globalPolicy === 'consecutive'}
              onChange={() => setGlobalPolicy('consecutive')}
            />
            <span className="text-gray-700">After</span>
          </label>
          {globalPolicy === 'consecutive' && (
            <div className="inline-flex items-center gap-2">
              <input
                type="number"
                min={1}
                max={12}
                value={consecutiveCount}
                onChange={(e) => setConsecutiveCount(Math.max(1, Math.min(12, Number(e.target.value) || 1)))}
                className="w-16 rounded-md border border-gray-200 px-2 py-1 text-[13px] text-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
              <span className="text-gray-700">consecutive breaches</span>
            </div>
          )}
        </div>
      </section>

      {/* DORA thresholds */}
      <section className="bg-white rounded-2xl border border-gray-200 p-5">
        <h2 className="text-[14px] text-gray-900 mb-4" style={{ fontWeight: 600 }}>DORA metrics thresholds</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-2 gap-4">
          {items.map((it) => (
            <div key={it.key} className="rounded-xl border border-gray-200 p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="text-[13px] text-gray-900" style={{ fontWeight: 600 }}>{it.name}</div>
                  {it.hint && <div className="text-[11px] text-gray-400 mt-0.5">{it.hint}</div>}
                </div>
                <div className="shrink-0 whitespace-nowrap text-[12px] text-gray-600 bg-gray-50 border border-gray-200 px-2 py-1 rounded-md">
                  {it.value} {it.unit}
                </div>
              </div>

              {/* Direction selector */}
              <div className="mt-3">
                <label className="text-[11px] text-gray-500 uppercase tracking-wide">Alert direction</label>
                <div className="mt-1 flex items-center gap-2">
                  <select
                    value={it.direction}
                    onChange={(e) => updateValue(it.key, { direction: e.target.value as Direction })}
                    className="text-[13px] rounded-md border border-gray-200 px-2 py-1 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="above">Above threshold</option>
                    <option value="below">Below threshold</option>
                  </select>
                </div>
              </div>

              {/* Slider and +/- */}
              <div className="mt-3">
                <label className="text-[11px] text-gray-500 uppercase tracking-wide">Threshold</label>
                <div className="mt-2 flex items-center gap-2">
                  <button
                    onClick={() => adjust(it.key, -1)}
                    className="w-8 h-8 rounded-md border border-gray-200 text-gray-700 hover:bg-gray-50"
                    aria-label={`Decrease ${it.name}`}
                  >
                    −
                  </button>
                  <input
                    type="range"
                    min={it.min}
                    max={it.max}
                    step={it.step}
                    value={it.value}
                    onChange={(e) => updateValue(it.key, { value: Number(e.target.value) })}
                    className="flex-1 accent-indigo-600"
                  />
                  <button
                    onClick={() => adjust(it.key, +1)}
                    className="w-8 h-8 rounded-md border border-gray-200 text-gray-700 hover:bg-gray-50"
                    aria-label={`Increase ${it.name}`}
                  >
                    +
                  </button>
                </div>
                <div className="mt-1 text-[11px] text-gray-400">
                  Range: {it.min} – {it.max} {it.unit}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

export default Thresholds;
