import React, { useMemo, useState } from 'react';
import { ChevronDown, Gauge, Users, ListChecks, TrendingUp, Activity, Timer, Layers, BarChart3 } from 'lucide-react';
import { useDateRange } from '../context/DateRangeContext';
import { useTeam } from '../context/TeamContext';

// Lightweight visual primitives (no external deps)
function Sparkline({ values, color = '#6366F1' }: { values: number[]; color?: string }) {
  const w = 80, h = 24, pad = 2;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const rng = max - min || 1;
  const ptsArr = values.map((v, i) => {
    const x = pad + (i * (w - pad * 2)) / Math.max(1, values.length - 1);
    const y = h - pad - ((v - min) * (h - pad * 2)) / rng;
    return [x, y] as const;
  });
  const pts = ptsArr.map(([x, y]) => `${x},${y}`).join(' ');
  const baseY = h - pad;
  const firstX = ptsArr[0]?.[0] ?? pad;
  const lastX = ptsArr[ptsArr.length - 1]?.[0] ?? (w - pad);
  const gid = React.useId();
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} className="overflow-visible">
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity={0.28} />
          <stop offset="100%" stopColor={color} stopOpacity={0} />
        </linearGradient>
      </defs>
      {/* Area under the line */}
      <polygon
        fill={`url(#${gid})`}
        stroke="none"
        points={`${pts} ${lastX},${baseY} ${firstX},${baseY}`}
      />
      {/* Line on top */}
      <polyline fill="none" stroke={color} strokeWidth="2" points={pts} strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}

function Donut({ value, color = 'indigo' }: { value: number; color?: 'indigo' | 'emerald' | 'violet' | 'amber' }) {
  const size = 120;
  const stroke = 12;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const off = c * (1 - Math.min(100, Math.max(0, value)) / 100);
  const colorMap: Record<string, string> = {
    indigo: '#6366F1', emerald: '#10B981', violet: '#8B5CF6', amber: '#F59E0B'
  };
  return (
    <svg width={size} height={size} className="block">
      <g transform={`rotate(-90 ${size/2} ${size/2})`}>
        <circle cx={size/2} cy={size/2} r={r} stroke="#E5E7EB" strokeWidth={stroke} fill="none" />
        <circle cx={size/2} cy={size/2} r={r} stroke={colorMap[color]} strokeWidth={stroke} fill="none" strokeDasharray={c} strokeDashoffset={off} strokeLinecap="round" />
      </g>
      <text x="50%" y="50%" dominantBaseline="middle" textAnchor="middle" className="fill-gray-900" style={{fontWeight:700, fontSize: '22px'}}>{Math.round(value)}%</text>
    </svg>
  );
}

function MiniGauge({ now, cap, color = 'indigo' }: { now: number; cap: number; color?: 'indigo' | 'violet' | 'emerald' | 'amber' | 'rose' }) {
  const pct = cap > 0 ? Math.min(150, Math.round((now / cap) * 100)) : 0;
  const col: Record<string,string> = { indigo: '#6366F1', violet:'#8B5CF6', emerald:'#10B981', amber:'#F59E0B', rose:'#F43F5E' };
  const w=120, h=50, r=40, cx=w/2, cy=h+8;
  const start = Math.PI, end = 2*Math.PI; // semi-circle
  const capAngle = start + (end-start) * Math.min(1, pct/100);
  const sx = cx + r*Math.cos(start), sy = cy + r*Math.sin(start);
  const ex = cx + r*Math.cos(capAngle), ey = cy + r*Math.sin(capAngle);
  const capPath = `M ${sx} ${sy} A ${r} ${r} 0 ${pct>50?1:0} 1 ${ex} ${ey}`;
  const basePath = `M ${sx} ${sy} A ${r} ${r} 0 1 1 ${cx+r} ${cy}`;
  return (
    <svg width={w} height={h} className="block">
      <path d={basePath} fill="none" stroke="#E5E7EB" strokeWidth={10} />
      <path d={capPath} fill="none" stroke={col[color]} strokeWidth={10} strokeLinecap="round" />
      <text x="50%" y={h-4} textAnchor="middle" className="fill-gray-700" style={{fontSize: '11px', fontWeight:600}}>{pct}%</text>
    </svg>
  );
}

function StackedBars({ series, colors }: { series: {target?: number; achieved: number[]; labels: string[]} ; colors: string[] }) {
  // Render as a simple line chart with points (keeps API for minimal change)
  const w = 220, h = 100, pad = 12;
  const vals = series.achieved || [];
  const labels = series.labels || [];
  const min = 0; // start at zero for velocity
  const max = Math.max(1, ...vals);
  const innerH = h - 24; // leave space for labels
  const innerW = w - pad * 2;
  const n = Math.max(1, vals.length);
  const color = colors?.[0] || '#6366F1';

  const ptsArr = vals.map((v, i) => {
    const x = pad + (i * innerW) / Math.max(1, n - 1);
    const y = (innerH) - ((v - min) / (max - min)) * (innerH - 8);
    return [x, y] as const;
  });
  const points = ptsArr.map(([x, y]) => `${x},${y}`).join(' ');
  const baseY = innerH;
  const firstX = ptsArr[0]?.[0] ?? pad;
  const lastX = ptsArr[ptsArr.length - 1]?.[0] ?? (w - pad);
  const gid = React.useId();

  return (
    <svg width={w} height={h} className="overflow-visible">
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity={0.22} />
          <stop offset="100%" stopColor={color} stopOpacity={0} />
        </linearGradient>
      </defs>
      {/* area fill */}
      <polygon fill={`url(#${gid})`} stroke="none" points={`${points} ${lastX},${baseY} ${firstX},${baseY}`} />
      {/* line */}
      <polyline fill="none" stroke={color} strokeWidth={2} points={points} strokeLinejoin="round" strokeLinecap="round" />
      {/* points */}
      {vals.map((v, i) => {
        const x = ptsArr[i]?.[0] ?? pad;
        const y = ptsArr[i]?.[1] ?? baseY;
        return (
          <g key={i}>
            <circle cx={x} cy={y} r={3.5} fill="#fff" stroke={color} strokeWidth={2} />
            <text x={x} y={h - 6} textAnchor="middle" className="fill-gray-500" style={{ fontSize: '10px' }}>{labels[i] || ''}</text>
          </g>
        );
      })}
    </svg>
  );
}

// Types for mock agile data
interface DevStats {
  id: string;
  name: string;
  teamId: string;
  current: { startTasks: number; addedTasks: number; doneTasks: number; startSP: number; addedSP: number; doneSP: number; wip: number; };
  history: { // last up to 4 sprints
    sprintId: string;
    tasksDone: number;
    storyPointsDone: number;
  }[];
}

interface TeamSprint {
  sprintId: string;
  name: string;
  startTasks: number;
  addedTasks: number;
  currentTasks: number; // now (start + added - done)
  doneTasks: number;
  startSP: number;
  addedSP: number;
  currentSP: number;
  doneSP: number;
}

interface Team {
  id: string;
  name: string;
  wip: number; // total WIP right now
  current: TeamSprint;
  history: TeamSprint[]; // previous up to 4 including current as [0]
  capacityTasks: number; // capacity marker for tasks (avg over last sprints)
  capacitySP: number; // capacity marker for story points (avg over last sprints)
}

function percent(n: number, d: number): number {
  if (!Number.isFinite(n) || !Number.isFinite(d) || d === 0) return 0;
  return Math.round((n / d) * 100);
}

function Chip({ children, color = 'indigo' }: { children: React.ReactNode; color?: 'indigo' | 'violet' | 'emerald' | 'amber' | 'sky' | 'rose' }) {
  const map: Record<string, string> = {
    indigo: 'bg-indigo-50 text-indigo-700 border-indigo-200',
    violet: 'bg-violet-50 text-violet-700 border-violet-200',
    emerald: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    amber: 'bg-amber-50 text-amber-700 border-amber-200',
    sky: 'bg-sky-50 text-sky-700 border-sky-200',
    rose: 'bg-rose-50 text-rose-700 border-rose-200',
  };
  return <span className={`inline-block text-[11px] px-2 py-0.5 rounded-full border ${map[color]}`} style={{ fontWeight: 600 }}>{children}</span>;
}

// Capacity deviation color helper
function capColor(now: number, capacity: number): 'emerald' | 'amber' | 'rose' {
  if (!Number.isFinite(capacity) || capacity <= 0) return 'amber';
  const ratio = now / capacity;
  if (ratio <= 0.75) return 'amber'; // underutilized (<= -25%)
  if (ratio <= 1.05) return 'emerald'; // within +5%
  return 'rose'; // above capacity by >5%
}

export function Agile() {
  // Mock data (fallback until backend endpoints are available)
  const data = useMemo(() => {
    const sprints = ['S-24.05', 'S-24.06', 'S-24.07', 'S-24.08'];
    const mkTeam = (id: string, name: string, seed: number): Team => {
      function rand(b: number, v: number) { return Math.max(0, Math.round(b + (Math.sin(seed + v) * 3))); }
      const hist: TeamSprint[] = sprints.map((sid, i) => {
        const startTasks = 40 + rand(0, i);
        const addedTasks = 8 + rand(0, i + 1);
        const doneTasks = 38 + rand(0, i + 2);
        const startSP = 120 + rand(0, i + 3) * 2;
        const addedSP = 20 + rand(0, i + 4);
        const doneSP = 115 + rand(0, i + 5);
        const currentTasks = Math.max(0, startTasks + addedTasks - doneTasks);
        const currentSP = Math.max(0, startSP + addedSP - doneSP);
        return { sprintId: sid, name: sid, startTasks, addedTasks, currentTasks, doneTasks, startSP, addedSP, currentSP, doneSP };
      });
      // Derive team capacity markers from recent history (average done per sprint)
      const capTasks = Math.max(1, Math.round(hist.reduce((a, h) => a + h.doneTasks, 0) / Math.max(1, hist.length)));
      const capSP = Math.max(1, Math.round(hist.reduce((a, h) => a + h.doneSP, 0) / Math.max(1, hist.length)));
      const devs: DevStats[] = [
        { id: `${id}-d1`, name: 'Alice Smith', teamId: id, current: { startTasks: 9, addedTasks: 2, doneTasks: 8, startSP: 28, addedSP: 6, doneSP: 26, wip: 3 }, history: sprints.map((s, i) => ({ sprintId: s, tasksDone: 8 + rand(0, i), storyPointsDone: 24 + rand(0, i) })) },
        { id: `${id}-d2`, name: 'Bob Jones', teamId: id, current: { startTasks: 8, addedTasks: 3, doneTasks: 7, startSP: 26, addedSP: 7, doneSP: 22, wip: 4 }, history: sprints.map((s, i) => ({ sprintId: s, tasksDone: 7 + rand(0, i+1), storyPointsDone: 20 + rand(0, i) })) },
        { id: `${id}-d3`, name: 'Carol White', teamId: id, current: { startTasks: 7, addedTasks: 1, doneTasks: 6, startSP: 22, addedSP: 4, doneSP: 20, wip: 3 }, history: sprints.map((s, i) => ({ sprintId: s, tasksDone: 6 + rand(0, i+2), storyPointsDone: 18 + rand(0, i) })) },
      ];
      const current = hist[hist.length - 1];
      const wip = devs.reduce((a, d) => a + d.current.wip, 0);
      return { id, name, wip, current, history: hist, capacityTasks: capTasks, capacitySP: capSP };
    };
    const teams = [mkTeam('t1', 'Frontend', 1), mkTeam('t2', 'Backend', 2), mkTeam('t3', 'Mobile', 3)];

    const devs: DevStats[] = teams.flatMap((t) => [
      { id: `${t.id}-d1`, name: 'Alice Smith', teamId: t.id, current: { startTasks: 9, addedTasks: 2, doneTasks: 8, startSP: 28, addedSP: 6, doneSP: 26, wip: 3 }, history: t.history.map((h) => ({ sprintId: h.sprintId, tasksDone: Math.max(5, Math.round(h.doneTasks/5)), storyPointsDone: Math.max(10, Math.round(h.doneSP/6)) })) },
      { id: `${t.id}-d2`, name: 'Bob Jones', teamId: t.id, current: { startTasks: 8, addedTasks: 3, doneTasks: 7, startSP: 26, addedSP: 7, doneSP: 22, wip: 4 }, history: t.history.map((h) => ({ sprintId: h.sprintId, tasksDone: Math.max(5, Math.round(h.doneTasks/6)), storyPointsDone: Math.max(10, Math.round(h.doneSP/7)) })) },
      { id: `${t.id}-d3`, name: 'Carol White', teamId: t.id, current: { startTasks: 7, addedTasks: 1, doneTasks: 6, startSP: 22, addedSP: 4, doneSP: 20, wip: 3 }, history: t.history.map((h) => ({ sprintId: h.sprintId, tasksDone: Math.max(4, Math.round(h.doneTasks/7)), storyPointsDone: Math.max(8, Math.round(h.doneSP/8)) })) },
    ]);

    return { teams, devs };
  }, []);

  const { label: dateRangeLabel } = useDateRange();
  const { selectedTeamName } = useTeam();
  const [showDetails, setShowDetails] = useState<boolean>(false);
  const teams = data.teams;
  const visibleTeams = selectedTeamName === 'All Teams' ? teams : teams.filter((t) => t.name === selectedTeamName);
  const visibleDevs = selectedTeamName === 'All Teams' ? data.devs : data.devs.filter((d) => teams.find(tt=>tt.name===selectedTeamName)?.id === d.teamId);

  // Aggregations for header KPIs
  const totals = useMemo(() => {
    const cur = visibleTeams.map((t) => t.current);
    const sTasks = cur.reduce((a, c) => a + c.startTasks, 0);
    const aTasks = cur.reduce((a, c) => a + c.addedTasks, 0);
    const dTasks = cur.reduce((a, c) => a + c.doneTasks, 0);
    const cTasks = cur.reduce((a, c) => a + c.currentTasks, 0);

    const sSP = cur.reduce((a, c) => a + c.startSP, 0);
    const aSP = cur.reduce((a, c) => a + c.addedSP, 0);
    const dSP = cur.reduce((a, c) => a + c.doneSP, 0);
    const cSP = cur.reduce((a, c) => a + c.currentSP, 0);

    const predictabilityTasks = percent(dTasks, sTasks + aTasks);
    const predictabilitySP = percent(dSP, sSP + aSP);

    const wip = visibleTeams.reduce((a, t) => a + t.wip, 0);

    return { sTasks, aTasks, dTasks, cTasks, sSP, aSP, dSP, cSP, predictabilityTasks, predictabilitySP, wip };
  }, [visibleTeams]);

  return (
    <div className="p-4 sm:p-6 space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-[20px] text-gray-900" style={{ fontWeight: 700 }}>Agile Portfolio Overview</h1>
          <p className="text-[13px] text-gray-500 mt-0.5">Essential signals to spot bottlenecks and process health.</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="px-2 py-1 rounded-md bg-indigo-50 text-indigo-700 border border-indigo-200 text-[11px] font-semibold">{selectedTeamName}</span>
          <span className="px-2 py-1 rounded-md bg-gray-50 text-gray-700 border border-gray-200 text-[11px]">{dateRangeLabel}</span>
        </div>
      </div>

      {/* KPI row — focus on essentials */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="bg-white rounded-xl border border-gray-200 p-3">
          <div className="text-[11px] text-gray-600" style={{fontWeight:600}}>Predictability (avg)</div>
          <div className="flex items-center justify-between mt-1">
            <div className="text-[22px] text-gray-900 font-bold">{Math.round((totals.predictabilityTasks + totals.predictabilitySP)/2)}%</div>
            <Sparkline values={[70,72,74,76,75,78,80]} color="#10B981" />
          </div>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-3">
          <div className="text-[11px] text-gray-600" style={{fontWeight:600}}>Total WIP</div>
          <div className="flex items-center justify-between mt-1">
            <div className="text-[22px] text-gray-900 font-bold">{totals.wip} items</div>
            <Sparkline values={[16,14,18,17,19,20,21]} color="#059669" />
          </div>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-3">
          <div className="text-[11px] text-gray-600" style={{fontWeight:600}}>Sprint load</div>
          <div className="flex items-center justify-between mt-1">
            <div className="text-[22px] text-gray-900 font-bold">{totals.sSP + totals.aSP} SP</div>
            <Sparkline values={[80,84,86,88,90,92,94]} color="#6366F1" />
          </div>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-3">
          <div className="text-[11px] text-gray-600" style={{fontWeight:600}}>Avg cycle time</div>
          <div className="flex items-center justify-between mt-1">
            <div className="text-[22px] text-gray-900 font-bold">4 days</div>
            <Sparkline values={[5,5,4,4,3,4,4]} color="#22C55E" />
          </div>
        </div>
      </div>

      {/* Status now by workflow (mocked) */}
      {(() => {
        const inProgress = totals.cTasks; // proxy for items currently in progress
        const done = totals.dTasks;
        const planned = totals.sTasks + totals.aTasks;
        const todo = Math.max(0, planned - done - inProgress);
        const blocked = Math.round(inProgress * 0.1); // mock 10% of in-progress
        return (
          <div className="bg-white rounded-xl border border-gray-200 p-3">
            <div className="flex items-center justify-between mb-2">
              <div className="text-[12px] text-gray-600 font-semibold">Status now — {selectedTeamName} · {dateRangeLabel}</div>
              <div className="text-[11px] text-gray-500">mocked distribution</div>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-2 text-[12px]">
              <div className="flex items-center gap-2 p-2 rounded-lg border border-emerald-200 bg-emerald-50"><span className="w-2.5 h-2.5 rounded-full bg-emerald-500"/> <span className="text-gray-700">Done</span> <span className="ml-auto font-semibold text-gray-900">{done}</span></div>
              <div className="flex items-center gap-2 p-2 rounded-lg border border-indigo-200 bg-indigo-50"><span className="w-2.5 h-2.5 rounded-full bg-indigo-500"/> <span className="text-gray-700">In Progress</span> <span className="ml-auto font-semibold text-gray-900">{inProgress}</span></div>
              <div className="flex items-center gap-2 p-2 rounded-lg border border-gray-200 bg-gray-50"><span className="w-2.5 h-2.5 rounded-full bg-gray-400"/> <span className="text-gray-700">To Do</span> <span className="ml-auto font-semibold text-gray-900">{todo}</span></div>
              <div className="flex items-center gap-2 p-2 rounded-lg border border-rose-200 bg-rose-50"><span className="w-2.5 h-2.5 rounded-full bg-rose-500"/> <span className="text-gray-700">Blocked</span> <span className="ml-auto font-semibold text-gray-900">{blocked}</span></div>
              <div className="hidden lg:flex items-center gap-2 p-2 rounded-lg border border-amber-200 bg-amber-50"><span className="w-2.5 h-2.5 rounded-full bg-amber-500"/> <span className="text-gray-700">Planned</span> <span className="ml-auto font-semibold text-gray-900">{planned}</span></div>
            </div>
          </div>
        );
      })()}

      {/* Main grid: left analytics, right performance */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        {/* Left column */}
        <div className="space-y-4">
          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <div className="text-[12px] text-gray-500 mb-2 font-semibold">Current Sprint Dashboard</div>
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-4">
                <Donut value={percent(totals.dTasks, totals.sTasks + totals.aTasks)} color="emerald" />
                <div className="text-[12px] text-gray-700 space-y-1">
                  <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full bg-emerald-500"/> Done</div>
                  <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full bg-indigo-500"/> In Progress</div>
                  <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full bg-gray-300"/> To Do</div>
                  <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full bg-rose-400"/> Blocked</div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3 text-[12px]">
                {visibleTeams.slice(0,3).map((t)=>{
                  const pct = percent(t.current.doneTasks, t.current.startTasks + t.current.addedTasks);
                  return (
                    <div key={t.id} className="border border-gray-200 rounded-lg p-3">
                      <div className="text-gray-700 font-semibold mb-1">{t.name}</div>
                      <MiniGauge now={t.current.doneSP} cap={t.capacitySP} color={pct>=90?'emerald':'amber'} />
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <div className="text-[12px] text-gray-500 mb-2 font-semibold">Sprint Velocity Trend</div>
            <StackedBars series={{ achieved: visibleTeams[0]?.history.slice(-4).map(h=>h.doneSP) || [80,90,85,92], labels: visibleTeams[0]?.history.slice(-4).map(h=>h.name) || ['S1','S2','S3','S4'] }} colors={["#6366F1","#A78BFA","#60A5FA","#22C55E"]} />
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <div className="text-[12px] text-gray-500 mb-2 font-semibold">Issue Type Breakdown (last 4 sprints)</div>
            <div className="flex items-center gap-6">
              <Donut value={62} color="amber" />
              <div className="grid grid-cols-2 gap-x-6 gap-y-1 text-[12px] text-gray-700">
                <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full bg-indigo-500"/> Features</div>
                <div className="text-right font-semibold">45%</div>
                <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full bg-amber-500"/> Bugs</div>
                <div className="text-right font-semibold">18%</div>
                <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full bg-emerald-500"/> Chores</div>
                <div className="text-right font-semibold">22%</div>
                <div className="flex items-center gap-2"><span className="w-2.5 h-2.5 rounded-full bg-gray-400"/> Others</div>
                <div className="text-right font-semibold">15%</div>
              </div>
            </div>
          </div>
        </div>

        {/* Right column */}
        <div className="space-y-4">
          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="text-[12px] text-gray-500 font-semibold">Historical Performance & Trends</div>
              <div className="flex items-center gap-2 text-[11px]">
                <span className="px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200 font-semibold">High risk developers</span>
                <span className="px-2 py-0.5 rounded bg-gray-50 text-gray-600 border border-gray-200">High performers</span>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex-1">
                <div className="text-[12px] text-gray-700 mb-1 font-semibold">Sprint Predictability Trend</div>
                <Sparkline values={visibleTeams[0]?.history.slice(-4).map(h=>percent(h.doneSP, h.startSP + h.addedSP)) || [70,78,82,85]} color="#22C55E" />
              </div>
              <div className="flex-1">
                <div className="text-[12px] text-gray-700 mb-1 font-semibold">Team Health</div>
                <Sparkline values={[60,62,65,68,70,72,72]} color="#F59E0B" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-0 overflow-hidden">
            <div className="px-4 py-3 border-b border-gray-100 text-[12px] text-gray-500 font-semibold">Developer Performance & Risks</div>
            <div className="divide-y divide-gray-100">
              {visibleDevs.slice(0,9).map((d,i)=>{
                const nowTasks = Math.max(0, d.current.startTasks + d.current.addedTasks - d.current.doneTasks);
                const pTasks = percent(d.current.doneTasks, d.current.startTasks + d.current.addedTasks);
                const risk = d.current.wip>2 || pTasks<80;
                return (
                  <div key={d.id} className={`grid grid-cols-12 gap-2 px-4 py-2 items-center ${i%2===0?'bg-white':'bg-gray-50'}`}>
                    <div className="col-span-4 flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full bg-gradient-to-br from-indigo-400 to-violet-500 text-white flex items-center justify-center text-[10px] font-bold">{d.name.split(' ').map(p=>p[0]).join('').slice(0,2)}</div>
                      <div className="text-[12px] text-gray-900 font-semibold">{d.name}</div>
                    </div>
                    <div className="col-span-3 text-[12px] text-gray-700">Current: {nowTasks} tasks, {Math.max(0, d.current.startSP + d.current.addedSP - d.current.doneSP)} SP</div>
                    <div className="col-span-1 text-[12px] text-gray-700"><span className={`px-2 py-0.5 rounded-full border text-[12px] font-semibold ${d.current.wip>2?'bg-rose-50 text-rose-700 border-rose-200':'bg-emerald-50 text-emerald-700 border-emerald-200'}`}>{d.current.wip}</span></div>
                    <div className="col-span-2 text-[12px] text-gray-700">Predict: <span className={`px-1.5 py-0.5 rounded ${pTasks>=90?'bg-emerald-50 text-emerald-700':'bg-amber-50 text-amber-700'}`} style={{fontWeight:600}}>{pTasks}%</span></div>
                    <div className="col-span-2 text-[12px] text-gray-700">{risk? 'At Risk — check assignment' : 'Healthy'}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Legacy detailed tables below */}
      <div className="flex items-center justify-between bg-white border border-gray-200 rounded-xl px-3 py-2">
        <div className="text-[12px] text-gray-600" style={{fontWeight:600}}>Detailed tables</div>
        <button
          onClick={() => setShowDetails(v => !v)}
          className="text-[12px] px-2.5 py-1 rounded-lg border border-gray-300 bg-gray-50 hover:bg-gray-100 text-gray-700"
        >{showDetails ? 'Hide details' : 'Show details'}</button>
      </div>

      {showDetails && (<>
      {/* Per-team current sprint table */}
      <section className="space-y-3">
        <h2 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>Current sprint — per team</h2>
        <div className="bg-white rounded-2xl border border-gray-200 overflow-x-auto">
          <div className="min-w-[900px]">
            {/* Header row */}
            <div className="sticky top-0 z-10 grid grid-cols-[180px_120px_80px_80px_repeat(4,80px)_repeat(4,80px)_80px] gap-2 px-4 py-2 bg-gray-50/95 backdrop-blur-sm border-b border-gray-100 text-[11px] text-gray-600 shadow-sm">
              <div className="font-semibold text-gray-600">Team</div>
              <div className="font-semibold text-gray-600">Predictability</div>
              <div className="text-center font-semibold">Cap T</div>
              <div className="text-center font-semibold">Cap SP</div>
              <div className="text-center">Tasks Now</div>
              <div className="text-center">Start</div>
              <div className="text-center">+Added</div>
              <div className="text-center">Done</div>
              <div className="text-center">SP Now</div>
              <div className="text-center">Start</div>
              <div className="text-center">+Added</div>
              <div className="text-center">Done</div>
              <div className="text-center">WIP</div>
            </div>
            {/* Rows */}
            <div className="divide-y divide-gray-100">
              {visibleTeams.map((t, idx) => {
                const pTasks = percent(t.current.doneTasks, t.current.startTasks + t.current.addedTasks);
                const pSP = percent(t.current.doneSP, t.current.startSP + t.current.addedSP);
                const predictGood = pTasks >= 90 && pSP >= 90;
                const rowBg = idx % 2 === 0 ? 'bg-white' : 'bg-gray-50';
                return (
                  <div key={t.id} className={`grid grid-cols-[180px_120px_80px_80px_repeat(4,80px)_repeat(4,80px)_80px] gap-2 px-4 py-2.5 items-center ${rowBg} hover:bg-gray-50 transition-colors`}>
                    {/* Team */}
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-indigo-50 flex items-center justify-center"><BarChart3 className="w-4 h-4 text-indigo-500" /></div>
                      <div className="text-[13px] text-gray-900 font-semibold">{t.name}</div>
                    </div>
                    {/* Predictability */}
                    <div className="text-[12px]">
                      <Chip color={predictGood ? 'emerald' : 'amber'}>{pTasks}% / {pSP}%</Chip>
                    </div>
                    {/* Capacity markers */}
                    <div className="text-center text-[12px] text-gray-700"><Chip color="sky">{t.capacityTasks}</Chip></div>
                    <div className="text-center text-[12px] text-gray-700"><Chip color="violet">{t.capacitySP}</Chip></div>
                    {/* Tasks */}
                    <div className="text-center text-[12px] text-gray-700 font-semibold"><Chip color={capColor(t.current.currentTasks, t.capacityTasks)}>{t.current.currentTasks}</Chip></div>
                    <div className="text-center text-[12px] text-gray-700">{t.current.startTasks}</div>
                    <div className="text-center text-[12px] text-gray-700">{t.current.addedTasks}</div>
                    <div className="text-center text-[12px] text-gray-700">{t.current.doneTasks}</div>
                    {/* Story Points */}
                    <div className="text-center text-[12px] text-gray-700 font-semibold"><Chip color={capColor(t.current.currentSP, t.capacitySP)}>{t.current.currentSP}</Chip></div>
                    <div className="text-center text-[12px] text-gray-700">{t.current.startSP}</div>
                    <div className="text-center text-[12px] text-gray-700">{t.current.addedSP}</div>
                    <div className="text-center text-[12px] text-gray-700">{t.current.doneSP}</div>
                    {/* WIP */}
                    <div className="text-center text-[12px] text-gray-700">
                      <Chip color={t.wip > 2 ? 'rose' : 'emerald'}>{t.wip}</Chip>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* History last 4 sprints */}
      <section className="space-y-3">
        <h2 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>History — last 4 sprints</h2>
        <div className="bg-white rounded-2xl border border-gray-200 p-4 overflow-x-auto">
          <div className="min-w-[680px] grid grid-cols-[140px_repeat(4,1fr)] gap-2 text-[12px]">
            <div className="text-gray-500" />
            {visibleTeams[0]?.history.map((h, i) => (
              <div key={i} className="text-gray-700 text-center font-semibold bg-gray-50 border border-gray-100 rounded-lg py-1">{h.name}</div>
            ))}
            {visibleTeams.map((t) => (
              <React.Fragment key={t.id}>
                <div className="text-gray-900 font-semibold flex items-center">{t.name}</div>
                {t.history.map((h, i) => (
                  <div key={i} className="border border-gray-100 rounded-lg p-2 bg-white">
                    <div className="grid grid-cols-2 gap-x-3 gap-y-1">
                      <div className="text-gray-500">Tasks</div>
                      <div className="text-right text-gray-700">{h.doneTasks}/{h.startTasks + h.addedTasks} <Chip color={percent(h.doneTasks, h.startTasks + h.addedTasks) >= 90 ? 'emerald' : 'amber'}>{percent(h.doneTasks, h.startTasks + h.addedTasks)}%</Chip></div>
                      <div className="text-gray-500">Story Pts</div>
                      <div className="text-right text-gray-700">{h.doneSP}/{h.startSP + h.addedSP} <Chip color={percent(h.doneSP, h.startSP + h.addedSP) >= 90 ? 'emerald' : 'amber'}>{percent(h.doneSP, h.startSP + h.addedSP)}%</Chip></div>
                    </div>
                  </div>
                ))}
              </React.Fragment>
            ))}
          </div>
        </div>
      </section>

      {/* Per-developer breakdown */}
      <section className="space-y-3">
        <h2 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>Developers — load and predictability</h2>
        <div className="bg-white rounded-2xl border border-gray-200 divide-y divide-gray-100 overflow-hidden">
          <div className="hidden md:grid grid-cols-12 gap-2 px-4 py-2 text-[11px] text-gray-500 bg-gray-50">
            <div className="col-span-3">Developer</div>
            <div className="col-span-2">Current: Tasks (Now/Start/+Added/Done)</div>
            <div className="col-span-2">Current: Story Points (Now/Start/+Added/Done)</div>
            <div className="col-span-1">WIP</div>
            <div className="col-span-2">Avg per sprint (4): Tasks / SP</div>
            <div className="col-span-2">Predictability (Tasks/SP)</div>
          </div>
          {visibleDevs.map((d, idx) => {
            const nowTasks = Math.max(0, d.current.startTasks + d.current.addedTasks - d.current.doneTasks);
            const nowSP = Math.max(0, d.current.startSP + d.current.addedSP - d.current.doneSP);
            const avgTasks = Math.round(d.history.reduce((a, h) => a + h.tasksDone, 0) / Math.max(1, d.history.length));
            const avgSP = Math.round(d.history.reduce((a, h) => a + h.storyPointsDone, 0) / Math.max(1, d.history.length));
            const pTasks = percent(d.current.doneTasks, d.current.startTasks + d.current.addedTasks);
            const pSP = percent(d.current.doneSP, d.current.startSP + d.current.addedSP);
            const rowBg = idx % 2 === 0 ? 'bg-white' : 'bg-gray-50';
            return (
              <div key={d.id} className={`grid grid-cols-12 gap-2 px-4 py-3 items-center ${rowBg} hover:bg-gray-50 transition-colors`}>
                <div className="col-span-12 md:col-span-3">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-400 to-violet-500 text-white flex items-center justify-center text-[11px] font-bold">
                      {d.name.split(' ').map(p=>p[0]).join('').slice(0,2)}
                    </div>
                    <div>
                      <div className="text-[13px] text-gray-900 font-semibold">{d.name}</div>
                      <div className="text-[11px] text-gray-500">Team: {teams.find(t=>t.id===d.teamId)?.name || '—'}</div>
                    </div>
                  </div>
                </div>
                <div className="col-span-6 md:col-span-2 text-[12px] text-gray-700">
                  <div>Now: <span className="font-semibold">{nowTasks}</span></div>
                  <div>Start: <span className="font-semibold">{d.current.startTasks}</span> · +<span className="font-semibold">{d.current.addedTasks}</span> · Done: <span className="font-semibold">{d.current.doneTasks}</span></div>
                </div>
                <div className="col-span-6 md:col-span-2 text-[12px] text-gray-700">
                  <div>Now: <span className="font-semibold">{nowSP}</span></div>
                  <div>Start: <span className="font-semibold">{d.current.startSP}</span> · +<span className="font-semibold">{d.current.addedSP}</span> · Done: <span className="font-semibold">{d.current.doneSP}</span></div>
                </div>
                <div className="col-span-6 md:col-span-1 text-[12px] text-gray-700"><Chip color={d.current.wip > 2 ? 'rose' : 'emerald'}>WIP {d.current.wip}</Chip></div>
                <div className="col-span-6 md:col-span-2 text-[12px] text-gray-700">{avgTasks} / {avgSP}</div>
                <div className="col-span-12 md:col-span-2 text-[12px] text-gray-700">
                  <Chip color={pTasks >= 90 ? 'emerald' : 'amber'}>{pTasks}%</Chip>
                  <span className="mx-1">/</span>
                  <Chip color={pSP >= 90 ? 'emerald' : 'amber'}>{pSP}%</Chip>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      </>)}

      {/* Notes */}
      <div className="rounded-xl border border-gray-200 bg-white p-4">
        <div className="flex items-start gap-2">
          <Timer className="w-4 h-4 text-gray-400 mt-0.5" />
          <p className="text-[12px] text-gray-600">
            This view uses the last four sprints to estimate team and individual predictability. Replace mock data by wiring to your Jira API or internal endpoints.
          </p>
        </div>
      </div>
    </div>
  );
}

export default Agile;
