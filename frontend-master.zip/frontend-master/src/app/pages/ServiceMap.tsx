import { useEffect, useMemo, useState } from 'react';
import { ArrowRight, Boxes, CheckCircle2, Columns3, FlaskConical, GitCommitHorizontal, GitCompareArrows, Info, RefreshCw, Search, Tag, Ticket, X, type LucideIcon } from 'lucide-react';
import type { ReactNode } from 'react';
import { usePick } from '../i18n';

// Service map: which version of every microservice (module) runs on which environment, from core /api/codemap/modules.
// The CI pipelines report every deployment with PUT /v1/environment/release?projectId=&env= {module, image, version};
// /api/environment gives the projects with their environments in the promotion order (e.g. dev -> test -> prod).
// The diff of an environment goes to the next one: Jira issues, commits and tags in it and not yet in the next one.

type TagDiff = { issues: string[] | null; commits: string[] | null; tags: string[] | null };
type ModuleEnv = { name: string; image: string | null; tag: string | null; diff: TagDiff | null };
type CodeMapModule = { projectId: string | null; module: string | null; envs: ModuleEnv[] | null };
type Project = { id: string; label: string | null; envs: string[] | null };

/** Jira issues in one version of a module (core /api/codemap/issues): by Fix Version and by the release tasks with it. */
type VersionIssue = { key: string; summary: string | null; type: string | null; status: string | null; assignee: string | null; url: string | null; source: string };
type VersionIssues = { module: string; tag: string; fixVersions: string[]; issues: VersionIssue[]; otherVersions: string[] };
/** A version clicked on the map: the module on {@code env}. */
type Version = { project: string; module: string; env: string; entry: ModuleEnv };

/** A step of the promotion: the module on {@code env} and what of it is not yet on {@code next}. */
type Step = { project: string; module: string; env: string; next: string; from: ModuleEnv; to: ModuleEnv | null };

const REFRESH_MS = 60_000;
const card = 'bg-white dark:bg-[#121317] rounded-xl border border-gray-200 dark:border-white/10';
const muted = 'text-gray-500 dark:text-gray-400';
const inputCls =
  'rounded-lg border border-gray-200 bg-white px-2.5 py-1.5 text-[12.5px] text-gray-800 outline-none focus:border-blue-400 dark:border-white/10 dark:bg-white/5 dark:text-gray-100';
const C = { synced: '#10b981', pending: '#f59e0b', missing: '#9ca3af' };

// shown by default (by name, any case); the other environments (dev, test...) are hidden until turned on
const SHOWN_ENVS = ['alfa', 'alpha', 'beta', 'prod'];
const HIDDEN_ENVS_KEY = 'serviceMap.envVisibility';
const shownByDefault = (name: string) => SHOWN_ENVS.includes(name.toLowerCase());

const count = (list: string[] | null | undefined) => (Array.isArray(list) ? list.length : 0);

/** Environments of the project in the promotion order, then the ones only seen in the reported states. */
function envOrder(project: Project | undefined, modules: CodeMapModule[]): string[] {
  const order = [...(project?.envs ?? [])];
  modules.forEach((m) => (m.envs ?? []).forEach((e) => { if (e.name && !order.includes(e.name)) order.push(e.name); }));
  return order;
}

// the master branch environment (e.g. ArgoCD) is what runs on PROD: shown as prod, a reported prod wins
const MASTER_ENV = 'master';
const PROD_ENV = 'prod';
const isMaster = (name: string | null | undefined) => (name ?? '').toLowerCase() === MASTER_ENV;
const withMasterAsProd = (m: CodeMapModule): CodeMapModule => {
  const envs = m.envs ?? [];
  if (!envs.some((e) => isMaster(e.name))) return m;
  const hasProd = envs.some((e) => e.name?.toLowerCase() === PROD_ENV);
  return { ...m, envs: envs.flatMap((e) => (!isMaster(e.name) ? [e] : hasProd ? [] : [{ ...e, name: PROD_ENV }])) };
};
const projectWithMasterAsProd = (p: Project): Project => {
  if (!(p.envs ?? []).some(isMaster)) return p;
  const envs: string[] = [];
  (p.envs ?? []).forEach((e) => { const name = isMaster(e) ? PROD_ENV : e; if (!envs.some((it) => it.toLowerCase() === name.toLowerCase())) envs.push(name); });
  return { ...p, envs };
};

const union = (lists: Array<string[] | null | undefined>) => [...new Set(lists.flatMap((it) => it ?? []))];

/**
 * What is on {@code from} and not yet on {@code to} (or the other way round, whichever is earlier in the order): core gives
 * the diff of every environment of the module to its next one, so the diffs between the two are joined (also over hidden ones).
 */
function chainDiff(m: CodeMapModule, order: string[], from: string, to: string): TagDiff {
  const [lo, hi] = [order.indexOf(from), order.indexOf(to)].sort((a, b) => a - b);
  const between = (m.envs ?? []).filter((e) => { const i = order.indexOf(e.name); return i >= lo && i < hi; });
  return {
    issues: union(between.map((e) => e.diff?.issues)),
    commits: union(between.map((e) => e.diff?.commits)),
    tags: union(between.map((e) => e.diff?.tags)),
  };
}

export function ServiceMap() {
  const pick = usePick();
  const [modules, setModules] = useState<CodeMapModule[] | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loadedAt, setLoadedAt] = useState<Date | null>(null);
  const [reload, setReload] = useState(0);
  const [project, setProject] = useState('all');
  const [query, setQuery] = useState('');
  const [pendingOnly, setPendingOnly] = useState(false);
  const [step, setStep] = useState<Step | null>(null);
  const [version, setVersion] = useState<Version | null>(null);
  const [panel, setPanel] = useState<'compare' | 'test-way' | null>(null);
  // environments turned on / off by the user (kept in this browser); the others follow SHOWN_ENVS
  const [envVisibility, setEnvVisibility] = useState<Record<string, boolean>>(() => {
    try { return JSON.parse(localStorage.getItem(HIDDEN_ENVS_KEY) ?? '{}') ?? {}; } catch { return {}; }
  });
  const envVisible = (name: string) => envVisibility[name] ?? shownByDefault(name);
  const toggleEnv = (name: string) => {
    const next = { ...envVisibility, [name]: !envVisible(name) };
    setEnvVisibility(next);
    try { localStorage.setItem(HIDDEN_ENVS_KEY, JSON.stringify(next)); } catch { /* private mode */ }
  };

  useEffect(() => {
    let cancelled = false;
    let stream: EventSource | undefined;
    const isModule = (it: CodeMapModule | null) => !!it?.projectId && !!it?.module;

    // a core without /codemap/modules: the event stream /api/codemap (all modules first, then every change live)
    const listen = () => {
      const byKey = new Map<string, CodeMapModule>();
      let flush: ReturnType<typeof setTimeout> | undefined;
      stream = new EventSource('/api/codemap', { withCredentials: true });
      stream.onmessage = (event) => {
        try {
          const it: CodeMapModule = JSON.parse(event.data);
          if (!isModule(it)) return; // heartbeat
          byKey.set(`${it.projectId}/${it.module}`, it);
          clearTimeout(flush);
          flush = setTimeout(() => {
            if (cancelled) return;
            setModules([...byKey.values()].map(withMasterAsProd));
            setLoadedAt(new Date());
            setError(null);
          }, 200);
        } catch {
          // not a module
        }
      };
      stream.onopen = () => { if (!cancelled) setModules((m) => m ?? []); };
      stream.onerror = () => { if (!cancelled && byKey.size === 0) setError(pick('event stream /api/codemap failed', 'strumień /api/codemap nie działa')); };
    };

    const load = async () => {
      try {
        const [m, p] = await Promise.all([
          fetch('/api/codemap/modules', { credentials: 'include' }),
          fetch('/api/environment', { credentials: 'include' }),
        ]);
        const projectList: Project[] = p.ok ? await p.json() : [];
        if (cancelled) return;
        setProjects(Array.isArray(projectList) ? projectList.map(projectWithMasterAsProd) : []);
        if (m.status === 401 || m.status === 403) throw new Error(`HTTP ${m.status}`);
        if (!m.ok) {
          clearInterval(timer);
          if (!stream) listen();
          return;
        }
        const list: CodeMapModule[] = await m.json();
        if (cancelled) return;
        setModules(list.filter(isModule).map(withMasterAsProd));
        setLoadedAt(new Date());
        setError(null);
      } catch (e) {
        if (!cancelled) setError(e instanceof Error ? e.message : String(e));
      }
    };
    // load() clears it only after its first await, when the timer exists
    load();
    const timer = setInterval(load, REFRESH_MS);
    return () => { cancelled = true; clearInterval(timer); stream?.close(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reload]);

  const projectById = useMemo(() => new Map(projects.map((it) => [it.id, it])), [projects]);
  const label = (id: string) => projectById.get(id)?.label || id;

  // project -> its modules (filtered) and environments
  const groups = useMemo(() => {
    const byProject = new Map<string, CodeMapModule[]>();
    (modules ?? []).forEach((m) => {
      const list = byProject.get(m.projectId!) ?? [];
      list.push(m);
      byProject.set(m.projectId!, list);
    });
    const q = query.trim().toLowerCase();
    return [...byProject.entries()]
      .filter(([id]) => project === 'all' || id === project)
      .map(([id, list]) => {
        const order = envOrder(projectById.get(id), list);
        const envs = order.filter(envVisible);
        const rows = list
          .filter((m) => (m.envs ?? []).some((e) => envVisible(e.name)))
          .filter((m) => !q || m.module!.toLowerCase().includes(q) || (m.envs ?? []).some((e) => (e.tag ?? '').toLowerCase().includes(q)))
          .map((m) => {
            const byEnv = new Map((m.envs ?? []).map((e) => [e.name, e]));
            const steps = envs.slice(0, -1).map((env, i) => {
              const found = byEnv.get(env);
              const to = byEnv.get(envs[i + 1]) ?? null;
              const pending = !!found && (!to || found.tag !== to.tag);
              // the diff to the next shown environment, over the hidden ones between
              const from = found && { ...found, diff: chainDiff(m, order, env, envs[i + 1]) };
              return { env, next: envs[i + 1], from, to, pending };
            });
            return { m, byEnv, steps, pending: steps.some((s) => s.pending) };
          })
          .filter((r) => !pendingOnly || r.pending);
        return { id, envs, rows };
      })
      .filter((g) => g.rows.length > 0)
      .sort((a, b) => label(a.id).localeCompare(label(b.id)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [modules, projectById, project, query, pendingOnly, envVisibility]);

  // every module with the environments of its project in the promotion order (compare, test-way)
  const allModules = useMemo(() => {
    const byProject = new Map<string, CodeMapModule[]>();
    (modules ?? []).forEach((m) => byProject.set(m.projectId!, [...(byProject.get(m.projectId!) ?? []), m]));
    return [...byProject.entries()].flatMap(([id, list]) => {
      const order = envOrder(projectById.get(id), list);
      return list.map((m) => ({ m, order }));
    });
  }, [modules, projectById]);
  const allEnvNames = useMemo(() => {
    const names: string[] = [];
    allModules.forEach(({ order }) => order.forEach((it) => { if (!names.includes(it)) names.push(it); }));
    return names;
  }, [allModules]);

  const allRows = groups.flatMap((g) => g.rows);
  const pendingRows = allRows.filter((r) => r.pending).length;
  const waitingIssues = new Set(allRows.flatMap((r) => r.steps.filter((s) => s.pending).flatMap((s) => s.from?.diff?.issues ?? []))).size;
  const envCount = new Set(groups.flatMap((g) => g.envs)).size;
  const projectIds = [...new Set((modules ?? []).map((m) => m.projectId!))].sort((a, b) => label(a).localeCompare(label(b)));

  return (
    <div className="p-4 md:p-6 space-y-4 text-gray-900 dark:text-gray-100">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-[22px] flex items-center gap-2" style={{ fontWeight: 800 }}>
            <Boxes className="w-6 h-6 text-blue-600" /> {pick('Service map', 'Mapa serwisów')}
          </h1>
          <p className={`text-[13px] mt-0.5 ${muted}`}>
            {pick('Which version of every microservice runs on which environment, and what waits for the next one',
              'Która wersja każdego mikroserwisu jest na którym środowisku i co czeka na promocję na kolejne')}
          </p>
        </div>
        <div className={`flex items-center gap-2 text-[11.5px] ${muted}`}>
          {loadedAt && <span>{pick('Updated', 'Aktualizacja')} {loadedAt.toLocaleTimeString(pick('en-GB', 'pl-PL'), { timeStyle: 'short' })}</span>}
          <button onClick={() => setReload((r) => r + 1)} className="p-1.5 rounded-md hover:bg-gray-100 dark:hover:bg-white/10" title={pick('Refresh', 'Odśwież')}>
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          [pick('Microservices', 'Mikroserwisy'), allRows.length, null],
          [pick('Environments', 'Środowiska'), envCount, null],
          [pick('Same version everywhere', 'Ta sama wersja wszędzie'), allRows.length - pendingRows, C.synced],
          [pick('Waiting for promotion', 'Czekają na promocję'), pendingRows, C.pending],
        ].map(([title, value, color]) => (
          <div key={String(title)} className={`${card} p-4`}>
            <div className={`text-[12px] ${muted} flex items-center gap-1.5`}>
              {color && <span className="w-2 h-2 rounded-full" style={{ backgroundColor: String(color) }} />}{title}
            </div>
            <div className="text-[28px] leading-tight mt-1" style={{ fontWeight: 700 }}>{modules ? value : '…'}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className={`${card} px-4 py-3 flex flex-wrap items-center gap-3`}>
        <select className={inputCls} value={project} onChange={(e) => setProject(e.target.value)}>
          <option value="all">{pick('All projects', 'Wszystkie projekty')}</option>
          {projectIds.map((id) => <option key={id} value={id}>{label(id)}</option>)}
        </select>
        <div className="relative">
          <Search className="w-4 h-4 text-gray-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
          <input className={`${inputCls} pl-8 w-64`} value={query} onChange={(e) => setQuery(e.target.value)}
                 placeholder={pick('Microservice or version', 'Mikroserwis lub wersja')} />
        </div>
        <label className="inline-flex items-center gap-1.5 text-[12.5px] cursor-pointer">
          <input type="checkbox" className="accent-blue-600" checked={pendingOnly} onChange={(e) => setPendingOnly(e.target.checked)} />
          {pick('Only waiting for promotion', 'Tylko czekające na promocję')}
        </label>
        <button onClick={() => setPanel('compare')} disabled={!modules?.length}
          className="inline-flex items-center gap-1.5 rounded-lg border border-gray-200 dark:border-white/10 px-2.5 py-1.5 text-[12.5px] hover:bg-gray-50 dark:hover:bg-white/5 disabled:opacity-50">
          <GitCompareArrows className="w-4 h-4 text-blue-600" />{pick('Compare environments', 'Porównanie środowisk')}
        </button>
        <button onClick={() => setPanel('test-way')} disabled={!modules?.length}
          className="inline-flex items-center gap-1.5 rounded-lg border border-gray-200 dark:border-white/10 px-2.5 py-1.5 text-[12.5px] hover:bg-gray-50 dark:hover:bg-white/5 disabled:opacity-50">
          <FlaskConical className="w-4 h-4 text-blue-600" />Test-way
        </button>
        <div className="flex-1" />
        <div className={`flex flex-wrap items-center gap-3 text-[11.5px] ${muted}`}>
          <span className="inline-flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: C.synced }} />{pick('same as next env', 'jak na następnym')}</span>
          <span className="inline-flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: C.pending }} />{pick('newer than next env', 'nowsza niż na następnym')}</span>
          <span className="inline-flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-sm border border-dashed border-gray-400" />{pick('not deployed', 'brak wdrożenia')}</span>
        </div>
      </div>

      {allEnvNames.length > 0 && (
        <div className={`flex flex-wrap items-center gap-1.5 text-[12px] ${muted}`}>
          <Columns3 className="w-4 h-4" />{pick('Environments:', 'Środowiska:')}
          {allEnvNames.map((env) => (
            <button key={env} onClick={() => toggleEnv(env)}
              title={envVisible(env) ? pick('Hide the column', 'Ukryj kolumnę') : pick('Show the column', 'Pokaż kolumnę')}
              className={`px-2 py-0.5 rounded-full border font-mono text-[11.5px] ${envVisible(env)
                ? 'border-blue-300 bg-blue-50 text-blue-700 dark:border-blue-400/40 dark:bg-blue-400/10 dark:text-blue-300'
                : 'border-dashed border-gray-300 dark:border-white/15 line-through'}`}>
              {env}
            </button>
          ))}
        </div>
      )}

      {error && !modules && (
        <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-[13px] text-red-700 dark:border-red-500/30 dark:bg-red-500/10 dark:text-red-300">
          {pick('Could not load the service map', 'Nie udało się wczytać mapy serwisów')}: {error}
        </div>
      )}
      {modules && modules.length === 0 && (
        // what is missing: the project of the service map (Settings) or the reported versions
        <div className={`${card} p-5 flex gap-3`}>
          <Info className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
          <div className="text-[13px] space-y-3">
            <div>
              <div style={{ fontWeight: 600 }}>
                {projects.length === 0
                  ? pick('No project of the service map yet', 'Brak projektu Mapy serwisów')
                  : pick('No versions on the environments yet', 'Brak wersji na środowiskach')}
              </div>
              <p className={`mt-1 ${muted}`}>
                {projects.length === 0
                  ? pick('The map shows the projects of your units that are set up with their environments.',
                    'Mapa pokazuje projekty twoich unitów, które mają ustawione środowiska.')
                  : pick(`Projects: ${projects.map((p) => p.label || p.id).join(', ')}. No microservice versions were reported for them.`,
                    `Projekty: ${projects.map((p) => p.label || p.id).join(', ')}. Nie zgłoszono jeszcze dla nich wersji mikroserwisów.`)}
              </p>
            </div>
            <ol className={`list-decimal pl-5 space-y-1.5 ${muted}`}>
              <li>
                <b className="text-gray-700 dark:text-gray-300">{pick('Automatically from ArgoCD (recommended):', 'Automatycznie z ArgoCD (zalecane):')}</b>{' '}
                {pick('add "architecture" to the importer job', 'dopisz "architecture" w jobie importera')} <span className="font-mono">ONELOOK_IMPORT=gitlab,architecture</span>{' '}
                {pick('and set', 'i ustaw')} <span className="font-mono">ARCH_DEPLOY_REPO=deploy/&lt;repo ArgoCD&gt;</span> {pick('(a repo or a whole group, also outside the group of the services)', '(repo albo cała grupa, też poza grupą serwisów)')}.{' '}
                {pick('It creates the project and takes the image tags of every environment.', 'Założy projekt i weźmie tagi obrazów z każdego środowiska.')}
              </li>
              <li>
                <b className="text-gray-700 dark:text-gray-300">{pick('Manually:', 'Ręcznie:')}</b>{' '}
                {pick('a project in', 'projekt w')} <a href="/settings/projects" className="text-blue-600">{pick('Settings → Projects and environments', 'Ustawienia → Projekty i środowiska')}</a>{' '}
                {pick('and the CI pipelines report each deployment:', 'i pipeline\'y CI zgłaszające każde wdrożenie:')}
                <pre className="mt-2 text-[11.5px] bg-gray-50 dark:bg-white/5 rounded-lg p-2.5 overflow-x-auto text-gray-700 dark:text-gray-300">{`curl -X PUT "$ONELOOK/v1/environment/release?projectId=<project>&env=<env>" \\
  -H "ZS-API-TOKEN: $ONELOOK_API_KEY" -H "Content-Type: application/json" \\
  -d '{"module":"payment-service","image":"registry/payment-service","version":"1.4.0"}'`}</pre>
              </li>
            </ol>
          </div>
        </div>
      )}
      {modules && modules.length > 0 && groups.length === 0 && (
        <div className={`${card} p-5 text-[13px] ${muted}`}>{pick('No microservices match the filters.', 'Brak mikroserwisów dla wybranych filtrów.')}</div>
      )}

      {/* Matrix per project */}
      {groups.map((g) => (
        <div key={g.id} className={`${card} overflow-hidden`}>
          <div className="px-5 py-3 border-b border-gray-200 dark:border-white/10 flex flex-wrap items-baseline justify-between gap-2">
            <h2 className="text-[15px]" style={{ fontWeight: 700 }}>{label(g.id)}</h2>
            <span className={`text-[11.5px] ${muted}`}>{g.envs.join(' → ')} · {g.rows.length} {pick('microservices', 'mikroserwisów')}</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-[13px] border-collapse">
              <thead>
                <tr className={`text-[11px] uppercase tracking-wide ${muted}`}>
                  <th className="text-left py-2 pl-5 pr-3 font-semibold">{pick('Microservice', 'Mikroserwis')}</th>
                  {g.envs.map((env, i) => (
                    <th key={env} colSpan={i < g.envs.length - 1 ? 2 : 1} className="text-left py-2 px-2 font-semibold">{env}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {g.rows.map(({ m, byEnv, steps }) => (
                  <tr key={m.module} className="border-t border-gray-100 dark:border-white/5">
                    <td className="py-2.5 pl-5 pr-3 whitespace-nowrap" style={{ fontWeight: 600 }}>{m.module}</td>
                    {g.envs.map((env, i) => {
                      const e = byEnv.get(env);
                      const s = steps[i];
                      const color = !e ? C.missing : !s ? C.synced : s.pending ? C.pending : C.synced;
                      const issues = s?.pending ? count(s.from?.diff?.issues) : 0;
                      const commits = s?.pending ? count(s.from?.diff?.commits) : 0;
                      return [
                        <td key={env} className="py-2 px-2">
                          {e ? (
                            <button onClick={() => setVersion({ project: label(g.id), module: m.module!, env, entry: e })} disabled={!e.tag}
                                  className="inline-flex items-center gap-1.5 px-2 py-1 rounded-md font-mono text-[12px] border whitespace-nowrap hover:brightness-95 hover:underline disabled:hover:no-underline"
                                  style={{ borderColor: `${color}66`, backgroundColor: `${color}14` }}
                                  title={`${e.image ?? ''}\n${pick('Jira issues in this version', 'Zgłoszenia Jira w tej wersji')}`}>
                              <span className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: color }} />{e.tag ?? '?'}
                            </button>
                          ) : (
                            <span className={`inline-block px-2 py-1 rounded-md border border-dashed border-gray-300 dark:border-white/15 text-[12px] ${muted}`}>—</span>
                          )}
                        </td>,
                        i < g.envs.length - 1 && (
                          <td key={`${env}>`} className="py-2 px-1 w-[92px]">
                            {s?.pending && s.from ? (
                              <button
                                onClick={() => setStep({ project: label(g.id), module: m.module!, env: s.env, next: s.next, from: s.from!, to: s.to })}
                                className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[11px] bg-amber-50 text-amber-800 hover:bg-amber-100 dark:bg-amber-500/15 dark:text-amber-300 whitespace-nowrap"
                                style={{ fontWeight: 600 }}
                                title={pick('What waits for the next environment', 'Co czeka na następne środowisko')}
                              >
                                <ArrowRight className="w-3 h-3" />
                                {!s.to ? pick('not deployed', 'brak wdrożenia') : issues > 0 ? `${issues} Jira` : commits > 0 ? `${commits} commit` : pick('diff', 'różnica')}
                              </button>
                            ) : e && s && !s.pending ? (
                              <span className="inline-flex items-center text-emerald-600 dark:text-emerald-400" title={pick('Same version on the next environment', 'Ta sama wersja na następnym środowisku')}>
                                <CheckCircle2 className="w-3.5 h-3.5" />
                              </span>
                            ) : (
                              <span className={`text-[11px] ${muted}`}>·</span>
                            )}
                          </td>
                        ),
                      ];
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ))}

      {modules && modules.length > 0 && (
        <p className={`text-[11.5px] ${muted}`}>
          {pick(`${waitingIssues} Jira issues are deployed somewhere but not yet on the next environment.`,
            `${waitingIssues} zgłoszeń Jira jest już na którymś środowisku, ale jeszcze nie na następnym.`)}
          {' '}{pick('Data from the CI pipelines (PUT /v1/environment/release), refreshed every minute.', 'Dane z pipeline\'ów CI (PUT /v1/environment/release), odświeżane co minutę.')}
        </p>
      )}

      {panel === 'compare' && (
        <CompareDrawer modules={allModules} envNames={allEnvNames} label={label} onClose={() => setPanel(null)}
          onOpen={(it) => { setPanel(null); setStep(it); }} />
      )}
      {panel === 'test-way' && <TestWayDrawer modules={allModules} label={label} onClose={() => setPanel(null)} />}

      {version && <VersionDrawer version={version} onClose={() => setVersion(null)} />}

      {/* What waits for the next environment */}
      {step && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/20" onClick={() => setStep(null)}>
          <div className="h-full w-full max-w-[460px] bg-white dark:bg-[#17181c] shadow-xl p-5 overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className={`text-[11px] uppercase tracking-wider ${muted}`} style={{ fontWeight: 700 }}>{step.project}</div>
                <h3 className="text-[18px]" style={{ fontWeight: 800 }}>{step.module}</h3>
              </div>
              <button onClick={() => setStep(null)} className="p-1.5 rounded-md hover:bg-gray-100 dark:hover:bg-white/10" aria-label={pick('Close', 'Zamknij')}>
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="mt-3 flex items-center gap-2 text-[13px]">
              <span className="px-2 py-1 rounded-md bg-amber-50 dark:bg-amber-500/15 font-mono">{step.env}: {step.from.tag}</span>
              <ArrowRight className={`w-4 h-4 ${muted}`} />
              <span className="px-2 py-1 rounded-md bg-gray-100 dark:bg-white/10 font-mono">{step.next}: {step.to?.tag ?? pick('none', 'brak')}</span>
            </div>
            {step.from.image && <div className={`mt-2 text-[11.5px] font-mono break-all ${muted}`}>{step.from.image}</div>}

            {[
              [Ticket, pick('Jira issues', 'Zgłoszenia Jira'), step.from.diff?.issues],
              [Tag, pick('Tags', 'Tagi'), step.from.diff?.tags],
              [GitCommitHorizontal, pick('Commits', 'Commity'), step.from.diff?.commits],
            ].map(([Icon, title, list]) => {
              const items = (list as string[] | null | undefined) ?? [];
              const I = Icon as typeof Ticket;
              return (
                <div key={String(title)} className="mt-5">
                  <div className="flex items-center gap-1.5 text-[13px]" style={{ fontWeight: 700 }}>
                    <I className="w-4 h-4 text-blue-600" />{String(title)} <span className={muted}>({items.length})</span>
                  </div>
                  {items.length === 0 ? (
                    <div className={`mt-1 text-[12px] ${muted}`}>—</div>
                  ) : (
                    <ul className="mt-1.5 space-y-1">
                      {items.map((it, i) => (
                        <li key={`${it}-${i}`} className={`text-[12.5px] ${title === pick('Commits', 'Commity') ? '' : 'font-mono'} border-b border-gray-100 dark:border-white/5 pb-1`}>
                          {it.split('\n')[0]}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              );
            })}
            {count(step.from.diff?.commits) === 0 && (
              <p className={`mt-5 text-[12px] ${muted}`}>
                {pick('No commit diff: one of the versions has no known Git tag in OneLook.',
                  'Brak listy zmian: jedna z wersji nie ma znanego tagu Git w OneLook.')}
              </p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

/** Jira issues in the version of a module on an environment: issues with its Fix Version and the ones of its release task. */
function VersionDrawer({ version, onClose }: { version: Version; onClose: () => void }) {
  const pick = usePick();
  const [data, setData] = useState<VersionIssues | null>(null);
  const [failed, setFailed] = useState(false);
  const tag = version.entry.tag ?? '';

  useEffect(() => {
    const controller = new AbortController();
    setData(null);
    setFailed(false);
    const p = new URLSearchParams({ module: version.module, tag });
    fetch(`/api/codemap/issues?${p.toString()}`, { credentials: 'include', signal: controller.signal })
      .then((res) => { if (!res.ok) throw new Error(String(res.status)); return res.json(); })
      .then((json: VersionIssues) => setData(json))
      .catch((e) => { if (e?.name !== 'AbortError') setFailed(true); });
    return () => controller.abort();
  }, [version.module, tag]);

  const statusCls = (status: string | null) => {
    const s = (status ?? '').toUpperCase();
    if (/LIVE|DONE|CLOSED|RESOLVED|RELEASED/.test(s)) return 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300';
    if (/TEST|UAT|ACCEPTANCE|REVIEW/.test(s)) return 'bg-blue-50 text-blue-700 dark:bg-blue-500/15 dark:text-blue-300';
    if (/BLOCK|HOLD/.test(s)) return 'bg-orange-50 text-orange-700 dark:bg-orange-500/15 dark:text-orange-300';
    return 'bg-gray-100 text-gray-600 dark:bg-white/10 dark:text-gray-300';
  };

  return (
    <Drawer title={`${version.module} · ${tag}`} icon={Ticket} onClose={onClose}>
      <div className={`text-[12px] ${muted}`}>
        {version.project} · {version.env}
        {version.entry.image && <div className="mt-1 font-mono text-[11.5px] break-all">{version.entry.image}</div>}
      </div>
      {!data && !failed ? (
        <div className={`mt-6 text-[13px] ${muted}`}>{pick('Loading Jira issues…', 'Pobieram zgłoszenia z Jiry…')}</div>
      ) : failed ? (
        <div className="mt-6 text-[13px] text-red-600">{pick('Could not load the Jira issues.', 'Nie udało się pobrać zgłoszeń z Jiry.')}</div>
      ) : data && (
        <>
          <div className={`mt-4 text-[12px] ${muted}`}>
            {data.fixVersions.length > 0
              ? <>{pick('Fix Version', 'Fix Version')}: <span className="font-mono">{data.fixVersions.join(', ')}</span></>
              : pick(`No Fix Version for ${version.module} ${tag} in Jira.`, `Brak Fix Version dla ${version.module} ${tag} w Jirze.`)}
          </div>
          <div className="mt-4 flex items-center gap-1.5 text-[13px]" style={{ fontWeight: 700 }}>
            <Ticket className="w-4 h-4 text-blue-600" />{pick('Jira issues in this version', 'Zgłoszenia Jira w tej wersji')} <span className={muted}>({data.issues.length})</span>
          </div>
          {data.issues.length === 0 ? (
            <div className={`mt-2 text-[12.5px] ${muted}`}>—</div>
          ) : (
            <ul className="mt-2 divide-y divide-gray-100 dark:divide-white/5">
              {data.issues.map((it) => (
                <li key={it.key} className="py-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    {it.url
                      ? <a href={it.url} target="_blank" rel="noopener noreferrer" className="font-mono text-[12.5px] text-blue-600 hover:underline" style={{ fontWeight: 700 }}>{it.key}</a>
                      : <span className="font-mono text-[12.5px]" style={{ fontWeight: 700 }}>{it.key}</span>}
                    {it.status && <span className={`px-1.5 py-0.5 rounded text-[10.5px] ${statusCls(it.status)}`} style={{ fontWeight: 700 }}>{it.status}</span>}
                    {it.type && <span className={`text-[11px] ${muted}`}>{it.type}</span>}
                  </div>
                  {it.summary && <div className="text-[12.5px] mt-0.5">{it.summary}</div>}
                  <div className={`text-[11px] ${muted} mt-0.5`}>
                    {it.assignee ?? pick('unassigned', 'nieprzypisane')}
                    {' · '}{it.source === 'FIX_VERSION' ? 'Fix Version' : `${pick('release', 'release')} ${it.source}`}
                  </div>
                </li>
              ))}
            </ul>
          )}
          {data.fixVersions.length === 0 && data.otherVersions.length > 0 && (
            <div className={`mt-5 text-[12px] ${muted}`}>
              {pick('Other Fix Versions of this microservice in Jira:', 'Inne Fix Version tego mikroserwisu w Jirze:')}
              <div className="mt-1 font-mono text-[11.5px]">{data.otherVersions.join(', ')}</div>
            </div>
          )}
          {version.entry.diff?.issues && version.entry.diff.issues.length > 0 && (
            <div className={`mt-5 text-[12px] ${muted}`}>
              {pick('From commits, not yet on the next environment:', 'Z commitów, jeszcze nie na następnym środowisku:')}
              <div className="mt-1 font-mono text-[11.5px]">{version.entry.diff.issues.join(', ')}</div>
            </div>
          )}
        </>
      )}
    </Drawer>
  );
}

type OrderedModule = { m: CodeMapModule; order: string[] };

function Drawer({ title, icon: Icon, onClose, children }: { title: string; icon: LucideIcon; onClose: () => void; children: ReactNode }) {
  const pick = usePick();
  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/20" onClick={onClose}>
      <div className="h-full w-full max-w-[640px] bg-white dark:bg-[#17181c] shadow-xl p-5 overflow-y-auto text-gray-900 dark:text-gray-100" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between gap-3">
          <h3 className="text-[18px] flex items-center gap-2" style={{ fontWeight: 800 }}><Icon className="w-5 h-5 text-blue-600" />{title}</h3>
          <button onClick={onClose} className="p-1.5 rounded-md hover:bg-gray-100 dark:hover:bg-white/10" aria-label={pick('Close', 'Zamknij')}>
            <X className="w-4 h-4" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

/** Versions of every microservice on two chosen environments and the Jira issues on one and not yet on the other. */
function CompareDrawer({ modules, envNames, label, onClose, onOpen }: {
  modules: OrderedModule[]; envNames: string[]; label: (id: string) => string; onClose: () => void; onOpen: (step: Step) => void;
}) {
  const pick = usePick();
  const [from, setFrom] = useState(() => envNames.find((it) => it.toLowerCase() === 'beta') ?? envNames[0] ?? '');
  const [to, setTo] = useState(() => envNames.find((it) => it.toLowerCase() === 'prod') ?? envNames[envNames.length - 1] ?? '');
  const [diffOnly, setDiffOnly] = useState(true);

  const rows = modules
    .filter(({ m, order }) => order.includes(from) && order.includes(to) && (m.envs ?? []).some((e) => e.name === from || e.name === to))
    .map(({ m, order }) => {
      const a = (m.envs ?? []).find((e) => e.name === from) ?? null;
      const b = (m.envs ?? []).find((e) => e.name === to) ?? null;
      const state = a && b ? (a.tag === b.tag ? 'same' : 'different') : a ? 'onlyFrom' : 'onlyTo';
      // the newer one is earlier in the promotion order
      const fromFirst = order.indexOf(from) <= order.indexOf(to);
      return { m, a, b, state, fromFirst, diff: chainDiff(m, order, from, to) };
    })
    .filter((r) => !diffOnly || r.state !== 'same')
    .sort((x, y) => label(x.m.projectId!).localeCompare(label(y.m.projectId!)) || x.m.module!.localeCompare(y.m.module!));
  const stateLabel: Record<string, [string, string]> = {
    same: [pick('same', 'ta sama'), 'text-emerald-600 dark:text-emerald-400'],
    different: [pick('different', 'różna'), 'text-amber-600 dark:text-amber-400'],
    onlyFrom: [pick(`only on ${from}`, `tylko na ${from}`), 'text-gray-500'],
    onlyTo: [pick(`only on ${to}`, `tylko na ${to}`), 'text-gray-500'],
  };
  const select = (value: string, set: (v: string) => void) => (
    <select className={inputCls} value={value} onChange={(e) => set(e.target.value)}>
      {envNames.map((it) => <option key={it} value={it}>{it}</option>)}
    </select>
  );

  return (
    <Drawer title={pick('Compare environments', 'Porównanie środowisk')} icon={GitCompareArrows} onClose={onClose}>
      <div className="mt-4 flex flex-wrap items-center gap-2 text-[12.5px]">
        {select(from, setFrom)}
        <button onClick={() => { setFrom(to); setTo(from); }} className="p-1.5 rounded-md hover:bg-gray-100 dark:hover:bg-white/10" title={pick('Swap', 'Zamień')}>
          <ArrowRight className="w-4 h-4" />
        </button>
        {select(to, setTo)}
        <label className="ml-auto inline-flex items-center gap-1.5 cursor-pointer">
          <input type="checkbox" className="accent-blue-600" checked={diffOnly} onChange={(e) => setDiffOnly(e.target.checked)} />
          {pick('Only differences', 'Tylko różnice')}
        </label>
      </div>
      {from === to ? (
        <p className={`mt-4 text-[12.5px] ${muted}`}>{pick('Choose two different environments.', 'Wybierz dwa różne środowiska.')}</p>
      ) : rows.length === 0 ? (
        <p className={`mt-4 text-[12.5px] ${muted}`}>{diffOnly ? pick('The same versions everywhere.', 'Wszędzie te same wersje.') : pick('No microservices on these environments.', 'Brak mikroserwisów na tych środowiskach.')}</p>
      ) : (
        <>
          <p className={`mt-3 text-[11.5px] ${muted}`}>{rows.filter((r) => r.state !== 'same').length} {pick('microservices differ', 'mikroserwisów się różni')}</p>
          <table className="mt-2 w-full text-[12.5px] border-collapse">
            <thead>
              <tr className={`text-left text-[11px] uppercase tracking-wide ${muted}`}>
                <th className="py-1.5 pr-2">{pick('Microservice', 'Mikroserwis')}</th>
                <th className="py-1.5 px-2">{from}</th>
                <th className="py-1.5 px-2">{to}</th>
                <th className="py-1.5 px-2">Jira</th>
              </tr>
            </thead>
            <tbody>
              {rows.map(({ m, a, b, state, fromFirst, diff }) => {
                const [text, cls] = stateLabel[state];
                const newer = fromFirst ? a : b;
                return (
                  <tr key={`${m.projectId}/${m.module}`} className="border-t border-gray-100 dark:border-white/5 align-top">
                    <td className="py-2 pr-2">
                      <div style={{ fontWeight: 600 }}>{m.module}</div>
                      <div className={`text-[11px] ${muted}`}>{label(m.projectId!)} · <span className={cls}>{text}</span></div>
                    </td>
                    <td className="py-2 px-2 font-mono text-[12px] whitespace-nowrap">{a?.tag ?? '—'}</td>
                    <td className="py-2 px-2 font-mono text-[12px] whitespace-nowrap">{b?.tag ?? '—'}</td>
                    <td className="py-2 px-2">
                      {state === 'same' ? <span className={muted}>—</span> : newer ? (
                        <button className="text-left hover:underline"
                          onClick={() => onOpen({ project: label(m.projectId!), module: m.module!, env: fromFirst ? from : to, next: fromFirst ? to : from,
                            from: { ...newer, diff }, to: fromFirst ? b : a })}>
                          {count(diff.issues) > 0
                            ? <span className="font-mono text-[11.5px]">{diff.issues!.slice(0, 4).join(', ')}{count(diff.issues) > 4 ? ` +${count(diff.issues) - 4}` : ''}</span>
                            : <span className={muted}>{count(diff.commits)} commit</span>}
                        </button>
                      ) : <span className={muted}>—</span>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </>
      )}
    </Drawer>
  );
}

/**
 * Test-way: the microservices where a Jira issue waits for promotion (not yet on the last environment of the project) and
 * the other Jira issues going with it there, to be tested together; then the microservices where those issues wait as well.
 */
function TestWayDrawer({ modules, label, onClose }: { modules: OrderedModule[]; label: (id: string) => string; onClose: () => void }) {
  const pick = usePick();
  const [input, setInput] = useState('');
  const key = input.trim().toUpperCase();

  // per module: Jira issue -> the steps (env -> next) where it waits
  const pending = useMemo(() => modules.map(({ m, order }) => {
    const envs = (m.envs ?? []).filter((e) => order.includes(e.name)).sort((x, y) => order.indexOf(x.name) - order.indexOf(y.name));
    const steps = new Map<string, string[]>();
    envs.slice(0, -1).forEach((e, i) => (e.diff?.issues ?? []).forEach((issue) => {
      steps.set(issue.toUpperCase(), [...(steps.get(issue.toUpperCase()) ?? []), `${e.name} → ${envs[i + 1].name}`]);
    }));
    return { m, steps };
  }), [modules]);

  const result = useMemo(() => {
    if (!/^[A-Z][A-Z0-9]*-\d+$/.test(key)) return null;
    const hits = pending.filter((it) => it.steps.has(key));
    const together = new Map<string, string[]>();
    hits.forEach(({ m, steps }) => steps.forEach((_, issue) => {
      if (issue !== key) together.set(issue, [...(together.get(issue) ?? []), m.module!]);
    }));
    const related = pending.filter((it) => !hits.includes(it) && [...together.keys()].some((issue) => it.steps.has(issue)))
      .map((it) => ({ ...it, via: [...together.keys()].filter((issue) => it.steps.has(issue)) }));
    return { hits, together: [...together.entries()].sort((a, b) => b[1].length - a[1].length || a[0].localeCompare(b[0])), related };
  }, [key, pending]);

  const chip = (text: string, cls = '') => (
    <span key={text} className={`inline-block px-1.5 py-0.5 rounded-md font-mono text-[11.5px] bg-gray-100 dark:bg-white/10 ${cls}`}>{text}</span>
  );

  return (
    <Drawer title="Test-way" icon={FlaskConical} onClose={onClose}>
      <p className={`mt-1 text-[12px] ${muted}`}>
        {pick('Enter a Jira issue: the microservices where it waits for promotion and the issues going together with it, to be tested together.',
          'Wpisz numer Jira: mikroserwisy, w których czeka na promocję, i zgłoszenia, które idą razem z nim - do przetestowania razem.')}
      </p>
      <div className="mt-3 relative">
        <Ticket className="w-4 h-4 text-gray-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
        <input autoFocus className={`${inputCls} pl-8 w-full font-mono`} value={input} onChange={(e) => setInput(e.target.value)} placeholder="PROJ-123" />
      </div>
      {!key ? null : !result ? (
        <p className={`mt-4 text-[12.5px] ${muted}`}>{pick('A Jira key like PROJ-123.', 'Numer Jira w postaci PROJ-123.')}</p>
      ) : result.hits.length === 0 ? (
        <p className={`mt-4 text-[12.5px] ${muted}`}>
          {pick(`${key} does not wait for promotion in any microservice: it is already on the last environment, or no commit mentions it.`,
            `${key} nie czeka na promocję w żadnym mikroserwisie: jest już na ostatnim środowisku albo żaden commit go nie wymienia.`)}
        </p>
      ) : (
        <div className="mt-5 space-y-5">
          <div>
            <div className="text-[13px]" style={{ fontWeight: 700 }}>{pick('Microservices with', 'Mikroserwisy z')} {key} <span className={muted}>({result.hits.length})</span></div>
            <ul className="mt-1.5 space-y-1.5">
              {result.hits.map(({ m, steps }) => (
                <li key={`${m.projectId}/${m.module}`} className="border-b border-gray-100 dark:border-white/5 pb-1.5">
                  <div className="text-[12.5px]" style={{ fontWeight: 600 }}>{m.module} <span className={`text-[11px] ${muted}`}>· {label(m.projectId!)}</span></div>
                  <div className={`text-[11.5px] ${muted}`}>{pick('waits', 'czeka')}: {steps.get(key)!.join(', ')} · {steps.size - 1} {pick('other issues', 'innych zgłoszeń')}</div>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <div className="text-[13px]" style={{ fontWeight: 700 }}>{pick('Test together', 'Do przetestowania razem')} <span className={muted}>({result.together.length})</span></div>
            {result.together.length === 0 ? (
              <div className={`mt-1 text-[12px] ${muted}`}>{pick(`Only ${key} waits in these microservices.`, `W tych mikroserwisach czeka tylko ${key}.`)}</div>
            ) : (
              <ul className="mt-1.5 space-y-1">
                {result.together.map(([issue, services]) => (
                  <li key={issue} className="flex flex-wrap items-center gap-1.5 text-[12px]">
                    {chip(issue, 'bg-amber-50 text-amber-800 dark:bg-amber-500/15 dark:text-amber-300')}
                    <span className={muted}>{services.join(', ')}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
          {result.related.length > 0 && (
            <div>
              <div className="text-[13px]" style={{ fontWeight: 700 }}>{pick('Related microservices', 'Powiązane mikroserwisy')} <span className={muted}>({result.related.length})</span></div>
              <p className={`text-[11.5px] ${muted}`}>{pick('The issues above wait for promotion here too.', 'Zgłoszenia z listy wyżej czekają na promocję także tutaj.')}</p>
              <ul className="mt-1.5 space-y-1.5">
                {result.related.map(({ m, via }) => (
                  <li key={`${m.projectId}/${m.module}`} className="flex flex-wrap items-center gap-1.5 text-[12px]">
                    <span style={{ fontWeight: 600 }}>{m.module}</span><span className={muted}>· {label(m.projectId!)} ·</span>
                    {via.map((it) => chip(it))}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </Drawer>
  );
}

export default ServiceMap;
