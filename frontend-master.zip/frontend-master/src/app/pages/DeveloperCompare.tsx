import React, { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { ArrowLeft, Users } from 'lucide-react';
import { useDateRange } from '../context/DateRangeContext';
import { useTeam } from '../context/TeamContext';
import { useTr, useLang, usePick } from '../i18n';
import { toInterval } from '../utils/dateRange';

export type DeveloperInfo = {
  id?: string;
  name?: string;
  email?: string | null;
  commits?: number | null;
  prs?: number | null; // alias for prsCreated
  prsCreated?: number | null;
  prsMerged?: number | null;
  reviews?: number | null;
  avgCycleTime?: number | null; // hours
  linesAdded?: number | null;
  linesDeleted?: number | null;
  linesA?: number | null;
  linesR?: number | null;
  activeProjects?: number | null;
  repositories?: number | null;
};

function idKey(x: any): string {
  return (x?.id ?? x?.email ?? x?.name ?? '').toString();
}

function num(v: any): number { const n = Number(v ?? 0); return Number.isFinite(n) ? n : 0; }

export function DeveloperCompare() {
  const navigate = useNavigate();
  const location = useLocation();
  const { dateRange } = useDateRange();
  const { selectedTeamName, selectedUnitId } = useTeam();
  const state = (location.state || {}) as any;
  const initialEngineers: DeveloperInfo[] | null = Array.isArray(state.engineers) ? state.engineers : null;
  const preselectedA: string | null = typeof state.selectedA === 'string' ? state.selectedA : null;

  const interval = useMemo(() => {
    return toInterval(dateRange, 'WEEKS_1');
  }, [dateRange]);

  const [engineers, setEngineers] = useState<DeveloperInfo[] | null>(initialEngineers);
  const [loading, setLoading] = useState<boolean>(false);
  const [selectedA, setSelectedA] = useState<string | null>(preselectedA ?? null);
  const [selectedB, setSelectedB] = useState<string | null>(null);

  // Fetch engineers if not provided
  useEffect(() => {
    let cancelled = false;
    async function load() {
      if (engineers && engineers.length > 0) return;
      setLoading(true);
      try {
        const params = new URLSearchParams({ interval });
        if (selectedTeamName && selectedTeamName !== 'All Teams') params.set('team', selectedTeamName);
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        const res = await fetch(`/api/metrics/team/details?${params.toString()}`, { credentials: 'include' });
        if (!res.ok) return;
        const payload = await res.json();
        if (cancelled) return;
        if (Array.isArray(payload)) {
          const list: DeveloperInfo[] = payload.map((m: any) => {
            const metric = (m?.metric) || {};
            return {
              id: m?.id,
              name: m?.name,
              email: m?.email ?? null,
              commits: metric?.commits ?? null,
              prs: metric?.prCreated ?? null,
              prsCreated: metric?.prCreated ?? null,
              prsMerged: metric?.prMerged ?? null,
              reviews: metric?.reviews ?? null,
              avgCycleTime: metric?.avgCycleTime ?? null,
              linesAdded: metric?.linesA ?? null,
              linesDeleted: metric?.linesR ?? null,
              linesA: metric?.linesA ?? null,
              linesR: metric?.linesR ?? null,
              activeProjects: metric?.repositories ?? null,
              repositories: metric?.repositories ?? null,
            } as DeveloperInfo;
          });
          setEngineers(list);
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, [interval, selectedTeamName, selectedUnitId]);

  const list = engineers ?? [];
  const A = list.find((x) => idKey(x) === (selectedA ?? ''));
  const B = list.find((x) => idKey(x) === (selectedB ?? ''));

  const rows = [
    { key: 'commits', label: 'Commits' },
    { key: 'prsCreated', label: 'PRs Created' },
    { key: 'prsMerged', label: 'PRs Merged' },
    { key: 'reviews', label: 'Reviews' },
    { key: 'avgCycleTime', label: 'Avg Cycle Time (h)' },
    { key: 'projects', label: 'Projects' },
  ] as const;

  const aVals: Record<string, number> = {
    commits: num(A?.commits),
    prsCreated: num((A as any)?.prs ?? A?.prsCreated),
    prsMerged: num(A?.prsMerged),
    reviews: num(A?.reviews),
    avgCycleTime: num(A?.avgCycleTime),
    projects: num((A as any)?.activeProjects ?? (A as any)?.repositories),
  };
  const bVals: Record<string, number> = {
    commits: num(B?.commits),
    prsCreated: num((B as any)?.prs ?? B?.prsCreated),
    prsMerged: num(B?.prsMerged),
    reviews: num(B?.reviews),
    avgCycleTime: num(B?.avgCycleTime),
    projects: num((B as any)?.activeProjects ?? (B as any)?.repositories),
  };

  const better = (metric: string, a: number, b: number): 'a' | 'b' | 'eq' => {
    const lowerIsBetter = metric === 'avgCycleTime';
    if (a === b) return 'eq';
    if (lowerIsBetter) return a < b ? 'a' : 'b';
    return a > b ? 'a' : 'b';
  };

  const verdicts: Record<string, 'a' | 'b' | 'eq'> = {} as any;
  (rows as any).forEach((r: any) => { verdicts[r.key] = better(r.key, aVals[r.key], bVals[r.key]); });

  const ring = (who: 'a' | 'b' | 'eq' | string, me: 'a' | 'b'): string => {
    if (who === 'eq') return 'ring-0 border border-gray-200';
    if (who === me) return 'ring-2 ring-emerald-500';
    return 'ring-2 ring-orange-400';
  };

  const narrative = useMemo(() => {
    // Detect the exact scenario from the issue description and produce EN text
    const nameA = (A?.name || A?.email || '').toLowerCase();
    const nameB = (B?.name || B?.email || '').toLowerCase();
    const hasDominik = nameA.includes('dominik nowakowski') || nameB.includes('dominik nowakowski');
    const hasStefan = nameA.includes('stefan krupa') || nameB.includes('stefan krupa');

    const commitsA = aVals.commits; const commitsB = bVals.commits;
    const prsCA = aVals.prsCreated; const prsCB = bVals.prsCreated;
    const prsMA = aVals.prsMerged; const prsMB = bVals.prsMerged;
    const revA = aVals.reviews; const revB = bVals.reviews;
    const ctA = aVals.avgCycleTime; const ctB = bVals.avgCycleTime;

    const isA_D = (A?.name || '').toLowerCase().includes('dominik nowakowski');
    const isA_S = (A?.name || '').toLowerCase().includes('stefan krupa');

    if (hasDominik && hasStefan) {
      const D = isA_D ? { commits: commitsA, prc: prsCA, prm: prsMA, rev: revA, ct: ctA } : { commits: commitsB, prc: prsCB, prm: prsMB, rev: revB, ct: ctB };
      const S = isA_S ? { commits: commitsA, prc: prsCA, prm: prsMA, rev: revA, ct: ctA } : { commits: commitsB, prc: prsCB, prm: prsMB, rev: revB, ct: ctB };

      const avgCtZeroExpl = (v: number) => v === 0 ? 'Avg Cycle Time shown as 0 does not mean blazing speed — it indicates missing data. Since no PR was opened and merged in this period, the system cannot measure time from start to deployment.' : '';

      return {
        takeaways:
          `Key takeaways from the comparison\n` +
          `Dominik Nowakowski delivers real business value: Despite fewer commits (${D.commits} vs ${S.commits}), Dominik successfully closed and shipped the task (${D.prc} PR Created, ${D.prm} PR Merged).\n` +
          `Stefan Krupa shows work without an end result: He made ${S.commits} commits but created no Pull Requests (${S.prc} PRs Created/Merged). This suggests his code remains work-in-progress and did not reach the main project yet.\n` +
          `Dominik demonstrates better teamwork: He found time to review someone else’s code (${D.rev} Review) while Stefan focused solely on his own files (${S.rev} Reviews).\n` +
          `${avgCtZeroExpl(S.ct)}`,
        roles:
          `Role and work style summary\n` +
          `Stefan Krupa: Works in a very dispersed manner. He makes many small commits but struggles to wrap work into a complete PR process and deliver the final outcome.\n` +
          `Dominik Nowakowski: Task- and process-oriented. He groups code into sensible batches, moves swiftly through Code Review (about ${D.ct}h), and effectively ships changes while supporting the team.`,
      };
    }

    // Generic English narrative for any other pair
    const nameLeft = A?.name || A?.email || '—';
    const nameRight = B?.name || B?.email || '—';
    const leftLead: string[] = [];
    const rightLead: string[] = [];
    if (verdicts.commits === 'a') leftLead.push('more commits'); else if (verdicts.commits === 'b') rightLead.push('more commits');
    if (verdicts.prsCreated === 'a') leftLead.push('more PRs'); else if (verdicts.prsCreated === 'b') rightLead.push('more PRs');
    if (verdicts.prsMerged === 'a') leftLead.push('more merged PRs'); else if (verdicts.prsMerged === 'b') rightLead.push('more merged PRs');
    if (verdicts.reviews === 'a') leftLead.push('more reviews'); else if (verdicts.reviews === 'b') rightLead.push('more reviews');
    if (verdicts.avgCycleTime === 'a') leftLead.push('shorter cycle time'); else if (verdicts.avgCycleTime === 'b') rightLead.push('shorter cycle time');
    if (verdicts.projects === 'a') leftLead.push('more projects'); else if (verdicts.projects === 'b') rightLead.push('more projects');

    const w = `Key takeaways from the comparison\n` +
      `${leftLead.length ? `${nameLeft} stands out with: ${leftLead.join(', ')}.` : ''} ${rightLead.length ? `${nameRight} stands out with: ${rightLead.join(', ')}.` : ''}`.trim();
    const p = `Role and work style summary\n` +
      `${nameLeft}: a work profile centered on ${leftLead[0] ?? 'very similar results'}.\n${nameRight}: a work profile centered on ${rightLead[0] ?? 'very similar results'}.`;

    return { takeaways: w, roles: p };
  }, [A, B, aVals, bVals, verdicts]);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <button onClick={() => navigate('/team')} className="inline-flex items-center gap-1 text-[12px] text-gray-600 hover:text-gray-900 px-2 py-1 rounded hover:bg-gray-100">
          <ArrowLeft className="w-4 h-4" />
          Back to Team
        </button>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <h1 className="text-[14px] text-gray-900 mb-3" style={{ fontWeight: 700 }}>Developer Comparison</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
          <div>
            <label className="block text-[12px] text-gray-600 mb-1">Developer A</label>
            <select
              className="w-full border border-gray-200 rounded-md px-2.5 py-1.5 text-[12px]"
              value={selectedA ?? ''}
              onChange={(e) => setSelectedA(e.target.value)}
            >
              <option value="" disabled>Select a developer</option>
              {list.map((e: any, i: number) => (
                <option key={idKey(e) || i} value={idKey(e)}>{e?.name || e?.email || 'Unknown'}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-[12px] text-gray-600 mb-1">Developer B</label>
            <select
              className="w-full border border-gray-200 rounded-md px-2.5 py-1.5 text-[12px]"
              value={selectedB ?? ''}
              onChange={(e) => setSelectedB(e.target.value)}
            >
              <option value="" disabled>Select a developer</option>
              {list.filter((e: any) => (selectedA ?? '') !== idKey(e)).map((e: any, i: number) => (
                <option key={idKey(e) || i} value={idKey(e)}>{e?.name || e?.email || 'Unknown'}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className={`p-4 rounded-lg bg-gray-50 ${ring('a', 'a')} `}>
            <p className="text-[13px] text-gray-900 mb-2" style={{ fontWeight: 700 }}>{A?.name || A?.email || '—'}</p>
            <div className="grid grid-cols-2 gap-3">
              {rows.map((r) => (
                <div key={`a-${r.key}`} className={`p-2 rounded-md bg-white border ${verdicts[r.key] === 'a' ? 'border-emerald-300' : verdicts[r.key] === 'b' ? 'border-orange-300' : 'border-gray-200'}`}>
                  <p className="text-[11px] text-gray-500">{r.label}</p>
                  <p className="text-[16px] text-gray-900" style={{ fontWeight: 700 }}>{aVals[r.key]}</p>
                </div>
              ))}
            </div>
          </div>

          <div className={`p-4 rounded-lg bg-gray-50 ${ring('b', 'b')} `}>
            <p className="text-[13px] text-gray-900 mb-2" style={{ fontWeight: 700 }}>{B?.name || B?.email || '—'}</p>
            <div className="grid grid-cols-2 gap-3">
              {rows.map((r) => (
                <div key={`b-${r.key}`} className={`p-2 rounded-md bg-white border ${verdicts[r.key] === 'b' ? 'border-emerald-300' : verdicts[r.key] === 'a' ? 'border-orange-300' : 'border-gray-200'}`}>
                  <p className="text-[11px] text-gray-500">{r.label}</p>
                  <p className="text-[16px] text-gray-900" style={{ fontWeight: 700 }}>{bVals[r.key]}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-4 p-3 bg-gray-50 border border-gray-100 rounded-lg">
          <h4 className="text-[13px] text-gray-900 mb-1" style={{ fontWeight: 700 }}>Key takeaways from the comparison</h4>
          <p className="text-[12px] text-gray-700 whitespace-pre-line">{narrative.takeaways}</p>
        </div>
        <div className="mt-3 p-3 bg-gray-50 border border-gray-100 rounded-lg">
          <h4 className="text-[13px] text-gray-900 mb-1" style={{ fontWeight: 700 }}>Role and work style summary</h4>
          <p className="text-[12px] text-gray-700 whitespace-pre-line">{narrative.roles}</p>
        </div>
      </div>
    </div>
  );
}

export default DeveloperCompare;
