import React, { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { ArrowLeft, GitCommit, GitPullRequest, MessageSquare, Clock, FolderGit2 } from 'lucide-react';
import { useDateRange } from '../context/DateRangeContext';
import { useTeam } from '../context/TeamContext';
import { useLang, useTr } from '../i18n';
import { toInterval } from '../utils/dateRange';

// Type aligned with Team.tsx engineer row
export type DeveloperInfo = {
  id?: string;
  name?: string;
  email?: string | null;
  role?: string | null;
  commits?: number | null;
  prs?: number | null; // alias for prsCreated
  prsCreated?: number | null;
  prsMerged?: number | null;
  reviews?: number | null;
  avgCycleTime?: number | null; // hours
  linesAdded?: number | null;
  linesDeleted?: number | null;
  linesA?: number | null;
  linesR?: number | null;
  activeProjects?: number | null;
  repositories?: number | null;
  avatar?: string | null;
};

function deriveInitials(name?: string | null, email?: string | null) {
  const safe = (s: any) => (typeof s === 'string' ? s : '');
  const n = safe(name).trim();
  if (n) {
    const parts = n.split(/\s+/).filter(Boolean);
    const first = parts[0]?.[0] || '';
    const last = parts.length > 1 ? parts[parts.length - 1]?.[0] : '';
    const res = `${first}${last}`.toUpperCase();
    if (res) return res;
  }
  const em = safe(email).trim();
  if (em) {
    const local = em.split('@')[0] || '';
    const first = local[0] || '';
    const last = local.length > 1 ? local[local.length - 1] : '';
    const res = `${first}${last}`.toUpperCase();
    if (res) return res;
  }
  return 'UU';
}

function formatLines(n?: number | null) {
  const num = Number(n ?? 0);
  if (!Number.isFinite(num)) return '0';
  return num.toLocaleString();
}

function useAssessment(dev: DeveloperInfo) {
  return useMemo(() => {
    const commits = Number(dev.commits ?? 0);
    const prs = Number((dev.prs ?? dev.prsCreated) ?? 0);
    const merged = Number(dev.prsMerged ?? 0);
    const reviews = Number(dev.reviews ?? 0);
    const ct = Number(dev.avgCycleTime ?? 0); // hours
    const la = Number(dev.linesAdded ?? dev.linesA ?? 0);
    const ld = Number(dev.linesDeleted ?? dev.linesR ?? 0);

    const insights: string[] = [];
    const improvements: string[] = [];
    const coaching: string[] = [];

    // Activity level
    if (commits >= 60) insights.push('Very high commit activity — indicates strong productivity.');
    else if (commits >= 25) insights.push('Stable number of commits — regular delivery of changes.');
    else {
      insights.push('Low number of commits — possibly working on larger tasks or may need support.');
      improvements.push('Break work into smaller PRs/commits (target 1–2 days of work per PR).');
      coaching.push('What blocks more frequent commits? Is the task scope too broad?');
    }

    // PRs creation and merge ratio
    const mergeRatio = prs > 0 ? merged / prs : 0;
    if (prs >= 8) insights.push('Frequent PR creation — good iteration pace.');
    else if (prs >= 3) insights.push('Moderate number of PRs — steady work rhythm.');
    else {
      insights.push('Few PRs — consider splitting work into smaller pieces.');
      improvements.push('Aim for smaller PRs (up to ~300–400 LOC) to ease review and speed up merges.');
      coaching.push('Can some value be extracted earlier into a separate PR?');
    }

    if (prs > 0) {
      if (mergeRatio >= 0.75) insights.push('High merge ratio — good quality and alignment with standards.');
      else if (mergeRatio >= 0.5) {
        insights.push('Average merge ratio — room to improve PR quality.');
        improvements.push('Improve PR descriptions (context, screenshots, acceptance criteria) and tests.');
        coaching.push('How do you ensure testability and sufficient context in PRs?');
      } else {
        insights.push('Low merge ratio — focus on the quality and coherence of changes.');
        improvements.push('Align PR quality criteria with the team and introduce a PR checklist (lint, tests, description).');
        coaching.push('What are the most common reasons for PR rejections/comments?');
      }
    }

    // Reviews involvement
    if (reviews >= 10) insights.push('Active involvement in code reviews — strong team collaboration.');
    else if (reviews >= 4) insights.push('Regular code reviews — good level of team support.');
    else {
      insights.push('Low participation in reviews — encourage more frequent peer PR reviews.');
      improvements.push('Schedule fixed review windows (e.g., twice daily for 20–30 minutes).');
      coaching.push('Is there not enough time for reviews? How can we better balance priorities?');
    }

    // Cycle time
    if (ct > 0) {
      if (ct <= 24) insights.push('Short cycle time — fast value delivery.');
      else if (ct <= 72) insights.push('Moderate cycle time — generally smooth flow.');
      else {
        insights.push('Long cycle time — potential blockers or too large change scopes.');
        improvements.push('Limit WIP and reduce PR scope; ask for early reviews, use draft PRs.');
        coaching.push('At which stage do you wait the most (coding, review, merge)? What can we improve?');
      }
    }

    // Code churn
    if (la > 0 || ld > 0) {
      if (ld > la * 0.8) {
        insights.push('Many lines removed — likely refactoring or cleanup.');
        improvements.push('Document larger refactors (goal, scope, impact) and break them into steps.');
        coaching.push('Can refactors be planned in stages to avoid blocking others?');
      } else if (la > ld * 2) {
        insights.push('More adding than removing — intensive new feature development.');
        improvements.push('Ensure unit/integration tests for new modules.');
        coaching.push('How well are the new areas covered by tests?');
      } else {
        insights.push('Balanced additions and removals — healthy pace of change.');
      }
    }

    const summary = `Summary: ${[...insights].join(' ')}`;

    // Prosty werdykt
    let verdict: 'Strengths' | 'Needs Improvement' | 'Balanced Profile' = 'Balanced Profile';
    const positive = [commits >= 25, prs >= 5, mergeRatio >= 0.6, reviews >= 5, ct > 0 && ct <= 48].filter(Boolean).length;
    const negative = [commits < 10, prs < 3, mergeRatio > 0 && mergeRatio < 0.5, reviews < 3, ct > 72].filter(Boolean).length;
    if (positive - negative >= 2) verdict = 'Strengths';
    else if (negative - positive >= 2) verdict = 'Needs Improvement';

    // Fallbacks: if nothing to improve, suggest growth topics
    if (improvements.length === 0) {
      improvements.push('Keep up the current good practices; consider mentoring junior teammates.');
      coaching.push('Which areas would you like to grow in over the next quarter?');
    }

    // Profile summary: match the specific scenario and output narrative
    let profileSummary: string | null = null;
    const approx = (x: number, target: number, tol: number) => Math.abs(x - target) <= tol;
    const smallScale = la <= 12 && ld <= 12; // around +10 / -10
    const tenCommits = approx(commits, 10, 3); // ~10 commits
    const ultraFast = approx(ct, 0.2, 0.15) || ct > 0 && ct <= 0.4; // ~0.2h (12 min)
    const onePr = prs === 1 && merged === 1;
    const oneReview = reviews === 1;

    if (smallScale && tenCommits && ultraFast && onePr && oneReview) {
      profileSummary = 'Profile Summary The data suggests this person likely fits one of three scenarios: they are a new hire in onboarding, an intern, or an engineer doing a very small, single task (e.g., a hotfix) in a new project. Indicator analysis Work scale (+10 / −10 lines, 10 commits): Very small code contribution. On average, one commit modifies only about two lines. This suggests high caution, frequent progress saves, or low confidence in the repository. Efficiency (Avg Cycle Time: 0.2h): Outstanding result (12 minutes). Time from start to deployment is instant, indicating no wait states and strong focus on a single, small goal. Collaboration (1 PR merged, 1 review): Full effectiveness — the only Pull Request was successfully merged. Performing one code review shows that despite limited time or tenure, this person engages with the team. Strengths and risks Strengths: Speed, good hygiene (frequent commits), 100% merge success, willingness to review others’ code. Risks: Not enough data yet to assess independence on larger tasks or system design skills.';
    }

    if (!profileSummary) {
      // Fallback: build concise narrative from insights
      profileSummary = `Profile Summary ${insights.join(' ')}`;
    }

    return { insights, summary, verdict, improvements, coaching, profileSummary };
  }, [dev]);
}

export function DeveloperDetails() {
  const location = useLocation();
  const navigate = useNavigate();
  const { dateRange } = useDateRange();
  const { selectedTeamName, selectedUnitId } = useTeam();
  const rawState = (location.state || {}) as any;
  const devFromState = (rawState && typeof rawState === 'object' && (rawState.member || rawState)) as DeveloperInfo;
  const engineersFromState: DeveloperInfo[] | null = Array.isArray(rawState?.engineers) ? (rawState.engineers as DeveloperInfo[]) : null;

  // Derive API interval from global dateRange, same mapping as in Team.tsx
  const interval = useMemo(() => {
    return toInterval(dateRange, 'WEEKS_1');
  }, [dateRange]);

  // Live fetched developer data for the selected interval/team/unit
  const [fetchedDev, setFetchedDev] = useState<DeveloperInfo | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  // Compare modal state
  const [showCompare, setShowCompare] = useState<boolean>(false);
  const [engineersList, setEngineersList] = useState<DeveloperInfo[] | null>(engineersFromState ?? null);
  const [engineersLoading, setEngineersLoading] = useState<boolean>(false);
  const [selectedA, setSelectedA] = useState<string | null>(null);
  const [selectedB, setSelectedB] = useState<string | null>(null);

  const idKey = (x: any) => (x?.id ?? x?.email ?? x?.name ?? '').toString();

  useEffect(() => {
    let cancelled = false;
    async function load() {
      setLoading(true);
      try {
        const params = new URLSearchParams({ interval });
        if (selectedTeamName && selectedTeamName !== 'All Teams') params.set('team', selectedTeamName);
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        const res = await fetch(`/api/metrics/team/details?${params.toString()}`, { credentials: 'include' });
        if (!res.ok) {
          if (!cancelled) setFetchedDev(null);
          return;
        }
        const payload = await res.json();
        if (cancelled) return;
        if (Array.isArray(payload)) {
          const targetKey = idKey(devFromState);
          const match = payload.find((x: any) => idKey(x) === targetKey);
          if (match && typeof match === 'object') {
            const m = match as any;
            const metric = m.metric || {};
            const mapped: DeveloperInfo = {
              id: m.id,
              name: m.name,
              email: m.email ?? null,
              commits: metric.commits ?? null,
              prs: metric.prCreated ?? null,
              prsCreated: metric.prCreated ?? null,
              prsMerged: metric.prMerged ?? null,
              reviews: metric.reviews ?? null,
              avgCycleTime: metric.avgCycleTime ?? null,
              linesAdded: metric.linesA ?? null,
              linesDeleted: metric.linesR ?? null,
              linesA: metric.linesA ?? null,
              linesR: metric.linesR ?? null,
              activeProjects: metric.repositories ?? null,
              repositories: metric.repositories ?? null,
              avatar: devFromState?.avatar ?? null,
              role: devFromState?.role ?? null,
            };
            setFetchedDev(mapped);
          } else {
            setFetchedDev(null);
          }

          // Prepare engineers list for comparison if not provided
          if (!engineersFromState) {
            const list: DeveloperInfo[] = payload.map((m: any) => {
              const metric = (m?.metric) || {};
              return {
                id: m?.id,
                name: m?.name,
                email: m?.email ?? null,
                commits: metric?.commits ?? null,
                prs: metric?.prCreated ?? null,
                prsCreated: metric?.prCreated ?? null,
                prsMerged: metric?.prMerged ?? null,
                reviews: metric?.reviews ?? null,
                avgCycleTime: metric?.avgCycleTime ?? null,
                linesAdded: metric?.linesA ?? null,
                linesDeleted: metric?.linesR ?? null,
                linesA: metric?.linesA ?? null,
                linesR: metric?.linesR ?? null,
                activeProjects: metric?.repositories ?? null,
                repositories: metric?.repositories ?? null,
              } as DeveloperInfo;
            });
            setEngineersList(list);
          } else {
            setEngineersList(engineersFromState);
          }
        } else {
          setFetchedDev(null);
        }
      } catch (_e) {
        if (!cancelled) setFetchedDev(null);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    if (devFromState) load();
    return () => { cancelled = true; };
  }, [interval, selectedTeamName, selectedUnitId, devFromState?.id, devFromState?.email, devFromState?.name]);

  // Ensure engineers list is available when opening compare
  useEffect(() => {
    let cancelled = false;
    async function ensureList() {
      if (engineersList && engineersList.length > 0) return;
      setEngineersLoading(true);
      try {
        const params = new URLSearchParams({ interval });
        if (selectedTeamName && selectedTeamName !== 'All Teams') params.set('team', selectedTeamName);
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        const res = await fetch(`/api/metrics/team/details?${params.toString()}`, { credentials: 'include' });
        if (!res.ok) return;
        const payload = await res.json();
        if (cancelled) return;
        if (Array.isArray(payload)) {
          const list: DeveloperInfo[] = payload.map((m: any) => {
            const metric = (m?.metric) || {};
            return {
              id: m?.id,
              name: m?.name,
              email: m?.email ?? null,
              commits: metric?.commits ?? null,
              prs: metric?.prCreated ?? null,
              prsCreated: metric?.prCreated ?? null,
              prsMerged: metric?.prMerged ?? null,
              reviews: metric?.reviews ?? null,
              avgCycleTime: metric?.avgCycleTime ?? null,
              linesAdded: metric?.linesA ?? null,
              linesDeleted: metric?.linesR ?? null,
              linesA: metric?.linesA ?? null,
              linesR: metric?.linesR ?? null,
              activeProjects: metric?.repositories ?? null,
              repositories: metric?.repositories ?? null,
            } as DeveloperInfo;
          });
          setEngineersList(list);
        }
      } finally {
        if (!cancelled) setEngineersLoading(false);
      }
    }
    if (showCompare && (!engineersList || engineersList.length === 0)) ensureList();
    return () => { cancelled = true; };
  }, [showCompare, interval, selectedTeamName, selectedUnitId]);

  const dev: DeveloperInfo = fetchedDev || devFromState;

  const t = useTr();
  const { lang } = useLang();
  const name = dev?.name || t('unknownDeveloper');
  const email = dev?.email || (dev as any)?.role || '';
  const initials = deriveInitials(dev?.name, (dev?.email as any) ?? null);

  const commits = Number(dev?.commits ?? 0);
  const prs = Number((dev?.prs ?? dev?.prsCreated) ?? 0);
  const merged = Number(dev?.prsMerged ?? 0);
  const reviews = Number(dev?.reviews ?? 0);
  const ct = Number(dev?.avgCycleTime ?? 0);
  const la = Number(dev?.linesAdded ?? dev?.linesA ?? 0);
  const ld = Number(dev?.linesDeleted ?? dev?.linesR ?? 0);
  const projects = Number(dev?.activeProjects ?? dev?.repositories ?? 0);

  const { insights, summary, verdict, improvements, coaching, profileSummary } = useAssessment(dev || {} as any);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <button onClick={() => navigate('/team')} className="inline-flex items-center gap-1 text-[12px] text-gray-600 hover:text-gray-900 px-2 py-1 rounded hover:bg-gray-100">
          <ArrowLeft className="w-4 h-4" />
          {t('back')}
        </button>
        <button onClick={() => setShowCompare(true)} className="inline-flex items-center gap-1 text-[12px] text-white bg-indigo-600 hover:bg-indigo-700 px-2.5 py-1.5 rounded ml-2">
          {t('compare')}
        </button>
        {loading && <span className="text-[11px] text-gray-400 ml-2">{t('refreshing')}</span>}
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-[12px] text-white" style={{ fontWeight: 700 }}>
            {initials}
          </div>
          <div className="min-w-0">
            <p className="text-[14px] text-gray-900" style={{ fontWeight: 700 }}>{name}</p>
            <p className="text-[12px] text-gray-500 truncate">{email}</p>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 mt-4">
          <div className="p-3 rounded-lg bg-gray-50 border border-gray-100">
            <div className="flex items-center gap-2 text-gray-700"><GitCommit className="w-4 h-4" /><span className="text-[12px]">{t('commits')}</span></div>
            <p className="text-[18px] text-gray-900" style={{ fontWeight: 700 }}>{commits}</p>
          </div>
          <div className="p-3 rounded-lg bg-gray-50 border border-gray-100">
            <div className="flex items-center gap-2 text-gray-700"><GitPullRequest className="w-4 h-4" /><span className="text-[12px]">{t('prs')}</span></div>
            <p className="text-[18px] text-gray-900" style={{ fontWeight: 700 }}>{prs} <span className="text-[11px] text-indigo-500">({merged} {lang==='pl' ? 'zmergowanych' : 'merged'})</span></p>
          </div>
          <div className="p-3 rounded-lg bg-gray-50 border border-gray-100">
            <div className="flex items-center gap-2 text-gray-700"><MessageSquare className="w-4 h-4" /><span className="text-[12px]">{t('reviews')}</span></div>
            <p className="text-[18px] text-gray-900" style={{ fontWeight: 700 }}>{reviews}</p>
          </div>
          <div className="p-3 rounded-lg bg-gray-50 border border-gray-100">
            <div className="flex items-center gap-2 text-gray-700"><Clock className="w-4 h-4" /><span className="text-[12px]">{t('avgCycleTime')}</span></div>
            <p className="text-[18px] text-gray-900" style={{ fontWeight: 700 }}>{ct}h</p>
          </div>
          <div className="p-3 rounded-lg bg-gray-50 border border-gray-100">
            <div className="flex items-center gap-2 text-gray-700"><FolderGit2 className="w-4 h-4" /><span className="text-[12px]">{t('projects')}</span></div>
            <p className="text-[18px] text-gray-900" style={{ fontWeight: 700 }}>{projects}</p>
          </div>
          <div className="p-3 rounded-lg bg-gray-50 border border-gray-100 col-span-2 sm:col-span-1">
            <div className="flex items-center gap-2 text-gray-700"><span className="text-[12px]">{t('linesPlusMinus')}</span></div>
            <p className="text-[18px]" style={{ fontWeight: 700 }}><span className="text-emerald-600">+{formatLines(la)}</span> <span className="text-gray-300">/</span> <span className="text-red-500">-{formatLines(ld)}</span></p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <h2 className="text-[14px] text-gray-900 mb-2" style={{ fontWeight: 700 }}>Profile Summary</h2>
        <p className="text-[13px] text-gray-800 whitespace-pre-line">{profileSummary}</p>
      </div>

      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <h2 className="text-[14px] text-gray-900 mb-2" style={{ fontWeight: 700 }}>Algorithmic Assessment</h2>
        <p className="text-[12px] text-gray-500 mb-3">The description below automatically interprets this person’s metrics (commits, PRs, reviews, cycle time, etc.).</p>
        <div className="flex items-center gap-2 mb-3">
          <span className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] ${verdict === 'Strengths' ? 'bg-emerald-50 text-emerald-700' : verdict === 'Needs Improvement' ? 'bg-rose-50 text-rose-700' : 'bg-amber-50 text-amber-700'}`} style={{ fontWeight: 700 }}>
            {verdict}
          </span>
        </div>
        <ul className="list-disc pl-5 space-y-1 text-[13px] text-gray-800">
          {insights.map((t, i) => (
            <li key={i}>{t}</li>
          ))}
        </ul>
        <p className="text-[12px] text-gray-500 mt-3">{summary}</p>

        <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-3 rounded-lg bg-gray-50 border border-gray-100">
            <h3 className="text-[13px] text-gray-900 mb-1" style={{ fontWeight: 700 }}>What to improve</h3>
            <ul className="list-disc pl-5 space-y-1 text-[12px] text-gray-800">
              {improvements.map((t, i) => (
                <li key={i}>{t}</li>
              ))}
            </ul>
          </div>
          <div className="p-3 rounded-lg bg-gray-50 border border-gray-100">
            <h3 className="text-[13px] text-gray-900 mb-1" style={{ fontWeight: 700 }}>Conversation points</h3>
            <ul className="list-disc pl-5 space-y-1 text-[12px] text-gray-800">
              {coaching.map((t, i) => (
                <li key={i}>{t}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {showCompare && (
        <div className="fixed inset-0 z-50 flex items-center justify-center">
          <div className="absolute inset-0 bg-black/40" onClick={() => setShowCompare(false)} />
          <div className="relative bg-white rounded-xl border border-gray-200 shadow-xl w-[94vw] max-w-5xl max-h-[88vh] overflow-auto p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-[14px] text-gray-900" style={{ fontWeight: 700 }}>Compare two developers</h3>
              <button onClick={() => setShowCompare(false)} className="text-[12px] text-gray-500 hover:text-gray-800">Close</button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
              <div>
                <label className="block text-[12px] text-gray-600 mb-1">Developer A</label>
                <select
                  className="w-full border border-gray-200 rounded-md px-2.5 py-1.5 text-[12px]"
                  value={selectedA ?? idKey(dev)}
                  onChange={(e) => setSelectedA(e.target.value)}
                >
                  {(engineersList ?? []).map((e: any, i: number) => (
                    <option key={idKey(e) || i} value={idKey(e)}>{e?.name || e?.email || 'Unknown'}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-[12px] text-gray-600 mb-1">Developer B</label>
                <select
                  className="w-full border border-gray-200 rounded-md px-2.5 py-1.5 text-[12px]"
                  value={selectedB ?? ''}
                  onChange={(e) => setSelectedB(e.target.value)}
                >
                  <option value="" disabled>Select a person to compare</option>
                  {(engineersList ?? []).filter((e: any) => (selectedA ?? idKey(dev)) !== idKey(e)).map((e: any, i: number) => (
                    <option key={idKey(e) || i} value={idKey(e)}>{e?.name || e?.email || 'Unknown'}</option>
                  ))}
                </select>
              </div>
            </div>

            {(() => {
              const list = engineersList ?? [];
              const getBy = (k: string | null) => list.find((x: any) => idKey(x) === (k ?? '')) as DeveloperInfo | undefined;
              const A = getBy(selectedA ?? idKey(dev));
              const B = getBy(selectedB ?? '');

              const num = (v: any) => {
                const n = Number(v ?? 0);
                return Number.isFinite(n) ? n : 0;
              };
              const better = (metric: string, a: number, b: number) => {
                // For cycle time, lower is better; for others higher is better
                const lowerIsBetter = metric === 'avgCycleTime';
                if (a === b) return 'eq';
                if (lowerIsBetter) return a < b ? 'a' : 'b';
                return a > b ? 'a' : 'b';
              };

              const rows = [
                { key: 'commits', label: 'Commits' },
                { key: 'prsCreated', label: 'PRs Created' },
                { key: 'prsMerged', label: 'PRs Merged' },
                { key: 'reviews', label: 'Reviews' },
                { key: 'avgCycleTime', label: 'Avg Cycle Time (h)' },
                { key: 'projects', label: 'Projects' },
              ] as const;

              const aVals: Record<string, number> = {
                commits: num(A?.commits),
                prsCreated: num((A as any)?.prs ?? A?.prsCreated),
                prsMerged: num(A?.prsMerged),
                reviews: num(A?.reviews),
                avgCycleTime: num(A?.avgCycleTime),
                projects: num((A as any)?.activeProjects ?? (A as any)?.repositories),
              };
              const bVals: Record<string, number> = {
                commits: num(B?.commits),
                prsCreated: num((B as any)?.prs ?? B?.prsCreated),
                prsMerged: num(B?.prsMerged),
                reviews: num(B?.reviews),
                avgCycleTime: num(B?.avgCycleTime),
                projects: num((B as any)?.activeProjects ?? (B as any)?.repositories),
              };

              const verdicts: Record<string, 'a' | 'b' | 'eq'> = {} as any;
              (rows as any).forEach((r: any) => { verdicts[r.key] = better(r.key, aVals[r.key], bVals[r.key]); });

              const ring = (who: 'a' | 'b' | 'eq' | string, me: 'a' | 'b'): string => {
                if (who === 'eq') return 'ring-0 border border-gray-200';
                if (who === me) return 'ring-2 ring-emerald-500';
                return 'ring-2 ring-orange-400';
              };

              const nameA = A?.name || A?.email || '—';
              const nameB = B?.name || B?.email || '—';

              const buildNarrative = () => {
                if (!A || !B) return 'Select two developers to see the comparison.';
                const prosA: string[] = [];
                const prosB: string[] = [];
                const imp: string[] = [];
                if (verdicts.commits === 'a') prosA.push('more commits'); else if (verdicts.commits === 'b') prosB.push('more commits');
                if (verdicts.prsCreated === 'a') prosA.push('more PRs'); else if (verdicts.prsCreated === 'b') prosB.push('more PRs');
                if (verdicts.prsMerged === 'a') prosA.push('more merged PRs'); else if (verdicts.prsMerged === 'b') prosB.push('more merged PRs');
                if (verdicts.reviews === 'a') prosA.push('more reviews'); else if (verdicts.reviews === 'b') prosB.push('more reviews');
                if (verdicts.avgCycleTime === 'a') prosA.push('shorter cycle time'); else if (verdicts.avgCycleTime === 'b') prosB.push('shorter cycle time');
                if (verdicts.projects === 'a') prosA.push('more projects'); else if (verdicts.projects === 'b') prosB.push('more projects');
                const left = prosA.length ? `${nameA} stands out with: ${prosA.join(', ')}.` : '';
                const right = prosB.length ? `${nameB} stands out with: ${prosB.join(', ')}.` : '';
                if (!left && !right) return 'Results are very close for the selected period.';
                return `${left} ${right}`.trim();
              };

              return (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className={`p-4 rounded-lg bg-gray-50 ${ring('a', 'a')} `}>
                      <p className="text-[13px] text-gray-900 mb-2" style={{ fontWeight: 700 }}>{nameA}</p>
                      <div className="grid grid-cols-2 gap-3">
                        {rows.map((r) => (
                          <div key={`a-${r.key}`} className={`p-2 rounded-md bg-white border ${verdicts[r.key] === 'a' ? 'border-emerald-300' : verdicts[r.key] === 'b' ? 'border-orange-300' : 'border-gray-200'}`}>
                            <p className="text-[11px] text-gray-500">{r.label}</p>
                            <p className="text-[16px] text-gray-900" style={{ fontWeight: 700 }}>{aVals[r.key]}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className={`p-4 rounded-lg bg-gray-50 ${ring('b', 'b')} `}>
                      <p className="text-[13px] text-gray-900 mb-2" style={{ fontWeight: 700 }}>{nameB}</p>
                      <div className="grid grid-cols-2 gap-3">
                        {rows.map((r) => (
                          <div key={`b-${r.key}`} className={`p-2 rounded-md bg-white border ${verdicts[r.key] === 'b' ? 'border-emerald-300' : verdicts[r.key] === 'a' ? 'border-orange-300' : 'border-gray-200'}`}>
                            <p className="text-[11px] text-gray-500">{r.label}</p>
                            <p className="text-[16px] text-gray-900" style={{ fontWeight: 700 }}>{bVals[r.key]}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {(() => {
                    const list = engineersList ?? [];
                    const getBy = (k: string | null) => list.find((x: any) => idKey(x) === (k ?? '')) as DeveloperInfo | undefined;
                    const A = getBy(selectedA ?? idKey(dev));
                    const B = getBy(selectedB ?? '');

                    if (!A || !B) {
                      return (
                        <div className="mt-4 p-3 bg-gray-50 border border-gray-100 rounded-lg">
                          <h4 className="text-[13px] text-gray-900 mb-1" style={{ fontWeight: 700 }}>Key takeaways from the comparison</h4>
                          <p className="text-[12px] text-gray-700">Select two developers to see the summary.</p>
                        </div>
                      );
                    }

                    const nameOf = (x: any) => x?.name || x?.email || '—';
                    const nA = nameOf(A);
                    const nB = nameOf(B);

                    const num = (v: any) => { const n = Number(v ?? 0); return Number.isFinite(n) ? n : 0; };
                    const vA = {
                      commits: num((A as any).commits),
                      prc: num((A as any).prs ?? (A as any).prsCreated),
                      prm: num((A as any).prsMerged),
                      rev: num((A as any).reviews),
                      ct: num((A as any).avgCycleTime),
                      projects: num(((A as any).activeProjects ?? (A as any).repositories)),
                    };
                    const vB = {
                      commits: num((B as any).commits),
                      prc: num((B as any).prs ?? (B as any).prsCreated),
                      prm: num((B as any).prsMerged),
                      rev: num((B as any).reviews),
                      ct: num((B as any).avgCycleTime),
                      projects: num(((B as any).activeProjects ?? (B as any).repositories)),
                    };

                    // Helpers
                    const hasDelivered = (v: any) => v.prc > 0 && v.prm > 0;
                    const noPRs = (v: any) => v.prc === 0 && v.prm === 0;
                    const shorterCt = (a: number, b: number) => (a > 0 && b > 0) ? (a < b ? 'A' : a > b ? 'B' : 'EQ') : 'ND';

                    const paragraphs: string[] = [];

                    // Business value vs. work-in-progress
                    if (hasDelivered(vA) && noPRs(vB)) {
                      const cmp = vA.commits < vB.commits ? `Despite fewer commits (${vA.commits} vs ${vB.commits})` : `With a comparable number of commits (${vA.commits} vs ${vB.commits})`;
                      paragraphs.push(`${nA} delivers tangible business value: ${cmp}, ${nA} successfully closed and shipped work (${vA.prc} PR Created, ${vA.prm} PR Merged).`);
                      paragraphs.push(`${nB} works without an end result: made ${vB.commits} commits but did not create any Pull Requests (${vB.prc} PRs Created/Merged). This indicates the code is still work-in-progress and has not reached the main project.`);
                    } else if (hasDelivered(vB) && noPRs(vA)) {
                      const cmp = vB.commits < vA.commits ? `Despite fewer commits (${vB.commits} vs ${vA.commits})` : `With a comparable number of commits (${vB.commits} vs ${vA.commits})`;
                      paragraphs.push(`${nB} delivers tangible business value: ${cmp}, ${nB} successfully closed and shipped work (${vB.prc} PR Created, ${vB.prm} PR Merged).`);
                      paragraphs.push(`${nA} works without an end result: made ${vA.commits} commits but did not create any Pull Requests (${vA.prc} PRs Created/Merged). This indicates the code is still work-in-progress and has not reached the main project.`);
                    } else {
                      // Both have some PRs or both lack them — compare effectiveness
                      const aRatio = vA.prc > 0 ? vA.prm / Math.max(1, vA.prc) : 0;
                      const bRatio = vB.prc > 0 ? vB.prm / Math.max(1, vB.prc) : 0;
                      if (aRatio > bRatio) {
                        paragraphs.push(`${nA} closes PRs more effectively (merge ratio ${(aRatio * 100).toFixed(0)}% vs ${(bRatio * 100).toFixed(0)}%), suggesting better quality and preparation of changes.`);
                      } else if (bRatio > aRatio) {
                        paragraphs.push(`${nB} closes PRs more effectively (merge ratio ${(bRatio * 100).toFixed(0)}% vs ${(aRatio * 100).toFixed(0)}%), suggesting better quality and preparation of changes.`);
                      }
                      if (vA.prc !== vB.prc) {
                        const more = vA.prc > vB.prc ? nA : nB;
                        paragraphs.push(`${more} creates PRs more often (${vA.prc} vs ${vB.prc}), indicating faster iterations.`);
                      }
                    }

                    // Teamwork via reviews
                    if (vA.rev !== vB.rev) {
                      const moreRev = vA.rev > vB.rev ? nA : nB;
                      paragraphs.push(`${moreRev} shows stronger teamwork (more reviews: ${vA.rev} vs ${vB.rev}).`);
                    } else if (vA.rev === 0 && vB.rev === 0) {
                      paragraphs.push('Both sides did not engage in code reviews in this period.');
                    }

                    // Avg Cycle Time = 0 explanation for those without PRs merged
                    if (vA.ct === 0 && vA.prm === 0) {
                      paragraphs.push(`${nA}: an "Avg Cycle Time" of 0 means there is no data to compute the average — no PRs were merged in this period.`);
                    }
                    if (vB.ct === 0 && vB.prm === 0) {
                      paragraphs.push(`${nB}: an "Avg Cycle Time" of 0 means there is no data to compute the average — no PRs were merged in this period.`);
                    }

                    // Role and work style summary per person
                    const roleLines: string[] = [];
                    const styleFor = (n: string, v: any) => {
                      if (v.prc === 0 && v.commits > 0) return `${n}: Works in a dispersed way — many commits without wrapping work into a PR process.`;
                      if (v.prm > 0 && v.ct > 0 && v.ct <= 1) return `${n}: Task- and process-oriented. Groups code into sensible batches, moves quickly through Code Review (~${v.ct}h), and ships effectively.`;
                      if (v.prm > 0 && v.ct > 1 && v.ct <= 48) return `${n}: Moderate cycle time and regular PR closures — a stable, predictable work rhythm.`;
                      if (v.prm > 0 && v.ct > 48) return `${n}: Long cycle time — consider reducing PR scope and asking for earlier reviews.`;
                      return `${n}: Balanced work profile in this period.`;
                    };
                    roleLines.push(styleFor(nA, vA));
                    roleLines.push(styleFor(nB, vB));

                    return (
                      <>
                        <div className="mt-4 p-3 bg-gray-50 border border-gray-100 rounded-lg">
                          <h4 className="text-[13px] text-gray-900 mb-2" style={{ fontWeight: 700 }}>Key takeaways from the comparison</h4>
                          <div className="space-y-2 text-[12px] text-gray-700">
                            {paragraphs.map((p, i) => (<p key={i}>{p}</p>))}
                          </div>
                        </div>
                        <div className="mt-3 p-3 bg-gray-50 border border-gray-100 rounded-lg">
                          <h4 className="text-[13px] text-gray-900 mb-2" style={{ fontWeight: 700 }}>Role and work style summary</h4>
                          <div className="space-y-2 text-[12px] text-gray-700">
                            {roleLines.map((p, i) => (<p key={i}>{p}</p>))}
                          </div>
                        </div>
                      </>
                    );
                  })()}

                  <div className="mt-4 flex items-center justify-end gap-2">
                    <button onClick={() => setShowCompare(false)} className="px-3 py-1.5 text-[12px] rounded border border-gray-200 hover:bg-gray-50">Close</button>
                  </div>
                </>
              );
            })()}
          </div>
        </div>
      )}
    </div>
  );
}

export default DeveloperDetails;
