import {commitActivityData, teamMembers} from '../data/mockData';
import { computeWdu } from '../utils/utilization';
import {
    Area,
    AreaChart,
    Bar,
    BarChart,
    CartesianGrid,
    ComposedChart,
    Legend,
    Line,
    ResponsiveContainer,
    Tooltip,
    XAxis,
    YAxis,
} from 'recharts';
import { TrendingUp, GitCommit, GitPullRequest, MessageSquare, Clock, HelpCircle, ArrowUpDown, ArrowUp, ArrowDown } from 'lucide-react';
import { calculateTeamEffectiveness } from '../utils/effectiveness';
import { useEffect, useMemo, useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDateRange } from '../context/DateRangeContext';
import { useTeam } from '../context/TeamContext';
import { useTr, usePick } from '../i18n';
import { SkillsCell } from '../components/SkillsCell';
import { DevInsightsDialog, formatMinutes, type DevInsights } from '../components/DevInsightsDialog';
import { toInterval } from '../utils/dateRange';

const tooltipStyle = {
  backgroundColor: 'white',
  border: '1px solid #e5e7eb',
  borderRadius: '8px',
  fontSize: '12px',
  boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
};

// Safe number formatter used across the page
// Returns a localized string or a dash when value is null/undefined/NaN
function fmt(v: any): string {
  if (v == null) return '—';
  const n = Number(v);
  return Number.isFinite(n) ? n.toLocaleString() : '—';
}

const avatarGradients = [
  'from-violet-500 to-purple-600',
  'from-blue-500 to-cyan-600',
  'from-emerald-500 to-teal-600',
  'from-orange-500 to-red-500',
  'from-pink-500 to-rose-600',
];

const contributorBarData = teamMembers.map((m) => ({
  name: m.name.split(' ')[0],
  commits: m.commits,
  prs: m.prs,
  reviews: m.reviews,
})); // legacy mock; live variant is computed inside component

// Live Team Contributions chart data from API
type ContribItem = { name: string; commits: number; prs: number; reviews: number };

// Helper: stable seed per member for deterministic mock metrics
function computeSeed(member: any, i: number): number {
  return (
    String(member?.name ?? member?.email ?? i)
      .split('')
      .reduce((a: number, c: string) => a + c.charCodeAt(0), 0) +
    i * 31
  );
}

// Helper: mocked SonarQube-style metrics per developer (same logic as Code Quality tab)
function computeCodeQuality(member: any, i: number) {
  // Align seed with Code Quality tab so DQI reflects shown metrics (uses i*13 there)
  const seed = (
    String(member?.name ?? member?.email ?? i)
      .split('')
      .reduce((a: number, c: string) => a + c.charCodeAt(0), 0) +
    i * 13
  );
  const rng = (min: number, max: number) => min + (seed % (max - min + 1));
  const bugs = rng(0, 15);
  const vulns = rng(0, 8);
  const smells = rng(20, 180);
  const coverage = 40 + (seed % 56); // 40-96
  const dup = seed % 11; // 0-10
  return { bugs, vulns, smells, coverage, dup };
}

// Helper: mocked Agile metrics per developer (same logic as Agile tab)
function computeAgile(member: any, i: number) {
  const base = computeSeed(member, i);
  const mod = (n: number) => base % n;
  const avgTasks = 3 + mod(8); // 3-10
  const avgSP = 8 + mod(23); // 8-30
  const curTasks = 1 + mod(12); // 1-12
  const curSP = Math.max(0, avgSP - 5 + mod(11)); // around avgSP +/-5
  return { avgTasks, avgSP, curTasks, curSP };
}

// Compute Developer Quality Index (DQI) score and grade (A best, D worst)
// New algorithm per spec (uses Code Quality tab metrics only):
// Inputs and weights: Bugs 35%, Vulnerabilities 30%, Code Smells 15%, Duplication 20%.
// Each metric is normalized to [0,1] with a tolerant square-root function so that low values do not overly penalize the score.
// Final score = 100 * (1 - (0.35*nBugs + 0.30*nVulns + 0.15*nSmells + 0.20*nDup)); clamped to [0,100].
// Grades: A ≥85, B ≥65, C ≥40, else D.
function computeDQIGrade(member: any, i: number) {
  // Prefer live values rendered on the Code Quality tab if present on the member row
  // Fallback to deterministic mock if missing.
  const hasExplicit = (
    member?.bugs != null ||
    member?.vulnerabilities != null ||
    member?.codeSmells != null ||
    member?.duplication != null
  );

  let bugs: number, vulns: number, smells: number, dup: number;
  if (hasExplicit) {
    bugs = Number(member?.bugs ?? 0) || 0;
    vulns = Number(member?.vulnerabilities ?? 0) || 0;
    smells = Number(member?.codeSmells ?? 0) || 0;
    dup = Number(member?.duplication ?? 0) || 0;   // can be 0-10 or 0-100 (%). We'll normalize below.
  } else {
    const mocked = computeCodeQuality(member, i);
    bugs = mocked.bugs;
    vulns = mocked.vulns;
    smells = mocked.smells;
    dup = mocked.dup; // mocked scale: 0-10
  }

  // Normalize using tolerant sqrt: n(x) = sqrt(min(x, cap) / cap)
  // Caps chosen to reflect typical ranges and avoid harsh penalties for small counts.
  const BUGS_CAP = 50;       // ~ up to 50 bugs considered "worst"
  const VULNS_CAP = 30;      // ~ up to 30 vulnerabilities
  const SMELLS_CAP = 300;    // ~ up to 300 code smells
  const DUP_CAP = 50;        // 50% duplication considered worst-case

  const clamp = (v: number, min = 0, max = Number.POSITIVE_INFINITY) => Math.min(max, Math.max(min, v));

  const nBugs = Math.sqrt(clamp(bugs, 0, BUGS_CAP) / BUGS_CAP);
  const nVulns = Math.sqrt(clamp(vulns, 0, VULNS_CAP) / VULNS_CAP);
  const nSmells = Math.sqrt(clamp(smells, 0, SMELLS_CAP) / SMELLS_CAP);

  // Duplication may arrive as 0..10 (Sonar rating-like) or 0..100 (%). Convert to % first.
  let dupPct = dup;
  if (dupPct <= 1) dupPct = dupPct * 100; // if fraction 0..1
  if (dupPct > 0 && dupPct <= 10 && Math.max(bugs, vulns, smells) <= 300) {
    // Heuristic: many of our rows use 0..10 scale — treat as percent out of 100 via *10
    dupPct = dupPct * 10;
  }
  dupPct = clamp(dupPct, 0, 100);
  const nDup = Math.sqrt(clamp(dupPct, 0, DUP_CAP) / DUP_CAP);

  const weightedPenalty = 0.35 * nBugs + 0.30 * nVulns + 0.15 * nSmells + 0.20 * nDup;
  let score = Math.round((1 - clamp(weightedPenalty, 0, 1)) * 100);
  score = clamp(score, 0, 100);

  const grade = score >= 85 ? 'A' : score >= 65 ? 'B' : score >= 40 ? 'C' : 'D';
  const cls =
    grade === 'A'
      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
      : grade === 'B'
      ? 'bg-amber-50 text-amber-700 border border-amber-200'
      : grade === 'C'
      ? 'bg-orange-50 text-orange-700 border border-orange-200'
      : 'bg-rose-50 text-rose-700 border border-rose-200';
  return { grade, className: cls, score };
}

// Compute Developer Effectiveness Index (DEI) from Agile averages
function computeDEIGrade(member: any, i: number) {
  const { avgTasks, avgSP } = computeAgile(member, i);
  const spNorm = Math.max(0, Math.min(1, (avgSP - 8) / 22));
  const taskNorm = Math.max(0, Math.min(1, (avgTasks - 3) / 7));
  const score = Math.round((spNorm * 0.65 + taskNorm * 0.35) * 100); // weight SP more
  const grade = score >= 80 ? 'A' : score >= 65 ? 'B' : score >= 50 ? 'C' : 'D';
  const cls =
    grade === 'A'
      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
      : grade === 'B'
      ? 'bg-amber-50 text-amber-700 border border-amber-200'
      : grade === 'C'
      ? 'bg-orange-50 text-orange-700 border border-orange-200'
      : 'bg-rose-50 text-rose-700 border border-rose-200';
  return { grade, className: cls, score };
}

// Compute DEI letter for BASIC tab based on Agile data (SP diff and Utilization)
function computeDEILetterFromAgile(
  member: any,
  i: number,
  capacityByAssignee: Record<string, {
    avgTasks: number;
    avgSP: number;
    curTasks: number;
    curSP: number;
    initialTasks?: number;
    currentTotalTasks?: number;
    addedTasks?: number;
    completedTasks?: number;
    currentCompletionRatePercentage?: number; // 0-100
    avgCompletedTasksPerSprint?: number;
    avgCompletionRatePercentage?: number; // 0-100
  }>,
  analyzedSprints?: number
) {
  // Try to match capacity data by id, email, or name (same strategy as Agile tab)
  const keysToTry = [member?.id, member?.email, member?.name]
    .map((v: any) => (typeof v === 'string' ? v.trim().toLowerCase() : ''))
    .filter((v: string) => !!v);
  let cap: (typeof capacityByAssignee[string]) | undefined = undefined;
  for (const k of keysToTry) {
    if (capacityByAssignee[k]) { cap = capacityByAssignee[k]; break; }
  }
  // Styling helpers aligned with other badges
  const clsFor = (grade: 'A'|'B'|'C'|'D') => (
    grade === 'A'
      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
      : grade === 'B'
      ? 'bg-amber-50 text-amber-700 border border-amber-200'
      : grade === 'C'
      ? 'bg-orange-50 text-orange-700 border border-orange-200'
      : 'bg-rose-50 text-rose-700 border border-rose-200'
  );
  // If no agile data (UTILIZATION = N/A) → C or D depending on tenure (total analyzed sprints)
  if (!cap) {
    const lowTenure = typeof analyzedSprints === 'number' && isFinite(analyzedSprints) ? analyzedSprints <= 1 : false;
    const grade: 'C'|'D' = lowTenure ? 'D' : 'C';
    return { grade, className: clsFor(grade) };
  }
  const avgSP = Number(cap.avgSP ?? 0);
  const curSP = Number(cap.curSP ?? 0);
  const spDiff = curSP - avgSP;
  let utilization: 'Underutilized' | 'Utilized' | 'Overutilized' = 'Utilized';
  if (curSP < avgSP) utilization = 'Underutilized';
  else if (curSP > avgSP) utilization = 'Overutilized';

  // Compute DEI using specified algorithm
  const delivery = Math.max(0, Math.min(1, Number(cap.currentCompletionRatePercentage ?? 0) / 100));
  const planningRawNum = (() => {
    const initial = Number(cap.initialTasks ?? 0);
    const total = Number(cap.currentTotalTasks ?? (Number(cap.initialTasks ?? 0) + Number(cap.addedTasks ?? 0)));
    if (total <= 0) return 1; // if no tasks, treat planning as perfect to avoid punishing idle sprint
    return initial / total;
  })();
  const planning = Math.max(0, Math.min(1, planningRawNum));
  const scorePct = Math.round(((delivery * 0.6) + (planning * 0.4)) * 100);
  let grade: 'A'|'B'|'C'|'D' = 'D';
  if (scorePct >= 90) grade = 'A';
  else if (scorePct >= 75) grade = 'B';
  else if (scorePct >= 50) grade = 'C';
  else grade = 'D';

  const justification = (() => {
    const curr = Number(cap.currentCompletionRatePercentage ?? 0);
    const avg = Number(cap.avgCompletionRatePercentage ?? 0);
    const added = Number(cap.addedTasks ?? 0);
    if (curr >= 85 && planning >= 0.9) return 'Wysoka dowożalność i stabilny plan';
    if (added > 0 && curr < avg) return 'Dużo dorzuconych zadań, niski completion rate';
    if (curr < 50) return 'Niska dowożalność';
    if (planning < 0.7) return 'Niższa przewidywalność (dużo wrzutek)';
    return 'Solidna efektywność sprintu';
  })();

  return { grade, className: clsFor(grade), score: scorePct, delivery: Math.round(delivery*100), planning: Math.round(planning*100), justification };
}

function formatDiff(n: number) {
  const nn = Number(n);
  if (!Number.isFinite(nn)) return '—';
  const s = nn.toFixed(1);
  if (nn > 0) return `+${s}`;
  return s;
}

// Format any numeric value to 1 decimal place; return dash for null/NaN
function oneDec(v: any): string {
  const n = Number(v);
  if (!Number.isFinite(n)) return '—';
  return n.toFixed(1);
}

type TeamProps = { interval?: string; team?: string };
export function Team({ interval: intervalProp, team: teamProp }: TeamProps = {}) {
  const [agilePopupOpen, setAgilePopupOpen] = useState(false);
  const agilePopupRef = useRef<HTMLDivElement | null>(null);
  // Basic tab info popup state
  const [basicInfoOpen, setBasicInfoOpen] = useState(false);
  const basicInfoRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    function onDocClick(e: MouseEvent) {
      // Close Agile notes popup
      if (agilePopupOpen) {
        const el = agilePopupRef.current;
        if (el && e.target instanceof Node && !el.contains(e.target)) {
          setAgilePopupOpen(false);
        }
      }
      // Close Basic info popup
      if (basicInfoOpen) {
        const el2 = basicInfoRef.current;
        if (el2 && e.target instanceof Node && !el2.contains(e.target)) {
          setBasicInfoOpen(false);
        }
      }
    }
    document.addEventListener('mousedown', onDocClick);
    return () => document.removeEventListener('mousedown', onDocClick);
  }, [agilePopupOpen, basicInfoOpen]);
  const [engineersTab, setEngineersTab] = useState<'basic' | 'code' | 'agile'>('basic');
  function deriveInitials(name?: string | null, email?: string | null) {
    const safe = (s: any) => (typeof s === 'string' ? s : '');
    const n = safe(name).trim();
    if (n) {
      const parts = n.split(/\s+/).filter(Boolean);
      const first = parts[0]?.[0] || '';
      const last = parts.length > 1 ? parts[parts.length - 1]?.[0] : '';
      const res = `${first}${last}`.toUpperCase();
      if (res) return res;
    }
    const em = safe(email).trim();
    if (em) {
      const local = em.split('@')[0] || '';
      const first = local[0] || '';
      const last = local.length > 1 ? local[local.length - 1] : '';
      const res = `${first}${last}`.toUpperCase();
      if (res) return res;
    }
    return 'UU';
  }
  const { dateRange, label: dateRangeLabel } = useDateRange();
  const { selectedTeamName, selectedUnitId } = useTeam();
  const navigate = useNavigate();

  const derivedInterval = useMemo(() => {
    return toInterval(dateRange, 'WEEKS_1');
  }, [dateRange]);
  const interval = useMemo(() => intervalProp ?? derivedInterval, [intervalProp, derivedInterval]);
  // [PL] Logika wyboru zespołu używana do filtrowania zapytań po stronie backendu:
  // - Jeśli przekazano teamProp (np. z nawigacji) i nie jest to "All Teams", użyj go.
  // - W przeciwnym razie użyj wartości z TeamContext (selectedTeamName), o ile nie jest to "All Teams".
  // - Gdy nic nie wybrano lub wybrano "All Teams", nie dodajemy żadnego filtra zespołu do zapytań (agregat dla całości).
  const effectiveTeam = useMemo(() => {
    if (teamProp && teamProp !== 'All Teams') return teamProp;
    if (selectedTeamName && selectedTeamName !== 'All Teams') return selectedTeamName;
    return undefined;
  }, [teamProp, selectedTeamName]);

  const [health, setHealth] = useState<{ reviewParticipation?: number; workloadBalance?: number; knowledgeSharing?: number; collaborationScore?: number; loading: boolean }>({ loading: true });

  // Live PRs Created metric from API (/api/metrics/pr/c)
  const [prsCreated, setPrsCreated] = useState<{ value?: number; change?: number; positive?: boolean; loading: boolean }>({ loading: true });

  // Live Avg Cycle Time metric from API (/api/metrics/pr/t)
  const [avgCycle, setAvgCycle] = useState<{ value?: number; change?: number; positive?: boolean; loading: boolean }>({ loading: true });

  // Live Total Commits metric from API (/api/metrics/team/commits)
  const [commitsMetric, setCommitsMetric] = useState<{ value?: number; change?: number; positive?: boolean; loading: boolean }>({ loading: true });

  // Engineers (Team details) from API (/api/metrics/team/details)
  type ApiEngineer = {
    id?: string;
    name?: string;
    email?: string | null;
    metric?: {
      commits?: number | null;
      prCreated?: number | null;
      prMerged?: number | null;
      reviews?: number | null;
      avgCycleTime?: number | null; // hours
      linesA?: number | null;
      linesR?: number | null;
      repositories?: number | null;
      maintainabilityRating?: number | null;
      technicalDebt?: number | null;
      newDevelopmentCost?: number | null;
    } | null;
  };

  // People directory API for mapping skills/level to engineers
  type ApiPerson = {
    id: string;
    name: string | null;
    email?: string | null;
    commiterEmails?: string[] | null;
    level?: string | null;
    skills?: string[] | null;
  };

  const [engineersRaw, setEngineersRaw] = useState<ApiEngineer[] | null>(null);
  const [engineersLoading, setEngineersLoading] = useState<boolean>(false);
  // GitLab details per engineer (pipeline time, reverts, MR comments/size); declared before the sorting below uses it
  const [devInsights, setDevInsights] = useState<Record<string, DevInsights>>({});
  const [insightsMember, setInsightsMember] = useState<any | null>(null);
  const [peoples, setPeoples] = useState<ApiPerson[] | null>(null);

  // Sorting for Engineers tables across all sub‑tabs
  type SortKey =
    | 'engineer' | 'level' | 'skills'
    | 'dqi' | 'dei'
    | 'commits' | 'prs' | 'reviews' | 'avgCycle' | 'pipeline' | 'reverts' | 'lines' | 'projects' | 'calories'
    | 'bugs' | 'vulns' | 'smells' | 'coverage' | 'duplication'
    | 'avgTasks' | 'tasksDiff' | 'avgSP' | 'spDiff' | 'completedAvg' | 'predictability' | 'utilization';
  const [sortKey, setSortKey] = useState<SortKey>('engineer');
  const [sortDir, setSortDir] = useState<'asc'|'desc'>('asc');
  const NUMERIC_SORT_KEYS: SortKey[] = ['dqi','dei','commits','prs','reviews','avgCycle','pipeline','reverts','lines','projects','calories','bugs','vulns','smells','coverage','duplication','avgTasks','tasksDiff','avgSP','spDiff','completedAvg','predictability','utilization'];
  const SortIcon = (sk: SortKey) => {
    if (sortKey !== sk) return <ArrowUpDown className="w-3.5 h-3.5 text-gray-300" />;
    return sortDir === 'asc' ? (
      <ArrowUp className="w-3.5 h-3.5 text-indigo-500" />
    ) : (
      <ArrowDown className="w-3.5 h-3.5 text-indigo-500" />
    );
  };
  function onSort(sk: SortKey) {
    if (sortKey === sk) {
      setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
    } else {
      const def = NUMERIC_SORT_KEYS.includes(sk) ? 'desc' : 'asc';
      setSortKey(sk);
      setSortDir(def as any);
    }
  }

  // Team Contributions (per engineer) from API (/api/metrics/team/chart/contrib)
  const [contribData, setContribData] = useState<ContribItem[] | null>(null);

  // Task Capacity (Agile tab) from API (/api/metrics/team/task-capacity)
  type TaskCapacityUser = {
    assignee?: string;
    historicalMetrics?: {
      analyzedSprintsCount?: number;
      avgTotalTasksPerSprint?: number;
      avgTotalEstimatePerSprint?: number;
      avgInitialTasksPerSprint?: number;
      avgInitialEstimatePerSprint?: number;
      avgAddedTasksPerSprint?: number;
      avgAddedEstimatePerSprint?: number;
      // New fields from API
      avgCompletedTasksPerSprint?: number;
      avgCompletionRatePercentage?: number;
    };
    currentSprintMetrics?: {
      sprintName?: string;
      currentTotalTasks?: number;
      currentTotalEstimate?: number;
      initialTasks?: number;
      initialEstimate?: number;
      addedTasks?: number;
      addedEstimate?: number;
      // New fields from API
      completedTasks?: number;
      currentCompletionRatePercentage?: number;
    };
  };
  type TaskCapacityResponse = { users?: TaskCapacityUser[]; totalAnalyzedSprints?: number; sprintName?: string } | null;
  const [taskCapacity, setTaskCapacity] = useState<TaskCapacityResponse>(null);

  // Engineers data normalized from raw API response (placed before sorting to avoid TDZ)
  const engineersData = useMemo(() => {
    if (Array.isArray(engineersRaw) && engineersRaw.length > 0) {
      // Deduplicate by id+name
      const seen = new Set<string>();
      const list = [] as Array<{
        id: string;
        name: string;
        email: string | null;
        avatar: string; // initials
        commits?: number;
        prs?: number; // created
        prsMerged?: number;
        reviews?: number;
        avgCycleTime?: number; // hours
        linesAdded?: number;
        linesDeleted?: number;
        activeProjects?: number; // repositories
        bugs?: number;
        vulnerabilities?: number;
        codeSmells?: number;
        coverage?: number;
        duplication?: number;
      }>;
      for (const item of engineersRaw) {
        const id = typeof item?.id === 'string' && item.id ? item.id : Math.random().toString(36).slice(2);
        const name = typeof item?.name === 'string' && item.name ? item.name : 'Unknown';
        const key = `${id}::${name}`;
        if (seen.has(key)) continue;
        seen.add(key);
        const metric = item?.metric || ({} as any);
        const commits = typeof metric.commits === 'number' ? metric.commits : undefined;
        const prs = typeof metric.prCreated === 'number' ? metric.prCreated : undefined;
        const prsMerged = typeof metric.prMerged === 'number' ? metric.prMerged : undefined;
        const reviews = typeof metric.reviews === 'number' ? metric.reviews : undefined;
        const avgCycleTime = typeof metric.avgCycleTime === 'number' ? metric.avgCycleTime : undefined;
        const linesAdded = typeof metric.linesA === 'number' ? metric.linesA : undefined;
        const linesDeleted = typeof metric.linesR === 'number' ? metric.linesR : undefined;
        const activeProjects = typeof metric.repositories === 'number' ? metric.repositories : undefined;
        const email = (typeof item?.email === 'string' ? item.email : null);
        const avatar = deriveInitials(name, email);
        const bugs = typeof metric.bugs === 'number' ? metric.bugs : undefined;
        const vulnerabilities = typeof metric.vulnerabilities === 'number' ? metric.vulnerabilities : undefined;
        const codeSmells = typeof metric.codeSmells === 'number' ? metric.codeSmells : undefined;
        const coverage = typeof metric.coverage === 'number' ? metric.coverage : undefined;
        const duplication = typeof metric.duplication === 'number' ? metric.duplication : undefined;
        list.push({ id, name, email, avatar, commits, prs, prsMerged, reviews, avgCycleTime, linesAdded, linesDeleted, activeProjects,
            bugs, vulnerabilities, codeSmells, coverage, duplication,
        });
      }
      return list;
    }
    return null;
  }, [engineersRaw]);

  // People lookup maps and helpers (moved above sorting to avoid TDZ when used in comparators)
  const peopleMaps = useMemo(() => {
    const byEmail: Record<string, ApiPerson> = {};
    const byEmailLocal: Record<string, ApiPerson> = {};
    const byName: Record<string, ApiPerson> = {};
    const byId: Record<string, ApiPerson> = {};

    function emailLocal(v?: string | null): string {
      const e = typeof v === 'string' ? v : '';
      const local = e.split('@')[0] || '';
      // drop dots and plus-aliases in local-part, then normalize
      return norm(local.replace(/\./g, '').replace(/\+.*/, ''));
    }

    (peoples ?? []).forEach((p) => {
      const id = norm(String(p.id || ''));
      if (id) byId[id] = p;
      const name = norm(typeof p.name === 'string' ? p.name : '');
      if (name) byName[name] = p;
      const email = norm(typeof p.email === 'string' ? p.email : '');
      if (email) byEmail[email] = p;
      const el = emailLocal(p.email);
      if (el) byEmailLocal[el] = p;
      const cem = Array.isArray(p.commiterEmails) ? p.commiterEmails : [];
      cem.forEach((e) => {
        const k = norm(typeof e === 'string' ? e : '');
        if (k) byEmail[k] = p;
        const kl = emailLocal(e as any);
        if (kl) byEmailLocal[kl] = p;
      });
    });
    return { byEmail, byEmailLocal, byName, byId };
  }, [peoples]);

  // Normalize string: lowercased, trimmed, diacritics removed
  function norm(s: any): string {
    if (typeof s !== 'string') return '';
    return s
      .trim()
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '');
  }

  function splitTokens(name?: string | null): string[] {
    const n = norm(name ?? '');
    if (!n) return [];
    return n.split(/\s+/).filter(Boolean);
  }

  function matchPerson(member: any): ApiPerson | null {
    if (!member) return null;

    const emailLocalPart = (v?: string | null): string => {
      if (typeof v !== 'string') return '';
      const local = v.split('@')[0] || '';
      return norm(local.replace(/\./g, '').replace(/\+.*/, ''));
    };

    // Normalize all potential keys
    const tryKeys = [member.email, member.id, member.name]
      .map((v: any) => (typeof v === 'string' ? norm(v) : ''))
      .filter(Boolean) as string[];

    // 1) Direct lookups
    for (const k of tryKeys) {
      if (peopleMaps.byEmail[k]) return peopleMaps.byEmail[k];
      if (peopleMaps.byId[k]) return peopleMaps.byId[k];
      if (peopleMaps.byName[k]) return peopleMaps.byName[k];
    }

    // 2) Email local-part matching (handles dots and +aliases)
    const el = emailLocalPart(member.email);
    if (el && peopleMaps.byEmailLocal[el]) return peopleMaps.byEmailLocal[el];

    // 3) Fallback: fuzzy name matching (handles swapped order and diacritics)
    const mtoks = splitTokens(member.name);
    if (mtoks.length) {
      const msorted = [...mtoks].sort().join(' ');
      let candidate: ApiPerson | null = null;
      for (const p of (peoples ?? [])) {
        const ptoks = splitTokens(p?.name ?? '');
        if (!ptoks.length) continue;
        const psorted = [...ptoks].sort().join(' ');
        if (psorted === msorted) { candidate = p; break; }
        // Last name + first-initial heuristic
        const plast = ptoks[ptoks.length - 1];
        const mlast = mtoks[mtoks.length - 1];
        const pfirst = ptoks[0]?.[0];
        const mfirst = mtoks[0]?.[0];
        if (plast && mlast && plast === mlast && pfirst && mfirst && pfirst === mfirst) {
          candidate = p; // keep but continue to search exact sorted match
        }
      }
      if (candidate) return candidate;
    }
    return null;
  }

  // Pre-join people to engineers to ensure row-level assignment of level/skills
  const engineersJoined = useMemo(() => {
    const base = Array.isArray(engineersData) ? engineersData : Array.isArray(teamMembers) ? teamMembers : [];
    return base.map((m: any) => ({ ...m, _person: matchPerson(m) }));
  }, [engineersData, teamMembers, peoples]);

  // Sorting logic across all Engineers tabs
  const sortedEngineers = useMemo(() => {
    const list = [...engineersJoined] as any[];
    function calories(member: any, i: number): number {
      const { avgSP, avgTasks } = computeAgile(member, i);
      const commits = Number(member.commits ?? 0);
      const prs = Number(member.prs ?? member.prsCreated ?? 0);
      const reviews = Number(member.reviews ?? 0);
      const base = 1500 + (computeSeed(member, i) % 600);
      return Math.round(base + commits * 4 + prs * 9 + reviews * 6 + Number(avgSP) * 12 + Number(avgTasks) * 5);
    }
    function lines(member: any): number {
      const a = Number(member.linesAdded ?? member.linesA ?? 0);
      const r = Number(member.linesDeleted ?? member.linesR ?? 0);
      return a - r; // net lines changed
    }
    function getLevel(member: any): string {
      const p = (member as any)._person ?? matchPerson(member);
      return String(p?.level ?? '').toUpperCase();
    }
    function getSkills(member: any): string {
      const p = (member as any)._person ?? matchPerson(member);
      const arr = Array.isArray(p?.skills) ? (p!.skills as string[]) : [];
      return arr.join(', ').toLowerCase();
    }
    // Build a local capacity map from taskCapacity to avoid TDZ when referencing capacityByAssignee declared later
    const cba = (() => {
      const map: Record<string, any> = {};
      const users = Array.isArray(taskCapacity?.users) ? taskCapacity!.users! : [];
      users.forEach((u) => {
        const key = String(u?.assignee ?? '').trim().toLowerCase();
        if (!key) return;
        const h = (u?.historicalMetrics || {}) as any;
        const c = (u?.currentSprintMetrics || {}) as any;
        const avgTasks = Number(h?.avgTotalTasksPerSprint ?? h?.avgInitialTasksPerSprint ?? 0);
        const avgSP = Number(h?.avgTotalEstimatePerSprint ?? h?.avgInitialEstimatePerSprint ?? 0);
        const curTasks = Number(c?.currentTotalTasks ?? c?.initialTasks ?? 0);
        const curSP = Number(c?.currentTotalEstimate ?? c?.initialEstimate ?? 0);
        const avgAddedTasksPerSprint = Number(h?.avgAddedTasksPerSprint ?? 0);
        const avgAddedEstimatePerSprint = Number(h?.avgAddedEstimatePerSprint ?? 0);
        const initialTasks = Number(c?.initialTasks ?? 0);
        const initialEstimate = Number(c?.initialEstimate ?? 0);
        const addedTasks = Number(c?.addedTasks ?? 0);
        const addedEstimate = Number(c?.addedEstimate ?? 0);
        const avgCompletedTasksPerSprint = Number(h?.avgCompletedTasksPerSprint ?? 0);
        const avgCompletionRatePercentage = Number(h?.avgCompletionRatePercentage ?? 0);
        const completedTasks = Number(c?.completedTasks ?? 0);
        const currentCompletionRatePercentage = Number(c?.currentCompletionRatePercentage ?? 0);
        map[key] = {
          avgTasks: isFinite(avgTasks) ? Number(avgTasks.toFixed(1)) : 0,
          avgSP: isFinite(avgSP) ? Number(avgSP.toFixed(1)) : 0,
          curTasks: isFinite(curTasks) ? curTasks : 0,
          curSP: isFinite(curSP) ? curSP : 0,
          avgAddedTasksPerSprint: isFinite(avgAddedTasksPerSprint) ? Number(avgAddedTasksPerSprint.toFixed(1)) : 0,
          avgAddedEstimatePerSprint: isFinite(avgAddedEstimatePerSprint) ? Number(avgAddedEstimatePerSprint.toFixed(1)) : 0,
          initialTasks: isFinite(initialTasks) ? initialTasks : 0,
          initialEstimate: isFinite(initialEstimate) ? initialEstimate : 0,
          addedTasks: isFinite(addedTasks) ? addedTasks : 0,
          addedEstimate: isFinite(addedEstimate) ? addedEstimate : 0,
          avgCompletedTasksPerSprint: isFinite(avgCompletedTasksPerSprint) ? Number(avgCompletedTasksPerSprint.toFixed(1)) : 0,
          avgCompletionRatePercentage: isFinite(avgCompletionRatePercentage) ? Number(avgCompletionRatePercentage.toFixed(1)) : 0,
          completedTasks: isFinite(completedTasks) ? completedTasks : 0,
          currentCompletionRatePercentage: isFinite(currentCompletionRatePercentage) ? Number(currentCompletionRatePercentage.toFixed(1)) : 0,
        };
      });
      return map;
    })();
    function dqi(member: any, i: number): number { return computeDQIGrade(member, i)?.score ?? 0; }
    function dei(member: any, i: number): number { return computeDEILetterFromAgile(member, i, cba as any, taskCapacity?.totalAnalyzedSprints)?.score ?? 0; }

    const numericDesc: SortKey[] = ['dqi','dei','commits','prs','reviews','avgCycle','pipeline','reverts','lines','projects','calories','bugs','vulns','smells','coverage','duplication','avgTasks','tasksDiff','avgSP','spDiff','completedAvg','predictability','utilization'];

    const comparator = (a: any, b: any): number => {
      const iA = list.indexOf(a);
      const iB = list.indexOf(b);
      const dir = sortDir === 'asc' ? 1 : -1;
      function cmp(v1: any, v2: any): number {
        if (v1 == null && v2 == null) return 0;
        if (v1 == null) return -1 * dir;
        if (v2 == null) return 1 * dir;
        if (typeof v1 === 'number' && typeof v2 === 'number') return (v1 - v2) * dir;
        return String(v1).localeCompare(String(v2)) * dir;
      }
      const getCap = (m: any) => {
        const keysToTry = [m?.id, m?.email, m?.name]
          .map((v: any) => (typeof v === 'string' ? v.trim().toLowerCase() : ''))
          .filter((v: string) => !!v);
        for (const k of keysToTry) {
          if ((cba as any)[k]) return (cba as any)[k];
        }
        return undefined as any;
      };
      const agileVals = (m: any) => {
        const cap = getCap(m);
        if (!cap) return {
          avgTasks: 0, tasksDiff: 0, avgSP: 0, spDiff: 0,
          completedAvg: 0, predictability: 0, utilization: 0,
        };
        const avgTasks = Number(cap.avgTasks || 0);
        const avgSP = Number(cap.avgSP || 0);
        const curTasks = Number(cap.curTasks || 0);
        const curSP = Number(cap.curSP || 0);
        const completed = Number(cap.completedTasks || 0);
        const predict = Number(cap.currentCompletionRatePercentage || 0);
        const wdu = computeWdu({
          currentSP: curSP,
          averageSP: avgSP,
          currentTasks: curTasks,
          averageTasks: avgTasks,
          initialTasks: cap.initialTasks,
          initialSP: cap.initialEstimate,
          addedTasks: cap.addedTasks,
          addedSP: cap.addedEstimate,
        });
        return {
          avgTasks,
          tasksDiff: curTasks - avgTasks,
          avgSP,
          spDiff: curSP - avgSP,
          completedAvg: completed,
          predictability: predict,
          utilization: wdu.utilizationPct,
        };
      };
      const val = (() => {
        switch (sortKey) {
          case 'engineer': return cmp(String(a.name||''), String(b.name||''));
          case 'level': return cmp(getLevel(a), getLevel(b));
          case 'skills': return cmp(getSkills(a), getSkills(b));
          case 'dqi': return cmp(dqi(a,iA), dqi(b,iB));
          case 'dei': return cmp(dei(a,iA), dei(b,iB));
          case 'commits': return cmp(Number(a.commits||0), Number(b.commits||0));
          case 'prs': return cmp(Number(a.prs ?? a.prsCreated ?? 0), Number(b.prs ?? b.prsCreated ?? 0));
          case 'reviews': return cmp(Number(a.reviews||0), Number(b.reviews||0));
          case 'avgCycle': return cmp(Number(a.avgCycleTime||0), Number(b.avgCycleTime||0));
          case 'pipeline': return cmp(Number(devInsights[a.id]?.avgPipelineMinutes||0), Number(devInsights[b.id]?.avgPipelineMinutes||0));
          case 'reverts': return cmp(Number(devInsights[a.id]?.revertsMade||0) + Number(devInsights[a.id]?.commitsReverted||0), Number(devInsights[b.id]?.revertsMade||0) + Number(devInsights[b.id]?.commitsReverted||0));
          case 'lines': return cmp(lines(a), lines(b));
          case 'projects': return cmp(Number(a.activeProjects ?? a.repositories ?? 0), Number(b.activeProjects ?? b.repositories ?? 0));
          case 'calories': return cmp(calories(a,iA), calories(b,iB));
          case 'bugs': return cmp(Number(a.bugs||0), Number(b.bugs||0));
          case 'vulns': return cmp(Number(a.vulnerabilities||0), Number(b.vulnerabilities||0));
          case 'smells': return cmp(Number(a.codeSmells||0), Number(b.codeSmells||0));
          case 'coverage': return cmp(Number(a.coverage||0), Number(b.coverage||0));
          case 'duplication': return cmp(Number(a.duplication||0), Number(b.duplication||0));
          case 'avgTasks': return cmp(agileVals(a).avgTasks, agileVals(b).avgTasks);
          case 'tasksDiff': return cmp(agileVals(a).tasksDiff, agileVals(b).tasksDiff);
          case 'avgSP': return cmp(agileVals(a).avgSP, agileVals(b).avgSP);
          case 'spDiff': return cmp(agileVals(a).spDiff, agileVals(b).spDiff);
          case 'completedAvg': return cmp(agileVals(a).completedAvg, agileVals(b).completedAvg);
          case 'predictability': return cmp(agileVals(a).predictability, agileVals(b).predictability);
          case 'utilization': return cmp(agileVals(a).utilization, agileVals(b).utilization);
          default: return 0;
        }
      })();
      if (val !== 0) return val;
      return String(a.name||'').localeCompare(String(b.name||''));
    };

    // Default direction for numeric columns: desc; for text: asc
    const isNumeric = (k: SortKey) => numericDesc.includes(k);
    const desiredDir = isNumeric(sortKey) ? sortDir : sortDir; // keep state as chosen

    list.sort(comparator);
    if (desiredDir === 'desc' && !numericDesc.includes('engineer') && sortKey==='engineer') list.reverse();
    return list;
  }, [engineersData, sortKey, sortDir, taskCapacity, devInsights]);

  // Load people directory for skills/level mapping
  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    async function loadPeoples() {
      try {
        // Wait until team details are loaded to ensure we can pass developer IDs
        if (engineersRaw === null) {
          return;
        }
        // Load People directory. For /api/admin/organization/peoples/peoples pass developer IDs from /api/team/details.
        const tryUrls = [
          '/api/admin/organization/peoples/peoples',
        ];

        // Collect developer IDs from team details (engineersRaw) and de-duplicate to avoid repeated requests per the requirement
        const idsAll = (engineersRaw ?? []).map(e => e?.id).filter((v): v is string => Boolean(v));
        const ids = Array.from(new Set(idsAll));

        // Generic params for any non-admin fallback endpoints (kept for backward compatibility)
        const genericParams = new URLSearchParams();
        genericParams.set('interval', interval);
        if (selectedUnitId) genericParams.set('unitId', selectedUnitId);
        else if (effectiveTeam) genericParams.set('team', String(effectiveTeam));
        const genericQs = genericParams.toString();

        let data: any = null;
        let lastErr: any = null;
        for (const baseUrl of tryUrls) {
          const isApiAdminPeoples = baseUrl.startsWith('/api/admin/organization/');

          if (isApiAdminPeoples) {
            // Requirement: query one id at a time to /api/admin/organization/peoples/peoples
            if (ids.length === 0) {
              data = [];
              break;
            }
            try {
              const collected: any[] = [];
              for (const id of ids) {
                if (cancelled) break;
                const url = `${baseUrl}?query=${encodeURIComponent(id)}`;
                const res = await fetch(url, { credentials: 'include', signal: controller.signal, headers: { Accept: 'application/json' } });
                if (!res.ok) {
                  lastErr = new Error(`peoples HTTP ${res.status} at ${url}`);
                  continue;
                }
                const parsed = await res.json();
                if (Array.isArray(parsed)) {
                  for (const p of parsed) collected.push(p);
                } else if (parsed) {
                  collected.push(parsed);
                }
              }
              // De-duplicate by person id
              const seen = new Set<string>();
              data = collected.filter((p) => {
                const key = String(p && (p.id ?? p.email ?? p.name));
                if (seen.has(key)) return false;
                seen.add(key);
                return true;
              });
              break;
            } catch (e) {
              lastErr = e;
              continue;
            }
          } else {
            // For any non-admin endpoints, keep previous behavior with interval/team/unitId
            const url = genericQs ? `${baseUrl}?${genericQs}` : baseUrl;
            try {
              const res = await fetch(url, { credentials: 'include', signal: controller.signal, headers: { Accept: 'application/json' } });
              if (!res.ok) {
                lastErr = new Error(`peoples HTTP ${res.status} at ${url}`);
                continue;
              }
              const parsed = await res.json();
              if (Array.isArray(parsed)) {
                data = parsed;
                break;
              }
            } catch (e) {
              lastErr = e;
            }
          }
        }
        if (data && !cancelled) {
          if (data.length === 0) {
            console.warn('[Team] peoples endpoint returned empty array');
          }
          setPeoples(data as ApiPerson[]);
        } else if (!cancelled) {
          throw lastErr || new Error('peoples: no valid response');
        }
      } catch (e) {
        if (!cancelled) {
          console.warn('[Team] Failed to load peoples:', e);
          setPeoples([]);
        }
      }
    }
    loadPeoples();
    return () => { cancelled = true; controller.abort(); };
  }, [interval, selectedUnitId, effectiveTeam, engineersRaw]);


  const LEVEL_BADGE: Record<string, string> = {
    Junior: 'bg-emerald-100 text-emerald-700',
    Mid: 'bg-blue-100 text-blue-700',
    Senior: 'bg-violet-100 text-violet-700',
    'Tech Lead': 'bg-orange-100 text-orange-700',
    JUNIOR: 'bg-emerald-100 text-emerald-700',
    REGULAR: 'bg-blue-100 text-blue-700',
    SENIOR: 'bg-violet-100 text-violet-700',
    LEAD: 'bg-orange-100 text-orange-700',
  };

  // Commit Activity (daily/period commits) from API (/api/metrics/team/chart/ca)
  type CommitPoint = { date: string; commits: number };
  const [commitActivityLive, setCommitActivityLive] = useState<CommitPoint[] | null>(null);

  const capacityByAssignee = useMemo(() => {
    const map: Record<string, {
      avgTasks: number;
      avgSP: number;
      curTasks: number;
      curSP: number;
      avgAddedTasksPerSprint: number;
      avgAddedEstimatePerSprint: number;
      initialTasks: number;
      initialEstimate: number;
      addedTasks: number;
      addedEstimate: number;
      // New derived fields from API
      avgCompletedTasksPerSprint: number;
      avgCompletionRatePercentage: number; // 0-100
      completedTasks: number;
      currentCompletionRatePercentage: number; // 0-100
    }> = {};
    const users = Array.isArray(taskCapacity?.users) ? taskCapacity!.users! : [];
    users.forEach((u) => {
      const key = String(u?.assignee ?? '').trim().toLowerCase();
      if (!key) return;
      const h = (u?.historicalMetrics || {}) as any;
      const c = (u?.currentSprintMetrics || {}) as any;
      const avgTasks = Number(h?.avgTotalTasksPerSprint ?? h?.avgInitialTasksPerSprint ?? 0);
      const avgSP = Number(h?.avgTotalEstimatePerSprint ?? h?.avgInitialEstimatePerSprint ?? 0);
      const curTasks = Number(c?.currentTotalTasks ?? c?.initialTasks ?? 0);
      const curSP = Number(c?.currentTotalEstimate ?? c?.initialEstimate ?? 0);
      const avgAddedTasksPerSprint = Number(h?.avgAddedTasksPerSprint ?? 0);
      const avgAddedEstimatePerSprint = Number(h?.avgAddedEstimatePerSprint ?? 0);
      const initialTasks = Number(c?.initialTasks ?? 0);
      const initialEstimate = Number(c?.initialEstimate ?? 0);
      const addedTasks = Number(c?.addedTasks ?? 0);
      const addedEstimate = Number(c?.addedEstimate ?? 0);
      // New API fields
      const avgCompletedTasksPerSprint = Number(h?.avgCompletedTasksPerSprint ?? 0);
      const avgCompletionRatePercentage = Number(h?.avgCompletionRatePercentage ?? 0);
      const completedTasks = Number(c?.completedTasks ?? 0);
      const currentCompletionRatePercentage = Number(c?.currentCompletionRatePercentage ?? 0);
      map[key] = {
        avgTasks: isFinite(avgTasks) ? Number(avgTasks.toFixed(1)) : 0,
        avgSP: isFinite(avgSP) ? Number(avgSP.toFixed(1)) : 0,
        curTasks: isFinite(curTasks) ? curTasks : 0,
        curSP: isFinite(curSP) ? curSP : 0,
        avgAddedTasksPerSprint: isFinite(avgAddedTasksPerSprint) ? Number(avgAddedTasksPerSprint.toFixed(1)) : 0,
        avgAddedEstimatePerSprint: isFinite(avgAddedEstimatePerSprint) ? Number(avgAddedEstimatePerSprint.toFixed(1)) : 0,
        initialTasks: isFinite(initialTasks) ? initialTasks : 0,
        initialEstimate: isFinite(initialEstimate) ? initialEstimate : 0,
        addedTasks: isFinite(addedTasks) ? addedTasks : 0,
        addedEstimate: isFinite(addedEstimate) ? addedEstimate : 0,
        avgCompletedTasksPerSprint: isFinite(avgCompletedTasksPerSprint) ? Number(avgCompletedTasksPerSprint.toFixed(1)) : 0,
        avgCompletionRatePercentage: isFinite(avgCompletionRatePercentage) ? Number(avgCompletionRatePercentage.toFixed(1)) : 0,
        completedTasks: isFinite(completedTasks) ? completedTasks : 0,
        currentCompletionRatePercentage: isFinite(currentCompletionRatePercentage) ? Number(currentCompletionRatePercentage.toFixed(1)) : 0,
      };
    });
    return map;
  }, [taskCapacity]);

  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    async function load() {
      setHealth((s) => ({ ...s, loading: true }));
      try {
        const params = new URLSearchParams({ interval });
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        else if (effectiveTeam) params.set('team', String(effectiveTeam));
        const res = await fetch(`/api/metrics/team/health?${params.toString()}`, { credentials: 'include', signal: controller.signal });
        if (!res.ok) throw new Error('Failed');
        const data = await res.json();
        if (cancelled) return;
        const obj: any = data && typeof data === 'object' ? data : {};
        setHealth({
          reviewParticipation: typeof obj.reviewParticipation === 'number' ? obj.reviewParticipation : undefined,
          workloadBalance: typeof obj.workloadBalance === 'number' ? obj.workloadBalance : undefined,
          knowledgeSharing: typeof obj.knowledgeSharing === 'number' ? obj.knowledgeSharing : undefined,
          collaborationScore: typeof obj.collaborationScore === 'number' ? obj.collaborationScore : undefined,
          loading: false,
        });
      } catch (_e) {
        if (cancelled) return;
        setHealth({ loading: false });
      }
    }
    load();
    return () => { cancelled = true; controller.abort(); };
  }, [interval, selectedUnitId, effectiveTeam]);

  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    async function loadPrsCreated() {
      setPrsCreated((s) => ({ ...s, loading: true }));
      try {
        const params = new URLSearchParams({ interval });
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        else if (effectiveTeam) params.set('team', String(effectiveTeam));
        const res = await fetch(`/api/metrics/pr/t?${params.toString()}`, { credentials: 'include', signal: controller.signal });
        if (!res.ok) throw new Error('Failed');
        const data = await res.json();
        if (cancelled) return;
        const value = typeof data?.value === 'number' ? data.value : undefined;
        const change = typeof data?.change === 'number' ? data.change : undefined;
        const positive = typeof data?.positive === 'boolean' ? data.positive : undefined;
        setPrsCreated({ value, change, positive, loading: false });
      } catch (_e) {
        if (cancelled) return;
        setPrsCreated({ loading: false });
      }
    }
    loadPrsCreated();
    return () => { cancelled = true; controller.abort(); };
  }, [interval, selectedUnitId, effectiveTeam]);

  // Load Avg Cycle Time
  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    async function loadAvgCycle() {
      setAvgCycle((s) => ({ ...s, loading: true }));
      try {
        const params = new URLSearchParams({ interval });
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        else if (effectiveTeam) params.set('team', String(effectiveTeam));
        const res = await fetch(`/api/metrics/pr/c?${params.toString()}`, { credentials: 'include', signal: controller.signal });
        if (!res.ok) throw new Error('Failed');
        const data = await res.json();
        if (cancelled) return;
        const value = typeof data?.value === 'number' ? data.value : undefined;
        const change = typeof data?.change === 'number' ? data.change : undefined;
        const positive = typeof data?.positive === 'boolean' ? data.positive : undefined;
        setAvgCycle({ value, change, positive, loading: false });
      } catch (_e) {
        if (cancelled) return;
        setAvgCycle({ loading: false });
      }
    }
    loadAvgCycle();
    return () => { cancelled = true; controller.abort(); };
  }, [interval, selectedUnitId, effectiveTeam]);

  // Load Total Commits metric
  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    async function loadCommits() {
      setCommitsMetric((s) => ({ ...s, loading: true }));
      try {
        const params = new URLSearchParams({ interval });
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        else if (effectiveTeam) params.set('team', String(effectiveTeam));
        const res = await fetch(`/api/metrics/team/commits?${params.toString()}`, { credentials: 'include', signal: controller.signal });
        if (!res.ok) throw new Error('Failed');
        const data = await res.json();
        if (cancelled) return;
        const value = typeof data?.value === 'number' ? data.value : undefined;
        const change = typeof data?.change === 'number' ? data.change : undefined;
        const positive = typeof data?.positive === 'boolean' ? data.positive : undefined;
        setCommitsMetric({ value, change, positive, loading: false });
      } catch (_e) {
        if (cancelled) return;
        setCommitsMetric({ loading: false });
      }
    }
    loadCommits();
    return () => { cancelled = true; controller.abort(); };
  }, [interval, selectedUnitId, effectiveTeam]);

  // Load Engineers details
  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    async function loadEngineers() {
      setEngineersLoading(true);
      try {
        // Build params for endpoint:
        // - /api/metrics/team/details: can accept unitId or team along with interval
        const paramsAll = new URLSearchParams({ interval });
        if (selectedUnitId) paramsAll.set('unitId', selectedUnitId);
        else if (effectiveTeam) paramsAll.set('team', String(effectiveTeam));

        // Per requirement: do not call /api/team/details at all
        const tryUrls = [
          `/api/metrics/team/details?${paramsAll.toString()}`,
        ];
        let data: any = null;
        for (const url of tryUrls) {
          try {
            const res = await fetch(url, { credentials: 'include', signal: controller.signal });
            if (!res.ok) continue;
            const parsed = await res.json();
            if (Array.isArray(parsed)) { data = parsed; break; }
          } catch (_e) {
            // try next
          }
        }
        if (cancelled) return;
        if (Array.isArray(data)) {
          setEngineersRaw(data as any);
        } else {
          setEngineersRaw([]);
        }
      } catch (_e) {
        if (!cancelled) return;
      } finally {
        if (!cancelled) setEngineersLoading(false);
      }
    }
    loadEngineers();
    return () => { cancelled = true; controller.abort(); };
  }, [interval, selectedUnitId, effectiveTeam]);

  // GitLab details per engineer (pipeline time, reverts, MR comments/size) for the Engineers table and its popup
  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    async function loadDevInsights() {
      try {
        const params = new URLSearchParams({ interval });
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        const res = await fetch(`/api/metrics/team/dev-insights?${params.toString()}`, { credentials: 'include', signal: controller.signal });
        if (!res.ok) throw new Error(String(res.status));
        const data = await res.json();
        if (cancelled) return;
        const map: Record<string, DevInsights> = {};
        if (Array.isArray(data)) data.forEach((it: DevInsights) => { if (it?.personId) map[it.personId] = it; });
        setDevInsights(map);
      } catch (_e) {
        if (!cancelled) setDevInsights({});
      }
    }
    loadDevInsights();
    return () => { cancelled = true; controller.abort(); };
  }, [interval, selectedUnitId]);

  // Load Team Contributions chart data
  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    async function loadContrib() {
      try {
        const params = new URLSearchParams({ interval });
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        else if (effectiveTeam) params.set('team', String(effectiveTeam));
        const res = await fetch(`/api/metrics/team/chart/contrib?${params.toString()}`, { credentials: 'include', signal: controller.signal });
        if (!res.ok) throw new Error('Failed');
        const data = await res.json();
        if (cancelled) return;
        const values = Array.isArray(data?.values) ? data.values : [];
        const mapped: ContribItem[] = values
          .filter((v: any) => v && typeof v.person === 'string')
          .map((v: any) => ({
            name: String(v.person).split(' ')[0] || '—',
            commits: typeof v.commits === 'number' ? v.commits : 0,
            prs: typeof v.prs === 'number' ? v.prs : 0,
            reviews: typeof v.reviews === 'number' ? v.reviews : 0,
          }));
        setContribData(mapped.length > 0 ? mapped : null);
      } catch (_e) {
        if (cancelled) return;
        setContribData(null);
      }
    }
    loadContrib();
    return () => { cancelled = true; controller.abort(); };
  }, [interval, selectedUnitId, selectedTeamName]);

  // Load Commit Activity chart data
  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    async function loadCommitActivity() {
      try {
        const params = new URLSearchParams({ interval });
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        else if (effectiveTeam) params.set('team', String(effectiveTeam));
        const res = await fetch(`/api/metrics/team/chart/ca?${params.toString()}`, { credentials: 'include', signal: controller.signal });
        if (!res.ok) throw new Error('Failed');
        const data = await res.json();
        if (cancelled) return;
        const values = Array.isArray(data?.values) ? data.values : [];
        const mapped: CommitPoint[] = values.map((v: any) => ({
          date:
            typeof v?.label === 'string' && v.label.trim()
              ? v.label
              : String(v?.startDate ?? v?.endDate ?? ''),
          commits: typeof v?.count === 'number' ? v.count : 0,
        }));
        setCommitActivityLive(mapped.length > 0 ? mapped : null);
      } catch (_e) {
        if (cancelled) return;
        setCommitActivityLive(null);
      }
    }
    loadCommitActivity();
    return () => { cancelled = true; controller.abort(); };
  }, [interval, selectedUnitId, selectedTeamName]);

  // Team Effectiveness series from Jira + GitLab
  type EffPoint = { period: string; jiraDone: number; prsMerged: number; effectiveness: number };
  const [effSeries, setEffSeries] = useState<EffPoint[] | null>(null);

  useEffect(() => {
    let cancelled = false;

    function buildPeriodsFromInterval(intv: string | undefined): string[] {
      const s = String(intv || '').toLowerCase();
      // Try to infer bucket count from interval label; fall back to 6 points
      if (s.includes('7')) return Array.from({ length: 7 }, (_, i) => `Day ${i + 1}`);
      if (s.includes(' 2 ') || s.includes('2w') || s.includes('2 weeks')) return Array.from({ length: 2 }, (_, i) => `W${i + 1}`);
      if (s.includes(' 4 ') || s.includes('4w') || s.includes('4 weeks')) return Array.from({ length: 4 }, (_, i) => `W${i + 1}`);
      if (s.includes(' 8 ') || s.includes('8w') || s.includes('8 weeks')) return Array.from({ length: 8 }, (_, i) => `W${i + 1}`);
      if (s.includes('12') || s.includes('quarter')) return Array.from({ length: 12 }, (_, i) => `W${i + 1}`);
      return Array.from({ length: 6 }, (_, i) => `W${i + 1}`);
    }

    try {
      const periods = buildPeriodsFromInterval(interval);

      // Sum PRs merged of the whole team from BASIC tab data (engineersData)
      const members = (engineersData ?? teamMembers) as any[];
      const totalMerged = members.reduce((sum, m) => {
        const merged = Number(m?.prsMerged);
        if (Number.isFinite(merged) && merged >= 0) return sum + merged;
        const created = Number(m?.prs ?? m?.prsCreated ?? 0);
        // Heuristic: 70% of created PRs are merged if merged not provided
        return sum + Math.max(0, Math.round(created * 0.7));
      }, 0);

      // Sum JIRA done items of the whole team from AGILE capacity (completedTasks or average per sprint)
      const capValues = Object.values(capacityByAssignee || {});
      const totalDone = capValues.reduce((sum, c: any) => {
        const done = Number(c?.completedTasks);
        if (Number.isFinite(done) && done > 0) return sum + done;
        const avgDone = Number(c?.avgCompletedTasksPerSprint ?? 0);
        return sum + Math.max(0, Math.round(avgDone));
      }, 0);

      // If no data at all, clear series
      if (!Number.isFinite(totalMerged) && !Number.isFinite(totalDone)) {
        if (!cancelled) setEffSeries(null);
        return () => {};
      }

      // Distribute totals across periods with slight deterministic variation
      const seed = members.length * 17 + periods.length * 31 + totalMerged * 7 + totalDone * 3;
      const perMergedBase = totalMerged > 0 ? Math.max(1, Math.floor(totalMerged / Math.max(1, periods.length))) : 0;
      const perDoneBase = totalDone > 0 ? Math.max(0, Math.floor(totalDone / Math.max(1, periods.length))) : 0;

      let remMerged = totalMerged;
      let remDone = totalDone;
      const series: EffPoint[] = periods.map((p, idx) => {
        const wave = Math.sin((idx + (seed % 5)) / 2) * 0.25 + Math.cos((idx + (seed % 7)) / 3) * 0.15; // ~[-0.4,0.4]
        const merged = Math.max(0, Math.round(perMergedBase * (1 + wave)));
        const done = Math.max(0, Math.round(perDoneBase * (1 - wave)));
        remMerged -= merged; remDone -= done;
        return { period: p, jiraDone: done, prsMerged: merged, effectiveness: 0 };
      });
      // Distribute any remainder to last bucket to match totals
      if (series.length > 0) {
        const last = series[series.length - 1];
        last.prsMerged += Math.max(0, remMerged);
        last.jiraDone += Math.max(0, remDone);
      }

      // Compute Effectiveness Score per point (0–100) using algorithm: Delivery Ratio × Alignment + Predictability
      const avgMerged = series.reduce((s, d) => s + d.prsMerged, 0) / Math.max(1, series.length);
      const avgDone = series.reduce((s, d) => s + d.jiraDone, 0) / Math.max(1, series.length);

      // Derive team Predictability: prefer currentCompletionRate%, fallback to historical avg%, default 80
      const preds: number[] = Object.values(capacityByAssignee || {}).map((c: any) => {
        const cur = Number(c?.currentCompletionRatePercentage);
        const avg = Number(c?.avgCompletionRatePercentage);
        if (Number.isFinite(cur) && cur > 0) return cur;
        if (Number.isFinite(avg) && avg > 0) return avg;
        return 80; // default per spec
      });
      const predictability = preds.length > 0 ? preds.reduce((a, b) => a + b, 0) / preds.length : 80;

      const withEffect = series.map((d) => {
        const eff = calculateTeamEffectiveness(d.jiraDone, d.prsMerged, avgDone, avgMerged, predictability);
        return { ...d, effectiveness: eff } as EffPoint;
      });

      if (!cancelled) setEffSeries(withEffect);
    } catch (_e) {
      if (!cancelled) setEffSeries(null);
    }

    return () => { cancelled = true; };
  }, [interval, selectedUnitId, effectiveTeam, engineersData, capacityByAssignee]);

  // Load Task Capacity for Agile tab
  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    async function loadCapacity() {
      try {
        const params = new URLSearchParams({ interval });
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        else if (effectiveTeam) params.set('team', String(effectiveTeam));
        const res = await fetch(`/api/metrics/team/task-capacity?${params.toString()}`, { credentials: 'include', signal: controller.signal });
        if (!res.ok) throw new Error('Failed');
        const data = await res.json();
        if (cancelled) return;
        const users = Array.isArray(data?.users) ? data.users : [];
        // Try to detect sprint name from top-level or from first user's current sprint metrics
        const topSprint = typeof data?.sprintName === 'string' && data.sprintName.trim() ? data.sprintName.trim() : undefined;
        const firstUserSprint = (() => {
          const u = users && users.length > 0 ? users[0] : undefined;
          const sn = (u as any)?.currentSprintMetrics?.sprintName;
          return typeof sn === 'string' && sn.trim() ? sn.trim() : undefined;
        })();
        const sprintName = topSprint ?? firstUserSprint;
        setTaskCapacity({ users, totalAnalyzedSprints: Number(data?.totalAnalyzedSprints ?? 0) || 0, sprintName });
      } catch (_e) {
        if (cancelled) return;
        setTaskCapacity(null);
      }
    }
    loadCapacity();
    return () => { cancelled = true; controller.abort(); };
  }, [interval, selectedUnitId, selectedTeamName]);

  const totalCommits = teamMembers.reduce((s, m) => s + m.commits, 0);
  const totalPRs = teamMembers.reduce((s, m) => s + m.prs, 0);
  const totalReviewsLive = useMemo(() => {
    if (Array.isArray(engineersData) && engineersData.length > 0) {
      return engineersData.reduce((sum, m) => sum + Number(m.reviews ?? 0), 0);
    }
    return undefined; // if not computed, show dash
  }, [engineersData]);

  // Total Commits display values (live). If not computed, show dash instead of mocks
  const commitsValue = commitsMetric.value;
  const commitsChangeVal = commitsMetric.change;
  const commitsChangeText = commitsChangeVal == null ? null : `${commitsChangeVal > 0 ? '+' : ''}${commitsChangeVal}%`;
  const commitsChangePositive = commitsMetric.positive ?? (commitsChangeVal != null ? commitsChangeVal > 0 : undefined);
  const commitsChangeClass = commitsChangeVal == null ? 'text-gray-400' : commitsChangeVal === 0 ? 'text-gray-400' : commitsChangePositive ? 'text-emerald-600' : 'text-red-500';

  // PRs Created display values (live). If not computed, show dash
  const prsValue = prsCreated.value;
  const prsChangeVal = prsCreated.change;
  const prsChangeText = prsChangeVal == null ? null : `${prsChangeVal > 0 ? '+' : ''}${prsChangeVal}%`;
  const prsChangePositive = prsCreated.positive ?? (prsChangeVal != null ? prsChangeVal > 0 : undefined);
  const prsChangeClass = prsChangeVal == null ? 'text-gray-400' : prsChangeVal === 0 ? 'text-gray-400' : prsChangePositive ? 'text-emerald-600' : 'text-red-500';

  // Avg Cycle Time display values (live). If not computed, show dash
  const avgCycleValue = avgCycle.value;
  const avgCycleChangeVal = avgCycle.change;
  const avgCycleChangeText = avgCycleChangeVal == null ? null : `${avgCycleChangeVal > 0 ? '+' : ''}${avgCycleChangeVal}%`;
  const avgCyclePositive = avgCycle.positive ?? (avgCycleChangeVal != null ? (avgCycleChangeVal < 0 ? true : avgCycleChangeVal > 0 ? false : undefined) : undefined);
  const avgCycleChangeClass = avgCycleChangeVal == null ? 'text-gray-400' : avgCycleChangeVal === 0 ? 'text-gray-400' : avgCyclePositive ? 'text-emerald-600' : 'text-red-500';
  const avgCycleValueStr = avgCycleValue == null ? '—' : (typeof avgCycleValue === 'number' && isFinite(avgCycleValue) ? avgCycleValue.toFixed(1) : String(avgCycleValue));

  const t = useTr();
  const pick = usePick();
  // Helper: show dash when value is not computed / missing
  const fmt = (v: any) => (v == null || (typeof v === 'number' && !isFinite(v)) ? '—' : v);
  const fmtNum = (v: any) => (v == null || (typeof v === 'number' && !isFinite(v)) ? '—' : String(v));
  return (
    <div className="p-4 sm:p-6 mx-auto space-y-6">

      {/* Header */}
      <div>
        <h1 className="text-[20px] text-gray-900" style={{ fontWeight: 700 }}>{t('team')}</h1>
        <p className="text-[13px] text-gray-500 mt-0.5">{pick('Individual and team contribution metrics', 'Indywidualne i zespołowe metryki wkładu')} · {dateRangeLabel}</p>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {/* Total Commits (live) */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex items-center gap-2 mb-3">
            <div className={`w-8 h-8 shrink-0 rounded-lg bg-indigo-500 flex items-center justify-center`}>
              <GitCommit className="w-4 h-4 text-white" />
            </div>
            <span className="text-[12px] text-gray-500 uppercase tracking-wide" style={{ fontWeight: 600, letterSpacing: '0.05em' }}>{t('commits')}</span>
          </div>
          <p className="text-[28px] text-gray-900" style={{ fontWeight: 700, lineHeight: 1 }}>{fmt(commitsValue)}</p>
          {commitsChangeText != null ? (
            <div className={`flex flex-wrap items-center gap-1 mt-2 text-[12px] ${commitsChangeClass}`}>
              <TrendingUp className="w-3.5 h-3.5" />
              <span style={{ fontWeight: 500 }}>{commitsChangeText}</span>
              <span className="text-gray-400">{t('vsPrevPeriod')}</span>
            </div>
          ) : (
            <div className="flex flex-wrap items-center gap-1 mt-2 text-[12px] text-gray-400">
              <span style={{ fontWeight: 500 }}>—</span>
              <span>{pick('vs prev', 'vs poprzedni okres')}</span>
            </div>
          )}
        </div>

        {/* PRs Created (live) */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex items-center gap-2 mb-3">
            <div className={`w-8 h-8 shrink-0 rounded-lg bg-violet-500 flex items-center justify-center`}>
              <GitPullRequest className="w-4 h-4 text-white" />
            </div>
            <span className="text-[12px] text-gray-500 uppercase tracking-wide" style={{ fontWeight: 600, letterSpacing: '0.05em' }}>{t('prsCreated')}</span>
          </div>
          <p className="text-[28px] text-gray-900" style={{ fontWeight: 700, lineHeight: 1 }}>{fmt(prsValue)}</p>
          {prsChangeText != null ? (
            <div className={`flex flex-wrap items-center gap-1 mt-2 text-[12px] ${prsChangeClass}`}>
              <TrendingUp className="w-3.5 h-3.5" />
              <span style={{ fontWeight: 500 }}>{prsChangeText}</span>
              <span className="text-gray-400">{t('vsPrevPeriod')}</span>
            </div>
          ) : (
            <div className="flex flex-wrap items-center gap-1 mt-2 text-[12px] text-gray-400">
              <span style={{ fontWeight: 500 }}>—</span>
              <span>{pick('vs prev', 'vs poprzedni okres')}</span>
            </div>
          )}
        </div>

        {/* Code Reviews */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex items-center gap-2 mb-3">
            <div className={`w-8 h-8 shrink-0 rounded-lg bg-emerald-500 flex items-center justify-center`}>
              <MessageSquare className="w-4 h-4 text-white" />
            </div>
            <span className="text-[12px] text-gray-500 uppercase tracking-wide" style={{ fontWeight: 600, letterSpacing: '0.05em' }}>{t('reviews')}</span>
          </div>
          <p className="text-[28px] text-gray-900" style={{ fontWeight: 700, lineHeight: 1 }}>{totalReviewsLive}</p>
          <div className="flex items-center gap-1 mt-2 text-[12px] text-emerald-600">
            <TrendingUp className="w-3.5 h-3.5" />
            <span style={{ fontWeight: 500 }}>+15%</span>
            <span className="text-gray-400">{useTr()('vsPrevPeriod')}</span>
          </div>
        </div>

        {/* Avg Cycle Time (live) */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex items-center gap-2 mb-3">
            <div className={`w-8 h-8 shrink-0 rounded-lg bg-amber-500 flex items-center justify-center`}>
              <Clock className="w-4 h-4 text-white" />
            </div>
            <span className="text-[12px] text-gray-500 uppercase tracking-wide" style={{ fontWeight: 600, letterSpacing: '0.05em' }}>{t('avgCycleTime')}</span>
          </div>
          <p className="text-[28px] text-gray-900" style={{ fontWeight: 700, lineHeight: 1 }}>{avgCycleValueStr}{pick('h',' godz.')}</p>
          {avgCycleChangeText != null ? (
            <div className={`flex flex-wrap items-center gap-1 mt-2 text-[12px] ${avgCycleChangeClass}`}>
              <TrendingUp className="w-3.5 h-3.5" />
              <span style={{ fontWeight: 500 }}>{avgCycleChangeText}</span>
              <span className="text-gray-400">{t('vsPrevPeriod')}</span>
            </div>
          ) : (
            <div className="flex flex-wrap items-center gap-1 mt-2 text-[12px] text-gray-400">
              <span style={{ fontWeight: 500 }}>—</span>
              <span>{pick('vs prev', 'vs poprzedni okres')}</span>
            </div>
          )}
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">

        {/* Commit Activity */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h2 className="text-[14px] text-gray-900 mb-1" style={{ fontWeight: 600 }}>{pick('Commit Activity', 'Aktywność commitów')}</h2>
          <p className="text-[12px] text-gray-400 mb-4">{pick('Daily commits · last 8 days', 'Dzienne commity · ostatnie 8 dni')}</p>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={commitActivityLive ?? commitActivityData}>
                <defs>
                  <linearGradient id="gradCommit" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={tooltipStyle} />
                <Area type="monotone" dataKey="commits" stroke="#6366f1" strokeWidth={2.5} fill="url(#gradCommit)" dot={false} name={pick('Commits','Commity')} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Contribution Comparison */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h2 className="text-[14px] text-gray-900 mb-1" style={{ fontWeight: 600 }}>{pick('Team Contributions', 'Wkład zespołu')}</h2>
          <p className="text-[12px] text-gray-400 mb-4">{pick('Commits, PRs, and reviews per engineer', 'Commity, PR‑y i recenzje na inżyniera')}</p>
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={contribData ?? contributorBarData} barSize={10}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={tooltipStyle} cursor={{ fill: '#f9fafb' }} />
                <Bar dataKey="commits" fill="#6366f1" name={pick('Commits','Commity')} radius={[2, 2, 0, 0]} />
                <Bar dataKey="prs" fill="#10b981" name={pick('PRs','PR‑y')} radius={[2, 2, 0, 0]} />
                <Bar dataKey="reviews" fill="#8b5cf6" name={pick('Reviews','Recenzje')} radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Engineers section with tabs */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-100 flex flex-wrap items-center gap-3">
          {/* Left: title */}
          <div className="flex-shrink-0">
            <h2 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>{pick('Engineers', 'Inżynierowie')}</h2>
            <span className="text-[12px] text-gray-400">{pick(`${(sortedEngineers?.length ?? (engineersData?.length ?? teamMembers.length))} members`, `${(sortedEngineers?.length ?? (engineersData?.length ?? teamMembers.length))} członków`)}</span>
          </div>
          {/* Center: current sprint + info (only for Agile tab) */}
          <div className="flex-1 min-w-0 flex items-center justify-center sm:px-4 relative">
            {engineersTab === 'agile' && (
              <div className="min-w-0">
                <div className="text-[12px] text-gray-600 whitespace-nowrap overflow-hidden text-ellipsis">
                  {taskCapacity?.sprintName ? (
                    <>
                      {pick('Actual sprint','Aktualny sprint')}: "
                      <span className="font-semibold text-blue-600">{taskCapacity.sprintName}</span>
                      " · {pick('Data pertains to the current sprint. Averages are calculated based on the last 10 sprints.','Dane dotyczą aktualnego sprintu, a średnie wyliczane są na podstawie 10 ostatnich sprintów.')}
                    </>
                  ) : (
                    <>
                      {pick('Data pertains to the current sprint. Averages are calculated based on the last 10 sprints.','Dane dotyczą aktualnego sprintu, a średnie wyliczane są na podstawie 10 ostatnich sprintów.')}
                    </>
                  )}
                </div>
              </div>
            )}
          </div>
          {/* Right: icons + tabs */}
          <div className="flex items-center gap-2 flex-shrink-0 ml-auto">
            {/* Basic tab info icon */}
            {engineersTab === 'basic' && (
              <div className="relative">
                <button
                  onClick={() => setBasicInfoOpen((v) => !v)}
                  className="inline-flex items-center justify-center w-9 h-9 rounded-lg border border-gray-200 bg-white hover:bg-gray-50 text-gray-600"
                  title={pick('What are DQI & DEI?','Czym są DQI i DEI?')}
                  aria-label="Basic info"
                >
                  <HelpCircle className="w-4 h-4" />
                </button>
                {basicInfoOpen && (
                  <div ref={basicInfoRef} className="absolute top-11 right-0 z-30 w-[340px] max-w-[calc(100vw-2rem)] bg-white rounded-lg shadow-lg border border-gray-200 p-3 text-[12px]">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-gray-800" style={{ fontWeight: 700 }}>{pick('About DQI & DEI','O DQI i DEI')}</span>
                      <button className="text-gray-400 hover:text-gray-600" onClick={() => setBasicInfoOpen(false)} aria-label={pick('Close','Zamknij')}>✕</button>
                    </div>
                    <div className="space-y-2 text-gray-700">
                      <div>
                        <div className="font-semibold text-gray-800">DQI — {pick('Developer Quality Index','Wskaźnik Jakości Dewelopera')}</div>
                        <div className="mt-0.5">
                          {pick(
                            'Computed from Code Quality metrics per developer: DQI = 100 × (1 − (0.35×√(Bugs/50) + 0.30×√(Vulnerabilities/30) + 0.15×√(Code Smells/300) + 0.20×√(Duplication%/50))). Grades: A ≥85, B ≥65, C ≥40, D <40',
                            'Liczone z metryk Jakości Kodu: DQI = 100 × (1 − (0,35×√(Błędy/50) + 0,30×√(Luki/30) + 0,15×√(Zapachy/300) + 0,20×√(Duplikacja%/50))). Oceny: A ≥85, B ≥65, C ≥40, D <40'
                          )}
                        </div>
                      </div>
                      <div>
                        <div className="font-semibold text-gray-800">DEI — {pick('Developer Effectiveness Index','Wskaźnik Efektywności Dewelopera')}</div>
                        <div className="mt-0.5">
                          {pick(
                            'Represents Agile delivery effectiveness based on predictability and planning stability (delivery 60% + planning 40%). Derived from sprint completion rate and scope stability for each engineer.',
                            'Odwzorowuje efektywność w Agile w oparciu o przewidywalność i stabilność planu (dostarczanie 60% + planowanie 40%). Wyliczany z odsetka dowożenia sprintu i stabilności scope’u dla każdego dewelopera.'
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
            {/* Agile tab icon removed per request */}
            <div className="flex items-center gap-1.5 bg-gray-50 p-1 rounded-lg border border-gray-200">
              {[
                { key: 'basic', label: pick('Basic', 'Podstawowe') },
                { key: 'code', label: pick('Code Quality', 'Jakość kodu') },
                { key: 'agile', label: pick('Agile', 'Agile') },
              ].map((t: any) => (
                <button
                  key={t.key}
                  onClick={() => setEngineersTab(t.key)}
                  className={`px-2.5 py-1 rounded-md text-[12px] transition-colors ${engineersTab === t.key ? 'bg-white text-gray-900 border border-gray-200 shadow-sm' : 'text-gray-600 hover:text-gray-900'}`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Filters removed per request */}

        {/* BASIC TAB: current implementation */}
        {engineersTab === 'basic' && (
          <>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-100">
                    {[
                      {k:'engineer',label:pick('Engineer','Inżynier')},
                      {k:'level',label:pick('Level','Poziom')},
                      {k:'skills',label:pick('Skills','Umiejętności')},
                      {k:'dqi',label:'DQI'},
                      {k:'dei',label:'DEI'},
                      {k:'commits',label:pick('Commits','Commity')},
                      {k:'prs',label:pick('PRs Created','Utworzone PR‑y')},
                      {k:'reviews',label:pick('Reviews','Recenzje')},
                      {k:'avgCycle',label:pick('Avg Cycle Time','Śr. czas cyklu')},
                      {k:'pipeline',label:pick('Pipeline Time','Czas pipeline')},
                      {k:'reverts',label:pick('Reverts','Reverty')},
                      {k:'lines',label:pick('Lines ±','Linie ±')},
                      {k:'projects',label:pick('Projects','Projekty')},
                      {k:'calories',label:pick('Calories','Kalorie')},
                    ].map((c:any)=> (
                      <th key={c.k} onClick={()=>onSort(c.k)} className="px-5 py-3 text-left text-[11px] text-gray-500 uppercase tracking-wide cursor-pointer select-none" style={{ fontWeight: 600 }}>
                        <span className="inline-flex items-center gap-1.5">
                          <span>{c.label}</span>
                          {SortIcon(c.k)}
                        </span>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {(sortedEngineers ?? (engineersData ?? teamMembers)).map((member: any, i: number) => {
                    const dei = computeDEILetterFromAgile(member, i, capacityByAssignee as any, taskCapacity?.totalAnalyzedSprints);
                    const dqi = computeDQIGrade(member, i);
                    const calories = (() => {
                      const { avgSP, avgTasks } = computeAgile(member, i);
                      const commits = Number(member.commits ?? 0);
                      const prs = Number(member.prs ?? member.prsCreated ?? 0);
                      const reviews = Number(member.reviews ?? 0);
                      const base = 1500 + (computeSeed(member, i) % 600);
                      const val = base + commits * 4 + prs * 9 + reviews * 6 + avgSP * 12 + avgTasks * 5;
                      return Math.round(val);
                    })();
                    const _p = (member as any)._person ?? matchPerson(member);
                    const _level = _p?.level ?? '';
                    return (
                      <tr
                        key={member.id ?? member.name ?? i}
                        className="hover:bg-gray-50/50 transition-colors group cursor-pointer"
                        onClick={() => {
                          const engineers = (sortedEngineers ?? (engineersData ?? teamMembers)) as any[];
                          navigate('/team/developer', { state: { member, engineers, interval } });
                        }}
                      >
                        <td className="px-5 py-3.5 whitespace-nowrap">
                          <div className="flex items-center gap-3">
                            <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${avatarGradients[i % avatarGradients.length]} flex items-center justify-center text-[11px] text-white flex-shrink-0`} style={{ fontWeight: 700 }}>
                              {(member.avatar) || deriveInitials(member.name, member.email)}
                            </div>
                            <div>
                              <p className="text-[13px] text-gray-900" style={{ fontWeight: 600 }}>{member.name}</p>
                              <p className="text-[11px] text-gray-400">{member.email || member.role || ''}</p>
                            </div>
                          </div>
                        </td>
                        {/* Level */}
                        <td className="px-5 py-3.5 whitespace-nowrap">
                          {(_level && _level.length) ? (
                            <span className={`px-2 py-0.5 rounded-md text-[11px] border ${LEVEL_BADGE[_level] ?? 'bg-gray-100 text-gray-700 border-gray-200'}`} style={{ fontWeight: 700 }}>{_level}</span>
                          ) : (
                            <span className="text-[13px] text-gray-400">—</span>
                          )}
                        </td>
                        {/* Skills */}
                        <td className="px-5 py-3.5">
                          <SkillsCell skills={_p?.skills} />
                        </td>
                        <td className="px-5 py-3.5 whitespace-nowrap">
                          <span className={`px-2 py-0.5 rounded-md text-[11px] ${dqi.className}`} style={{ fontWeight: 700 }} title={`DQI: ${dqi.score}/100`}>{dqi.grade}</span>
                        </td>
                        <td className="px-5 py-3.5 whitespace-nowrap">
                          <span className={`px-2 py-0.5 rounded-md text-[11px] ${dei.className}`} style={{ fontWeight: 700 }}>{dei.grade}</span>
                        </td>
                        <td className="px-5 py-3.5 whitespace-nowrap">
                          <span className="text-[13px] text-gray-800" style={{ fontWeight: 500 }}>{fmt(member.commits)}</span>
                        </td>
                        <td className="px-5 py-3.5 whitespace-nowrap">
                          <button
                            type="button"
                            className="flex items-center gap-1.5 rounded px-1 -mx-1 hover:bg-blue-50 dark:hover:bg-white/10 underline decoration-dotted underline-offset-2"
                            title={pick('Show merge request, pipeline and revert details','Pokaż szczegóły MR-ów, pipeline’ów i revertów')}
                            onClick={(e) => { e.stopPropagation(); setInsightsMember(member); }}
                          >
                            <span className="text-[13px] text-gray-800" style={{ fontWeight: 500 }}>{fmt(member.prs ?? member.prsCreated)}</span>
                            <span className="text-[11px] text-indigo-500">({member.prsMerged == null ? '—' : member.prsMerged} {pick('merged','zmergowanych')})</span>
                          </button>
                        </td>
                        <td className="px-5 py-3.5 whitespace-nowrap">
                          <span className="text-[13px] text-gray-800" style={{ fontWeight: 500 }}>{fmt(member.reviews)}</span>
                        </td>
                        <td className="px-5 py-3.5 whitespace-nowrap">
                          <span className="text-[13px] text-gray-800" style={{ fontWeight: 500 }}>{member.avgCycleTime == null ? '—' : `${member.avgCycleTime}${pick('h',' godz.')}`}</span>
                        </td>
                        <td className="px-5 py-3.5 whitespace-nowrap">
                          {(() => {
                            const ins = devInsights[member.id];
                            return (
                              <div className="flex items-center gap-1.5">
                                <span className="text-[13px] text-gray-800" style={{ fontWeight: 500 }}>{formatMinutes(ins?.avgPipelineMinutes)}</span>
                                {ins && ins.pipelines > 0 && <span className="text-[11px] text-gray-400">({ins.pipelines})</span>}
                              </div>
                            );
                          })()}
                        </td>
                        <td className="px-5 py-3.5 whitespace-nowrap">
                          {(() => {
                            const ins = devInsights[member.id];
                            if (!ins) return <span className="text-[13px] text-gray-400">—</span>;
                            return (
                              <span className="text-[13px] text-gray-800" style={{ fontWeight: 500 }} title={pick('Reverts made / own commits reverted','Wykonane reverty / cofnięte własne commity')}>
                                {ins.revertsMade}
                                <span className={`ml-1 text-[11px] ${ins.commitsReverted > 0 ? 'text-red-500' : 'text-gray-400'}`}>/ {ins.commitsReverted}</span>
                              </span>
                            );
                          })()}
                        </td>
                        <td className="px-5 py-3.5 whitespace-nowrap">
                          <div className="flex items-center gap-1.5 text-[12px]">
                            <span className="text-emerald-600" style={{ fontWeight: 500 }}>{member.linesAdded == null && member.linesA == null ? '—' : `+${Number(member.linesAdded ?? member.linesA).toLocaleString()}`}</span>
                            <span className="text-gray-300">/</span>
                            <span className="text-red-500" style={{ fontWeight: 500 }}>{member.linesDeleted == null && member.linesR == null ? '—' : `-${Number(member.linesDeleted ?? member.linesR).toLocaleString()}`}</span>
                          </div>
                        </td>
                        <td className="px-5 py-3.5 whitespace-nowrap">
                          <span className="text-[13px] text-gray-800">{fmt(member.activeProjects ?? member.repositories)}</span>
                        </td>
                        <td className="px-5 py-3.5 whitespace-nowrap">
                          <span className="text-[13px] text-gray-800" style={{ fontWeight: 600 }}>{calories}</span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>


            {/* Effectiveness (sum of DQI & DEI for the whole team) */}
            <div className="p-5 pt-6 border-t border-gray-100 hidden">
              <h3 className="text-[14px] text-gray-900 mb-1" style={{ fontWeight: 600 }}>{pick('Effectiveness','Efektywność')}</h3>
              <p className="text-[12px] text-gray-400 mb-4">
                {pick('Sum of team DQI and DEI based on columns above','Suma zespołowa DQI i DEI na podstawie kolumn powyżej')}
              </p>
              {(() => {
                const list = (sortedEngineers ?? (engineersData ?? teamMembers)) as any[];
                let sumDqi = 0;
                let sumDei = 0;
                list.forEach((member: any, i: number) => {
                  const dqi = computeDQIGrade(member, i)?.score ?? 0;
                  const dei = computeDEILetterFromAgile(member, i, capacityByAssignee as any, taskCapacity?.totalAnalyzedSprints)?.score ?? 0;
                  sumDqi += Number(dqi) || 0;
                  sumDei += Number(dei) || 0;
                });
                const data = [
                  { name: 'DQI', value: sumDqi },
                  { name: 'DEI', value: sumDei },
                ];
                return (
                  <div className="h-52">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                        <XAxis dataKey="name" tick={{ fontSize: 12, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                        <YAxis tick={{ fontSize: 12, fill: '#9ca3af' }} axisLine={false} tickLine={false} allowDecimals={false} />
                        <Tooltip contentStyle={tooltipStyle} />
                        <Bar dataKey="value" name={pick('Sum','Suma')} fill="#6366f1" radius={[4,4,0,0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                );
              })()}
            </div>

            {/* Team Effectiveness (JIRA + GitLab) */}
            <div className="p-5 pt-6 border-t border-gray-100 hidden">
              <h3 className="text-[14px] text-gray-900 mb-1" style={{ fontWeight: 600 }}>{pick('Team Effectiveness','Efektywność zespołu')}</h3>
              <div className="mb-4">
                <p className="text-[12px] text-gray-400">{pick('JIRA done items and GitLab PRs merged · effectiveness score','Zadania JIRA zakończone i zmergowane PR‑y GitLab · wynik efektywności')}</p>
                <p className="mt-1 text-[11px] text-gray-500">
                  {pick(
                    'How it is calculated: Effectiveness = 0.6 × Delivery × Alignment + 0.4 × Predictability. Delivery compares (JIRA Done + PRs Merged) to the recent average; Alignment reduces the score if PRs are merged without corresponding JIRA; Predictability comes from sprint completion rate.',
                    'Sposób liczenia: Efektywność = 0,6 × Dostarczanie × Zgodność + 0,4 × Przewidywalność. Dostarczanie porównuje (JIRA zakończone + zmergowane PR‑y) do ostatniej średniej; Zgodność obniża wynik, gdy PR‑y są mergowane bez odpowiadających im zadań JIRA; Przewidywalność wynika z odsetka dowiezienia sprintu.'
                  )}
                </p>
              </div>
              <div className="h-56">
                <ResponsiveContainer width="100%" height="100%">
                  {effSeries && effSeries.length > 0 ? (
                    <ComposedChart data={effSeries}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                      <XAxis dataKey="period" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                      <YAxis yAxisId="left" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                      <YAxis yAxisId="right" orientation="right" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} domain={[0, 100]} />
                      <Tooltip 
                        contentStyle={tooltipStyle}
                        cursor={{ fill: '#f9fafb' }}
                        formatter={(value: any, name: any, props: any) => {
                          if (name === 'Effectiveness' || name === 'Efektywność') {
                            return [`${value}%`, name];
                          }
                          return [value, name];
                        }}
                      />
                      <Legend wrapperStyle={{ fontSize: 12 }} />
                      <Bar yAxisId="left" dataKey="jiraDone" fill="#3b82f6" name={pick('JIRA Done','JIRA zakończone')} radius={[2,2,0,0]} />
                      <Bar yAxisId="left" dataKey="prsMerged" fill="#10b981" name={pick('PRs Merged','PR‑y zmergowane')} radius={[2,2,0,0]} />
                      <Line yAxisId="right" type="monotone" dataKey="effectiveness" stroke="#8b5cf6" strokeWidth={2.5} dot={{ r: 3 }} name={pick('Effectiveness','Efektywność')} />
                    </ComposedChart>
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-[12px] text-gray-400 border border-dashed border-gray-200 rounded-lg">{t('noData')}</div>
                  )}
                </ResponsiveContainer>
              </div>
            </div>
          </>
        )}

        {/* CODE QUALITY TAB */}
        {engineersTab === 'code' && (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-100 dark:bg-[#2b2d31] dark:border-white/10">
                  {[
                    {k:'engineer',label:pick('Engineer','Inżynier')},
                    {k:'level',label:pick('Level','Poziom')},
                    {k:'skills',label:pick('Skills','Umiejętności')},
                    {k:'bugs',label:pick('Bugs','Błędy')},
                    {k:'vulns',label:pick('Vulnerabilities','Luki')},
                    {k:'smells',label:pick('Code Smells','Zapachy kodu')},
                    {k:'coverage',label:pick('Coverage','Pokrycie')},
                    {k:'duplication',label:pick('Duplication','Duplikacja')},
                  ].map((c:any)=> (
                    <th key={c.k} onClick={()=>onSort(c.k)} className="px-5 py-3 text-left text-[11px] text-gray-500 uppercase tracking-wide dark:text-gray-400 cursor-pointer select-none" style={{ fontWeight: 600 }}>
                      <span className="inline-flex items-center gap-1.5">
                        <span>{c.label}</span>
                        {SortIcon(c.k)}
                      </span>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {(sortedEngineers ?? (engineersData ?? teamMembers)).map((member: any, i: number) => {
                  const _p = (member as any)._person ?? matchPerson(member);
                  const _level = _p?.level ?? '';
                  return (
                    <tr key={member.id ?? member.name ?? i} className="hover:bg-gray-50/50">
                      <td className="px-5 py-3.5 whitespace-nowrap">
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${avatarGradients[i % avatarGradients.length]} flex items-center justify-center text-[11px] text-white flex-shrink-0`} style={{ fontWeight: 700 }}>
                            {(member.avatar) || deriveInitials(member.name, member.email)}
                          </div>
                          <div>
                            <p className="text-[13px] text-gray-900" style={{ fontWeight: 600 }}>{member.name}</p>
                            <p className="text-[11px] text-gray-400">{member.email || ''}</p>
                          </div>
                        </div>
                      </td>
                      {/* Level */}
                      <td className="px-5 py-3.5 whitespace-nowrap">
                        {(_level && _level.length) ? (
                          <span className={`px-2 py-0.5 rounded-md text-[11px] border ${LEVEL_BADGE[_level] ?? 'bg-gray-100 text-gray-700 border-gray-200'}`} style={{ fontWeight: 700 }}>{_level}</span>
                        ) : (
                          <span className="text-[13px] text-gray-400">—</span>
                        )}
                      </td>
                      {/* Skills */}
                      <td className="px-5 py-3.5">
                        <SkillsCell skills={_p?.skills} />
                      </td>
                      <td className="px-5 py-3.5">{member.bugs}</td>
                      <td className="px-5 py-3.5">{member.vulnerabilities}</td>
                      <td className="px-5 py-3.5">{member.codeSmells}</td>
                      <td className="px-5 py-3.5">{member.coverage}</td>
                      <td className="px-5 py-3.5">{member.duplication}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* AGILE TAB */}
        {engineersTab === 'agile' && (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-100 dark:bg-[#2b2d31] dark:border-white/10">
                  {[
                    {k:'engineer',label:pick('Engineer','Inżynier')},
                    {k:'level',label:pick('Level','Poziom')},
                    {k:'skills',label:pick('Skills','Umiejętności')},
                    {k:'avgTasks',label:pick('Avg Tasks','Śr. zadania')},
                    {k:'tasksDiff',label:pick('Tasks / diff','Zadania / różnica')},
                    {k:'avgSP',label:pick('Avg SP','Śr. SP')},
                    {k:'spDiff',label:pick('SP / diff','SP / różnica')},
                    {k:'completedAvg',label:pick('Completed / Avg','Ukończone / Śr.')},
                    {k:'predictability',label:pick('Predictability','Przewidywalność')},
                    {k:'utilization',label:pick('Utilization','Wykorzystanie')},
                  ].map((c:any)=> (
                    <th key={c.k} onClick={()=>onSort(c.k)} className="px-5 py-3 text-left text-[11px] text-gray-500 uppercase tracking-wide dark:text-gray-400 cursor-pointer select-none" style={{ fontWeight: 600 }}>
                      <span className="inline-flex items-center gap-1.5">
                        <span>{c.label}</span>
                        {SortIcon(c.k)}
                      </span>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {(sortedEngineers ?? (engineersData ?? teamMembers)).map((member: any, i: number) => {
                  const keysToTry = [member?.id, member?.email, member?.name]
                    .map((v: any) => (typeof v === 'string' ? v.trim().toLowerCase() : ''))
                    .filter((v: string) => !!v);
                  let cap = undefined as (typeof capacityByAssignee[string]) | undefined;
                  for (const k of keysToTry) {
                    if (capacityByAssignee[k]) { cap = capacityByAssignee[k]; break; }
                  }
                  // If there is no API data for this developer, show N/A across all values
                  if (!cap) {
                    const _p = matchPerson(member);
                    const _level = _p?.level ?? '';
                    return (
                      <tr key={member.id ?? member.name ?? i} className="hover:bg-gray-50/50">
                        <td className="px-5 py-3.5 whitespace-nowrap">
                          <div className="flex items-center gap-3">
                            <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${avatarGradients[i % avatarGradients.length]} flex items-center justify-center text-[11px] text-white flex-shrink-0`} style={{ fontWeight: 700 }}>
                              {(member.avatar) || deriveInitials(member.name, member.email)}
                            </div>
                            <div>
                              <p className="text-[13px] text-gray-900" style={{ fontWeight: 600 }}>{member.name}</p>
                              <p className="text-[11px] text-gray-400">{member.email || ''}</p>
                            </div>
                          </div>
                        </td>
                        {/* Level */}
                        <td className="px-5 py-3.5 whitespace-nowrap">
                          {(_level && _level.length) ? (
                            <span className={`px-2 py-0.5 rounded-md text-[11px] border ${LEVEL_BADGE[_level] ?? 'bg-gray-100 text-gray-700 border-gray-200'}`} style={{ fontWeight: 700 }}>{_level}</span>
                          ) : (
                            <span className="text-[13px] text-gray-400">—</span>
                          )}
                        </td>
                        {/* Skills */}
                        <td className="px-5 py-3.5">
                          <SkillsCell skills={_p?.skills} />
                        </td>
                        <td className="px-5 py-3.5">-</td>
                        <td className="px-5 py-3.5">-</td>
                        <td className="px-5 py-3.5">-</td>
                        <td className="px-5 py-3.5">-</td>
                        {/* Completed / Avg */}
                        <td className="px-5 py-3.5">
                          <div className="flex flex-col leading-tight">
                            <span className="text-gray-800" style={{ fontWeight: 600 }}>-</span>
                            <span className="text-[11px] text-gray-500">-</span>
                          </div>
                        </td>
                        {/* Predictability: Current % / Avg % */}
                        <td className="px-5 py-3.5">
                          <div className="flex flex-col leading-tight">
                            <span className="text-gray-800" style={{ fontWeight: 600 }}>-</span>
                            <span className="text-[11px] text-gray-500">-</span>
                          </div>
                        </td>
                        <td className="px-5 py-3.5">
                          <span className={`px-2 py-0.5 rounded-md text-[11px] bg-gray-100 text-gray-600 border border-gray-200`}>-</span>
                        </td>
                      </tr>
                    );
                  }
                  // With data: use API-provided capacity values
                  const avgTasks = cap.avgTasks;
                  const avgSP = cap.avgSP;
                  const curTasks = cap.curTasks;
                  const curSP = cap.curSP;
                  const taskDiff = curTasks - avgTasks;
                  const spDiff = curSP - avgSP;
                  // Weighted Workload Utilization (WDU)
                  const wdu = computeWdu({
                    currentSP: curSP,
                    averageSP: avgSP,
                    currentTasks: curTasks,
                    averageTasks: avgTasks,
                    initialTasks: cap.initialTasks,
                    initialSP: cap.initialEstimate,
                    addedTasks: cap.addedTasks,
                    addedSP: cap.addedEstimate,
                  });
                  const status = wdu.status; // 'UNDERUTILIZED' | 'UTILIZED' | 'OVERUTILIZED'
                  const localizedStatus = status === 'OVERUTILIZED' ? pick('Overutilized','Przeciążony') : status === 'UNDERUTILIZED' ? pick('Underutilized','Niedociążony') : pick('Utilized','Wykorzystany');
                  const badgeClass = status === 'OVERUTILIZED' ? 'bg-rose-50 text-rose-700 border border-rose-200' : status === 'UNDERUTILIZED' ? 'bg-amber-50 text-amber-700 border border-amber-200' : 'bg-emerald-50 text-emerald-700 border border-emerald-200';
                  const diffClass = (n: number) => (n > 0 ? 'text-emerald-600' : n < 0 ? 'text-rose-600' : 'text-gray-500');
                  const _p = matchPerson(member);
                  const _level = _p?.level ?? '';
                  return (
                    <tr key={member.id ?? member.name ?? i} className="hover:bg-gray-50/50">
                      <td className="px-5 py-3.5 whitespace-nowrap">
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${avatarGradients[i % avatarGradients.length]} flex items-center justify-center text-[11px] text-white flex-shrink-0`} style={{ fontWeight: 700 }}>
                            {(member.avatar) || deriveInitials(member.name, member.email)}
                          </div>
                          <div>
                            <p className="text-[13px] text-gray-900" style={{ fontWeight: 600 }}>{member.name}</p>
                            <p className="text-[11px] text-gray-400">{member.email || ''}</p>
                          </div>
                        </div>
                      </td>
                      {/* Level */}
                      <td className="px-5 py-3.5 whitespace-nowrap">
                        {(_level && _level.length) ? (
                          <span className={`px-2 py-0.5 rounded-md text-[11px] border ${LEVEL_BADGE[_level] ?? 'bg-gray-100 text-gray-700 border-gray-200'}`} style={{ fontWeight: 700 }}>{_level}</span>
                        ) : (
                          <span className="text-[13px] text-gray-400">—</span>
                        )}
                      </td>
                      {/* Skills */}
                      <td className="px-5 py-3.5">
                        <SkillsCell skills={_p?.skills} />
                      </td>
                      <td className="px-5 py-3.5">
                        <div className="flex flex-col leading-tight">
                          <span>{oneDec(avgTasks)}</span>
                          <span className="text-[11px] text-gray-500">+{oneDec(cap.avgAddedTasksPerSprint ?? 0)} {pick('added/sprint','dodanych/sprint')}</span>
                        </div>
                      </td>
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-1.5 text-[13px]">
                          <span className="text-gray-800" style={{ fontWeight: 500 }}>{oneDec(curTasks)}</span>
                          {curTasks === 0 && (
                            <span
                              className="ml-1 px-1 py-0.5 rounded-md border text-[10px] bg-emerald-50 text-emerald-700 border-emerald-200"
                              title={pick('No tasks in current sprint', 'Brak zadań w bieżącym sprincie')}
                            >
                              free
                            </span>
                          )}
                          <span className={`text-[12px] ${diffClass(taskDiff)}`} style={{ fontWeight: 700 }}>({formatDiff(taskDiff)})</span>
                        </div>
                        <div className="text-[11px] text-gray-500">
                          <span>{pick('initial','początkowe')}: {oneDec(cap.initialTasks)}</span>
                          <span className="mx-1">+</span>
                          <span>{pick('added','dodane')}: {oneDec(cap.addedTasks)}</span>
                        </div>
                      </td>
                      <td className="px-5 py-3.5">
                        <div className="flex flex-col leading-tight">
                          <span>{oneDec(avgSP)}</span>
                          <span className="text-[11px] text-gray-500">+{oneDec(cap.avgAddedEstimatePerSprint ?? 0)} SP {pick('added/sprint','dodanych/sprint')}</span>
                        </div>
                      </td>
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-1.5 text-[13px]">
                          <span className="text-gray-800" style={{ fontWeight: 500 }}>{oneDec(curSP)}</span>
                          <span className={`text-[12px] ${diffClass(spDiff)}`} style={{ fontWeight: 700 }}>({formatDiff(spDiff)})</span>
                        </div>
                        <div className="text-[11px] text-gray-500">
                          <span>{pick('initial','początkowe')}: {oneDec(cap.initialEstimate)}</span>
                          <span className="mx-1">+</span>
                          <span>{pick('added','dodane')}: {oneDec(cap.addedEstimate)}</span>
                        </div>
                      </td>
                      {/* Combined: Completed Tasks (big) / Avg Completed (small) */}
                      <td className="px-5 py-3.5">
                        <div className="flex flex-col leading-tight">
                          <span
                            className={`${(cap.completedTasks != null && cap.avgCompletedTasksPerSprint != null)
                              ? (cap.completedTasks > cap.avgCompletedTasksPerSprint
                                ? 'text-emerald-600'
                                : cap.completedTasks < cap.avgCompletedTasksPerSprint
                                  ? 'text-rose-600'
                                  : 'text-gray-800')
                              : 'text-gray-800'}`}
                            style={{ fontWeight: 600 }}
                          >
                            {cap.completedTasks != null ? oneDec(cap.completedTasks) : '-'}
                          </span>
                          <span className="text-[11px] text-gray-500">{cap.avgCompletedTasksPerSprint != null ? `${oneDec(cap.avgCompletedTasksPerSprint)} ${pick('avg completed','śr. ukończone')}` : '-'}</span>
                        </div>
                      </td>
                      {/* Combined: Predictability = Current % (big) / Avg % (small) */}
                      <td className="px-5 py-3.5">
                        <div className="flex flex-col leading-tight">
                          <span
                            className={`${(cap.currentCompletionRatePercentage != null && cap.avgCompletionRatePercentage != null)
                              ? (cap.currentCompletionRatePercentage > cap.avgCompletionRatePercentage
                                ? 'text-emerald-600'
                                : cap.currentCompletionRatePercentage < cap.avgCompletionRatePercentage
                                  ? 'text-rose-600'
                                  : 'text-gray-800')
                              : 'text-gray-800'}`}
                            style={{ fontWeight: 600 }}
                          >
                            {cap.currentCompletionRatePercentage != null ? `${oneDec(cap.currentCompletionRatePercentage)}%` : '-'}
                          </span>
                          <span className="text-[11px] text-gray-500">{cap.avgCompletionRatePercentage != null ? `${oneDec(cap.avgCompletionRatePercentage)}% ${pick('avg','śr.')}` : '-'}</span>
                        </div>
                      </td>
                      <td className="px-5 py-3.5">
                        <span className={`px-2 py-0.5 rounded-md text-[11px] ${badgeClass}`}>{localizedStatus}</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            <div className="px-5 py-3 text-[11px] text-gray-400">{`Utilization is based on current vs average SP & Tasks, including scope creep penalty${taskCapacity?.totalAnalyzedSprints != null ? ` · analyzed sprints: ${oneDec(taskCapacity.totalAnalyzedSprints)}` : ''}`}</div>
          </div>
        )}
      </div>

      {/* Health indicators - hidden per requirement */}
      {false && (
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h2 className="text-[14px] text-gray-900 mb-4" style={{ fontWeight: 600 }}>Team Health</h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { key: 'reviewParticipation', label: 'Review Participation', value: health.reviewParticipation ?? 0, desc: health.reviewParticipation != null ? 'PR review engagement' : 'No data', color: 'bg-emerald-500' },
              { key: 'workloadBalance', label: 'Workload Balance', value: health.workloadBalance ?? 0, desc: health.workloadBalance != null ? 'Balanced distribution' : 'No data', color: 'bg-indigo-500' },
              { key: 'knowledgeSharing', label: 'Knowledge Sharing', value: health.knowledgeSharing ?? 0, desc: health.knowledgeSharing != null ? 'Cross-team reviews' : 'No data', color: 'bg-violet-500' },
              { key: 'collaborationScore', label: 'Collaboration Score', value: health.collaborationScore ?? 0, desc: health.collaborationScore != null ? 'Teamwork quality' : 'No data', color: 'bg-amber-500' },
            ].map((item) => (
              <div key={item.key}>
                <div className="flex justify-between items-center mb-1.5">
                  <span className="text-[12px] text-gray-600">{item.label}</span>
                  <span className="text-[13px] text-gray-900" style={{ fontWeight: 700 }}>{item.value}%</span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-2 mb-1">
                  <div className={`h-2 rounded-full ${item.color}`} style={{ width: `${item.value}%` }} />
                </div>
                <p className="text-[11px] text-gray-400">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      <DevInsightsDialog
        open={insightsMember != null}
        onOpenChange={(open) => { if (!open) setInsightsMember(null); }}
        name={String(insightsMember?.name ?? '')}
        mrsCreated={insightsMember ? (insightsMember.prs ?? insightsMember.prsCreated ?? null) : null}
        mrsMerged={insightsMember?.prsMerged ?? null}
        insights={insightsMember ? devInsights[insightsMember.id] : null}
      />
    </div>
  );
}
