import { useMemo, useEffect, useState, type ReactNode } from 'react';
import { useDateRange } from '../context/DateRangeContext';
import { usePick, useTr } from '../i18n';
import { Calendar, Timer, UserCheck } from 'lucide-react';
import { ResponsiveContainer, Tooltip, CartesianGrid, XAxis, YAxis, AreaChart, Area } from 'recharts';
import { useNavigate } from 'react-router-dom';
import LoadingSpinner from '../components/LoadingSpinner';
import { toInterval } from '../utils/dateRange';

// Personal metrics of the logged-in user, from /api/metrics/me (commits and MRs matched to the user, Sonar scans,
// languages from GitLab commit diffs). Widgets without backing data are intentionally not shown.

type MyMetrics = {
  profile: { id: string; name?: string | null; email?: string | null; level?: string | null; role?: string | null; squad?: string | null; tribe?: string | null };
  commits: number;
  commitsPrev: number;
  dailyAvgCommits: number;
  activeDays: number;
  workingDays: number | null;
  additions: number;
  deletions: number;
  mrsCreated: number;
  mrsCreatedPrev: number;
  mrsMerged: number;
  avgPickupHours: number;
  avgReviewHours: number;
  avgCycleHours: number;
  quality: { scannedCommits: number; avgNewBugs: number; avgNewViolations: number; avgNewCodeSmells: number; avgNewCoverage: number; avgNewDuplicatedBlocks: number };
  commitsPerDay: Array<{ day: string; commits: number }>;
  languages: Array<{ name: string; lines: number; pct: number }>;
  commitsWithLanguages: number;
  reviewers: Array<{ id: string; name: string; mrs: number; pct: number }>;
  recentCommits: Array<{ id: string; title?: string | null; tasks?: string[] | null; project?: string | null; module?: string | null; date: string }>;
};

function initials(name?: string | null, email?: string | null) {
  const s = (v: unknown) => (typeof v === 'string' ? v : '');
  const n = s(name).trim();
  if (n) {
    const parts = n.split(/\s+/).filter(Boolean);
    const a = parts[0]?.[0] || '';
    const b = parts.length > 1 ? parts[parts.length - 1]?.[0] : '';
    const res = `${a}${b}`.toUpperCase();
    if (res) return res;
  }
  const em = s(email).trim();
  if (em) {
    const local = em.split('@')[0] || '';
    const a = local[0] || '';
    const b = local.length > 1 ? local[local.length - 1] : '';
    const res = `${a}${b}`.toUpperCase();
    if (res) return res;
  }
  return 'UU';
}

function changePct(current: number, previous: number): number | null {
  if (!previous) return null;
  return Math.round(((current - previous) / previous) * 1000) / 10;
}

function ChangeBadge({ value, lessIsBetter = false }: { value: number | null; lessIsBetter?: boolean }) {
  if (value == null) return null;
  const good = lessIsBetter ? value <= 0 : value >= 0;
  return (
    <span className={good ? 'text-emerald-600' : 'text-red-600'} style={{ fontWeight: 600 }}>
      {value > 0 ? `+${value}%` : `${value}%`}
    </span>
  );
}

function Tile({ label, value, children }: { label: string; value: ReactNode; children?: ReactNode }) {
  return (
    <div className="rounded-lg border border-gray-200 p-4">
      <div className="text-[12px] text-gray-600 mb-1">{label}</div>
      <div className="text-[20px] text-gray-900" style={{ fontWeight: 700 }}>{value}</div>
      {children && <div className="text-[12px] text-gray-500 flex flex-wrap items-center gap-x-2">{children}</div>}
    </div>
  );
}

export function MyMetrics() {
  const t = useTr();
  const pick = usePick();
  const { dateRange, label: dateRangeLabel } = useDateRange();
  const navigate = useNavigate();

  const interval = useMemo(() => {
    return toInterval(dateRange, 'WEEKS_1');
  }, [dateRange]);

  const [data, setData] = useState<MyMetrics | null>(null);
  const [loading, setLoading] = useState(true);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    async function load() {
      setLoading(true);
      setFailed(false);
      try {
        const res = await fetch(`/api/metrics/me?interval=${encodeURIComponent(interval)}`, { credentials: 'include', signal: controller.signal, headers: { Accept: 'application/json' } });
        if (!res.ok) throw new Error(String(res.status));
        const js = await res.json();
        if (cancelled) return;
        setData(js as MyMetrics);
      } catch {
        if (cancelled) return;
        setData(null);
        setFailed(true);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; controller.abort(); };
  }, [interval]);

  const profile = data?.profile;
  const displayName = profile?.name || profile?.id || '—';
  const firstName = String(profile?.name || '').trim().split(/\s+/)[0];
  const commitsSeries = useMemo(
    () => (data?.commitsPerDay ?? []).map((d) => ({ day: new Date(d.day).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }), commits: d.commits })),
    [data],
  );
  const hasQuality = (data?.quality?.scannedCommits ?? 0) > 0;
  const mainReviewer = data?.reviewers?.[0];

  return (
    <div className="p-4 sm:p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="min-w-0">
          <h1 className="text-[20px] text-gray-900" style={{ fontWeight: 700 }}>{firstName ? `Hi ${firstName},` : 'Hi,'}</h1>
          <p className="text-[12px] text-gray-500 mt-0.5">that's your personal engineering metrics · {dateRangeLabel}</p>
        </div>
        <div className="hidden sm:flex items-center gap-2 text-[12px] text-gray-600">
          <Calendar className="w-4 h-4" />
          {dateRangeLabel}
        </div>
      </div>

      {loading && !data ? (
        <div className="bg-white rounded-xl border border-gray-200 p-5 min-h-[160px] flex items-center justify-center">
          <LoadingSpinner size={20} />
        </div>
      ) : failed || !data ? (
        <div className="bg-white rounded-xl border border-gray-200 p-5 min-h-[120px] flex items-center justify-center text-[12px] text-gray-500">
          {t('noData')}
        </div>
      ) : (
        <>
          {/* Top row: Profile card (left) + Developer Overview (right) */}
          <div className="grid grid-cols-1 xl:grid-cols-12 gap-4">
            {/* Profile card (left) */}
            <div className="xl:col-span-3 bg-white rounded-xl border border-gray-200 p-4 flex items-start gap-4">
              <div className="w-12 h-12 shrink-0 rounded-full bg-gradient-to-br from-blue-500 to-cyan-600 text-white flex items-center justify-center text-[14px]" style={{ fontWeight: 700 }}>
                {initials(displayName, profile?.email)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="min-w-0">
                    <div className="text-[16px] text-gray-900 break-words" style={{ fontWeight: 700 }}>{displayName}</div>
                    <div className="text-[12px] text-gray-500">{profile?.role || '—'}</div>
                  </div>
                  <button onClick={() => navigate('/team')} className="shrink-0 px-3 py-1.5 text-[12px] rounded-md border border-gray-300 hover:bg-gray-50" style={{ fontWeight: 600 }}>View full profile</button>
                </div>
                <div className="mt-2 flex flex-col gap-2 text-[12px]">
                  <div>
                    <div className="text-gray-400">Tribe</div>
                    <div className="text-gray-900">{profile?.tribe || '—'}</div>
                  </div>
                  <div>
                    <div className="text-gray-400">Squad</div>
                    <div className="text-gray-900 truncate">{profile?.squad || '—'}</div>
                  </div>
                  <div>
                    <div className="text-gray-400">GitLab</div>
                    <div className="text-gray-900 truncate">{profile?.id || '—'}</div>
                  </div>
                  <div>
                    <div className="text-gray-400">Email</div>
                    <div className="text-gray-900 truncate">{profile?.email || '—'}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Developer Overview (right) */}
            <div className="xl:col-span-9 bg-white rounded-xl border border-gray-200 p-5">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h2 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>Developer Overview</h2>
                  <p className="text-[12px] text-gray-500">Track your engineering performance and code quality over time.</p>
                </div>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3">
                <Tile label="Commits" value={data.commits}>
                  <ChangeBadge value={changePct(data.commits, data.commitsPrev)} />
                  <span>Daily avg.</span>
                  <span className="text-gray-400">{data.dailyAvgCommits}</span>
                </Tile>
                <Tile label="Merge Requests" value={data.mrsCreated}>
                  <ChangeBadge value={changePct(data.mrsCreated, data.mrsCreatedPrev)} />
                  <span>Merged</span>
                  <span className="text-gray-400">{data.mrsMerged}</span>
                </Tile>
                <Tile label="Pickup Time" value={`${data.avgPickupHours}h`}>
                  <span>Avg. per MR</span>
                </Tile>
                <Tile label="Review Time" value={`${data.avgReviewHours}h`}>
                  <span>Avg. per MR</span>
                </Tile>
                <Tile label="Cycle Time" value={`${data.avgCycleHours}h`}>
                  <span>Created → merged</span>
                </Tile>
                <Tile label="Lines Changed" value={<><span className="text-emerald-600">+{data.additions}</span> <span className="text-red-600">−{data.deletions}</span></>} />
                <Tile label="Active Days" value={data.workingDays != null ? `${data.activeDays} / ${data.workingDays}` : data.activeDays}>
                  <span>Days with commits</span>
                </Tile>
                {hasQuality && (
                  <>
                    <Tile label="New Bugs" value={data.quality.avgNewBugs}>
                      <span>Avg. per scanned commit</span>
                    </Tile>
                    <Tile label="New Code Smells" value={data.quality.avgNewCodeSmells}>
                      <span>Avg. per scanned commit</span>
                    </Tile>
                    <Tile label="New Violations" value={data.quality.avgNewViolations}>
                      <span>Avg. per scanned commit</span>
                    </Tile>
                    <Tile label="New Code Coverage" value={`${data.quality.avgNewCoverage}%`}>
                      <span>Scanned commits</span>
                      <span className="text-gray-400">{data.quality.scannedCommits}</span>
                    </Tile>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Review insights */}
          <div className="bg-white rounded-xl border border-gray-200 p-4">
            <div className="flex items-center flex-wrap gap-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-violet-500 flex items-center justify-center"><Timer className="w-4 h-4 text-white"/></div>
                <div>
                  <div className="text-[12px] text-gray-500">Avg time to review your MRs</div>
                  <div className="text-[16px] text-gray-900" style={{ fontWeight: 700 }}>{data.avgReviewHours}h</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center"><UserCheck className="w-4 h-4 text-white"/></div>
                <div>
                  <div className="text-[12px] text-gray-500">Main reviewer of your MRs</div>
                  <div className="text-[16px] text-gray-900" style={{ fontWeight: 700 }}>
                    {mainReviewer ? <>{mainReviewer.name} <span className="text-[12px] text-gray-500 font-normal">({mainReviewer.pct}% of your reviewed MRs)</span></> : '—'}
                  </div>
                </div>
              </div>
            </div>
            {data.reviewers.length > 0 && (
              <div className="mt-3 grid grid-cols-1 sm:grid-cols-5 gap-2 text-[11px] text-gray-600">
                {data.reviewers.map((r) => (
                  <div key={r.id} className="flex items-center justify-between bg-gray-50 border border-gray-200 rounded-md px-2 py-1">
                    <span className="truncate">{r.name}</span>
                    <span className="text-gray-900" style={{ fontWeight: 700 }}>{r.pct}%</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Commits Over Time */}
          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <h2 className="text-[14px] text-gray-900 mb-1" style={{ fontWeight: 600 }}>{pick('Commits Over Time', 'Commity w czasie')}</h2>
            <p className="text-[12px] text-gray-400 mb-4">{pick('Activity trend', 'Trend aktywności')}</p>
            <div className="h-44">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={commitsSeries}>
                  <defs>
                    <linearGradient id="gradMyCommits" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#6366f1" stopOpacity={0.2} />
                      <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid stroke="#f0f0f0" strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="day" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                  <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                  <Tooltip contentStyle={{ backgroundColor: 'white', border: '1px solid #e5e7eb', borderRadius: 8, fontSize: 12 }} />
                  <Area type="monotone" dataKey="commits" stroke="#6366f1" strokeWidth={2.5} fill="url(#gradMyCommits)" dot={false} name={pick('Commits','Commity')} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Languages */}
          <div className="bg-white rounded-xl border border-gray-200 p-5">
            <h2 className="text-[14px] text-gray-900 mb-1" style={{ fontWeight: 600 }}>{pick('Languages (by changed lines)', 'Języki (wg zmienionych linii)')}</h2>
            <p className="text-[12px] text-gray-400 mb-3">
              {pick(`From your GitLab commits · ${data.commitsWithLanguages} of ${data.commits} commits analysed`, `Z Twoich commitów w GitLabie · przeanalizowano ${data.commitsWithLanguages} z ${data.commits} commitów`)}
            </p>
            {data.languages.length === 0 ? (
              <p className="text-[12px] text-gray-500">{pick('No language data for this period yet.', 'Brak danych o językach dla tego okresu.')}</p>
            ) : (
              <div className="space-y-2">
                {data.languages.map((b) => (
                  <div key={b.name} className="flex items-center gap-3">
                    <div className="w-24 text-[12px] text-gray-600">{b.name}</div>
                    <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div className="h-full bg-indigo-500" style={{ width: `${b.pct}%` }} />
                    </div>
                    <div className="w-12 text-right text-[12px] text-gray-900" style={{ fontWeight: 600 }}>{b.pct}%</div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Recent Commits */}
          <div className="bg-white rounded-xl border border-gray-200 p-5 overflow-x-auto">
            <h2 className="text-[14px] text-gray-900 mb-2" style={{ fontWeight: 600 }}>{pick('Recent Commits', 'Ostatnie commity')}</h2>
            {data.recentCommits.length === 0 ? (
              <p className="text-[12px] text-gray-500">{t('noData')}</p>
            ) : (
              <table className="w-full text-[12px] min-w-[640px]">
                <thead className="text-gray-500">
                  <tr className="bg-gray-50">
                    {['Commit', 'Message', 'JIRA Issue', 'Repository', 'Date'].map((h) => (
                      <th key={h} className="text-left px-3 py-2">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 text-gray-700">
                  {data.recentCommits.map((c) => {
                    const d = new Date(c.date);
                    return (
                      <tr key={`${c.project}/${c.module}/${c.id}`} className="hover:bg-gray-50">
                        <td className="px-3 py-2"><span className="text-indigo-600" title={c.id}>{c.id.slice(0, 7)}</span></td>
                        <td className="px-3 py-2 whitespace-nowrap">{c.title || '—'}</td>
                        <td className="px-3 py-2">{c.tasks && c.tasks.length > 0 ? c.tasks.join(', ') : '—'}</td>
                        <td className="px-3 py-2">{[c.project, c.module].filter(Boolean).join('/')}</td>
                        <td className="px-3 py-2 whitespace-nowrap">
                          {d.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })}
                          <span className="text-gray-400"> · {d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })}</span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </div>
        </>
      )}
    </div>
  );
}

export default MyMetrics;
