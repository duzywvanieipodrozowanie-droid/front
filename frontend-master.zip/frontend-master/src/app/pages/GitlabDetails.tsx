import { Fragment, useEffect, useMemo, useState, type ReactNode } from 'react';
import { ChevronDown, ChevronRight, Clock, RefreshCw } from 'lucide-react';
import { useDateRange } from '../context/DateRangeContext';
import { useTeam } from '../context/TeamContext';
import { useLang, usePick } from '../i18n';
import HelpTip from '../components/HelpTip';
import LoadingSpinner from '../components/LoadingSpinner';
import { CommitTimeDialog } from '../components/CommitTimeDialog';
import { toInterval } from '../utils/dateRange';

// Merge request activity of the selected unit, from /api/metrics/gitlab/details (computed in core from imported MRs
// of all the unit's repositories, read-only). All times are hours.

type NameCount = { name: string; count: number };
type Summary = {
  merged: number; mergedPrevious: number; leadTime: number; leadTimePrevious: number; pickup: number; pickupPrevious: number;
  mainMergesPerWeek: number; mainMergesPerWeekPrevious: number; withoutApproval: number; stale: number; oldestStaleDays?: number | null;
};
type Breakdown = { mergeRequests: number; coding: number; pickup: number; review: number; merge: number };
type Developer = {
  key: string; name: string; mergeRequests: number; coding: number; pickup: number; review: number; merge: number;
  withoutApproval: number; selfApprovals: number; topApprovers: NameCount[];
};
type Reviewer = { key: string; name: string; approvals: number; avgHoursToApprove: number; sharePct: number };
type AttentionKind = 'WITHOUT_APPROVAL' | 'STALE' | 'WAITING_PICKUP' | 'ABANDONED';
type Attention = { kind: AttentionKind; mrId: string; title?: string | null; project: string; module: string; authorName: string; since?: string | null; days: number };
type SiloPair = { a: string; b: string; mutual: number; sharePct: number; modules: NameCount[] };
type ReviewEdge = { reviewer: string; author: string; count: number };
type MrItem = {
  mrId: string; title?: string | null; project: string; module: string; authorKey: string; authorName: string; state: string;
  targetBranch?: string | null; createdAt: string; mergedAt?: string | null; coding: number; pickup: number; review: number; merge: number;
  approvers: string[]; commitTitles: string[];
};
type Details = {
  summary: Summary; breakdown: Breakdown; developers: Developer[]; reviewers: Reviewer[]; attention: Attention[];
  silos: SiloPair[]; reviewNetwork: ReviewEdge[]; selfApprovals: number; mergeRequests: MrItem[];
};

// Explicit hex colors: theme.css remaps Tailwind indigo classes to brand green.
const PHASES: Array<{ key: 'coding' | 'pickup' | 'review' | 'merge'; color: string; en: string; pl: string; hintEn: string; hintPl: string }> = [
  { key: 'coding', color: '#6366f1', en: 'Coding', pl: 'Coding', hintEn: 'first commit → MR opened', hintPl: 'pierwszy commit → otwarcie MR' },
  { key: 'pickup', color: '#f59e0b', en: 'Pickup', pl: 'Pickup', hintEn: 'opened → first approval', hintPl: 'otwarcie → 1. akceptacja' },
  { key: 'review', color: '#10b981', en: 'Review', pl: 'Review', hintEn: 'first → last approval', hintPl: '1. → ostatnia akceptacja' },
  { key: 'merge', color: '#64748b', en: 'Merge', pl: 'Merge', hintEn: 'last approval → merge', hintPl: 'ostatnia akceptacja → merge' },
];

const card = 'bg-white dark:bg-[#121317] rounded-xl border border-gray-200 dark:border-white/10';
const muted = 'text-gray-500 dark:text-gray-400';
const th = 'py-1.5 px-2 text-left text-[11px] text-gray-500 dark:text-gray-400 border-b border-gray-200 dark:border-white/10';
const td = 'py-1.5 px-2 border-b border-gray-100 dark:border-white/5';

function intervalOf(dateRange: string): string {
  return toInterval(dateRange, 'WEEKS_4');
}

function fmtHours(h: number | null | undefined): string {
  const v = Number(h ?? 0);
  if (!Number.isFinite(v) || v <= 0) return '0 h';
  if (v >= 48) return `${(v / 24).toFixed(1)} d`;
  return `${v.toFixed(1)} h`;
}

function Badge({ children, className }: { children: ReactNode; className: string }) {
  return <span className={`inline-block px-1.5 py-0.5 rounded text-[10.5px] whitespace-nowrap ${className}`} style={{ fontWeight: 700 }}>{children}</span>;
}

const RED = 'bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-400';
const AMBER = 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400';
const GREEN = 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-400';
const GRAY = 'bg-gray-100 text-gray-600 dark:bg-[#2a2c33] dark:text-gray-300';

/** Change vs previous period; lessBetter flips the colour (e.g. shorter lead time is good). */
function Delta({ value, previous, lessBetter, unit }: { value: number; previous: number; lessBetter?: boolean; unit?: 'h' | '%' | '' }) {
  const pick = usePick();
  if (!previous) return <span className={`text-[11px] ${muted}`}>{pick('no previous data', 'brak danych z poprz. okresu')}</span>;
  const diff = value - previous;
  if (Math.abs(diff) < 0.05) return <span className={`text-[11px] ${muted}`}>{pick('no change', 'bez zmian')}</span>;
  const good = lessBetter ? diff < 0 : diff > 0;
  const text = unit === 'h' ? fmtHours(Math.abs(diff)) : unit === '%' ? `${Math.round(Math.abs(diff) / previous * 100)}%` : Math.abs(diff).toFixed(1);
  return (
    <span className={`text-[11px] ${good ? 'text-emerald-600' : 'text-red-600'}`}>
      {diff > 0 ? '▲' : '▼'} {text} {pick('vs prev.', 'vs poprz.')}
    </span>
  );
}

function Kpi({ label, value, help, children }: { label: string; value: ReactNode; help?: string; children?: ReactNode }) {
  return (
    <div className={`${card} p-3`}>
      <div className={`flex items-center gap-1 text-[10.5px] uppercase tracking-wide ${muted}`}>
        {label}{help ? <HelpTip size="sm" content={help} /> : null}
      </div>
      <div className="text-[22px] mt-1" style={{ fontWeight: 700 }}>{value}</div>
      <div className="mt-0.5">{children}</div>
    </div>
  );
}

function PhaseBar({ item, height = 8, labels = false }: { item: Pick<Breakdown, 'coding' | 'pickup' | 'review' | 'merge'>; height?: number; labels?: boolean }) {
  const total = PHASES.reduce((s, p) => s + Number(item[p.key] || 0), 0);
  if (total <= 0) return <div className={`text-[11px] ${muted}`}>—</div>;
  return (
    <div className="flex w-full rounded overflow-hidden" style={{ height }}>
      {PHASES.map((p) => {
        const v = Number(item[p.key] || 0);
        if (v <= 0) return null;
        return (
          <div
            key={p.key}
            title={`${p.en}: ${fmtHours(v)}`}
            className="flex items-center justify-center text-white text-[11px] overflow-hidden whitespace-nowrap"
            style={{ width: `${(v / total) * 100}%`, backgroundColor: p.color, fontWeight: 600 }}
          >{labels && v / total > 0.08 ? `${p.en} ${fmtHours(v)}` : ''}</div>
        );
      })}
    </div>
  );
}

export function GitlabDetails() {
  const pick = usePick();
  const { lang } = useLang();
  const { dateRange, label: dateRangeLabel } = useDateRange();
  const { selectedUnitId, selectedTeamName } = useTeam();
  const interval = useMemo(() => intervalOf(dateRange), [dateRange]);

  const [data, setData] = useState<Details | null>(null);
  const [loading, setLoading] = useState(true);
  const [failed, setFailed] = useState(false);
  const [forbidden, setForbidden] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);
  // #commit-time in the URL opens the commit time popup directly (link from other screens)
  const [commitTimeOpen, setCommitTimeOpen] = useState(() => typeof window !== 'undefined' && window.location.hash === '#commit-time');
  const [expanded, setExpanded] = useState<string | null>(null);
  const [showNetwork, setShowNetwork] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    async function load() {
      setLoading(true);
      setFailed(false);
      setForbidden(false);
      try {
        const params = new URLSearchParams({ interval });
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        const res = await fetch(`/api/metrics/gitlab/details?${params.toString()}`, { credentials: 'include', signal: controller.signal });
        if (res.status === 403) { if (!cancelled) { setData(null); setForbidden(true); } return; }
        if (!res.ok) throw new Error(String(res.status));
        const js = (await res.json()) as Details;
        if (!cancelled) setData(js);
      } catch {
        if (!cancelled) { setData(null); setFailed(true); }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; controller.abort(); };
  }, [interval, selectedUnitId, reloadKey]);

  const mrsByAuthor = useMemo(() => {
    const map = new Map<string, MrItem[]>();
    (data?.mergeRequests ?? []).forEach((m) => {
      const list = map.get(m.authorKey) ?? [];
      list.push(m);
      map.set(m.authorKey, list);
    });
    return map;
  }, [data]);

  const network = useMemo(() => {
    const edges = data?.reviewNetwork ?? [];
    const reviewers = Array.from(new Set(edges.map((e) => e.reviewer))).sort();
    const authors = Array.from(new Set(edges.map((e) => e.author))).sort();
    const counts = new Map(edges.map((e) => [`${e.reviewer}|${e.author}`, e.count]));
    const max = edges.reduce((m, e) => Math.max(m, e.count), 0);
    return { reviewers, authors, counts, max };
  }, [data]);

  const locale = lang === 'pl' ? 'pl-PL' : 'en-GB';
  const fmtDate = (iso?: string | null) => (iso ? new Date(iso).toLocaleDateString(locale, { day: 'numeric', month: 'short' }) : '—');
  const teamLabel = selectedTeamName && selectedTeamName !== 'All Teams' ? selectedTeamName : pick('all your units', 'wszystkie Twoje unity');

  const attentionLabel: Record<AttentionKind, [string, string]> = {
    WITHOUT_APPROVAL: [pick('merged without approval', 'zmergowany bez akceptacji'), RED],
    STALE: [pick('no update for 3+ days', 'wisi bez aktualizacji'), AMBER],
    WAITING_PICKUP: [pick('waiting for pickup', 'czeka na pickup'), AMBER],
    ABANDONED: [pick('closed without merge', 'zamknięty bez merge'), GRAY],
  };

  function developerSignal(d: Developer): ReactNode {
    if (d.withoutApproval > 0) return <Badge className={RED}>{d.withoutApproval} {pick('without approval', 'bez akceptacji')}</Badge>;
    const silo = (data?.silos ?? []).find((s) => (s.a === d.name || s.b === d.name) && s.sharePct >= 60);
    if (silo) return <Badge className={AMBER}>{pick('silo with', 'silos z')} {silo.a === d.name ? silo.b : silo.a}</Badge>;
    if (d.selfApprovals > 0) return <Badge className={AMBER}>{d.selfApprovals} {pick('self-approved', 'samoakcept.')}</Badge>;
    return <Badge className={GREEN}>OK</Badge>;
  }

  const s = data?.summary;
  const topReviewer = data?.reviewers?.[0];

  return (
    <div className="p-4 sm:p-6 space-y-4 text-gray-900 dark:text-gray-100">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-[20px]" style={{ fontWeight: 700 }}>{pick('GitLab details', 'Szczegóły GitLab')}</h1>
          <p className={`text-[12px] ${muted} mt-0.5`}>
            {pick('Merge requests of all repositories of the unit', 'Merge requesty ze wszystkich repozytoriów jednostki')} · {teamLabel} · {dateRangeLabel}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setCommitTimeOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[12px] text-white"
            style={{ backgroundColor: '#065f46', fontWeight: 600 }}
          >
            <Clock className="w-4 h-4" /> {pick('Commit time', 'Czas commitów')}
          </button>
          <button
            onClick={() => setReloadKey((k) => k + 1)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[12px] border border-gray-200 bg-white hover:bg-gray-50 dark:bg-white/5 dark:border-white/10"
            aria-label={pick('Refresh data', 'Odśwież dane')}
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /> {pick('Refresh', 'Odśwież')}
          </button>
        </div>
      </div>

      {loading && !data ? (
        <div className={`${card} p-5 min-h-[160px] flex items-center justify-center`}><LoadingSpinner size={20} /></div>
      ) : forbidden ? (
        <div className={`${card} p-5 text-[13px] ${muted}`}>{pick('You do not manage this unit.', 'Nie zarządzasz tą jednostką.')}</div>
      ) : failed || !data || !s ? (
        <div className={`${card} p-5 text-[13px] ${muted}`}>{pick('Could not load GitLab data.', 'Nie udało się pobrać danych z GitLaba.')}</div>
      ) : (
        <>
          <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
            <Kpi label={pick('Merged MRs', 'Zmergowane MR-y')} value={s.merged}>
              <Delta value={s.merged} previous={s.mergedPrevious} unit="%" />
            </Kpi>
            <Kpi label={pick('Lead time (avg)', 'Lead time (śr.)')} value={fmtHours(s.leadTime)}
              help={pick('First commit → merge into main/master.', 'Pierwszy commit → merge do main/master.')}>
              <Delta value={s.leadTime} previous={s.leadTimePrevious} lessBetter unit="h" />
            </Kpi>
            <Kpi label={pick('Pickup (avg)', 'Pickup (śr.)')} value={fmtHours(s.pickup)}
              help={pick('MR opened → first approval.', 'Otwarcie MR → pierwsza akceptacja.')}>
              <Delta value={s.pickup} previous={s.pickupPrevious} lessBetter unit="h" />
            </Kpi>
            <Kpi label={pick('Merges to main / week', 'Merge do main / tydz.')} value={Number(s.mainMergesPerWeek).toFixed(1)}>
              <Delta value={s.mainMergesPerWeek} previous={s.mainMergesPerWeekPrevious} />
            </Kpi>
            <Kpi label={pick('Without approval', 'Bez akceptacji')} value={s.withoutApproval}>
              <span className={`text-[11px] ${s.withoutApproval > 0 ? 'text-red-600' : muted}`}>
                {s.merged ? Math.round((s.withoutApproval / s.merged) * 100) : 0}% {pick('of merged MRs', 'zmergowanych MR-ów')}
              </span>
            </Kpi>
            <Kpi label={pick('Stale > 3 days', 'Wiszące > 3 dni')} value={s.stale}>
              <span className={`text-[11px] ${s.stale > 0 ? 'text-red-600' : muted}`}>
                {s.oldestStaleDays != null ? `${pick('oldest', 'najstarszy')} ${s.oldestStaleDays} d` : pick('none', 'brak')}
              </span>
            </Kpi>
          </div>

          <div className={`${card} p-4`}>
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-[14px]" style={{ fontWeight: 600 }}>{pick('Where the time goes (PR cycle time breakdown)', 'Gdzie ucieka czas (PR Cycle Time Breakdown)')}</h2>
              <span className={`text-[11px] ${muted}`}>{data.breakdown.mergeRequests} {pick('MRs merged into main/master', 'MR-ów zmergowanych do main/master')}</span>
            </div>
            <PhaseBar item={data.breakdown} height={28} labels />
            <div className="flex flex-wrap gap-4 mt-2 text-[12px] text-gray-700 dark:text-gray-300">
              {PHASES.map((p) => (
                <span key={p.key} className="inline-flex items-center gap-1.5">
                  <i className="inline-block w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: p.color }} />
                  <span style={{ fontWeight: 600 }}>{pick(p.en, p.pl)} {fmtHours(data.breakdown[p.key])}</span>
                  <span className={muted}>{pick(p.hintEn, p.hintPl)}</span>
                </span>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-[2fr_1fr] gap-3">
            <div className={`${card} p-4 overflow-x-auto`}>
              <h2 className="text-[14px] mb-2" style={{ fontWeight: 600 }}>{pick('Developers', 'Deweloperzy')}</h2>
              {data.developers.length === 0 ? (
                <div className={`text-[12px] ${muted}`}>{pick('No merged MRs in this period.', 'Brak zmergowanych MR-ów w tym okresie.')}</div>
              ) : (
                <table className="w-full text-[12px]">
                  <thead>
                    <tr>
                      <th className={th}>{pick('Developer', 'Deweloper')}</th>
                      <th className={th}>{pick('MRs', 'MR-y')}</th>
                      <th className={`${th} w-36`}>{pick('MR cycle', 'Cykl MR')}</th>
                      <th className={th}>Pickup</th>
                      <th className={th}>Review</th>
                      <th className={th}>{pick('Approved mostly by', 'Najczęściej akceptuje')}</th>
                      <th className={th}>{pick('Signal', 'Sygnał')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.developers.map((d) => {
                      const open = expanded === d.key;
                      const mrs = mrsByAuthor.get(d.key) ?? [];
                      return (
                        <Fragment key={d.key}>
                          <tr className="cursor-pointer hover:bg-gray-50 dark:hover:bg-white/5" onClick={() => setExpanded(open ? null : d.key)}>
                            <td className={td}>
                              <span className="inline-flex items-center gap-1">
                                {open ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                                {d.name}
                              </span>
                            </td>
                            <td className={td}>{d.mergeRequests}</td>
                            <td className={td}><PhaseBar item={d} /></td>
                            <td className={td}>{fmtHours(d.pickup)}</td>
                            <td className={td}>{fmtHours(d.review)}</td>
                            <td className={td}>{d.topApprovers.length ? d.topApprovers.map((a) => a.name).join(', ') : '—'}</td>
                            <td className={td}>{developerSignal(d)}</td>
                          </tr>
                          {open ? (
                            <tr>
                              <td colSpan={7} className="px-2 pb-3 pt-1 bg-gray-50/60 dark:bg-white/[0.03]">
                                <table className="w-full text-[11.5px]">
                                  <thead>
                                    <tr>
                                      <th className={th}>MR</th>
                                      <th className={th}>{pick('Repository', 'Repozytorium')}</th>
                                      <th className={th}>{pick('Merged', 'Merge')}</th>
                                      <th className={`${th} w-32`}>{pick('Phases', 'Fazy')}</th>
                                      <th className={th}>{pick('Approvers', 'Akceptujący')}</th>
                                      <th className={th}>{pick('Commits', 'Commity')}</th>
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {mrs.map((m) => (
                                      <tr key={`${m.project}-${m.module}-${m.mrId}`}>
                                        <td className={td}>!{m.mrId} {m.title ?? ''}</td>
                                        <td className={`${td} ${muted}`}>{m.module}{m.targetBranch ? ` → ${m.targetBranch}` : ''}</td>
                                        <td className={td}>{fmtDate(m.mergedAt)}</td>
                                        <td className={td} title={PHASES.map((p) => `${p.en} ${fmtHours(m[p.key])}`).join(' · ')}><PhaseBar item={m} /></td>
                                        <td className={td}>{m.approvers.length ? m.approvers.join(', ') : <Badge className={RED}>{pick('none', 'brak')}</Badge>}</td>
                                        <td className={`${td} ${muted}`}>
                                          {m.commitTitles.length ? (
                                            <span title={m.commitTitles.join('\n')}>{m.commitTitles.length} · {m.commitTitles[0]}</span>
                                          ) : '—'}
                                        </td>
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </td>
                            </tr>
                          ) : null}
                        </Fragment>
                      );
                    })}
                  </tbody>
                </table>
              )}
              <div className={`text-[11px] ${muted} mt-2`}>{pick('Click a row to see the developer\'s MRs.', 'Klik w wiersz → lista MR-ów dewelopera.')}</div>
            </div>

            <div className={`${card} p-4`}>
              <h2 className="text-[14px] mb-2" style={{ fontWeight: 600 }}>{pick('Reviewers', 'Reviewerzy')}</h2>
              {data.reviewers.length === 0 ? (
                <div className={`text-[12px] ${muted}`}>{pick('No approvals in this period.', 'Brak akceptacji w tym okresie.')}</div>
              ) : (
                <table className="w-full text-[12px]">
                  <thead>
                    <tr>
                      <th className={th}>{pick('Reviewer', 'Reviewer')}</th>
                      <th className={th}>{pick('Approvals', 'Akcept.')}</th>
                      <th className={th}>{pick('Avg time', 'Śr. czas')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.reviewers.map((r) => (
                      <tr key={r.key}>
                        <td className={td}>{r.name}</td>
                        <td className={td}>{r.approvals} <span className={muted}>({r.sharePct}%)</span></td>
                        <td className={td}>{fmtHours(r.avgHoursToApprove)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
              {topReviewer && topReviewer.sharePct >= 35 ? (
                <div className="text-[11px] text-amber-700 mt-2">
                  {pick('Load', 'Obciążenie')}: {topReviewer.name} {pick('does', 'robi')} {topReviewer.sharePct}% {pick('of all approvals.', 'wszystkich akceptacji.')}
                </div>
              ) : null}
            </div>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-2 gap-3">
            <div className={`${card} p-4 overflow-x-auto`}>
              <h2 className="text-[14px] mb-2" style={{ fontWeight: 600 }}>{pick('Needs attention', 'Wymaga uwagi')}</h2>
              {data.attention.length === 0 ? (
                <div className={`text-[12px] ${muted}`}>{pick('Nothing to look at — process looks stable.', 'Nic do sprawdzenia – proces wygląda stabilnie.')}</div>
              ) : (
                <table className="w-full text-[12px]">
                  <thead>
                    <tr>
                      <th className={th}>MR</th>
                      <th className={th}>{pick('Author', 'Autor')}</th>
                      <th className={th}>{pick('Problem', 'Problem')}</th>
                      <th className={th}>{pick('For', 'Od')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.attention.map((a) => {
                      const [label, cls] = attentionLabel[a.kind];
                      return (
                        <tr key={`${a.kind}-${a.project}-${a.module}-${a.mrId}`}>
                          <td className={td}>
                            <div>!{a.mrId} {a.title ?? ''}</div>
                            <div className={`text-[10.5px] ${muted}`}>{a.module}</div>
                          </td>
                          <td className={td}>{a.authorName}</td>
                          <td className={td}><Badge className={cls}>{label}</Badge></td>
                          <td className={td}>{a.days} d</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </div>

            <div className={`${card} p-4 overflow-x-auto`}>
              <h2 className="text-[14px] mb-2" style={{ fontWeight: 600 }}>{pick('Knowledge silos and review network', 'Silosy wiedzy i sieć akceptacji')}</h2>
              {data.silos.length === 0 ? (
                <div className={`text-[12px] ${muted}`}>{pick('No pairs approving each other.', 'Brak par akceptujących się nawzajem.')}</div>
              ) : (
                <table className="w-full text-[12px]">
                  <thead>
                    <tr>
                      <th className={th}>{pick('Pair', 'Para')}</th>
                      <th className={th}>{pick('Mutual approvals', 'Wzajemne akceptacje')}</th>
                      <th className={th}>{pick('Modules', 'Moduły')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.silos.map((p) => (
                      <tr key={`${p.a}-${p.b}`}>
                        <td className={td}>{p.a} ↔ {p.b}</td>
                        <td className={td}>
                          {p.mutual} <span className={p.sharePct >= 60 ? 'text-amber-700' : muted}>({p.sharePct}% {pick('of their MRs', 'ich MR-ów')})</span>
                        </td>
                        <td className={`${td} ${muted}`}>{p.modules.map((m) => m.name).join(', ')}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
              <div className={`flex items-center gap-3 text-[11px] ${muted} mt-2`}>
                <span>{pick('Self-approvals', 'Samoakceptacje')}: <b className="text-gray-900 dark:text-gray-100">{data.selfApprovals}</b></span>
                {network.reviewers.length ? (
                  <button className="underline text-[11px]" onClick={() => setShowNetwork((v) => !v)}>
                    {showNetwork ? pick('Hide who approves whom', 'Ukryj „kto komu akceptuje”') : pick('Show who approves whom', 'Pokaż „kto komu akceptuje”')}
                  </button>
                ) : null}
              </div>
              {showNetwork ? (
                <div className="overflow-x-auto mt-2">
                  <table className="text-[11px]">
                    <thead>
                      <tr>
                        <th className="p-1 text-left">{pick('reviewer ↓ / author →', 'reviewer ↓ / autor →')}</th>
                        {network.authors.map((a) => <th key={a} className="p-1 whitespace-nowrap" style={{ fontWeight: 600 }}>{a}</th>)}
                      </tr>
                    </thead>
                    <tbody>
                      {network.reviewers.map((r) => (
                        <tr key={r}>
                          <td className="p-1 whitespace-nowrap" style={{ fontWeight: 600 }}>{r}</td>
                          {network.authors.map((a) => {
                            const c = network.counts.get(`${r}|${a}`) ?? 0;
                            const alpha = c && network.max ? 0.15 + 0.85 * (c / network.max) : 0;
                            return (
                              <td key={a} className="p-1 text-center min-w-[28px]"
                                style={{ backgroundColor: c ? `rgba(22,163,74,${alpha})` : undefined, color: alpha > 0.6 ? '#fff' : undefined }}>
                                {c || ''}
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : null}
            </div>
          </div>
        </>
      )}

      <CommitTimeDialog open={commitTimeOpen} onOpenChange={setCommitTimeOpen} unitId={selectedUnitId} teamName={selectedTeamName} />
    </div>
  );
}

export default GitlabDetails;
