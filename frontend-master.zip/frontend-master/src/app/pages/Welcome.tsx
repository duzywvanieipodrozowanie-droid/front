import React, { useEffect, useState } from 'react';
import ModalLogin from '../components/ModalLogin';

export default function Welcome() {
  const [showLogin, setShowLogin] = useState(true);

  // On first visit, if organization is not configured yet, prompt the configurator overlay
  useEffect(() => {
    try {
      const orgName = (localStorage.getItem('org.name') || '').trim();
      const licKey = (localStorage.getItem('org.licence.key') || '').trim();
      const dismissed = localStorage.getItem('configurator.dismissed') === '1';
      if ((!orgName || !licKey) && !dismissed) {
        localStorage.setItem('configurator.show', 'true');
        window.dispatchEvent(new Event('configurator.changed'));
      }
    } catch {}
  }, []);

  function openConfigurator() {
    try {
      const alreadyOpen = localStorage.getItem('configurator.show') === 'true';
      if (alreadyOpen) return;
      localStorage.setItem('configurator.show', 'true');
      window.dispatchEvent(new Event('configurator.changed'));
    } catch {}
  }

  function handleLoginSubmit(_login: string, _password: string) {
    // This Welcome modal is decorative for SSO users; just close it and optionally open configurator
    setShowLogin(false);
  }

  return (
    <div className="relative p-6">
      {/* Login modal over the page */}
      <ModalLogin
        open={showLogin}
        onClose={() => setShowLogin(false)}
        onSubmit={handleLoginSubmit}
        feetTopVH={28}
      />

      {/* Underlying authenticated Welcome page content */}
      <div className="bg-white rounded-2xl border border-gray-200 p-6 shadow-sm">
        <h1 className="text-[18px] text-gray-900" style={{ fontWeight: 800 }}>Welcome</h1>
        <p className="text-[13px] text-gray-600 mt-1">This is your Welcome space. Use the sidebar to navigate the app. You can start by completing the setup.</p>
        <div className="mt-4">
          <button onClick={openConfigurator} className="px-4 py-2 rounded-md bg-indigo-600 text-white text-[12px] hover:bg-indigo-700" style={{ fontWeight: 700 }}>
            Open configurator
          </button>
        </div>
      </div>
    </div>
  );
}
