import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

export function Configurator() {
  const navigate = useNavigate();
  const [appName, setAppName] = useState<string>('OneLook');
  const [licenceKey, setLicenceKey] = useState<string>('');
  const [savedMsg, setSavedMsg] = useState<string>('');

  useEffect(() => {
    try {
      const storedName = localStorage.getItem('app.brand.name');
      const storedKey = localStorage.getItem('app.licence.key');
      if (storedName) setAppName(storedName);
      if (storedKey) setLicenceKey(storedKey);
    } catch {}
  }, []);

  function save() {
    try {
      localStorage.setItem('app.brand.name', appName.trim() || 'OneLook');
      localStorage.setItem('app.licence.key', licenceKey.trim());
      window.dispatchEvent(new CustomEvent('app.brand.updated', { detail: { name: appName.trim() } }));
    } catch {}
    setSavedMsg('Saved!');
    setTimeout(() => setSavedMsg(''), 1500);
  }

  function tryBasic() {
    setLicenceKey('');
    try {
      localStorage.setItem('app.licence.key', '');
    } catch {}
    setSavedMsg('Using BASIC');
    setTimeout(() => setSavedMsg(''), 1500);
  }

  function close() {
    try {
      localStorage.removeItem('configurator.show');
      window.dispatchEvent(new Event('configurator.changed'));
    } catch {}
    navigate('/', { replace: true });
  }

  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-gray-900/40 backdrop-blur-sm" onClick={close} />
      <div className="relative z-10 min-h-full w-full flex items-center justify-center p-6">
        <div className="w-full max-w-3xl bg-white rounded-2xl border border-gray-200 shadow-xl">
          <div className="px-6 py-4 border-b border-gray-100 flex items-center justify-between">
            <div>
              <h2 className="text-[16px] text-gray-900" style={{ fontWeight: 800 }}>Settings</h2>
              <p className="text-[12px] text-gray-500">Start with the setup below, then connect your tools. All changes are safe to try — you can adjust anytime.</p>
            </div>
            <button onClick={close} className="px-3 py-1.5 text-[12px] rounded-lg border border-gray-200 hover:bg-gray-50">Close</button>
          </div>

          <div className="p-6">
            <div className="rounded-2xl border border-gray-200 bg-white p-6">
              <h3 className="text-[14px] mb-4" style={{ fontWeight: 800 }}>WELCOME TO ONELOOK lorem ipsum</h3>
              <div className="grid gap-4">
                <div>
                  <label className="block text-[12px] text-gray-600 mb-1" style={{ fontWeight: 600 }}>Application name:</label>
                  <input value={appName} onChange={(e)=>setAppName(e.target.value)} className="w-full rounded-lg border border-gray-300 px-3 py-2 text-[13px] focus:outline-none focus:ring-2 focus:ring-indigo-200" />
                </div>
                <div>
                  <label className="block text-[12px] text-gray-600 mb-1" style={{ fontWeight: 600 }}>Licence key:</label>
                  <input value={licenceKey} onChange={(e)=>setLicenceKey(e.target.value)} className="w-full rounded-lg border border-gray-300 px-3 py-2 text-[13px] focus:outline-none focus:ring-2 focus:ring-indigo-200" />
                </div>
                <div className="flex items-center justify-end gap-3 pt-2">
                  <button onClick={save} className="px-5 py-2 rounded-lg bg-gray-100 text-[13px] border border-gray-300 hover:bg-gray-200" style={{ fontWeight: 700 }}>Save</button>
                  <button onClick={tryBasic} className="px-5 py-2 rounded-lg bg-indigo-600 text-white text-[13px] hover:bg-indigo-700" style={{ fontWeight: 800 }}>Try BASIC</button>
                </div>
                {savedMsg && <p className="text-[12px] text-green-600 text-right">{savedMsg}</p>}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
