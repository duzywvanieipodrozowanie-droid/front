import { useCallback, useEffect, useMemo, useState } from 'react';
import { Download, ExternalLink, RefreshCw } from 'lucide-react';
import { usePick } from '../i18n';
import { useTeam } from '../context/TeamContext';
import { usePageAccess } from '../hooks/usePageAccess';
import LoadingSpinner from '../components/LoadingSpinner';

// Tests → Release check: the image tags of the microservices (service map) of one environment against another
// (alfa -> beta), or of an environment against the Fix Versions of a release task (/api/release-check/*).

type Result = 'DIFFERENT' | 'MISSING' | 'EXTRA' | 'SAME';
type Side = { version: string | null; image: string | null; environment: string | null; fixVersion: string | null } | null;
type Row = { microservice: string; serviceMapProject: string | null; left: Side; right: Side; result: Result; release: string | null };
type ReleaseTask = {
  key: string; summary: string | null; status: string | null; assignee: string | null; url: string | null;
  fixVersions: string[]; dueDate: string | null; updated: string | null; created: string | null;
};
type Comparison = { leftName: string; rightName: string; environmentsMatched: string[]; rows: Row[]; releases: ReleaseTask[]; note: string | null };
type Mode = 'env' | 'release';
type TaskState = 'OPEN' | 'DONE';

const MODE_KEY = 'releaseCheck.mode';
const ORDER: Result[] = ['DIFFERENT', 'MISSING', 'EXTRA', 'SAME'];
const PILL: Record<Result, string> = {
  DIFFERENT: 'bg-red-50 text-red-700',
  MISSING: 'bg-amber-50 text-amber-700',
  EXTRA: 'bg-gray-100 text-gray-600',
  SAME: 'bg-emerald-50 text-emerald-700',
};
const DOT: Record<Result, string> = { DIFFERENT: 'bg-red-500', MISSING: 'bg-amber-500', EXTRA: 'bg-gray-400', SAME: 'bg-emerald-500' };

const norm = (v: string | null | undefined) => (v ?? '').trim().replace(/^v(?=\d)/i, '');
/** The environment of the list named like {@code wanted} ("alfa" also "alpha"), else the name itself. */
const pickEnv = (envs: string[], wanted: string[], fallback: string) =>
  envs.find((e) => wanted.includes(e.toLowerCase())) ?? envs.find((e) => wanted.some((w) => e.toLowerCase().includes(w))) ?? fallback;

const card = 'bg-white rounded-2xl border border-gray-200';

export function ReleaseCheck() {
  const pick = usePick();
  const { selectedUnitId } = useTeam();
  const { loading: accessLoading, allowed: canOpen } = usePageAccess('release-check');

  const [mode, setMode] = useState<Mode>(() => {
    try { return localStorage.getItem(MODE_KEY) === 'env' ? 'env' : 'release'; } catch { return 'release'; }
  });
  const [envs, setEnvs] = useState<string[]>([]);
  const [from, setFrom] = useState('alfa');
  const [to, setTo] = useState('beta');
  const [releaseEnv, setReleaseEnv] = useState('beta');
  const [taskState, setTaskState] = useState<TaskState>('OPEN');
  const [releases, setReleases] = useState<ReleaseTask[] | null>(null);
  const [releaseKey, setReleaseKey] = useState<string>('');
  const [data, setData] = useState<Comparison | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [onlyDiff, setOnlyDiff] = useState(true);
  const [filter, setFilter] = useState<Result | null>(null);
  const [query, setQuery] = useState('');
  const [reload, setReload] = useState(0);

  useEffect(() => { try { localStorage.setItem(MODE_KEY, mode); } catch { /* not kept */ } }, [mode]);

  // environments of the service map, alfa and beta chosen by name
  useEffect(() => {
    if (!canOpen) return;
    fetch('/api/release-check/environments', { credentials: 'include' })
      .then((r) => (r.ok ? r.json() : []))
      .then((list: unknown) => {
        const names = Array.isArray(list) ? list.filter((e): e is string => typeof e === 'string') : [];
        setEnvs(names);
        const beta = pickEnv(names, ['beta'], 'beta');
        setFrom(pickEnv(names, ['alfa', 'alpha'], 'alfa'));
        setTo(beta);
        setReleaseEnv(beta);
      })
      .catch(() => setEnvs([]));
  }, [canOpen]);

  // release tasks in the chosen status, the newest selected
  useEffect(() => {
    if (!canOpen || mode !== 'release') return;
    let cancelled = false;
    setReleases(null);
    const p = new URLSearchParams({ status: taskState });
    if (selectedUnitId) p.set('unitId', selectedUnitId);
    fetch(`/api/release-check/releases?${p}`, { credentials: 'include' })
      .then((r) => (r.ok ? r.json() : []))
      .then((list: ReleaseTask[]) => {
        if (cancelled) return;
        const tasks = Array.isArray(list) ? list : [];
        setReleases(tasks);
        setReleaseKey((key) => (tasks.some((t) => t.key === key) ? key : tasks[0]?.key ?? ''));
      })
      .catch(() => { if (!cancelled) setReleases([]); });
    return () => { cancelled = true; };
  }, [canOpen, mode, taskState, selectedUnitId, reload]);

  const load = useCallback(async (signal: AbortSignal) => {
    setError(null);
    let url: string;
    if (mode === 'env') {
      url = `/api/release-check/environments/compare?${new URLSearchParams({ from, to })}`;
    } else {
      if (!releaseKey) { setData(null); return; }
      const p = new URLSearchParams({ key: releaseKey, environment: releaseEnv });
      if (selectedUnitId) p.set('unitId', selectedUnitId);
      url = `/api/release-check/release/compare?${p}`;
    }
    setLoading(true);
    try {
      const res = await fetch(url, { credentials: 'include', signal });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setData(await res.json());
    } catch (e) {
      if (signal.aborted) return;
      setData(null);
      setError((e instanceof Error && e.message) || 'Failed to load');
    } finally {
      if (!signal.aborted) setLoading(false);
    }
  }, [mode, from, to, releaseKey, releaseEnv, selectedUnitId]);

  useEffect(() => {
    if (!canOpen) return;
    const controller = new AbortController();
    load(controller.signal);
    return () => controller.abort();
  }, [canOpen, load, reload]);

  useEffect(() => { setFilter(null); }, [mode, releaseKey, from, to, releaseEnv]);

  const rows = useMemo(() => data?.rows ?? [], [data]);
  const counts = useMemo(() => Object.fromEntries(ORDER.map((r) => [r, rows.filter((x) => x.result === r).length])) as Record<Result, number>, [rows]);
  const shown = useMemo(() => rows.filter((r) =>
    (!filter || r.result === filter)
    && (filter || !onlyDiff || r.result !== 'SAME')
    && (!query || r.microservice.toLowerCase().includes(query.trim().toLowerCase()))), [rows, filter, onlyDiff, query]);

  const release = mode === 'release' ? (data?.releases?.[0] ?? releases?.find((r) => r.key === releaseKey) ?? null) : null;
  const leftLabel = mode === 'release' ? pick(`Version on ${releaseEnv}`, `Wersja na ${releaseEnv}`) : pick(`Version on ${from}`, `Wersja na ${from}`);
  const rightLabel = mode === 'release' ? pick(`Version in Fix Version (${releaseKey || '—'})`, `Wersja w Fix Version (${releaseKey || '—'})`) : pick(`Version on ${to}`, `Wersja na ${to}`);

  const label = (r: Result) => {
    switch (r) {
      case 'DIFFERENT': return pick('Different version', 'Inna wersja');
      case 'MISSING': return mode === 'release' ? pick(`Not on ${releaseEnv}`, `Brak na ${releaseEnv}`) : pick(`Not on ${to}`, `Brak na ${to}`);
      case 'EXTRA': return mode === 'release' ? pick('Outside the release', 'Spoza release') : pick(`Not on ${from}`, `Brak na ${from}`);
      default: return pick('Matching', 'Zgodne');
    }
  };
  const why = (r: Result) => {
    switch (r) {
      case 'DIFFERENT': return mode === 'release'
        ? pick(`${releaseEnv} runs another image than the Fix Version`, `Na ${releaseEnv} jest inny obraz niż w Fix Version`)
        : pick(`${from} and ${to} run different images`, `${from} i ${to} mają różne obrazy`);
      case 'MISSING': return mode === 'release'
        ? pick(`The Fix Version is not deployed on ${releaseEnv}`, `Wersja z Fix Version nie jest wdrożona na ${releaseEnv}`)
        : pick(`Only on ${from}`, `Tylko na ${from}`);
      case 'EXTRA': return mode === 'release'
        ? pick(`On ${releaseEnv}, no Fix Version of this task names it`, `Jest na ${releaseEnv}, nie ma go w Fix Versions tego tasku`)
        : pick(`Only on ${to}`, `Tylko na ${to}`);
      default: return '';
    }
  };
  const hint = (r: Result) => {
    switch (r) {
      case 'DIFFERENT': return mode === 'release' ? `${releaseEnv} ≠ Fix Version` : `${from} ≠ ${to}`;
      case 'MISSING': return mode === 'release' ? pick('in the task, not deployed', 'w tasku, nie wdrożone') : pick(`only on ${from}`, `tylko na ${from}`);
      case 'EXTRA': return mode === 'release' ? pick(`on ${releaseEnv}, no Fix Version`, `na ${releaseEnv}, bez Fix Version`) : pick(`only on ${to}`, `tylko na ${to}`);
      default: return mode === 'release' ? `${releaseEnv} = Fix Version` : `${from} = ${to}`;
    }
  };

  const exportCsv = () => {
    const esc = (v: string | null | undefined) => `"${(v ?? '').replace(/"/g, '""')}"`;
    const head = ['microservice', 'project', mode === 'release' ? releaseEnv : from, mode === 'release' ? 'fix version' : to, 'result'];
    const lines = rows.map((r) => [r.microservice, r.serviceMapProject, r.left?.version, r.right?.fixVersion ?? r.right?.version, r.result].map(esc).join(','));
    const blob = new Blob([[head.map(esc).join(','), ...lines].join('\n')], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = mode === 'release' ? `release-check-${releaseKey}-${releaseEnv}.csv` : `release-check-${from}-${to}.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  if (accessLoading) return <div className="p-6"><LoadingSpinner size={20} /></div>;
  if (!canOpen) {
    return (
      <div className="p-6 mx-auto">
        <div className={`${card} p-5`}>
          <p className="text-[14px] text-gray-800" style={{ fontWeight: 600 }}>{pick('No access', 'Brak dostępu')}</p>
          <p className="text-[12px] text-gray-500 mt-1">{pick('Your role has no access to this screen. An admin can change it in Settings → Users and access.', 'Twoja rola nie ma dostępu do tego ekranu. Admin może to zmienić w Ustawienia → Użytkownicy i dostęp.')}</p>
        </div>
      </div>
    );
  }

  const seg = (on: boolean) => `px-3 py-1.5 rounded-lg text-[12.5px] transition-colors ${on ? 'bg-white text-gray-900 shadow-sm border border-gray-200' : 'text-gray-600 hover:text-gray-900 border border-transparent'}`;
  const select = 'px-2.5 py-1.5 rounded-lg border border-gray-200 bg-white text-[12.5px] text-gray-800';
  const lbl = 'text-[11px] uppercase tracking-wider text-gray-500';
  const envSelect = (value: string, onChange: (v: string) => void, aria: string) => (
    <select className={select} value={value} onChange={(e) => onChange(e.target.value)} aria-label={aria}>
      {(envs.includes(value) ? envs : [value, ...envs]).map((e) => <option key={e} value={e}>{e}</option>)}
    </select>
  );
  const version = (side: Side, other: Side, result: Result) => {
    if (!side || !side.version) return <span className="text-[12.5px] italic text-gray-400">{pick('none', 'brak')}</span>;
    const differs = result === 'DIFFERENT' && norm(side.version) !== norm(other?.version);
    return <span className={`font-mono text-[12.5px] ${differs ? 'text-red-600' : 'text-gray-900'}`} style={{ fontWeight: 500 }}>{side.version}</span>;
  };
  const detail = (side: Side) => side && (side.image || side.fixVersion) ? (
    <div className="mt-0.5 text-[11px] text-gray-400 break-all">
      {side.fixVersion ? `Fix Version: ${side.fixVersion}` : <span className="font-mono">{side.image}</span>}
    </div>
  ) : null;

  return (
    <div className="p-4 sm:p-6 mx-auto space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="text-[11.5px] text-gray-400">{pick('Tests', 'Testy')}</p>
          <h1 className="text-[20px] text-gray-900" style={{ fontWeight: 700 }}>Release check</h1>
          <p className="text-[13px] text-gray-500 mt-0.5">
            {pick('Microservice images that differ between environments or from the Fix Versions of a release task',
              'Które obrazy mikroserwisów różnią się między środowiskami albo od Fix Version w tasku release')}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button onClick={() => setReload((n) => n + 1)} className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 text-gray-700 text-[12.5px]">
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} /> {pick('Refresh', 'Odśwież')}
          </button>
          <button onClick={exportCsv} disabled={!rows.length} className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 text-gray-700 text-[12.5px] disabled:opacity-50">
            <Download className="w-4 h-4" /> CSV
          </button>
        </div>
      </div>

      <section className={`${card} p-4 grid gap-3 sm:grid-cols-[auto_minmax(0,1fr)] sm:items-center`}>
        <span className={lbl}>{pick('Compare', 'Porównaj')}</span>
        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex gap-1 p-1 rounded-xl bg-gray-100 border border-gray-200">
            <button className={seg(mode === 'env')} onClick={() => setMode('env')} aria-pressed={mode === 'env'}>
              {pick('Environment → environment', 'Środowisko → środowisko')}
            </button>
            <button className={seg(mode === 'release')} onClick={() => setMode('release')} aria-pressed={mode === 'release'}>
              {pick('Environment → release task', 'Środowisko → task Release')}
            </button>
          </div>
          {mode === 'env' ? (
            <div className="flex items-center gap-2 text-[12.5px] text-gray-500">
              {envSelect(from, setFrom, pick('Source environment', 'Środowisko źródłowe'))}
              <span>→</span>
              {envSelect(to, setTo, pick('Target environment', 'Środowisko docelowe'))}
            </div>
          ) : (
            <div className="flex items-center gap-2 text-[12.5px] text-gray-500">
              {envSelect(releaseEnv, setReleaseEnv, pick('Environment', 'Środowisko'))}
              <span>→ {pick('Fix Versions of the task', 'Fix Versions tasku')}</span>
            </div>
          )}
        </div>

        {mode === 'release' && (
          <>
            <span className={lbl}>{pick('Task status', 'Status tasku')}</span>
            <div className="flex flex-wrap items-center gap-2">
              <div className="inline-flex gap-1 p-1 rounded-xl bg-gray-100 border border-gray-200">
                <button className={seg(taskState === 'OPEN')} onClick={() => setTaskState('OPEN')} aria-pressed={taskState === 'OPEN'}>Open</button>
                <button className={seg(taskState === 'DONE')} onClick={() => setTaskState('DONE')} aria-pressed={taskState === 'DONE'}>Done</button>
              </div>
              {releases === null ? (
                <span className="text-[12px] text-gray-400">{pick('Loading tasks…', 'Ładowanie tasków…')}</span>
              ) : releases.length ? (
                <select className={`${select} max-w-full`} value={releaseKey} onChange={(e) => setReleaseKey(e.target.value)} aria-label={pick('Release task', 'Task release')}>
                  {releases.map((r) => <option key={r.key} value={r.key}>{r.key} · {r.summary ?? ''}</option>)}
                </select>
              ) : (
                <span className="text-[12px] text-gray-500">
                  {pick(`No release task in status ${taskState === 'OPEN' ? 'Open' : 'Done'} in the projects of the unit.`,
                    `Brak tasków release w statusie ${taskState === 'OPEN' ? 'Open' : 'Done'} w projektach unitu.`)}
                </span>
              )}
              <span className="text-[11.5px] text-gray-400">
                {taskState === 'OPEN'
                  ? pick('The newest open release task is chosen', 'Domyślnie najnowszy otwarty task release')
                  : pick('The last 20 closed release tasks', 'Ostatnie 20 zamkniętych tasków release')}
              </span>
            </div>
          </>
        )}
      </section>

      {release && (
        <section className={`${card} p-4 flex flex-wrap items-center justify-between gap-3`}>
          <div className="min-w-0">
            <span className="font-mono text-[12px] text-emerald-700">{release.key}</span>
            <h2 className="text-[15px] text-gray-900" style={{ fontWeight: 600 }}>{release.summary}</h2>
            <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-[12px] text-gray-500">
              {release.status && <span className={`px-2 py-0.5 rounded-full ${taskState === 'OPEN' ? 'bg-blue-50 text-blue-700' : 'bg-emerald-50 text-emerald-700'}`} style={{ fontWeight: 600 }}>{release.status}</span>}
              <span>Fix Versions: <b className="text-gray-700">{release.fixVersions?.length ?? 0}</b></span>
              {release.assignee && <span>Assignee: {release.assignee}</span>}
              {release.dueDate && <span>{pick('Due', 'Termin')}: {new Date(release.dueDate).toLocaleDateString(pick('en-GB', 'pl-PL'))}</span>}
            </div>
          </div>
          {release.url && (
            <a href={release.url} target="_blank" rel="noreferrer" className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 text-gray-700 text-[12.5px]">
              {pick('Open in Jira', 'Otwórz w Jira')} <ExternalLink className="w-3.5 h-3.5" />
            </a>
          )}
        </section>
      )}

      {error ? (
        <div className={`${card} p-4 text-[13px] text-red-600`}>{pick('Failed to load:', 'Nie udało się załadować:')} {error}</div>
      ) : (
        <>
          <section className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {ORDER.map((r) => (
              <button key={r} onClick={() => setFilter((f) => (f === r ? null : r))} aria-pressed={filter === r}
                className={`${card} p-3.5 text-left ${filter === r ? 'ring-2 ring-emerald-500 border-emerald-500' : 'hover:bg-gray-50'}`}>
                <span className="flex items-center gap-1.5 text-[12px] text-gray-600"><i className={`w-2 h-2 rounded-full ${DOT[r]}`} />{label(r)}</span>
                <span className="block text-[24px] text-gray-900 tabular-nums" style={{ fontWeight: 700 }}>{data ? counts[r] : '—'}</span>
                <span className="block text-[11.5px] text-gray-400">{hint(r)}</span>
              </button>
            ))}
          </section>

          <section className={`${card} overflow-hidden`}>
            <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 border-b border-gray-100">
              <h3 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>
                {mode === 'release' ? `${pick('Microservices', 'Mikroserwisy')}: ${releaseEnv} vs ${releaseKey || '—'}` : `${pick('Microservices', 'Mikroserwisy')}: ${from} vs ${to}`}
              </h3>
              <div className="flex flex-wrap items-center gap-3">
                <input type="search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder={pick('Search microservice', 'Szukaj mikroserwisu')}
                  className="px-2.5 py-1.5 rounded-lg border border-gray-200 bg-white text-[12.5px] text-gray-800 w-56 max-w-full" />
                <label className="flex items-center gap-1.5 text-[12px] text-gray-600">
                  <input type="checkbox" checked={onlyDiff} onChange={(e) => setOnlyDiff(e.target.checked)} /> {pick('Differences only', 'Tylko różnice')}
                </label>
              </div>
            </div>
            {data?.note && <p className="px-4 py-2 text-[12px] text-amber-700 bg-amber-50 border-b border-amber-100">{data.note}</p>}
            <div className="overflow-x-auto">
              <table className="w-full min-w-[760px] text-[13px]">
                <thead>
                  <tr className="bg-gray-50 border-b border-gray-200 text-left text-[11px] uppercase tracking-wider text-gray-500">
                    <th className="px-4 py-2" style={{ fontWeight: 500 }}>{pick('Microservice', 'Mikroserwis')}</th>
                    <th className="px-4 py-2" style={{ fontWeight: 500 }}>{leftLabel}</th>
                    <th className="px-1 py-2" />
                    <th className="px-4 py-2" style={{ fontWeight: 500 }}>{rightLabel}</th>
                    <th className="px-4 py-2" style={{ fontWeight: 500 }}>{pick('Result', 'Wynik')}</th>
                  </tr>
                </thead>
                <tbody>
                  {loading && !data ? (
                    <tr><td colSpan={5} className="px-4 py-6 text-center text-gray-400">{pick('Loading…', 'Ładowanie…')}</td></tr>
                  ) : mode === 'release' && !releaseKey ? (
                    <tr><td colSpan={5} className="px-4 py-6 text-center text-gray-500">{pick('Choose a release task.', 'Wybierz task release.')}</td></tr>
                  ) : !shown.length ? (
                    <tr><td colSpan={5} className="px-4 py-6 text-center text-gray-500">
                      {rows.length ? (onlyDiff && !filter ? pick('No differences: every microservice matches.', 'Brak różnic: wszystkie mikroserwisy są zgodne.') : pick('Nothing matches the filter.', 'Nic nie pasuje do filtra.'))
                        : pick('No microservices to compare.', 'Brak mikroserwisów do porównania.')}
                    </td></tr>
                  ) : shown.map((r, i) => (
                    <tr key={`${r.serviceMapProject}-${r.microservice}-${r.right?.fixVersion ?? ''}-${i}`} className={`border-b border-gray-100 last:border-0 align-top ${r.result === 'DIFFERENT' ? 'bg-amber-50/40' : ''}`}>
                      <td className="px-4 py-2.5">
                        <div className="text-gray-900" style={{ fontWeight: 600 }}>{r.microservice}</div>
                        {r.serviceMapProject && <div className="text-[11.5px] text-gray-400">{r.serviceMapProject}</div>}
                      </td>
                      <td className="px-4 py-2.5">{version(r.left, r.right, r.result)}{detail(r.left)}</td>
                      <td className="px-1 py-2.5 text-center text-gray-400" aria-hidden>{r.result === 'SAME' ? '=' : '≠'}</td>
                      <td className="px-4 py-2.5">{version(r.right, r.left, r.result)}{detail(r.right)}</td>
                      <td className="px-4 py-2.5">
                        <span className={`inline-block px-2 py-0.5 rounded-full text-[11.5px] whitespace-nowrap ${PILL[r.result]}`} style={{ fontWeight: 600 }}>{label(r.result)}</span>
                        {why(r.result) && <div className="mt-1 text-[11.5px] text-gray-500 max-w-[34ch]">{why(r.result)}</div>}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="flex flex-wrap justify-between gap-2 px-4 py-2.5 border-t border-gray-100 text-[11.5px] text-gray-400">
              <span>{pick(`Showing ${shown.length} of ${rows.length}`, `Pokazano ${shown.length} z ${rows.length}`)}</span>
              <span>{pick('Fix Version "payment-service 2.4.1" → microservice payment-service, version 2.4.1; v2.4.1 = 2.4.1.',
                'Fix Version „payment-service 2.4.1” → mikroserwis payment-service, wersja 2.4.1; v2.4.1 = 2.4.1.')}</span>
            </div>
          </section>
        </>
      )}
    </div>
  );
}

export default ReleaseCheck;
