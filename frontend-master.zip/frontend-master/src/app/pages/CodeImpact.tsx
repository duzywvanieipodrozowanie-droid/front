import { useEffect, useMemo, useState, type ReactNode } from 'react';
import { AlertTriangle, FileCode2, Folder, Info, UserX, Users } from 'lucide-react';
import { useTeam } from '../context/TeamContext';
import { usePick, useTr } from '../i18n';
import LoadingSpinner from '../components/LoadingSpinner';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '../components/ui/dialog';

// Code ownership of the services (GitLab repositories) the selected unit works on, from /api/metrics/code-impact:
// who wrote how much of each service / directory / file (added lines from commit diffs), bus factor, knowledge held
// by people no longer in the unit, and developer criticality ("what if this person leaves").

type Risk = 'HIGH' | 'MEDIUM' | 'LOW';
type Criticality = 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'DEPARTED';
type AuthorShare = { key: string; name: string; personId?: string | null; lines: number; pct: number; current: boolean; known: boolean };
type AreaImpact = { path: string; lines: number; busFactor: number; authors: number; topAuthor?: AuthorShare | null };
type ServiceImpact = {
  project: string; service: string; totalLines: number; busFactor: number; risk: Risk; departedPct: number;
  authors: AuthorShare[]; directories: AreaImpact[]; knowledgeSilos: AreaImpact[];
};
type DeveloperImpact = {
  key: string; name: string; personId?: string | null; current: boolean; known: boolean; lines: number; pct: number;
  servicesOwned: number; soleOwnerServices: number; siloFiles: number; mainServices: string[]; criticality: Criticality;
};
type CodeImpactData = {
  totalLines: number; commitsAnalyzed: number; commitsWithoutFileData: number; departedKnowledgePct: number;
  services: ServiceImpact[]; developers: DeveloperImpact[];
};

const PERIODS: Array<[string, string, string]> = [
  ['MONTHS_3', '3 months', '3 miesiące'],
  ['MONTHS_6', '6 months', '6 miesięcy'],
  ['MONTHS_12', '12 months', '12 miesięcy'],
];

// Explicit hex colors: theme.css remaps Tailwind indigo classes to brand green.
const AUTHOR_COLORS = ['#3b82f6', '#a855f7', '#10b981', '#f59e0b', '#ef4444', '#06b6d4', '#ec4899', '#84cc16'];
const DEPARTED_COLOR = '#9ca3af';

const card = 'bg-white dark:bg-[#121317] rounded-xl border border-gray-200 dark:border-white/10';
const muted = 'text-gray-500 dark:text-gray-400';

function riskClass(risk: Risk | Criticality): string {
  switch (risk) {
    case 'CRITICAL':
    case 'HIGH': return 'bg-red-100 text-red-700 dark:bg-red-500/15 dark:text-red-400';
    case 'MEDIUM': return 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400';
    case 'LOW': return 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-400';
    default: return 'bg-gray-100 text-gray-600 dark:bg-[#2a2c33] dark:text-gray-300';
  }
}

function fmtLines(n: number): string {
  return n >= 10000 ? `${Math.round(n / 1000)}k` : n.toLocaleString();
}

function Badge({ children, className }: { children: ReactNode; className: string }) {
  return <span className={`inline-block px-1.5 py-0.5 rounded text-[10.5px] whitespace-nowrap ${className}`} style={{ fontWeight: 700 }}>{children}</span>;
}

function AuthorFlags({ author }: { author: { current: boolean; known: boolean } }) {
  const pick = usePick();
  if (author.current) return null;
  return (
    <Badge className="bg-gray-100 text-gray-600 dark:bg-[#2a2c33] dark:text-gray-300">
      {author.known ? pick('not in unit · left?', 'poza unitem · odszedł?') : pick('unknown account · left?', 'nieznane konto · odszedł?')}
    </Badge>
  );
}

function OwnershipBar({ authors }: { authors: AuthorShare[] }) {
  const rest = Math.max(0, 100 - authors.reduce((a, s) => a + s.pct, 0));
  return (
    <div className="flex h-2.5 w-full rounded-full overflow-hidden bg-gray-100 dark:bg-[#2a2c33]">
      {authors.map((a, i) => (
        <div
          key={a.key}
          title={`${a.name}: ${a.pct}%`}
          style={{
            width: `${a.pct}%`,
            backgroundColor: a.current ? AUTHOR_COLORS[i % AUTHOR_COLORS.length] : DEPARTED_COLOR,
            backgroundImage: a.current ? undefined : 'repeating-linear-gradient(45deg, rgba(255,255,255,.35) 0 3px, transparent 3px 6px)',
          }}
        />
      ))}
      {rest > 0.5 && <div style={{ width: `${rest}%` }} title={`Other: ${Math.round(rest * 10) / 10}%`} />}
    </div>
  );
}

/** Red: one person knows it (bus factor ≤ 1 / high risk) or most of it was written by people who left. */
function serviceTone(s: ServiceImpact): 'bad' | 'warn' | 'ok' {
  if (s.risk === 'HIGH' || s.busFactor <= 1 || s.departedPct >= 50) return 'bad';
  if (s.risk === 'MEDIUM' || s.busFactor === 2 || s.departedPct >= 25) return 'warn';
  return 'ok';
}

const TONE_COLORS: Record<'bad' | 'warn' | 'ok', { fill: string; stroke: string; text: string }> = {
  bad: { fill: '#fecaca', stroke: '#ef4444', text: '#991b1b' },
  warn: { fill: '#fde68a', stroke: '#f59e0b', text: '#92400e' },
  ok: { fill: '#bbf7d0', stroke: '#10b981', text: '#065f46' },
};

type Bubble = { s: ServiceImpact; x: number; y: number; r: number };

/**
 * Circles with area proportional to the service's lines, packed around the centre: biggest first, each placed at
 * the first point of an outward spiral where it does not overlap the ones already placed.
 */
function packBubbles(services: ServiceImpact[]): { bubbles: Bubble[]; minX: number; minY: number; width: number; height: number } {
  const max = Math.max(1, ...services.map((s) => s.totalLines));
  const sorted = [...services].sort((a, b) => b.totalLines - a.totalLines);
  const placed: Bubble[] = [];
  const gap = 3;
  for (const s of sorted) {
    const r = 18 + 82 * Math.sqrt(s.totalLines / max);
    let x = 0;
    let y = 0;
    for (let step = 0; placed.length > 0; step++) {
      const angle = step * 0.15;
      const dist = 1.1 * angle;
      x = Math.cos(angle) * dist;
      y = Math.sin(angle) * dist * 0.75;
      if (placed.every((p) => Math.hypot(p.x - x, p.y - y) >= p.r + r + gap)) break;
    }
    placed.push({ s, x, y, r });
  }
  const pad = 6;
  const minX = Math.min(0, ...placed.map((b) => b.x - b.r)) - pad;
  const minY = Math.min(0, ...placed.map((b) => b.y - b.r)) - pad;
  const maxX = Math.max(0, ...placed.map((b) => b.x + b.r)) + pad;
  const maxY = Math.max(0, ...placed.map((b) => b.y + b.r)) + pad;
  return { bubbles: placed, minX, minY, width: maxX - minX, height: maxY - minY };
}

function ServiceBubbles({ services, onSelect }: { services: ServiceImpact[]; onSelect: (s: ServiceImpact) => void }) {
  const pick = usePick();
  const [hover, setHover] = useState<string | null>(null);
  const { bubbles, minX, minY, width, height } = useMemo(() => packBubbles(services), [services]);
  return (
    <svg viewBox={`${minX} ${minY} ${width} ${height}`} className="w-full" style={{ maxHeight: 640 }} role="img">
      {bubbles.map((b) => {
        const id = `${b.s.project}/${b.s.service}`;
        const tone = TONE_COLORS[serviceTone(b.s)];
        const nameSize = Math.max(7, Math.min(15, b.r / 4.2));
        const maxChars = Math.max(3, Math.floor((b.r * 1.8) / (nameSize * 0.58)));
        const name = b.s.service.length > maxChars ? `${b.s.service.slice(0, maxChars - 1)}…` : b.s.service;
        const showDetails = b.r >= 34;
        return (
          <g
            key={id}
            transform={`translate(${b.x},${b.y})`}
            onClick={() => onSelect(b.s)}
            onMouseEnter={() => setHover(id)}
            onMouseLeave={() => setHover(null)}
            style={{ cursor: 'pointer' }}
          >
            <title>
              {`${id}\n${fmtLines(b.s.totalLines)} ${pick('lines', 'linii')} · Bus factor ${b.s.busFactor} · ${pick('risk', 'ryzyko')} ${b.s.risk}`
                + (b.s.departedPct > 0 ? `\n${b.s.departedPct}% ${pick('by people who left', 'kodu osób, które odeszły')}` : '')
                + (b.s.authors[0] ? `\n${pick('Main author', 'Główny autor')}: ${b.s.authors[0].name} ${b.s.authors[0].pct}%` : '')}
            </title>
            <circle r={b.r} fill={tone.fill} stroke={tone.stroke} strokeWidth={hover === id ? 3 : 1.5} opacity={hover && hover !== id ? 0.75 : 1} />
            <text textAnchor="middle" y={showDetails ? -nameSize * 0.35 : nameSize * 0.35} fontSize={nameSize} fontWeight={700} fill={tone.text}>{name}</text>
            {showDetails && (
              <>
                <text textAnchor="middle" y={nameSize * 0.95} fontSize={nameSize * 0.72} fill={tone.text}>{fmtLines(b.s.totalLines)} {pick('lines', 'linii')}</text>
                <text textAnchor="middle" y={nameSize * 2.05} fontSize={nameSize * 0.68} fontWeight={700} fill={tone.text}>
                  BF {b.s.busFactor}{b.s.departedPct >= 25 ? ` · ${pick('left', 'odeszli')} ${Math.round(b.s.departedPct)}%` : ''}
                </text>
              </>
            )}
          </g>
        );
      })}
    </svg>
  );
}

function ServiceDetails({ s }: { s: ServiceImpact }) {
  const pick = usePick();
  return (
    <div className="space-y-4 min-w-0">
      <div className="flex flex-wrap items-center gap-1.5">
        <span className={`text-[12px] ${muted} mr-1`}>{s.project} · {fmtLines(s.totalLines)} {pick('lines', 'linii')}</span>
        <Badge className={riskClass(s.risk)}>{pick('Risk', 'Ryzyko')}: {s.risk}</Badge>
        <Badge className={s.busFactor <= 1 ? riskClass('HIGH') : s.busFactor === 2 ? riskClass('MEDIUM') : riskClass('LOW')}>Bus factor: {s.busFactor}</Badge>
      </div>

      <div className={`${card} p-4`}>
        <div className="text-[12px] text-gray-800 dark:text-gray-200 mb-2 flex items-center gap-1.5" style={{ fontWeight: 600 }}>
          <Users className="w-3.5 h-3.5" />{pick('Authors', 'Autorzy')}
        </div>
        <OwnershipBar authors={s.authors} />
        <div className="mt-2 space-y-1">
          {s.authors.map((a, i) => (
            <div key={a.key} className="flex items-center gap-2 text-[12px] min-w-0">
              <span className="w-2.5 h-2.5 rounded-sm shrink-0" style={{ backgroundColor: a.current ? AUTHOR_COLORS[i % AUTHOR_COLORS.length] : DEPARTED_COLOR }} />
              <span className={`truncate ${a.current ? 'text-gray-800 dark:text-gray-200' : 'text-gray-500 dark:text-gray-400 line-through decoration-gray-400/60'}`}>{a.name}</span>
              <AuthorFlags author={a} />
              <span className={`ml-auto shrink-0 text-[11px] ${muted}`}>{fmtLines(a.lines)}</span>
              <span className="w-12 text-right shrink-0 text-gray-900 dark:text-gray-100" style={{ fontWeight: 600 }}>{a.pct}%</span>
            </div>
          ))}
        </div>
        {s.departedPct > 0 && (
          <div className="mt-2 flex items-center gap-1.5 text-[11.5px] text-amber-700 dark:text-amber-400">
            <UserX className="w-3.5 h-3.5" />
            {pick(`${s.departedPct}% of the code was written by people no longer in the unit`, `${s.departedPct}% kodu napisały osoby, których nie ma już w unicie`)}
          </div>
        )}
      </div>

      <div className={`${card} p-4`}>
        <AreaTable title={pick('Directories', 'Katalogi')} icon={<Folder className="w-3.5 h-3.5" />} rows={s.directories} showBusFactor />
      </div>
      <div className={`${card} p-4`}>
        <AreaTable
          title={pick('Knowledge silos (files ≥ 80% by one person)', 'Silosy wiedzy (pliki w ≥ 80% jednej osoby)')}
          icon={<FileCode2 className="w-3.5 h-3.5" />}
          rows={s.knowledgeSilos}
          empty={pick('No knowledge silos.', 'Brak silosów wiedzy.')}
        />
      </div>
    </div>
  );
}

function AreaTable({ title, icon, rows, showBusFactor = false, empty }: { title: string; icon: ReactNode; rows: AreaImpact[]; showBusFactor?: boolean; empty?: string }) {
  const pick = usePick();
  return (
    <div>
      <div className="flex items-center gap-1.5 text-[12px] text-gray-800 dark:text-gray-200 mb-1" style={{ fontWeight: 600 }}>{icon}{title}</div>
      {rows.length === 0 ? (
        <div className={`text-[11.5px] ${muted}`}>{empty ?? '—'}</div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-[11.5px] min-w-[420px]">
            <thead className={muted}>
              <tr className="text-left">
                <th className="py-1 pr-2" style={{ fontWeight: 600 }}>{pick('Path', 'Ścieżka')}</th>
                <th className="py-1 pr-2 text-right" style={{ fontWeight: 600 }}>{pick('Lines', 'Linie')}</th>
                {showBusFactor && <th className="py-1 pr-2 text-right" style={{ fontWeight: 600 }}>Bus factor</th>}
                <th className="py-1" style={{ fontWeight: 600 }}>{pick('Main author', 'Główny autor')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-white/5 text-gray-700 dark:text-gray-300">
              {rows.map((r) => (
                <tr key={r.path}>
                  <td className="py-1 pr-2 font-mono text-[11px] truncate max-w-[260px]" title={r.path}>{r.path}</td>
                  <td className="py-1 pr-2 text-right">{fmtLines(r.lines)}</td>
                  {showBusFactor && <td className={`py-1 pr-2 text-right ${r.busFactor <= 1 ? 'text-red-600 dark:text-red-400' : ''}`} style={{ fontWeight: 600 }}>{r.busFactor}</td>}
                  <td className="py-1">
                    {r.topAuthor ? (
                      <span className="inline-flex items-center gap-1.5 flex-wrap">
                        <span className={r.topAuthor.current ? '' : 'line-through decoration-gray-400/60'}>{r.topAuthor.name}</span>
                        <span className="text-gray-900 dark:text-gray-100" style={{ fontWeight: 600 }}>{r.topAuthor.pct}%</span>
                        <AuthorFlags author={r.topAuthor} />
                      </span>
                    ) : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function Tile({ label, value, hint, tone }: { label: string; value: ReactNode; hint?: string; tone?: 'bad' | 'warn' }) {
  const color = tone === 'bad' ? 'text-red-600 dark:text-red-400' : tone === 'warn' ? 'text-amber-600 dark:text-amber-400' : 'text-gray-900 dark:text-gray-100';
  return (
    <div className={`${card} p-4`}>
      <div className={`text-[12px] ${muted}`}>{label}</div>
      <div className={`text-[24px] ${color}`} style={{ fontWeight: 700 }}>{value}</div>
      {hint && <div className={`text-[11px] ${muted}`}>{hint}</div>}
    </div>
  );
}

export function CodeImpact() {
  const t = useTr();
  const pick = usePick();
  const { selectedUnitId, selectedTeamName } = useTeam();
  const [period, setPeriod] = useState('MONTHS_12');
  const [data, setData] = useState<CodeImpactData | null>(null);
  const [loading, setLoading] = useState(true);
  const [failed, setFailed] = useState(false);
  const [forbidden, setForbidden] = useState(false);
  const [showDeparted, setShowDeparted] = useState(true);
  const [selected, setSelected] = useState<ServiceImpact | null>(null);

  useEffect(() => {
    let cancelled = false;
    const controller = new AbortController();
    async function load() {
      setLoading(true);
      setFailed(false);
      setForbidden(false);
      try {
        const params = new URLSearchParams({ interval: period });
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        const res = await fetch(`/api/metrics/code-impact?${params.toString()}`, { credentials: 'include', signal: controller.signal });
        if (res.status === 403) { if (!cancelled) { setData(null); setForbidden(true); } return; }
        if (!res.ok) throw new Error(String(res.status));
        const js = await res.json();
        if (cancelled) return;
        setData(js as CodeImpactData);
      } catch {
        if (cancelled) return;
        setData(null);
        setFailed(true);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; controller.abort(); };
  }, [period, selectedUnitId]);

  const developers = useMemo(() => (data?.developers ?? []).filter((d) => showDeparted || d.current), [data, showDeparted]);
  const highRisk = (data?.services ?? []).filter((s) => s.risk === 'HIGH').length;
  const busFactorOne = (data?.services ?? []).filter((s) => s.busFactor <= 1).length;
  const critical = (data?.developers ?? []).filter((d) => d.criticality === 'CRITICAL').length;

  return (
    <div className="p-4 sm:p-6 space-y-5 text-gray-900 dark:text-gray-100">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-[20px]" style={{ fontWeight: 700 }}>Code Impact</h1>
          <p className={`text-[12px] ${muted} mt-0.5`}>
            {pick('Who knows which part of the code: ownership of services, directories and files, bus factor and developer criticality',
              'Kto zna którą część kodu: udziały w serwisach, katalogach i plikach, bus factor i krytyczność developerów')}
            {' · '}{selectedTeamName && selectedTeamName !== 'All Teams' ? selectedTeamName : pick('all your units', 'wszystkie Twoje unity')}
          </p>
        </div>
        <div className="flex items-center gap-1">
          {PERIODS.map(([value, en, pl]) => (
            <button
              key={value}
              onClick={() => setPeriod(value)}
              className={`px-2.5 py-1 rounded-md text-[12px] border ${period === value
                ? 'bg-gray-900 text-white border-gray-900 dark:bg-gray-100 dark:text-gray-900 dark:border-gray-100'
                : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50 dark:bg-white/5 dark:text-gray-300 dark:border-white/10'}`}
            >{pick(en, pl)}</button>
          ))}
        </div>
      </div>

      {loading && !data ? (
        <div className={`${card} p-5 min-h-[160px] flex items-center justify-center`}><LoadingSpinner size={20} /></div>
      ) : forbidden ? (
        <div className={`${card} p-5 text-[12px] ${muted}`}>{pick('Your role has no access to this screen. An admin can change it in Settings → Users and access.', 'Twoja rola nie ma dostępu do tego ekranu. Admin może to zmienić w Ustawienia → Użytkownicy i dostęp.')}</div>
      ) : failed || !data ? (
        <div className={`${card} p-5 text-[12px] ${muted}`}>{t('noData')}</div>
      ) : (
        <>
          {data.commitsWithoutFileData > 0 && (
            <div className="flex items-start gap-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-[12px] text-amber-800 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-300">
              <Info className="w-4 h-4 shrink-0 mt-0.5" />
              <span>
                {pick(
                  `${data.commitsWithoutFileData} of ${data.commitsAnalyzed} commits have no per-file data yet (imported before this feature). To include them, run the GitLab importer once with ZS_COMMITS_SINCE=<start date>.`,
                  `${data.commitsWithoutFileData} z ${data.commitsAnalyzed} commitów nie ma jeszcze danych per plik (zaimportowane przed tą funkcją). Aby je uwzględnić, uruchom raz importer GitLaba z ZS_COMMITS_SINCE=<data początkowa>.`,
                )}
              </span>
            </div>
          )}

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <Tile label={pick('Services analysed', 'Przeanalizowane serwisy')} value={data.services.length} hint={`${fmtLines(data.totalLines)} ${pick('lines written', 'napisanych linii')}`} />
            <Tile label={pick('Services at high risk', 'Serwisy wysokiego ryzyka')} value={highRisk} hint={pick(`${busFactorOne} with bus factor ≤ 1`, `${busFactorOne} z bus factor ≤ 1`)} tone={highRisk > 0 ? 'bad' : undefined} />
            <Tile label={pick('Knowledge of people who left', 'Wiedza osób, które odeszły')} value={`${data.departedKnowledgePct}%`} hint={pick('of the code, by authors not in the unit', 'kodu, autorzy spoza unitu')} tone={data.departedKnowledgePct >= 25 ? 'warn' : undefined} />
            <Tile label={pick('Critical developers', 'Krytyczni developerzy')} value={critical} hint={pick('only current owner of a service', 'jedyny aktualny właściciel serwisu')} tone={critical > 0 ? 'bad' : undefined} />
          </div>

          {/* Services */}
          <div className={`${card} p-5`}>
            <div className="flex flex-wrap items-center justify-between gap-2 mb-1">
              <h2 className="text-[14px]" style={{ fontWeight: 600 }}>{pick('Services', 'Serwisy')}</h2>
              <div className="flex items-center gap-3 text-[11px]">
                {(['bad', 'warn', 'ok'] as const).map((k) => (
                  <span key={k} className="flex items-center gap-1">
                    <span className="w-3 h-3 rounded-full border" style={{ backgroundColor: TONE_COLORS[k].fill, borderColor: TONE_COLORS[k].stroke }} />
                    {k === 'bad' ? pick('at risk: one person knows it or the authors left', 'ryzyko: zna go jedna osoba lub autorzy odeszli')
                      : k === 'warn' ? pick('watch', 'do obserwacji') : pick('OK', 'OK')}
                  </span>
                ))}
              </div>
            </div>
            <p className={`text-[12px] ${muted} mb-2`}>
              {pick('Bubble size = lines of code written in the period. Click a bubble for authors, directories and knowledge silos.',
                'Wielkość bąbla = liczba linii kodu napisanych w okresie. Kliknij bąbel, aby zobaczyć autorów, katalogi i silosy wiedzy.')}
            </p>
            {data.services.length === 0 ? (
              <div className={`text-[12px] ${muted}`}>{pick('No services with per-file data for this unit and period.', 'Brak serwisów z danymi per plik dla tego unitu i okresu.')}</div>
            ) : (
              <ServiceBubbles services={data.services} onSelect={setSelected} />
            )}
          </div>


          {/* Impact analysis */}
          <div className={`${card} p-5`}>
            <div className="flex flex-wrap items-center justify-between gap-2 mb-1">
              <h2 className="text-[14px] flex items-center gap-1.5" style={{ fontWeight: 600 }}><AlertTriangle className="w-4 h-4 text-amber-500" />{pick('Impact analysis — developer criticality', 'Analiza wpływu — krytyczność developerów')}</h2>
              <label className={`flex items-center gap-1.5 text-[12px] ${muted} cursor-pointer`}>
                <input type="checkbox" className="accent-blue-600" checked={showDeparted} onChange={(e) => setShowDeparted(e.target.checked)} />
                {pick('Show people who left', 'Pokaż osoby, które odeszły')}
              </label>
            </div>
            <p className={`text-[12px] ${muted} mb-3`}>
              {pick('How much of the unit’s code each person wrote and what is at risk if they leave. Critical = the only current member covering half of a service.',
                'Ile kodu unitu napisała każda osoba i co jest zagrożone, jeśli odejdzie. Krytyczny = jedyny aktualny członek pokrywający połowę serwisu.')}
            </p>
            {developers.length === 0 ? (
              <div className={`text-[12px] ${muted}`}>{t('noData')}</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-[12.5px] min-w-[860px]">
                  <thead className={`${muted} text-[11px] uppercase tracking-wide`}>
                    <tr className="text-left border-b border-gray-100 dark:border-white/10">
                      <th className="py-2 pr-3" style={{ fontWeight: 600 }}>{pick('Developer', 'Developer')}</th>
                      <th className="py-2 pr-3" style={{ fontWeight: 600 }}>{pick('Criticality', 'Krytyczność')}</th>
                      <th className="py-2 pr-3" style={{ fontWeight: 600 }}>{pick('Share of unit code', 'Udział w kodzie unitu')}</th>
                      <th className="py-2 pr-3 text-right" style={{ fontWeight: 600 }}>{pick('Services led', 'Prowadzone serwisy')}</th>
                      <th className="py-2 pr-3 text-right" style={{ fontWeight: 600 }}>{pick('Sole owner', 'Jedyny właściciel')}</th>
                      <th className="py-2 pr-3 text-right" style={{ fontWeight: 600 }}>{pick('Silo files', 'Pliki-silosy')}</th>
                      <th className="py-2" style={{ fontWeight: 600 }}>{pick('Main services', 'Główne serwisy')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-white/5">
                    {developers.map((d) => (
                      <tr key={d.key}>
                        <td className="py-2 pr-3">
                          <div className="flex items-center gap-2 flex-wrap">
                            {d.current ? <Users className="w-3.5 h-3.5 text-gray-400" /> : <UserX className="w-3.5 h-3.5 text-gray-400" />}
                            <span className={d.current ? '' : 'text-gray-500 dark:text-gray-400'} style={{ fontWeight: 600 }}>{d.name}</span>
                            <AuthorFlags author={d} />
                          </div>
                        </td>
                        <td className="py-2 pr-3"><Badge className={riskClass(d.criticality)}>{d.criticality === 'DEPARTED' ? pick('LEFT', 'ODSZEDŁ') : d.criticality}</Badge></td>
                        <td className="py-2 pr-3">
                          <div className="flex items-center gap-2">
                            <div className="w-28 h-1.5 rounded-full bg-gray-100 dark:bg-[#2a2c33] overflow-hidden">
                              <div className="h-full rounded-full" style={{ width: `${Math.min(100, d.pct)}%`, backgroundColor: d.current ? '#3b82f6' : DEPARTED_COLOR }} />
                            </div>
                            <span style={{ fontWeight: 600 }}>{d.pct}%</span>
                            <span className={`text-[11px] ${muted}`}>({fmtLines(d.lines)})</span>
                          </div>
                        </td>
                        <td className="py-2 pr-3 text-right">{d.servicesOwned}</td>
                        <td className={`py-2 pr-3 text-right ${d.soleOwnerServices > 0 ? 'text-red-600 dark:text-red-400' : ''}`} style={{ fontWeight: d.soleOwnerServices > 0 ? 700 : 400 }}>{d.soleOwnerServices}</td>
                        <td className="py-2 pr-3 text-right">{d.siloFiles}</td>
                        <td className={`py-2 text-[11.5px] ${muted}`}>{d.mainServices.join(', ') || '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          <Dialog open={!!selected} onOpenChange={(o) => { if (!o) setSelected(null); }}>
            <DialogContent className="sm:max-w-[860px] max-h-[90vh] overflow-y-auto bg-gray-50 dark:bg-[#0b0c0f]">
              <DialogHeader>
                <DialogTitle className="text-[18px] flex items-center gap-2">
                  {selected && <span className="w-3 h-3 rounded-full" style={{ backgroundColor: TONE_COLORS[serviceTone(selected)].stroke }} />}
                  {selected?.service}
                </DialogTitle>
                <DialogDescription className="text-[12px]">
                  {pick('Who wrote the code of this service', 'Kto napisał kod tego serwisu')}
                </DialogDescription>
              </DialogHeader>
              {selected && <ServiceDetails s={selected} />}
            </DialogContent>
          </Dialog>
        </>
      )}
    </div>
  );
}

export default CodeImpact;
