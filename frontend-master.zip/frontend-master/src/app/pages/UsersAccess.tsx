import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Search, ShieldCheck } from 'lucide-react';

// Settings → Users and access (core /api/admin/access/*, ADMIN only): the roles of every user (each its own flag;
// MANAGER also for the unit managers of the organization setup) and the roles allowed on every menu page.

type Role = 'ADMIN' | 'DOMAIN_LEADER' | 'MANAGER' | 'PO' | 'TECH_LEAD' | 'DEVELOPER';
type Flag = 'admin' | 'domainLeader' | 'manager' | 'po' | 'techLead' | 'developer';

type UserView = {
  id: string;
  name: string | null;
  email: string | null;
  admin: boolean;
  developer: boolean;
  techLead?: boolean;
  manager: boolean;
  po?: boolean;
  domainLeader?: boolean;
  managedUnits: string[];
  roles: Role[];
  created: string | null;
  lastLogin: string | null;
};

type PageView = { key: string; name: string; roles: Role[]; defaultRoles: Role[] };

// the roles in their order on the screen, with the flag of a user
const ROLES: Array<{ role: Role; flag: Flag; label: string }> = [
  { role: 'ADMIN', flag: 'admin', label: 'Admin' },
  { role: 'DOMAIN_LEADER', flag: 'domainLeader', label: 'IT Domain Leader' },
  { role: 'MANAGER', flag: 'manager', label: 'Manager' },
  { role: 'PO', flag: 'po', label: 'PO' },
  { role: 'TECH_LEAD', flag: 'techLead', label: 'Tech Lead' },
  { role: 'DEVELOPER', flag: 'developer', label: 'Developer' },
];
const sameRoles = (a: Role[], b: Role[]) => a.length === b.length && a.every((r) => b.includes(r));

const section = 'bg-white rounded-2xl border border-gray-200 p-5 space-y-4 dark:bg-[#2b2d31] dark:border-white/10';
const inputCls =
  'w-full rounded-lg border border-gray-200 bg-white px-3 py-2 text-[13px] text-gray-800 outline-none focus:border-indigo-400 dark:border-white/10 dark:bg-black/20 dark:text-gray-100';

async function errorText(res: Response) {
  try {
    const js = await res.json();
    return js?.message || js?.errorCode || `HTTP ${res.status}`;
  } catch {
    return `HTTP ${res.status}`;
  }
}

const formatDate = (iso: string | null) => (iso ? new Date(iso).toLocaleString('pl-PL', { dateStyle: 'short', timeStyle: 'short' }) : '—');

export function UsersAccess() {
  const navigate = useNavigate();
  const [tab, setTab] = useState<'users' | 'pages'>('users');
  const [users, setUsers] = useState<UserView[] | null>(null);
  const [pages, setPages] = useState<PageView[] | null>(null);
  const [pageDraft, setPageDraft] = useState<Record<string, Role[]>>({});
  const [query, setQuery] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState<string | null>(null);
  const [savedPages, setSavedPages] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [u, p] = await Promise.all([
          fetch('/api/admin/access/users', { credentials: 'include' }),
          fetch('/api/admin/access/pages', { credentials: 'include' }),
        ]);
        if (!u.ok) throw new Error(await errorText(u));
        if (!p.ok) throw new Error(await errorText(p));
        const pageList: PageView[] = await p.json();
        if (cancelled) return;
        setUsers(await u.json());
        setPages(pageList);
        setPageDraft(Object.fromEntries(pageList.map((it) => [it.key, it.roles])));
      } catch (e: any) {
        if (!cancelled) setError(e?.message || 'Nie udało się wczytać danych');
      }
    })();
    return () => { cancelled = true; };
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!users) return [];
    if (!q) return users;
    return users.filter((u) => [u.name, u.email, u.id, ...u.managedUnits].some((v) => (v || '').toLowerCase().includes(q)));
  }, [users, query]);

  async function updateUser(user: UserView, change: Partial<Record<Flag, boolean>>) {
    setSaving(user.id);
    setError(null);
    try {
      const res = await fetch(`/api/admin/access/users/${encodeURIComponent(user.id)}`, {
        method: 'PUT',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(change),
      });
      if (res.status === 409) throw new Error('Co najmniej jeden użytkownik musi zostać Adminem.');
      if (!res.ok) throw new Error(await errorText(res));
      const saved: UserView = await res.json();
      setUsers((list) => (list || []).map((it) => (it.id === saved.id ? saved : it)));
    } catch (e: any) {
      setError(e?.message || 'Nie udało się zapisać');
    } finally {
      setSaving(null);
    }
  }

  async function savePages() {
    setSaving('pages');
    setError(null);
    setSavedPages(false);
    try {
      const res = await fetch('/api/admin/access/pages', {
        method: 'PUT',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(pageDraft),
      });
      if (!res.ok) throw new Error(await errorText(res));
      const saved: PageView[] = await res.json();
      setPages(saved);
      setPageDraft(Object.fromEntries(saved.map((it) => [it.key, it.roles])));
      setSavedPages(true);
    } catch (e: any) {
      setError(e?.message || 'Nie udało się zapisać');
    } finally {
      setSaving(null);
    }
  }

  const pagesChanged = !!pages && pages.some((p) => !sameRoles(pageDraft[p.key] ?? [], p.roles));
  const toggleRole = (key: string, role: Role, on: boolean) => {
    setSavedPages(false);
    setPageDraft((d) => ({ ...d, [key]: on ? [...(d[key] ?? []), role] : (d[key] ?? []).filter((r) => r !== role) }));
  };
  const tabCls = (active: boolean) =>
    `px-4 py-2 rounded-lg text-[13px] border ${active
      ? 'bg-indigo-50 border-indigo-200 text-indigo-700 dark:bg-white/10 dark:border-white/20 dark:text-white'
      : 'bg-white border-gray-200 text-gray-600 hover:bg-gray-50 dark:bg-transparent dark:border-white/10 dark:text-gray-300'}`;

  return (
    <div className="p-4 sm:p-6 mx-auto max-w-6xl space-y-4">
      <button onClick={() => navigate('/settings')} className="flex items-center gap-1.5 text-[12px] text-gray-500 hover:text-gray-800 dark:hover:text-gray-200">
        <ArrowLeft className="w-4 h-4" /> Ustawienia
      </button>
      <div className="flex items-start gap-3">
        <ShieldCheck className="w-7 h-7 text-indigo-600 mt-0.5" />
        <div>
          <h1 className="text-[22px] text-gray-900 dark:text-gray-100" style={{ fontWeight: 800 }}>Użytkownicy i dostęp</h1>
          <p className="text-[13px] text-gray-500 mt-1">
            Role każdego użytkownika (można mieć kilka) i które strony menu widzi każda rola. Managerem jest też automatycznie
            manager unitu w konfiguracji organizacji. Zmiany działają od razu, bez ponownego logowania.
          </p>
        </div>
      </div>

      <div className="flex gap-2">
        <button className={tabCls(tab === 'users')} onClick={() => setTab('users')}>Użytkownicy{users ? ` (${users.length})` : ''}</button>
        <button className={tabCls(tab === 'pages')} onClick={() => setTab('pages')}>Strony menu</button>
      </div>

      {error && (
        <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-[13px] text-red-700 dark:border-red-500/30 dark:bg-red-500/10 dark:text-red-300">{error}</div>
      )}

      {tab === 'users' && (
        <section className={section}>
          <div className="relative">
            <Search className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input className={`${inputCls} pl-9`} value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Szukaj po nazwisku, e-mailu, loginie lub unicie" />
          </div>
          {!users ? (
            <p className="text-[13px] text-gray-500">{error ? '' : 'Ładowanie…'}</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-[13px]">
                <thead>
                  <tr className="text-left text-[11px] uppercase tracking-wide text-gray-500 border-b border-gray-100 dark:border-white/10">
                    <th className="py-2 pr-3">Użytkownik</th>
                    {ROLES.map((r) => <th key={r.role} className="py-2 px-2 text-center whitespace-nowrap">{r.label}</th>)}
                    <th className="py-2 pl-3 whitespace-nowrap">Ostatnie logowanie</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((u) => (
                    <tr key={u.id} className="border-b border-gray-50 last:border-0 dark:border-white/5">
                      <td className="py-2 pr-3">
                        <div className="text-gray-900 dark:text-gray-100" style={{ fontWeight: 600 }}>{u.name || u.id}</div>
                        <div className="text-[11px] text-gray-500">{u.email || u.id}</div>
                      </td>
                      {ROLES.map((r) => (
                        <td key={r.role} className="py-2 px-2 text-center align-top">
                          <input
                            type="checkbox"
                            className="h-4 w-4 accent-indigo-600"
                            checked={!!u[r.flag]}
                            disabled={saving === u.id}
                            onChange={(e) => updateUser(u, { [r.flag]: e.target.checked })}
                            aria-label={`${r.label}: ${u.name || u.id}`}
                          />
                          {/* a unit manager is a manager also without the flag */}
                          {r.role === 'MANAGER' && u.managedUnits.length > 0 && (
                            <div className="mt-1 flex flex-col items-center gap-0.5">
                              {u.managedUnits.map((unit) => (
                                <span key={unit} title="Manager unitu (konfiguracja organizacji)" className="px-1.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[10.5px] whitespace-nowrap dark:bg-emerald-500/10 dark:text-emerald-300">{unit}</span>
                              ))}
                            </div>
                          )}
                        </td>
                      ))}
                      <td className="py-2 pl-3 text-gray-500 whitespace-nowrap">{formatDate(u.lastLogin)}</td>
                    </tr>
                  ))}
                  {filtered.length === 0 && (
                    <tr><td colSpan={ROLES.length + 2} className="py-4 text-center text-gray-500">Brak użytkowników</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </section>
      )}

      {tab === 'pages' && (
        <section className={section}>
          <p className="text-[12px] text-gray-500">
            Które role widzą każdą stronę (wystarczy jedna z ról użytkownika). Admin widzi wszystko. Strony niedozwolone znikają z menu,
            a ich API w core jest zablokowane (np. Deliver, Code Impact, Task Timeline). Ekran Ustawienia jest zawsze tylko dla Admina.
          </p>
          {!pages ? (
            <p className="text-[13px] text-gray-500">{error ? '' : 'Ładowanie…'}</p>
          ) : (
            <>
              <div className="overflow-x-auto">
                <table className="w-full text-[13px]">
                  <thead>
                    <tr className="text-left text-[11px] uppercase tracking-wide text-gray-500 border-b border-gray-100 dark:border-white/10">
                      <th className="py-2 pr-3">Strona</th>
                      {ROLES.map((r) => <th key={r.role} className="py-2 px-2 text-center whitespace-nowrap">{r.label}</th>)}
                    </tr>
                  </thead>
                  <tbody>
                    {pages.map((p) => {
                      const draft = pageDraft[p.key] ?? [];
                      return (
                        <tr key={p.key} className="border-b border-gray-50 last:border-0 dark:border-white/5">
                          <td className="py-2 pr-3">
                            <span className="text-gray-900 dark:text-gray-100" style={{ fontWeight: 600 }}>{p.name}</span>
                            {!sameRoles(draft, p.defaultRoles) && (
                              <button
                                className="ml-2 text-[11px] text-indigo-600 hover:underline"
                                onClick={() => { setSavedPages(false); setPageDraft((d) => ({ ...d, [p.key]: p.defaultRoles })); }}
                              >
                                przywróć domyślne
                              </button>
                            )}
                          </td>
                          {ROLES.map((r) => (
                            <td key={r.role} className="py-2 px-2 text-center">
                              <input
                                type="checkbox"
                                className="h-4 w-4 accent-indigo-600"
                                checked={r.role === 'ADMIN' || draft.includes(r.role)}
                                disabled={r.role === 'ADMIN'}
                                onChange={(e) => toggleRole(p.key, r.role, e.target.checked)}
                                aria-label={`${p.name}: ${r.label}`}
                              />
                            </td>
                          ))}
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={savePages}
                  disabled={!pagesChanged || saving === 'pages'}
                  className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-[13px] disabled:opacity-50"
                  style={{ fontWeight: 600 }}
                >
                  {saving === 'pages' ? 'Zapisywanie…' : 'Zapisz'}
                </button>
                {savedPages && <span className="text-[12px] text-emerald-600">Zapisano</span>}
              </div>
            </>
          )}
        </section>
      )}
    </div>
  );
}

export default UsersAccess;
