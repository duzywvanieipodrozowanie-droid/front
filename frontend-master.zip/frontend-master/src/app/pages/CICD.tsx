import { cicdMetrics, buildTimeData, pipelineStatusData } from '../data/mockData';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  ReferenceLine,
} from 'recharts';
import { useDateRange } from '../context/DateRangeContext';
import { useLang } from '../i18n';
import { getIntervalSuffix } from '../utils/intervalUnit';
import {
  TrendingUp,
  TrendingDown,
  CheckCircle2,
  XCircle,
  Zap,
  Clock,
  Activity,
  Rocket,
} from 'lucide-react';

const tooltipStyle = {
  backgroundColor: 'white',
  border: '1px solid #e5e7eb',
  borderRadius: '8px',
  fontSize: '12px',
  boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
};

function CICDCard({
  label,
  value,
  unit,
  previous,
  trend,
  goodDirection = 'up',
  icon: Icon,
  iconBg,
}: {
  label: string;
  value: number;
  unit: string;
  previous: number;
  trend: 'up' | 'down';
  goodDirection?: 'up' | 'down';
  icon: React.ElementType;
  iconBg: string;
}) {
  const pct = Math.abs(((value - previous) / previous) * 100).toFixed(1);
  const isGood = trend === goodDirection;
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-5">
      <div className="flex items-center gap-2 mb-3">
        <div className={`w-8 h-8 rounded-lg ${iconBg} flex items-center justify-center`}>
          <Icon className="w-4 h-4 text-white" />
        </div>
        <span className="text-[12px] text-gray-500 uppercase tracking-wide" style={{ fontWeight: 600, letterSpacing: '0.05em' }}>{label}</span>
      </div>
      <div className="flex items-baseline gap-1.5 mb-2">
        <span className="text-[28px] text-gray-900" style={{ fontWeight: 700, lineHeight: 1 }}>{value}</span>
        <span className="text-[13px] text-gray-400">{unit}</span>
      </div>
      <div className={`flex items-center gap-1 text-[12px] ${isGood ? 'text-emerald-600' : 'text-red-500'}`}>
        {trend === 'up' ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
        <span style={{ fontWeight: 500 }}>{pct}%</span>
        <span className="text-gray-400">· was {previous} {unit}</span>
      </div>
    </div>
  );
}

const recentRuns = [
  { id: 1, branch: 'main', commit: 'feat: add SSO integration', status: 'success', duration: '8m 23s', ago: '5 min ago', trigger: 'push' },
  { id: 2, branch: 'feature/auth-update', commit: 'fix: token refresh', status: 'success', duration: '7m 45s', ago: '12 min ago', trigger: 'pr' },
  { id: 3, branch: 'develop', commit: 'chore: update deps', status: 'success', duration: '9m 12s', ago: '28 min ago', trigger: 'push' },
  { id: 4, branch: 'release/v2.3.0', commit: 'build: release prep', status: 'success', duration: '8m 56s', ago: '45 min ago', trigger: 'manual' },
  { id: 5, branch: 'hotfix/user-login', commit: 'fix: login race condition', status: 'failed', duration: '3m 21s', ago: '1 hour ago', trigger: 'push' },
  { id: 6, branch: 'main', commit: 'refactor: auth middleware', status: 'success', duration: '8m 34s', ago: '2 hours ago', trigger: 'push' },
];

const pipelineStages = [
  { name: 'Checkout', duration: '12s', success: 99.8, color: 'bg-indigo-500' },
  { name: 'Install Deps', duration: '1m 45s', success: 98.5, color: 'bg-violet-500' },
  { name: 'Build', duration: '3m 20s', success: 97.2, color: 'bg-purple-500' },
  { name: 'Unit Tests', duration: '2m 15s', success: 96.8, color: 'bg-fuchsia-500' },
  { name: 'Integration Tests', duration: '1m 30s', success: 95.5, color: 'bg-amber-500' },
  { name: 'Deploy', duration: '45s', success: 98.9, color: 'bg-emerald-500' },
];

export function CICD() {
  const total = pipelineStatusData.reduce((s, d) => s + d.value, 0);
  const { dateRange, label: dateRangeLabel } = useDateRange();
  const { lang } = useLang();
  const unitSuffix = getIntervalSuffix(dateRange, lang);

  return (
    <div className="p-4 sm:p-6 mx-auto space-y-6">

      {/* Header */}
      <div>
        <h1 className="text-[20px] text-gray-900" style={{ fontWeight: 700 }}>CI/CD Performance</h1>
        <p className="text-[13px] text-gray-500 mt-0.5">Pipeline health and deployment metrics · {dateRangeLabel}</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <CICDCard
          label="Build Success"
          value={cicdMetrics.buildSuccessRate.current}
          unit="%"
          previous={cicdMetrics.buildSuccessRate.previous}
          trend={cicdMetrics.buildSuccessRate.trend}
          goodDirection="up"
          icon={CheckCircle2}
          iconBg="bg-emerald-500"
        />
        <CICDCard
          label="Avg Build Time"
          value={cicdMetrics.avgBuildTime.current}
          unit="min"
          previous={cicdMetrics.avgBuildTime.previous}
          trend={cicdMetrics.avgBuildTime.trend}
          goodDirection="down"
          icon={Clock}
          iconBg="bg-indigo-500"
        />
        <CICDCard
          label="Pipeline Runs"
          value={cicdMetrics.pipelineExecutions.current}
          unit={unitSuffix}
          previous={cicdMetrics.pipelineExecutions.previous}
          trend={cicdMetrics.pipelineExecutions.trend}
          goodDirection="up"
          icon={Activity}
          iconBg="bg-violet-500"
        />
        <CICDCard
          label="Deploy Success"
          value={cicdMetrics.deploymentSuccess.current}
          unit="%"
          previous={cicdMetrics.deploymentSuccess.previous}
          trend={cicdMetrics.deploymentSuccess.trend}
          goodDirection="up"
          icon={Rocket}
          iconBg="bg-amber-500"
        />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">

        {/* Build Time Trend */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex items-center justify-between mb-1">
            <h2 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>Build Time Trend</h2>
            <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-50 border border-emerald-200 text-[11px] text-emerald-700" style={{ fontWeight: 600 }}>
              ↓ 26% improvement
            </div>
          </div>
          <p className="text-[12px] text-gray-400 mb-4">Minutes per build · threshold: 10 min</p>
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={buildTimeData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} unit="m" domain={[6, 13]} />
                <Tooltip contentStyle={tooltipStyle} />
                <ReferenceLine y={10} stroke="#ef4444" strokeDasharray="4 4" strokeWidth={1.5} label={{ value: 'Threshold', fill: '#ef4444', fontSize: 10, position: 'right' }} />
                <Line type="monotone" dataKey="time" stroke="#6366f1" strokeWidth={2.5} dot={{ fill: '#6366f1', r: 4, strokeWidth: 0 }} activeDot={{ r: 6 }} name="Build Time" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Pipeline Status Donut */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h2 className="text-[14px] text-gray-900 mb-1" style={{ fontWeight: 600 }}>Pipeline Status</h2>
          <p className="text-[12px] text-gray-400 mb-4">{total} runs this week</p>
          <div className="flex items-center gap-6">
            <div className="w-44 h-44 flex-shrink-0">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pipelineStatusData}
                    cx="50%"
                    cy="50%"
                    innerRadius={44}
                    outerRadius={68}
                    dataKey="value"
                    strokeWidth={0}
                  >
                    {pipelineStatusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={tooltipStyle} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex-1 space-y-3">
              {pipelineStatusData.map((entry) => (
                <div key={entry.name}>
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: entry.color }} />
                      <span className="text-[13px] text-gray-700">{entry.name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[12px] text-gray-400">{Math.round((entry.value / total) * 100)}%</span>
                      <span className="text-[13px] text-gray-900" style={{ fontWeight: 700 }}>{entry.value}</span>
                    </div>
                  </div>
                  <div className="w-full bg-gray-100 rounded-full h-1.5">
                    <div className="h-1.5 rounded-full" style={{ width: `${(entry.value / total) * 100}%`, backgroundColor: entry.color }} />
                  </div>
                </div>
              ))}
              <div className="pt-2 border-t border-gray-100 text-[12px] text-gray-500">
                Cache hit rate: <span className="text-gray-800" style={{ fontWeight: 600 }}>87%</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Pipeline Stages */}
      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <h2 className="text-[14px] text-gray-900 mb-1" style={{ fontWeight: 600 }}>Pipeline Stage Performance</h2>
        <p className="text-[12px] text-gray-400 mb-4">Success rate and avg duration per stage</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {pipelineStages.map((stage) => (
            <div key={stage.name} className="p-4 bg-gray-50 rounded-lg border border-gray-100">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[13px] text-gray-700" style={{ fontWeight: 500 }}>{stage.name}</span>
                <span className="text-[12px] text-gray-400">{stage.duration}</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex-1 bg-gray-200 rounded-full h-1.5">
                  <div className={`h-1.5 rounded-full ${stage.color}`} style={{ width: `${stage.success}%` }} />
                </div>
                <span className="text-[12px] text-emerald-600 flex-shrink-0" style={{ fontWeight: 600 }}>{stage.success}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent runs + performance details */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">

        {/* Recent Pipeline Runs */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>Recent Pipeline Runs</h2>
            <span className="text-[11px] text-gray-400">Live</span>
          </div>
          <div className="space-y-2">
            {recentRuns.map((run) => (
              <div key={run.id} className="flex items-center gap-3 py-2.5 border-b border-gray-50 last:border-0">
                <div className="flex-shrink-0">
                  {run.status === 'success' ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  ) : (
                    <XCircle className="w-4 h-4 text-red-500" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[12px] text-gray-800 truncate" style={{ fontWeight: 500 }}>{run.commit}</p>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className="text-[11px] text-indigo-600 truncate">{run.branch}</span>
                    <span className="text-gray-300">·</span>
                    <span className="text-[11px] text-gray-400">{run.ago}</span>
                  </div>
                </div>
                <span className="text-[12px] text-gray-500 flex-shrink-0">{run.duration}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Performance Details */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h2 className="text-[14px] text-gray-900 mb-4" style={{ fontWeight: 600 }}>Performance Details</h2>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-4">
              <div>
                <p className="text-[11px] text-gray-400 mb-0.5">Fastest build</p>
                <p className="text-[18px] text-gray-900" style={{ fontWeight: 700 }}>6m 12s</p>
              </div>
              <div>
                <p className="text-[11px] text-gray-400 mb-0.5">Average build</p>
                <p className="text-[18px] text-gray-900" style={{ fontWeight: 700 }}>8m 18s</p>
              </div>
              <div>
                <p className="text-[11px] text-gray-400 mb-0.5">Slowest build</p>
                <p className="text-[18px] text-gray-900" style={{ fontWeight: 700 }}>12m 45s</p>
              </div>
            </div>
            <div className="space-y-4">
              <div>
                <p className="text-[11px] text-gray-400 mb-0.5">Unit tests</p>
                <p className="text-[18px] text-gray-900" style={{ fontWeight: 700 }}>1,234</p>
              </div>
              <div>
                <p className="text-[11px] text-gray-400 mb-0.5">Integration tests</p>
                <p className="text-[18px] text-gray-900" style={{ fontWeight: 700 }}>89</p>
              </div>
              <div>
                <p className="text-[11px] text-gray-400 mb-0.5">E2E tests</p>
                <p className="text-[18px] text-gray-900" style={{ fontWeight: 700 }}>23</p>
              </div>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-gray-100 grid grid-cols-3 gap-3">
            <div className="text-center">
              <p className="text-[18px] text-emerald-600" style={{ fontWeight: 700 }}>23</p>
              <p className="text-[11px] text-gray-400">Prod deploys</p>
            </div>
            <div className="text-center">
              <p className="text-[18px] text-indigo-600" style={{ fontWeight: 700 }}>67</p>
              <p className="text-[11px] text-gray-400">Staging deploys</p>
            </div>
            <div className="text-center">
              <p className="text-[18px] text-amber-600" style={{ fontWeight: 700 }}>1</p>
              <p className="text-[11px] text-gray-400">Rollbacks</p>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}
