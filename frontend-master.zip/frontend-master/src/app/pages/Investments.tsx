// Removed mock data fallback per requirement to display N/A when API has no data
import { Info } from 'lucide-react';
import { useEffect, useMemo, useState, useRef } from 'react';
import { useDateRange } from '../context/DateRangeContext';
import { useTeam } from '../context/TeamContext';
import { useTr, usePick } from '../i18n';
import { toInterval } from '../utils/dateRange';

const tooltipStyle = {
  backgroundColor: 'white',
  border: '1px solid #e5e7eb',
  borderRadius: '8px',
  fontSize: '12px',
  boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
};

const CATEGORY_COLORS = ['#6366f1', '#ef4444', '#f59e0b', '#10b981', '#8b5cf6'];

function CustomTooltip({ active, payload }: { active?: boolean; payload?: any[] }) {
  const pick = usePick();
  if (active && payload && payload.length) {
    const d = payload[0].payload;
    return (
      <div className="bg-white border border-gray-200 rounded-lg p-3 shadow-md">
        <p className="text-[13px] text-gray-900" style={{ fontWeight: 600 }}>{d.category}</p>
        <p className="text-[12px] text-gray-500">{d.percentage}% {pick('of effort', 'nakładu')}</p>
        <p className="text-[12px] text-gray-500">{d.hours} {pick('hours', 'godzin')}</p>
      </div>
    );
  }
  return null;
}

type InvestmentsProps = { interval?: string; team?: string };

export function Investments({ interval: intervalProp, team: teamProp }: InvestmentsProps = {}) {
  const { dateRange, label: dateRangeLabel } = useDateRange();
  const { selectedTeamName, selectedUnitId } = useTeam();

  // De-duplication refs to ensure each API is called only once per param set
  const lastTotalUrlRef = useRef<string | null>(null);

  const derivedInterval = useMemo(() => {
    return toInterval(dateRange, 'WEEKS_1');
  }, [dateRange]);

  const interval = useMemo(() => intervalProp ?? derivedInterval, [intervalProp, derivedInterval]);

  type Category = { category: string; percentage: number; hours: number };
  const [categories, setCategories] = useState<Category[]>([]);
  const [hoverType, setHoverType] = useState<'run' | 'change'>('run');

  // Compute Run vs Change split and breakdowns from API categories (no mock fallback)
  const classification = useMemo(() => {
    const runKeywords = ['bug', 'fix', 'maintenance', 'ops', 'operation', 'operational', 'tech debt', 'debt', 'stability', 'support'];
    const changeKeywords = ['feature', 'new', 'improvement', 'enhancement', 'innovation', 'experiment', 'change'];
    const norm = (s: string) => s.toLowerCase();
    const isMatch = (label: string, keywords: string[]) => {
      const l = norm(label);
      return keywords.some((k) => l.includes(k));
    };

    const run: Category[] = [];
    const change: Category[] = [];
    const unknown: Category[] = [];
    (categories || []).forEach((c) => {
      if (!c?.category) return;
      if (isMatch(c.category, runKeywords)) run.push(c);
      else if (isMatch(c.category, changeKeywords)) change.push(c);
      else unknown.push(c);
    });
    const runTotal = run.reduce((s, c) => s + (c.percentage || 0), 0);
    const changeTotal = change.reduce((s, c) => s + (c.percentage || 0), 0);
    const total = runTotal + changeTotal;
    const runPct = total > 0 ? Math.round((runTotal / total) * 100) : 0;
    const changePct = total > 0 ? 100 - runPct : 0;
    return { run, change, unknown, runTotal, changeTotal, total, runPct, changePct };
  }, [categories]);


  // Build a stable color map based on the current category order used by the Pie
  const colorMap = useMemo(() => {
    const map: Record<string, string> = {};
    categories.forEach((c, i) => {
      map[c.category] = CATEGORY_COLORS[i % CATEGORY_COLORS.length];
    });
    return map;
  }, [categories]);

  const runBreakdown = useMemo(() => classification.run.map((c, i) => ({
    label: c.category,
    hours: 0,
    pct: Math.round(c.percentage),
    color: colorMap[c.category] || CATEGORY_COLORS[i % CATEGORY_COLORS.length],
  })), [classification, colorMap]);

  const changeBreakdown = useMemo(() => classification.change.map((c, i) => ({
    label: c.category,
    hours: 0,
    pct: Math.round(c.percentage),
    color: colorMap[c.category] || CATEGORY_COLORS[i % CATEGORY_COLORS.length],
  })), [classification, colorMap]);
  // Closed items will be hydrated from /api/investment/total (bau/feature arrays)
  const [totalData, setTotalData] = useState<any | null>(null);
  const closedEpicsRun = useMemo(() => Array.isArray(totalData?.bau) ? totalData!.bau : [], [totalData]);
  const closedEpicsChange = useMemo(() => Array.isArray(totalData?.feature) ? totalData!.feature : [], [totalData]);

  // Compute Run vs Change split using API percent map if available, otherwise fall back to classification
  const split = useMemo(() => {
    const pct = totalData?.percent;
    if (pct && (typeof pct.bau === 'number' || typeof pct.feature === 'number')) {
      const run = Math.max(0, Math.min(100, Number(pct.bau ?? 0)));
      const change = Math.max(0, Math.min(100, Number(pct.feature ?? 0)));
      const total = run + change;
      return {
        runPct: total > 0 ? Math.round((run / total) * 100) : 0,
        changePct: total > 0 ? 100 - Math.round((run / total) * 100) : 0,
        runHours: 0,
        changeHours: 0,
        hasData: total > 0,
      } as { runPct: number; changePct: number; runHours: number; changeHours: number; hasData: boolean };
    }
    return {
      runPct: classification.total > 0 ? classification.runPct : 0,
      changePct: classification.total > 0 ? classification.changePct : 0,
      runHours: 0,
      changeHours: 0,
      hasData: classification.total > 0,
    } as { runPct: number; changePct: number; runHours: number; changeHours: number; hasData: boolean };
  }, [totalData, classification]);

  const effectiveTeam = useMemo(() => {
    if (teamProp && teamProp !== 'All Teams') return teamProp;
    if (selectedTeamName && selectedTeamName !== 'All Teams') return selectedTeamName;
    return undefined;
  }, [teamProp, selectedTeamName]); // effectiveTeam updates when context team changes

  const effectiveTeamName = useMemo(() => effectiveTeam ?? 'your org', [effectiveTeam]);

  // Load Time Allocation and totals from API: GET /investment/total
  useEffect(() => {
    const controller = new AbortController();
    async function loadCategories() {
      try {
        const params = new URLSearchParams();
        if (interval) params.set('interval', String(interval));
        // As per Swagger, only pass unitId (no team fallback)
        if (selectedUnitId) params.set('unitId', String(selectedUnitId));
        const qs = params.toString();
        const url = `/api/investment/total${qs ? `?${qs}` : ''}`;
        // De-dup: skip if URL hasn't changed
        if (lastTotalUrlRef.current === url) return;
        lastTotalUrlRef.current = url;
        const res = await fetch(url , {
          signal: controller.signal,
          credentials: 'include',
          headers: { 'Accept': 'application/json' },
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const json = await res.json();
        setTotalData(json);
        const arr = Array.isArray(json?.investments) ? json.investments : [];
        const mapped: Category[] = arr
          .map((it: any) => {
            const label = it?.label;
            const percent = it?.percent;
            if (label == null || typeof percent !== 'number') return null;
            return { category: String(label), percentage: percent, hours: 0 } as Category;
          })
          .filter((v: Category | null): v is Category => Boolean(v));
        setCategories(mapped);
      } catch (e) {
        // keep previous categories on error
      }
    }
    loadCategories();
    return () => controller.abort();
  }, [interval, selectedUnitId]);



  // Removed /api/investment/chart/total fetching per requirement
  
  // Removed investment/teams/api fetching per requirement
  
  // Removed derived labels and helpers tied to teamRows

  const t = useTr();
  const pick = usePick();
  return (
    <div className="p-4 sm:p-6 mx-auto space-y-6">

      {/* Header */}
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <h1 className="text-[20px] text-gray-900" style={{ fontWeight: 700 }}>{t('investments')}</h1>
          <p className="text-[13px] text-gray-500 mt-0.5">
            {pick(`How ${effectiveTeamName} is spending engineering time`, `Jak ${effectiveTeamName} wydatkuje czas inżynieryjny`)} · {dateRangeLabel}
          </p>
        </div>
        <div className="flex items-center gap-1.5 text-[12px] text-gray-400 bg-blue-50 border border-blue-200 rounded-lg px-3 py-2">
          <Info className="w-3.5 h-3.5 text-blue-500" />
          <span className="text-blue-700">{pick('Based on PR labels & commit messages', 'Na podstawie etykiet PR i wiadomości commitów')}</span>
        </div>
      </div>


      {/* Two cards: Run / Change breakdowns */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Run the Product */}
        <div className="bg-white rounded-xl border border-gray-200 p-5" onMouseEnter={() => setHoverType('run')}>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-emerald-50 border border-emerald-200 flex items-center justify-center">🔧</div>
              <div>
                <div className="text-[13px] text-gray-900" style={{ fontWeight: 700 }}>{pick('Run the Product', 'Utrzymanie produktu')}</div>
                <div className="text-[11px] text-gray-500 -mt-0.5">{pick('Keep the lights on · BAU', 'Utrzymanie działania · BAU')}</div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-[22px] text-gray-900" style={{ fontWeight: 800 }}>{split.runPct}%</div>
              <div className="text-[11px] text-gray-400 -mt-1">{split.runHours} {pick('h','godz.')}</div>
            </div>
          </div>
          <div className="space-y-3">
            {runBreakdown.map((r) => (
              <div key={r.label}>
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: r.color }} />
                    <span className="text-[13px] text-gray-700">{r.label}</span>
                  </div>
                  <div className="text-[12px] text-gray-500">{r.hours} {pick('h','godz.')} <span className="ml-1 text-gray-900" style={{ fontWeight: 700 }}>{r.pct}%</span></div>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-1.5">
                  <div className="h-1.5 rounded-full" style={{ width: `${r.pct}%`, backgroundColor: r.color }} />
                </div>
              </div>
            ))}
          </div>
          <div className="mt-3 text-[12px] text-indigo-600 cursor-pointer select-none">{pick('Showing', 'Wyświetlono')} {closedEpicsRun.length} {pick('items below', 'pozycji poniżej')}</div>
        </div>
        {/* Change the Product */}
        <div className="bg-white rounded-xl border border-gray-200 p-5" onMouseEnter={() => setHoverType('change')}>
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-indigo-50 border border-indigo-200 flex items-center justify-center">🚀</div>
              <div>
                <div className="text-[13px] text-gray-900" style={{ fontWeight: 700 }}>{pick('Change the Product', 'Zmiana produktu')}</div>
                <div className="text-[11px] text-gray-500 -mt-0.5">{pick('Move forward · Features & Innovation', 'Rozwój · Funkcje i innowacje')}</div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-[22px] text-gray-900" style={{ fontWeight: 800 }}>{split.changePct}%</div>
              <div className="text-[11px] text-gray-400 -mt-1">{split.changeHours} {pick('h','godz.')}</div>
            </div>
          </div>
          <div className="space-y-3">
            {changeBreakdown.map((r) => (
              <div key={r.label}>
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <div className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: r.color }} />
                    <span className="text-[13px] text-gray-700">{r.label}</span>
                  </div>
                  <div className="text-[12px] text-gray-500">{r.hours}h <span className="ml-1 text-gray-900" style={{ fontWeight: 700 }}>{r.pct}%</span></div>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-1.5">
                  <div className="h-1.5 rounded-full" style={{ width: `${r.pct}%`, backgroundColor: r.color }} />
                </div>
              </div>
            ))}
          </div>
          <div className="mt-3 text-[12px] text-indigo-600 cursor-pointer select-none">{pick('Showing', 'Wyświetlono')} {closedEpicsChange.length} {pick('items below', 'pozycji poniżej')}</div>
        </div>
      </div>



      {/* Closed epics list driven by hovered type */}
      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-2 mb-3">
          <div className="flex items-center gap-2 min-w-0">
            <div className={`w-2 h-2 shrink-0 rounded-full ${hoverType==='run' ? 'bg-emerald-500' : 'bg-indigo-500'}`} />
            <h3 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>
              {hoverType === 'run' ? pick('Run the Product', 'Utrzymanie produktu') : pick('Change the Product', 'Zmiana produktu')} — {pick('Closed epics', 'Zamknięte epiki')}
            </h3>
          </div>
          <div className="flex flex-wrap items-center gap-1.5 sm:gap-2">
            {(hoverType === 'run' ? [pick('All','Wszystko'), pick('Bug Fixes','Poprawki błędów'), pick('Maintenance','Utrzymanie'), pick('Tech Debt','Dług techniczny'), pick('Operations','Operacje')] : [pick('All','Wszystko'), pick('New Features','Nowe funkcje'), pick('Improvements','Usprawnienia'), pick('Innovation','Innowacje')]).map((f) => (
              <span key={f} className={`whitespace-nowrap px-2 py-0.5 rounded-full text-[11px] border ${f===pick('All','Wszystko') ? 'bg-gray-900 text-white border-gray-900' : 'bg-gray-50 text-gray-700 border-gray-200'}`}>{f}</span>
            ))}
          </div>
        </div>
        <div className="divide-y divide-gray-100">
          {(hoverType === 'run' ? closedEpicsRun : closedEpicsChange).map((e: any, idx: number) => {
            const key = e?.key ?? idx;
            const title = e?.summary ?? e?.title ?? e?.summaryText ?? '—';
            const labels = Array.isArray(e?.labels) ? e.labels : Array.isArray(e?.tags) ? e.tags : [];
            const status = e?.status ?? '—';
            const updated = e?.updated ? new Date(e.updated).toLocaleDateString() : (e?.date ?? '');
            return (
              <div key={key} className="py-3 flex items-center justify-between gap-3">
                <div className="min-w-0">
                  <div className="text-[12px] text-gray-500">{String(e?.projectId ?? '')}{e?.key ? ' · ' + e.key : ''}</div>
                  <div className="text-[13px] text-gray-800" style={{ fontWeight: 600 }}>{title}</div>
                  <div className="mt-1 flex items-center gap-1.5 flex-wrap">
                    {labels.map((t: string) => (
                      <span key={t} className={`px-1.5 py-0.5 rounded-md text-[11px] bg-gray-100 text-gray-700`}>{t}</span>
                    ))}
                  </div>
                </div>
                <div className="flex items-center gap-6 shrink-0 text-[12px] text-gray-500">
                  <span className="hidden sm:inline">{status}</span>
                  <div className="text-right">
                    <div className="text-[11px] text-gray-400">{updated}</div>
                    <div className="text-[11px] text-emerald-600">closed</div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
