import { useCallback, useEffect, useState } from 'react';
import { ChevronLeft, RefreshCw } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useTr, usePick } from '../i18n';

// Authors of the commits not assigned to any person (/api/metrics/alert/unknown-commiters?days=): the import matches
// a commit to a person by the author's name / e-mail, so these need the e-mail added to a person (Users and access).
// mappedPersonId: such a person exists by now, the commits were imported before and keep no person.
type UnknownCommitter = {
  email: string | null; name: string | null; commits: number; lastCommit: string | null; repositories: string[];
  mappedPersonId: string | null;
};

const PERIODS = [7, 30, 90, 365];

export function UnknownCommiters() {
  const navigate = useNavigate();
  const t = useTr();
  const pick = usePick();
  const [days, setDays] = useState(30);
  const [data, setData] = useState<UnknownCommitter[] | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/metrics/alert/unknown-commiters?days=${days}`, { credentials: 'include' });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const payload = await res.json();
      // an older core returns only [{email}]
      setData(Array.isArray(payload) ? payload.map((it) => ({ name: null, commits: 0, lastCommit: null, repositories: [], mappedPersonId: null, ...it })) : []);
    } catch (e) {
      setError((e instanceof Error && e.message) || 'Failed to load');
    } finally {
      setLoading(false);
    }
  }, [days]);

  useEffect(() => { load(); }, [load]);

  const th = 'text-left text-[11.5px] text-gray-500 uppercase tracking-wider px-3 py-2';
  return (
    <div className="p-4 sm:p-6 mx-auto space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-col items-start gap-2 sm:flex-row sm:items-center sm:gap-3 min-w-0">
          <button
            onClick={() => navigate('/settings')}
            className="shrink-0 flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-gray-200 text-[12px] text-gray-600 hover:bg-gray-50 transition-colors"
            aria-label="Back to Settings"
          >
            <ChevronLeft className="w-4 h-4 text-gray-500" /> {t('back')}
          </button>
          <div>
            <h1 className="text-[20px] text-gray-900" style={{ fontWeight: 700 }}>
              {pick('Unknown committers', 'Nieznani commitujący')}
            </h1>
            <p className="text-[13px] text-gray-500 mt-0.5">
              {pick('Authors of commits not assigned to any person - add their e-mail to a person in Users and access',
                'Autorzy commitów nieprzypisanych do żadnej osoby - dopisz ich e-mail do osoby w Użytkownicy i dostęp')}
            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex rounded-xl border border-gray-200 overflow-hidden text-[12.5px]">
            {PERIODS.map((d) => (
              <button key={d} onClick={() => setDays(d)} className={`px-3 py-2 ${days === d ? 'bg-gray-900 text-white' : 'bg-white hover:bg-gray-50 text-gray-700'}`}>
                {d} {pick('days', 'dni')}
              </button>
            ))}
          </div>
          <button
            onClick={load}
            className="flex items-center gap-2 px-3 py-2 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 text-gray-700 text-[13px] transition-colors"
            style={{ fontWeight: 500 }}
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            {pick('Refresh', 'Odśwież')}
          </button>
        </div>
      </div>

      <section className="bg-white rounded-2xl border border-gray-200 p-2 sm:p-3 overflow-x-auto">
        {loading ? (
          <p className="p-3 text-[13px] text-gray-400 italic">{pick('Loading…', 'Ładowanie…')}</p>
        ) : error ? (
          <p className="p-3 text-[13px] text-red-500">{pick('Failed to load:', 'Nie udało się załadować:')} {error}</p>
        ) : !data?.length ? (
          <p className="p-3 text-[13px] text-gray-500">
            {pick(`Every commit of the last ${days} days has a person.`, `Każdy commit z ostatnich ${days} dni ma przypisaną osobę.`)}
          </p>
        ) : (
          <table className="w-full text-[13px]">
            <thead>
              <tr className="border-b border-gray-100">
                <th className={th}>E-mail</th>
                <th className={th}>{pick('Name', 'Nazwa')}</th>
                <th className={`${th} text-right`}>{pick('Commits', 'Commity')}</th>
                <th className={th}>{pick('Last commit', 'Ostatni commit')}</th>
                <th className={th}>{pick('Repositories', 'Repozytoria')}</th>
              </tr>
            </thead>
            <tbody>
              {data.map((c, i) => (
                <tr key={`${c.email ?? c.name}-${i}`} className="border-b border-gray-50 last:border-0">
                  <td className="px-3 py-2 break-all text-gray-900" style={{ fontWeight: 600 }}>
                    {c.email ?? '—'}
                    {c.mappedPersonId && (
                      <div className="text-[11.5px] text-amber-700" style={{ fontWeight: 500 }}>
                        {pick(`now matches ${c.mappedPersonId} - older commits keep no person`, `pasuje już do ${c.mappedPersonId} - starsze commity zostają bez osoby`)}
                      </div>
                    )}
                  </td>
                  <td className="px-3 py-2 text-gray-700">{c.name ?? '—'}</td>
                  <td className="px-3 py-2 text-right tabular-nums">{c.commits}</td>
                  <td className="px-3 py-2 text-gray-600 whitespace-nowrap">
                    {c.lastCommit ? new Date(c.lastCommit).toLocaleDateString(pick('en-GB', 'pl-PL')) : '—'}
                  </td>
                  <td className="px-3 py-2 text-gray-600 break-all">{c.repositories.join(', ') || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>
    </div>
  );
}

export default UnknownCommiters;
