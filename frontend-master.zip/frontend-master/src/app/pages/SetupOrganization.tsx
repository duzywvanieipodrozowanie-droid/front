import { useState, useRef, useEffect } from 'react';
import {
  Building2, Plus, Pencil, Trash2, X, ChevronDown, ChevronLeft, ChevronRight,
  ArrowRightLeft, Users, Check, Upload,
  FileText, AlertCircle, Search, Minus,
  ZoomIn, ZoomOut, RefreshCcw,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';

// ─── Types ───────────────────────────────────────────────────────────────────

// API shape for /api//v1/organization (nested tree)
interface ApiOrgNode {
  id: string;
  name: string;
  type?: string | null;
  managers?: string[] | null;
  members?: string[] | null;
  projects?: string[] | null;
  units?: ApiOrgNode[] | null;
}

interface OrgUnit {
  id: string;
  name: string;
  level: number;
  linkedTo: string | null;
  managerLogin?: string;
  managerIds?: string[]; // from API: node.managers
  memberIds?: string[];  // from API: node.members
  projects?: string[] | null; // from API: node.projects
}

interface Developer {
  id: string;
  name: string;
  surname: string;
  login: string;
  email: string;
  otherEmails?: string; // optional, comma-separated
  language: string;
  level: 'Junior' | 'Mid' | 'Senior' | 'Tech Lead';
  unitId: string;
  isManager?: boolean; // flag to highlight managers in UI
}

// ─── Constants ────────────────────────────────────────────────────────────────

const ORG_LEVELS = [0, 1, 2, 3, 4];
const LANGUAGES = [
  'Rust',
  'JavaScript',
  'HTML/CSS',
  'C',
  'Scala',
  'Dart',
  'Go',
  'TypeScript',
  'Kotlin',
  'C++',
  'Ruby',
  'Java',
  'C#',
  'Other',
  'Bash/Shell',
  'Swift',
  'Python',
  'R',
  'PHP',
  'SQL',
];
const DEV_LEVELS = ['Junior', 'Mid', 'Senior', 'Tech Lead'] as const;
const LEVEL_COLORS: Record<string, string> = {
  // canonical
  Junior: 'bg-emerald-100 text-emerald-700',
  Mid: 'bg-blue-100 text-blue-700',
  Senior: 'bg-violet-100 text-violet-700',
  'Tech Lead': 'bg-orange-100 text-orange-700',
  // API/JSON uppercase variants
  JUNIOR: 'bg-emerald-100 text-emerald-700',
  REGULAR: 'bg-blue-100 text-blue-700',
  SENIOR: 'bg-violet-100 text-violet-700',
  LEAD: 'bg-orange-100 text-orange-700',
};
const CARD_STYLE: Record<number, { border: string; header: string; badge: string; text: string; sub: string }> = {
  0: { border: 'border-indigo-500', header: 'bg-indigo-600', badge: 'bg-white/20 text-white', text: 'text-white', sub: 'text-white/60' },
  1: { border: 'border-indigo-300', header: 'bg-indigo-50', badge: 'bg-indigo-100 text-indigo-600', text: 'text-gray-800', sub: 'text-gray-400' },
  2: { border: 'border-violet-300', header: 'bg-violet-50', badge: 'bg-violet-100 text-violet-600', text: 'text-gray-800', sub: 'text-gray-400' },
  3: { border: 'border-emerald-300', header: 'bg-emerald-50', badge: 'bg-emerald-100 text-emerald-600', text: 'text-gray-800', sub: 'text-gray-400' },
  4: { border: 'border-amber-300', header: 'bg-amber-50', badge: 'bg-amber-100 text-amber-600', text: 'text-gray-800', sub: 'text-gray-400' },
};

function genId() { return Math.random().toString(36).slice(2, 9); }

// Flatten nested API organization tree into flat OrgUnit list (preserves manager/member IDs)
function flattenOrg(node: ApiOrgNode, level: number, parentId: string | null, acc: OrgUnit[]) {
  if (!node || typeof node !== 'object') return;
  const id = String(node.id);
  const name = String(node.name ?? '');
  const managerIds = Array.isArray(node.managers) ? node.managers.map(String) : undefined;
  const memberIds = Array.isArray(node.members) ? node.members.map(String) : undefined;
  const projects = Array.isArray(node.projects) ? node.projects.map(String) : undefined;
  acc.push({ id, name, level, linkedTo: parentId, managerIds, memberIds, projects });
  const children = Array.isArray(node.units) ? node.units : [];
  children.forEach((child) => flattenOrg(child, Math.min(level + 1, 10), id, acc));
}

async function fetchOrganizationTree(): Promise<ApiOrgNode | null> {
  const urls = ['/api/admin/organization',];
  for (const url of urls) {
    try {
      const res = await fetch(url, { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!res.ok) continue;
      const data = await res.json();
      if (data && typeof data === 'object') return data as ApiOrgNode;
    } catch (_e) {
      // try next
    }
  }
  return null;
}

// People API
interface ApiPerson {
  id: string;
  name: string | null;
  email?: string | null;
  commiterEmails?: string[] | null;
  technical?: boolean | null;
  admin?: boolean | null;
  level?: string | null;
  skills?: string[] | null;
}

async function fetchPeoples(): Promise<ApiPerson[] | null> {
  const urls = ['/api/admin/organization/peoples/peoples'];
  for (const url of urls) {
    try {
      const res = await fetch(url, { credentials: 'include', headers: { Accept: 'application/json' } });
      if (!res.ok) continue;
      const data = await res.json();
      if (Array.isArray(data)) return data as ApiPerson[];
    } catch (_e) {
      // try next
    }
  }
  return null;
}

// ─── Form helpers ─────────────────────────────────────────────────────────────

const inputCls = 'w-full rounded-lg border border-gray-200 bg-white px-3 py-2 text-[13px] text-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder-gray-400';

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1">
      <label className="text-[11px] text-gray-500 uppercase tracking-wide">{label}</label>
      {children}
    </div>
  );
}

function Sel({ value, onChange, placeholder, children }: { value: string; onChange: (v: string) => void; placeholder?: string; children: React.ReactNode }) {
  return (
    <div className="relative">
      <select value={value} onChange={(e) => onChange(e.target.value)} className={inputCls + ' appearance-none cursor-pointer pr-8'}>
        {placeholder && <option value="">{placeholder}</option>}
        {children}
      </select>
      <ChevronDown className="pointer-events-none absolute right-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
    </div>
  );
}

// ─── Avatar strip (6 max + dots) ─────────────────────────────────────────────

function AvatarStrip({ devs }: { devs: Developer[] }) {
  const shown = devs.slice(0, 6);
  const extra = devs.length - shown.length;
  return (
    <div className="flex flex-wrap items-center gap-0.5 mt-1.5">
      {shown.map((d) => (
        <div
          key={d.id}
          title={`${d.name} ${d.surname}${d.isManager ? ' · Manager' : ''}`}
          className={`relative w-5 h-5 rounded-full border-2 flex items-center justify-center text-[7px] text-white flex-shrink-0 ${d.isManager ? 'bg-gradient-to-br from-amber-300 to-amber-400 border-amber-100' : 'bg-gradient-to-br from-indigo-300 to-violet-400 border-white'}`}
          style={{ fontWeight: 800 }}
        >
          {d.name[0] || ''}{d.surname[0] || ''}
          {d.isManager && (
            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-amber-500 border border-white" title="Manager" />
          )}
        </div>
      ))}
      {extra > 0 && (
        <div className="flex items-center gap-0.5 ml-0.5">
          {[0, 1, 2].map((i) => (
            <div key={i} className="w-1.5 h-1.5 rounded-full bg-gray-400/60" />
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Add-to-unit modal ────────────────────────────────────────────────────────

function AddToUnitModal({
  unit, units, onClose, onAddUnit, onAddDev, onAddManager,
}: {
  unit: OrgUnit;
  units: OrgUnit[];
  onClose: () => void;
  onAddUnit: (name: string, type: string, parentUnitId: string) => Promise<void> | void;
  onAddDev: (dev: Omit<Developer, 'id'>) => Promise<void> | void;
  onAddManager: (unitId: string, manager: string) => Promise<void> | void;
}) {
  const [tab, setTab] = useState<'unit' | 'dev' | 'manager'>('dev');

  // unit form
  const [uName, setUName] = useState('');
  const [uType, setUType] = useState('');
  const [uManagerLogin, setUManagerLogin] = useState('');
  const [uError, setUError] = useState('');
  const [uSaving, setUSaving] = useState(false);

  // manager form
  const [mManager, setMManager] = useState('');
  const [mError, setMError] = useState('');
  const [mSaving, setMSaving] = useState(false);
  const [people, setPeople] = useState<Array<{ id: string; login: string }>>([]);
  const [peopleLoading, setPeopleLoading] = useState(false);

  // Load managers with typeahead: show all when query empty; call API with query when length >= 3
  const [mQuery, setMQuery] = useState('');
  const [showDrop, setShowDrop] = useState(false);
  const [debouncedQuery, setDebouncedQuery] = useState('');

  useEffect(() => {
    const h = setTimeout(() => setDebouncedQuery(mQuery.trim()), 250);
    return () => clearTimeout(h);
  }, [mQuery]);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      if (tab !== 'manager') return;
      try {
        setPeopleLoading(true);
        let data: any = null;
        const base = '/api/admin/organization/peoples/peoples';
        const url = debouncedQuery && debouncedQuery.length >= 3 ? `${base}?query=${encodeURIComponent(debouncedQuery)}` : base;
        const res = await fetch(url, { credentials: 'include', headers: { Accept: 'application/json' } });
        if (res.ok) data = await res.json();
        if (cancelled) return;
        const arr = Array.isArray(data) ? data : [];
        const items: Array<{ id: string; login: string }> = arr
          .map((p: any) => {
            const id = String(p?.id ?? '').trim();
            if (!id) return null;
            const email = typeof p?.email === 'string' ? p.email : null;
            const login = email && email.includes('@') ? email.split('@')[0] : id;
            return { id, login } as const;
          })
          .filter((v: any) => Boolean(v)) as Array<{ id: string; login: string }>;
        setPeople(items);
      } catch (_e) {
        if (cancelled) return;
        setPeople([]);
      } finally {
        if (!cancelled) setPeopleLoading(false);
      }
    }
    if (debouncedQuery.length === 0 || debouncedQuery.length >= 3) {
      load();
    } else {
      // require 3+ chars before searching; clear list to avoid confusion
      setPeople([]);
    }
    return () => { cancelled = true; };
  }, [tab, debouncedQuery]);

  // dev form
  const [dName, setDName] = useState('');
  const [dSurname, setDSurname] = useState('');
  const [dLogin, setDLogin] = useState('');
  const [dEmail, setDEmail] = useState('');
  const [dOtherEmails, setDOtherEmails] = useState('');
  const [dLang, setDLang] = useState('');
  const [dLevel, setDLevel] = useState('');
  const [dError, setDError] = useState('');
  const [dSaving, setDSaving] = useState(false);
  // init data for dropdowns (levels, skills)
  const [initLevels, setInitLevels] = useState<string[]>([]);
  const [initSkills, setInitSkills] = useState<string[]>([]);
  const [initLoading, setInitLoading] = useState<boolean>(false);

  useEffect(() => {
    let cancelled = false;
    async function loadInit() {
      if (tab !== 'dev') return;
      try {
        setInitLoading(true);
        const res = await fetch('/api/admin/organization/peoples/init', { credentials: 'include', headers: { Accept: 'application/json' } });
        if (!res.ok) throw new Error('init failed');
        const data = await res.json();
        if (cancelled) return;
        const levels = Array.isArray(data?.levels) ? data.levels.map((s: any) => String(s)) : [];
        const skills = Array.isArray(data?.skills) ? data.skills.map((s: any) => String(s)) : [];
        setInitLevels(levels);
        setInitSkills(skills);
      } catch (_e) {
        if (cancelled) return;
        // fallback to local constants when API is not available
        setInitLevels(['JUNIOR', 'REGULAR', 'SENIOR', 'LEAD']);
        setInitSkills(LANGUAGES);
      } finally {
        if (!cancelled) setInitLoading(false);
      }
    }
    loadInit();
    return () => { cancelled = true; };
  }, [tab]);

  async function submitUnit() {
    const name = uName.trim();
    const type = uType.trim();
    if (!name || !type) {
      setUError(!name ? 'Please enter unit name' : 'Please enter unit type');
      return;
    }
    try {
      setUError('');
      setUSaving(true);
      await onAddUnit(name, type, unit.id);
      onClose();
    } catch (e) {
      console.error(e);
      setUError('Failed to add unit');
    } finally {
      setUSaving(false);
    }
  }

  async function submitManager() {
    const manager = mManager.trim();
    if (!manager) {
      setMError('Please enter manager');
      return;
    }
    try {
      setMError('');
      setMSaving(true);
      await onAddManager(unit.id, manager);
      onClose();
    } catch (e) {
      console.error(e);
      setMError('Failed to add manager');
    } finally {
      setMSaving(false);
    }
  }

  async function submitDev() {
    if (!dName.trim() || !dSurname.trim() || !dLogin.trim() || !dEmail.trim() || !dLang || !dLevel) return;
    const payload: Omit<Developer, 'id'> = {
      name: dName.trim(),
      surname: dSurname.trim(),
      login: dLogin.trim(),
      email: dEmail.trim(),
      language: dLang,
      level: dLevel as Developer['level'],
      unitId: unit.id,
    } as any;
    if (dOtherEmails.trim()) {
      (payload as any).otherEmails = dOtherEmails.trim();
    }
    try {
      setDError('');
      setDSaving(true);
      await onAddDev(payload);
      onClose();
    } catch (e) {
      console.error(e);
      setDError('Failed to add developer');
    } finally {
      setDSaving(false);
    }
  }

  const cs = CARD_STYLE[unit.level] ?? CARD_STYLE[4];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className={`${cs.header} px-5 py-4 border-b border-gray-100 flex items-center justify-between`}>
          <div className="flex items-center gap-2">
            <Plus className="w-4 h-4 text-indigo-500" />
            <span className="text-[14px] text-gray-800" style={{ fontWeight: 600 }}>
              Add to <span className="text-indigo-600">{unit.name}</span>
            </span>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-black/5 transition-colors">
            <X className="w-4 h-4 text-gray-500" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-100">
          {(['dev', 'unit', 'manager'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`flex-1 py-2.5 text-[13px] transition-colors ${tab === t ? 'text-indigo-600 border-b-2 border-indigo-500' : 'text-gray-500 hover:text-gray-700'}`}
              style={{ fontWeight: tab === t ? 600 : 400 }}
            >
              {t === 'dev' ? '👤 Add developer' : t === 'unit' ? '🏢 Add sub-unit' : '🧑‍💼 Add manager to unit'}
            </button>
          ))}
        </div>

        {/* Body */}
        <div className="p-5 space-y-3">
          {tab === 'unit' ? (
            <>
              <Field label="Unit name">
                <input className={inputCls} placeholder="e.g. QA" value={uName} onChange={(e) => setUName(e.target.value)} autoFocus />
              </Field>
              <Field label="Type">
                <input className={inputCls} placeholder="e.g. Department, Team" value={uType} onChange={(e) => setUType(e.target.value)} />
              </Field>
              <Field label="Linked to">
                <input className={inputCls + ' bg-gray-50 text-gray-500'} value={`L${unit.level} — ${unit.name}`} readOnly />
              </Field>
              {uError && <div className="text-[12px] text-red-600">{uError}</div>}
            </>
          ) : tab === 'manager' ? (
            <>
              <Field label="Manager">
                <div className="relative">
                  <input
                    className={inputCls}
                    placeholder={mQuery.length >= 0 ? 'Type to search…' : 'Select…'}
                    value={mQuery}
                    onChange={(e) => { setMQuery(e.target.value); setShowDrop(true); }}
                    onFocus={() => setShowDrop(true)}
                    onBlur={() => setTimeout(() => setShowDrop(false), 150)}
                  />
                  {peopleLoading && (
                    <div className="absolute right-2 top-1/2 -translate-y-1/2 text-[11px] text-gray-400">Loading…</div>
                  )}
                  {showDrop && (
                    <div className="absolute z-20 mt-1 w-full max-h-56 overflow-auto bg-white border border-gray-200 rounded-lg shadow-lg">
                      {debouncedQuery.length > 0 && debouncedQuery.length < 3 ? (
                        <div className="px-3 py-2 text-[12px] text-gray-500">Type at least 3 characters…</div>
                      ) : people.length === 0 ? (
                        <div className="px-3 py-2 text-[12px] text-gray-500">No results</div>
                      ) : (
                        <ul className="divide-y divide-gray-50">
                          {people.map((p) => (
                            <li key={p.id}>
                              <button
                                type="button"
                                className="w-full text-left px-3 py-2 text-[13px] hover:bg-indigo-50"
                                onMouseDown={(e) => e.preventDefault()}
                                onClick={() => { setMManager(p.id); setMQuery(p.login); setShowDrop(false); }}
                              >
                                <span className="font-semibold text-gray-800">{p.login}</span>
                                <span className="ml-2 text-gray-400 text-[11px]">{p.id}</span>
                              </button>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  )}
                </div>
              </Field>
              <Field label="Unit">
                <input className={inputCls + ' bg-gray-50 text-gray-500'} value={`L${unit.level} — ${unit.name}`} readOnly />
              </Field>
              {mError && <div className="text-[12px] text-red-600">{mError}</div>}
            </>
          ) : (
            <>
              <div className="grid grid-cols-2 gap-3">
                <Field label="First name"><input className={inputCls} placeholder="Name" value={dName} onChange={(e) => setDName(e.target.value)} autoFocus /></Field>
                <Field label="Last name"><input className={inputCls} placeholder="Surname" value={dSurname} onChange={(e) => setDSurname(e.target.value)} /></Field>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Login"><input className={inputCls} placeholder="@handle" value={dLogin} onChange={(e) => setDLogin(e.target.value)} /></Field>
                <Field label="Email"><input className={inputCls} placeholder="dev@co.com" type="email" value={dEmail} onChange={(e) => setDEmail(e.target.value)} /></Field>
              </div>
              <Field label="GitLab Commiter Emails">
                <input className={inputCls} placeholder="other1@co.com, other2@co.com (optional)" value={dOtherEmails} onChange={(e) => setDOtherEmails(e.target.value)} />
              </Field>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Language">
                  <Sel value={dLang} onChange={setDLang} placeholder={initLoading ? 'Loading…' : 'Select…'}>
                    {(initSkills.length ? initSkills : LANGUAGES).map((l) => <option key={l} value={l}>{l}</option>)}
                  </Sel>
                </Field>
                <Field label="Level">
                  <Sel value={dLevel} onChange={setDLevel} placeholder={initLoading ? 'Loading…' : 'Select…'}>
                    {(initLevels.length ? initLevels : (DEV_LEVELS as unknown as string[])).map((l) => <option key={l} value={l}>{l}</option>)}
                  </Sel>
                </Field>
              </div>
              <Field label="Unit">
                <input className={inputCls + ' bg-gray-50 text-gray-500'} value={`L${unit.level} — ${unit.name}`} readOnly />
              </Field>
              {dError && <div className="text-[12px] text-red-600">{dError}</div>}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="flex justify-end gap-2 px-5 pb-5">
          <button onClick={onClose} className="px-4 py-2 rounded-lg text-[13px] text-gray-600 hover:bg-gray-100 transition-colors">Cancel</button>
          <button
            onClick={tab === 'unit' ? submitUnit : tab === 'manager' ? submitManager : submitDev}
            disabled={
              tab === 'unit'
                ? (!uName.trim() || !uType.trim() || uSaving)
                : tab === 'manager'
                  ? (!mManager.trim() || mSaving)
                  : (!dName.trim() || !dSurname.trim() || !dLogin.trim() || !dEmail.trim() || !dLang || !dLevel || dSaving)
            }
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 disabled:cursor-not-allowed text-white text-[13px] transition-colors"
            style={{ fontWeight: 500 }}
          >
            <Plus className="w-3.5 h-3.5" /> {tab === 'unit' ? 'Add unit' : tab === 'manager' ? 'Add manager' : 'Add developer'}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Confirm delete modal ─────────────────────────────────────────────────────

function ConfirmDeleteModal({
  unit, devCount, onClose, onConfirm,
}: {
  unit: OrgUnit;
  devCount: number;
  onClose: () => void;
  onConfirm: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
      <div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl overflow-hidden">
        <div className="px-6 pt-6 pb-4">
          <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center mb-4">
            <Trash2 className="w-5 h-5 text-red-500" />
          </div>
          <h2 className="text-[15px] text-gray-900" style={{ fontWeight: 700 }}>Delete "{unit.name}"?</h2>
          <p className="text-[13px] text-gray-500 mt-1.5">
            This will permanently remove the unit
            {devCount > 0 && <> and <span className="text-red-600" style={{ fontWeight: 600 }}>{devCount} developer{devCount !== 1 ? 's' : ''}</span> assigned to it</>}. 
            This action cannot be undone.
          </p>
        </div>
        <div className="flex justify-end gap-2 px-6 pb-5">
          <button onClick={onClose} className="px-4 py-2 rounded-lg text-[13px] text-gray-600 hover:bg-gray-100 transition-colors">Cancel</button>
          <button
            onClick={() => { onConfirm(); onClose(); }}
            className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white text-[13px] transition-colors"
            style={{ fontWeight: 500 }}
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Horizontal org chart node ────────────────────────────────────────────────

function OrgChartNode({
  unit, units, developers, onAdd, onDelete,
}: {
  unit: OrgUnit;
  units: OrgUnit[];
  developers: Developer[];
  onAdd: (unitId: string) => void;
  onDelete: (unitId: string) => void;
}) {
  const [collapsed, setCollapsed] = useState(false);
  const children = units.filter((u) => u.linkedTo === unit.id);
  const unitDevs = developers.filter((d) => d.unitId === unit.id);
  const cs = CARD_STYLE[unit.level] ?? CARD_STYLE[4];

  return (
    <div className="flex flex-col items-center">
      {/* ── Card ── */}
      <div className={`relative border-2 rounded-xl bg-white shadow-sm ${cs.border}`} style={{ minWidth: 148, maxWidth: 172 }}>
        {/* Card header strip */}
        <div className={`${cs.header} rounded-t-[10px] px-3 py-2 flex items-center justify-between gap-1`}>
          <span className={`text-[9px] px-1.5 py-0.5 rounded ${cs.badge}`} style={{ fontWeight: 700 }}>L{unit.level}</span>
          <div className="flex items-center gap-0.5">
            {children.length > 0 && (
              <button
                type="button"
                onClick={() => setCollapsed((c) => !c)}
                className="w-5 h-5 rounded flex items-center justify-center hover:bg-black/10 transition-colors"
                title={collapsed ? 'Expand' : 'Collapse'}
              >
                <ChevronDown className={`w-3 h-3 ${cs.text} opacity-70 transition-transform duration-200 ${collapsed ? '-rotate-90' : ''}`} />
              </button>
            )}
            <button
              type="button"
              onClick={() => onAdd(unit.id)}
              className="w-5 h-5 rounded flex items-center justify-center hover:bg-black/10 transition-colors"
              title="Add sub-unit or developer"
            >
              <Plus className={`w-3 h-3 ${cs.text} opacity-70`} />
            </button>
            <button
              type="button"
              onClick={() => onDelete(unit.id)}
              className="w-5 h-5 rounded flex items-center justify-center hover:bg-red-100 transition-colors"
              title="Delete unit"
            >
              <Minus className="w-3 h-3 text-red-400" />
            </button>
          </div>
        </div>

        {/* Card body */}
        <div className="px-3 pb-3 pt-2">
          <p className="text-[12px] text-gray-800 text-center break-words leading-snug" style={{ fontWeight: 700, wordBreak: 'break-word', whiteSpace: 'normal' }}>{unit.name}</p>
          {Array.isArray(unit.projects) && unit.projects.length > 0 ? (
            <p className="text-[10px] text-indigo-600 text-center mt-0.5 truncate" title={unit.projects.join(', ')}>
              {unit.projects[0]}{unit.projects.length > 1 ? ` · +${unit.projects.length - 1} more` : ''}
            </p>
          ) : null}

          {/* Avatars */}
          {unitDevs.length > 0 ? (
            <div className="flex flex-col items-center">
              <AvatarStrip devs={unitDevs} />
              {/* Show all full names, highlight managers */}
              <div className="mt-1.5 flex flex-wrap justify-center gap-1">
                {unitDevs.map((d) => (
                  <span
                    key={d.id}
                    className={`px-1.5 py-0.5 rounded-full text-[10px] border ${d.isManager ? 'bg-amber-50 border-amber-200 text-amber-700 font-semibold' : 'bg-gray-50 border-gray-200 text-gray-700'}`}
                  >
                    {d.name} {d.surname}
                  </span>
                ))}
              </div>
            </div>
          ) : (
            <p className="text-[10px] text-gray-300 text-center mt-1">no members</p>
          )}
        </div>
      </div>

      {/* ── Children ── */}
      {!collapsed && children.length > 0 && (
        <>
          <div className="w-px bg-gray-300" style={{ height: 20 }} />
          <div className="flex items-start">
            {children.map((child, idx) => {
              const isFirst = idx === 0;
              const isLast = idx === children.length - 1;
              const isOnly = children.length === 1;
              return (
                <div key={child.id} className="flex flex-col items-center">
                  <div className="flex w-full" style={{ height: 20 }}>
                    <div style={{ flex: 1, borderTop: !isFirst && !isOnly ? '1px solid #d1d5db' : 'none' }} />
                    <div style={{ width: 1, backgroundColor: '#d1d5db' }} />
                    <div style={{ flex: 1, borderTop: !isLast && !isOnly ? '1px solid #d1d5db' : 'none' }} />
                  </div>
                  <div className="px-3 pb-4">
                    <OrgChartNode unit={child} units={units} developers={developers} onAdd={onAdd} onDelete={onDelete} />
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}

// ─── Org editor modal (with dev search) ──────────────────────────────────────

function OrgEditorModal({
  units, developers, onClose, onDeleteDev, onMoveDev, onDeleteUnit,
}: {
  units: OrgUnit[];
  developers: Developer[];
  onClose: () => void;
  onDeleteDev: (id: string) => void;
  onMoveDev: (devId: string, toUnitId: string) => void;
  onDeleteUnit: (id: string) => void;
}) {
  const [search, setSearch] = useState('');
  const [movingDev, setMovingDev] = useState<string | null>(null);
  const [moveTarget, setMoveTarget] = useState('');

  const query = search.trim().toLowerCase();
  const filteredDevs = query
    ? developers.filter((d) => d.surname.toLowerCase().includes(query) || d.name.toLowerCase().includes(query))
    : null;

  function handleMove(devId: string) {
    if (!moveTarget) return;
    onMoveDev(devId, moveTarget);
    setMovingDev(null);
    setMoveTarget('');
  }

  const sortedUnits = [...units].sort((a, b) => a.level - b.level);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
      <div className="bg-white w-full max-w-3xl max-h-[88vh] rounded-2xl shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <div className="flex items-center gap-2.5">
            <Building2 className="w-5 h-5 text-indigo-500" />
            <h2 className="text-[16px] text-gray-900" style={{ fontWeight: 600 }}>Edit Organization</h2>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors">
            <X className="w-4 h-4 text-gray-500" />
          </button>
        </div>

        {/* Search bar */}
        <div className="px-6 py-3 border-b border-gray-100">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              className="w-full pl-9 pr-3 py-2 rounded-lg border border-gray-200 text-[13px] text-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder-gray-400"
              placeholder="Search developer by name or surname…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              autoFocus
            />
            {search && (
              <button onClick={() => setSearch('')} className="absolute right-2.5 top-1/2 -translate-y-1/2 p-0.5 rounded hover:bg-gray-100">
                <X className="w-3.5 h-3.5 text-gray-400" />
              </button>
            )}
          </div>
          {filteredDevs && (
            <p className="text-[11px] text-gray-400 mt-1.5">
              {filteredDevs.length === 0 ? 'No developers found.' : `Showing ${filteredDevs.length} result${filteredDevs.length !== 1 ? 's' : ''} for "${search.trim()}"`}
            </p>
          )}
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {/* Search results mode */}
          {filteredDevs ? (
            filteredDevs.length === 0 ? (
              <p className="text-[13px] text-gray-400 text-center py-8 italic">No developers match your search.</p>
            ) : (
              <div className="space-y-2">
                {filteredDevs.map((dev) => {
                  const devUnit = units.find((u) => u.id === dev.unitId);
                  return (
                    <div key={dev.id} className="flex items-center justify-between px-4 py-3 rounded-xl border border-gray-200 bg-gray-50">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-400 to-violet-500 flex items-center justify-center text-[11px] text-white flex-shrink-0" style={{ fontWeight: 700 }}>
                          {dev.name[0]}{dev.surname[0]}
                        </div>
                        <div>
                          <p className="text-[13px] text-gray-800" style={{ fontWeight: 600 }}>{dev.name} <span className="text-indigo-600">{dev.surname}</span></p>
                          <p className="text-[11px] text-gray-400">@{dev.login} · {dev.language} · {devUnit?.name ?? '—'}</p>
                        </div>
                        <span className={`text-[10px] px-1.5 py-0.5 rounded ${LEVEL_COLORS[dev.level]}`} style={{ fontWeight: 600 }}>{dev.level}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        {movingDev === dev.id ? (
                          <div className="flex items-center gap-1.5">
                            <select value={moveTarget} onChange={(e) => setMoveTarget(e.target.value)} className="text-[11px] border border-gray-200 rounded-lg px-2 py-1 focus:outline-none focus:ring-1 focus:ring-indigo-500 appearance-none">
                              <option value="">Select unit…</option>
                              {units.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
                            </select>
                            <button onClick={() => handleMove(dev.id)} className="p-1 rounded-lg text-indigo-600 hover:bg-indigo-50"><Check className="w-3.5 h-3.5" /></button>
                            <button onClick={() => { setMovingDev(null); setMoveTarget(''); }} className="p-1 rounded-lg text-gray-400 hover:bg-gray-100"><X className="w-3.5 h-3.5" /></button>
                          </div>
                        ) : (
                          <button onClick={() => { setMovingDev(dev.id); setMoveTarget(''); }} className="p-1.5 rounded-lg text-gray-400 hover:bg-gray-100" title="Move"><ArrowRightLeft className="w-3.5 h-3.5" /></button>
                        )}
                        <button onClick={() => onDeleteDev(dev.id)} className="p-1.5 rounded-lg text-red-400 hover:bg-red-50"><Trash2 className="w-3.5 h-3.5" /></button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )
          ) : (
            // Normal unit-grouped view
            <>
              {sortedUnits.length === 0 && <p className="text-[13px] text-gray-400 text-center py-8">No units yet.</p>}
              {sortedUnits.map((unit) => {
                const unitDevs = developers.filter((d) => d.unitId === unit.id);
                const parent = units.find((u) => u.id === unit.linkedTo);
                return (
                  <div key={unit.id} className="rounded-xl border border-gray-200 overflow-hidden">
                    <div className="flex items-center justify-between bg-gray-50 px-4 py-3">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-600" style={{ fontWeight: 600 }}>L{unit.level}</span>
                        <span className="text-[14px] text-gray-800" style={{ fontWeight: 600 }}>{unit.name}</span>
                        {parent && <span className="text-[11px] text-gray-400">↳ {parent.name}</span>}
                      </div>
                      <button onClick={() => onDeleteUnit(unit.id)} className="p-1.5 rounded-lg text-red-400 hover:bg-red-50"><Trash2 className="w-3.5 h-3.5" /></button>
                    </div>
                    {unitDevs.length === 0 ? (
                      <p className="text-[12px] text-gray-400 px-4 py-3 italic">No developers</p>
                    ) : (
                      <div className="divide-y divide-gray-100">
                        {unitDevs.map((dev) => (
                          <div key={dev.id} className="flex items-center justify-between px-4 py-2.5">
                            <div className="flex items-center gap-3">
                              <div className="w-7 h-7 rounded-full bg-gradient-to-br from-indigo-400 to-violet-500 flex items-center justify-center text-[10px] text-white flex-shrink-0" style={{ fontWeight: 700 }}>
                                {dev.name[0]}{dev.surname[0]}
                              </div>
                              <div>
                                <p className="text-[13px] text-gray-800">{dev.name} {dev.surname}</p>
                                <p className="text-[11px] text-gray-400">@{dev.login} · {dev.language}</p>
                              </div>
                              <span className={`text-[10px] px-1.5 py-0.5 rounded ${LEVEL_COLORS[dev.level]}`} style={{ fontWeight: 600 }}>{dev.level}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              {movingDev === dev.id ? (
                                <div className="flex items-center gap-1.5">
                                  <select value={moveTarget} onChange={(e) => setMoveTarget(e.target.value)} className="text-[11px] border border-gray-200 rounded-lg px-2 py-1 focus:outline-none focus:ring-1 focus:ring-indigo-500 appearance-none">
                                    <option value="">Select unit…</option>
                                    {units.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
                                  </select>
                                  <button onClick={() => handleMove(dev.id)} className="p-1 rounded-lg text-indigo-600 hover:bg-indigo-50"><Check className="w-3.5 h-3.5" /></button>
                                  <button onClick={() => { setMovingDev(null); setMoveTarget(''); }} className="p-1 rounded-lg text-gray-400 hover:bg-gray-100"><X className="w-3.5 h-3.5" /></button>
                                </div>
                              ) : (
                                <button onClick={() => { setMovingDev(dev.id); setMoveTarget(''); }} className="p-1.5 rounded-lg text-gray-400 hover:bg-gray-100" title="Move"><ArrowRightLeft className="w-3.5 h-3.5" /></button>
                              )}
                              <button onClick={() => onDeleteDev(dev.id)} className="p-1.5 rounded-lg text-red-400 hover:bg-red-50"><Trash2 className="w-3.5 h-3.5" /></button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </>
          )}
        </div>

        <div className="px-6 py-4 border-t border-gray-100">
          <button onClick={onClose} className="px-4 py-2 rounded-lg bg-gray-100 text-[13px] text-gray-700 hover:bg-gray-200 transition-colors">Close</button>
        </div>
      </div>
    </div>
  );
}

// ─── Upload modal ─────────────────────────────────────────────────────────────

function UploadModal({ onClose }: { onClose: () => void }) {
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const ref = useRef<HTMLInputElement>(null);

  function onChange(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    if (!f.name.endsWith('.yml') && !f.name.endsWith('.yaml')) {
      setError('Invalid file type. Please upload a .yml or .yaml file.');
      setFile(null);
      return;
    }
    setError('');
    setFile(f);
  }

  function confirm() {
    if (!file) return;
    setSuccess(true);
    setTimeout(() => onClose(), 1800);
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <div className="flex items-center gap-2.5"><Upload className="w-5 h-5 text-sky-500" /><h2 className="text-[15px] text-gray-900" style={{ fontWeight: 600 }}>Upload organization file</h2></div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors"><X className="w-4 h-4 text-gray-500" /></button>
        </div>
        <div className="px-6 py-5 space-y-4">
          <div className="flex items-start gap-3 bg-amber-50 border border-amber-200 rounded-xl px-4 py-3">
            <AlertCircle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-[13px] text-amber-800" style={{ fontWeight: 600 }}>Required format: YML</p>
              <p className="text-[12px] text-amber-700 mt-0.5">File must be a valid <strong>.yml</strong> or <strong>.yaml</strong> file describing your organization.</p>
            </div>
          </div>
          <div className="border-2 border-dashed border-gray-200 rounded-xl p-6 flex flex-col items-center gap-3 cursor-pointer hover:border-sky-400 hover:bg-sky-50/40 transition-colors" onClick={() => ref.current?.click()}>
            <div className="w-10 h-10 rounded-full bg-sky-50 flex items-center justify-center"><FileText className="w-5 h-5 text-sky-500" /></div>
            {file ? (
              <div className="text-center">
                <p className="text-[13px] text-gray-800" style={{ fontWeight: 600 }}>{file.name}</p>
                <p className="text-[11px] text-gray-400 mt-0.5">{(file.size / 1024).toFixed(1)} KB · click to change</p>
              </div>
            ) : (
              <div className="text-center">
                <p className="text-[13px] text-gray-700" style={{ fontWeight: 500 }}>Click to select a file</p>
                <p className="text-[11px] text-gray-400 mt-0.5">Supported: <strong>.yml</strong>, <strong>.yaml</strong></p>
              </div>
            )}
            <input ref={ref} type="file" accept=".yml,.yaml" className="hidden" onChange={onChange} />
          </div>
          {error && <div className="flex items-center gap-2 text-[12px] text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2"><AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />{error}</div>}
          {success && <div className="flex items-center gap-2 text-[12px] text-emerald-700 bg-emerald-50 border-emerald-200 rounded-lg px-3 py-2"><Check className="w-3.5 h-3.5 flex-shrink-0" />Organization imported successfully!</div>}
        </div>
        <div className="flex justify-end gap-2 px-6 pb-5">
          <button onClick={onClose} className="px-4 py-2 rounded-lg text-[13px] text-gray-600 hover:bg-gray-200 transition-colors">Cancel</button>
          <button onClick={confirm} disabled={!file || !!error || success} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-700 disabled:opacity-40 disabled:cursor-not-allowed text-white text-[13px] transition-colors" style={{ fontWeight: 500 }}>
            <Upload className="w-3.5 h-3.5" /> Import
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Main Setup Organization page ────────────────────────────────────────────

export function SetupOrganization() {
  const navigate = useNavigate();
  const [units, setUnits] = useState<OrgUnit[]>([]);
  const [developers, setDevelopers] = useState<Developer[]>([]);
  const [loadingOrg, setLoadingOrg] = useState<boolean>(true);
  const [toast, setToast] = useState('');

  // Branding state (app name and logo)
  const [brandName, setBrandName] = useState<string>(() => {
    try {
      return localStorage.getItem('app.brand.name') || '';
    } catch {
      return '';
    }
  });
  const [brandLogo, setBrandLogo] = useState<string>(() => {
    try {
      return localStorage.getItem('app.brand.logo') || '';
    } catch {
      return '';
    }
  });
  const [brandError, setBrandError] = useState<string>('');
  const [savingBrand, setSavingBrand] = useState<boolean>(false);

  function onPickBrandLogo(e: any) {
    const file = e.target.files?.[0];
    if (!file) return;
    setBrandError('');
    const validTypes = ['image/png', 'image/jpeg', 'image/svg+xml'];
    if (!validTypes.includes(file.type)) {
      setBrandError('Unsupported file type. Please upload PNG, JPG, or SVG.');
      return;
    }
    const maxBytes = 1024 * 1024 * 2; // 2MB
    if (file.size > maxBytes) {
      setBrandError('File is too large. Max size is 2MB.');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result || '');
      setBrandLogo(result);
    };
    reader.onerror = () => setBrandError('Failed to read the file.');
    reader.readAsDataURL(file);
  }

  function saveBranding() {
    setSavingBrand(true);
    try {
      const name = (brandName || '').trim();
      if (name) localStorage.setItem('app.brand.name', name); else localStorage.removeItem('app.brand.name');
      if (brandLogo) localStorage.setItem('app.brand.logo', brandLogo); else localStorage.removeItem('app.brand.logo');

      // Notify app (same-tab) about immediate branding update
      try {
        const evt = new CustomEvent('app.brand.updated', {
          detail: { name, logo: brandLogo }
        });
        window.dispatchEvent(evt);
      } catch (_e) { /* ignore */ }

      setToast('Branding saved');
      setTimeout(() => setToast(''), 1500);
    } catch (e) {
      console.error(e);
      setBrandError('Failed to save branding');
    } finally {
      setSavingBrand(false);
    }
  }

  function resetBranding() {
    setBrandName('');
    setBrandLogo('');
    setBrandError('');
    try {
      localStorage.removeItem('app.brand.name');
      localStorage.removeItem('app.brand.logo');
      // Notify app (same-tab) about reset
      try {
        const evt = new CustomEvent('app.brand.updated', {
          detail: { name: '', logo: '' }
        });
        window.dispatchEvent(evt);
      } catch (_e) { /* ignore */ }
    } catch {}
  }

  // Load organization from API and build flat units with people resolved
  useEffect(() => {
    let cancelled = false;

    function splitName(full?: string | null): { name: string; surname: string } {
      const s = (full || '').trim();
      if (!s) return { name: 'Unknown', surname: '' };
      const parts = s.split(/\s+/).filter(Boolean);
      if (parts.length === 1) return { name: parts[0], surname: '' };
      return { name: parts.slice(0, -1).join(' '), surname: parts[parts.length - 1] };
    }

    function deriveLogin(email?: string | null, fallbackName?: string | null): string {
      if (email && typeof email === 'string' && email.includes('@')) return email.split('@')[0];
      const s = (fallbackName || '').trim();
      return s ? s.toLowerCase().replace(/\s+/g, '.') : 'user';
    }

    async function load() {
      setLoadingOrg(true);
      const [tree, people] = await Promise.all([fetchOrganizationTree(), fetchPeoples()]);
      if (cancelled) return;
      if (tree) {
        const acc: OrgUnit[] = [];
        flattenOrg(tree, 0, null, acc);
        setUnits(acc);

        // Build developers array by resolving managerIds and memberIds per unit
        const byId: Record<string, ApiPerson> = {};
        (people || []).forEach((p) => {
          if (p && typeof p.id === 'string') {
            byId[p.id] = p as ApiPerson;
            const email = typeof p.email === 'string' ? p.email : '';
            if (email && email.includes('@')) {
              const login = email.split('@')[0];
              if (login) byId[login] = p as ApiPerson;
            }
          }
        });

        const devs: Developer[] = [];
        acc.forEach((u) => {
          const managers = Array.isArray(u.managerIds) ? u.managerIds : [];
          const members = Array.isArray(u.memberIds) ? u.memberIds : [];
          const all = [...new Set([...managers, ...members])];
          all.forEach((pid) => {
            const p = byId[pid];
            if (!p) return;
            // Skip technical users (do not display on unit cards)
            if (p.technical) return;
            const { name, surname } = splitName(p.name);
            const login = deriveLogin(p.email, p.name);
            devs.push({
              id: pid,
              name,
              surname,
              login,
              email: p.email || '',
              language: '—',
              level: 'Mid',
              unitId: u.id,
              otherEmails: Array.isArray(p.commiterEmails) ? p.commiterEmails.join(', ') : undefined,
              isManager: managers.includes(pid),
            });
          });
        });
        setDevelopers(devs);
      } else {
        // fallback demo org if API unavailable
        setUnits([
          { id: 'u1', name: 'Engineering', level: 0, linkedTo: null },
          { id: 'u2', name: 'Frontend', level: 1, linkedTo: 'u1' },
          { id: 'u3', name: 'Backend', level: 1, linkedTo: 'u1' },
          { id: 'u4', name: 'Mobile', level: 1, linkedTo: 'u1' },
          { id: 'u5', name: 'Platform', level: 2, linkedTo: 'u3' },
        ]);
        setDevelopers([
          { id: 'd1', name: 'Alice', surname: 'Smith', login: 'asmith', email: 'alice@acme.com', language: 'TypeScript', level: 'Senior', unitId: 'u2' },
          { id: 'd2', name: 'Bob', surname: 'Jones', login: 'bjones', email: 'bob@acme.com', language: 'Python', level: 'Mid', unitId: 'u3' },
          { id: 'd3', name: 'Carol', surname: 'White', login: 'cwhite', email: 'carol@acme.com', language: 'Go', level: 'Tech Lead', unitId: 'u3' },
          { id: 'd4', name: 'Dan', surname: 'Brown', login: 'dbrown', email: 'dan@acme.com', language: 'Swift', level: 'Senior', unitId: 'u4' },
          { id: 'd5', name: 'Eva', surname: 'Garcia', login: 'egarcia', email: 'eva@acme.com', language: 'Kotlin', level: 'Mid', unitId: 'u4' },
          { id: 'd6', name: 'Frank', surname: 'Lee', login: 'flee', email: 'frank@acme.com', language: 'Rust', level: 'Junior', unitId: 'u5' },
          { id: 'd7', name: 'Grace', surname: 'Kim', login: 'gkim', email: 'grace@acme.com', language: 'Java', level: 'Senior', unitId: 'u2' },
          { id: 'd8', name: 'Hank', surname: 'Taylor', login: 'htaylor', email: 'hank@acme.com', language: 'C#', level: 'Mid', unitId: 'u2' },
        ]);
      }
      setLoadingOrg(false);
    }
    load();
    return () => { cancelled = true; };
  }, []);

  // Modals
  const [addToUnitId, setAddToUnitId] = useState<string | null>(null);
  const [deleteUnitId, setDeleteUnitId] = useState<string | null>(null);
  const [orgEditorOpen, setOrgEditorOpen] = useState(false);
  const [uploadOpen, setUploadOpen] = useState(false);

  // Org chart autoscale
  const containerRef = useRef<HTMLDivElement | null>(null);
  const contentRef = useRef<HTMLDivElement | null>(null);
  const [chartScale, setChartScale] = useState(1);
  const [userZoom, setUserZoom] = useState(false);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);

  const MIN_SCALE = 0.5;
  const MAX_SCALE = 2.0;
  const STEP = 0.1;

  function clampScale(v: number) {
    return Math.max(MIN_SCALE, Math.min(MAX_SCALE, Number.isFinite(v) ? v : 1));
  }

  function zoomIn() {
    setUserZoom(true);
    setChartScale((s) => clampScale(Math.round((s + STEP) * 100) / 100));
  }

  function zoomOut() {
    setUserZoom(true);
    setChartScale((s) => clampScale(Math.round((s - STEP) * 100) / 100));
  }

  function resetZoom() {
    // Return control to autoscale and give it a sensible starting point
    setUserZoom(false);
    setChartScale(1);
  }

  function updateScrollHints() {
    const el = containerRef.current;
    if (!el) return;
    const { scrollLeft, scrollWidth, clientWidth } = el;
    const hasOverflow = scrollWidth > clientWidth + 1;
    setCanScrollLeft(hasOverflow && scrollLeft > 0);
    setCanScrollRight(hasOverflow && scrollLeft < scrollWidth - clientWidth - 1);
  }

  // Recompute scale to keep the whole org chart visible horizontally
  useEffect(() => {
    const container = containerRef.current;
    const content = contentRef.current;
    if (!container || !content) return;

    function recompute() {
      const containerWidth = container.clientWidth || 0;
      // Use scrollWidth to get unscaled natural width
      const contentWidth = content.scrollWidth || content.getBoundingClientRect().width || 0;
      if (userZoom) {
        // When user adjusted zoom, keep current scale and only update scroll hints
        updateScrollHints();
        return;
      }
      if (containerWidth <= 0 || contentWidth <= 0) {
        setChartScale(1);
        updateScrollHints();
        return;
      }
      // Leave a small margin so it doesn't touch edges
      const margin = 24; // px
      const available = Math.max(0, containerWidth - margin);
      const scale = Math.min(1, available / contentWidth);
      setChartScale(Number.isFinite(scale) && scale > 0 ? scale : 1);
      updateScrollHints();
    }

    // Initial compute (after paint)
    const raf = requestAnimationFrame(recompute);

    // Observe size changes of container and content
    let ro: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined') {
      ro = new ResizeObserver(() => recompute());
      ro.observe(container);
      ro.observe(content);
    } else {
      window.addEventListener('resize', recompute);
    }

    return () => {
      cancelAnimationFrame(raf);
      if (ro) {
        try { ro.disconnect(); } catch {}
      } else {
        window.removeEventListener('resize', recompute);
      }
    };
  }, [units, developers]);

  async function handleAddUnit(name: string, type: string, parentUnitId: string) {
    try {
      // Call backend API to add organization unit
      const res = await fetch('/api/admin/organization/add', {
        method: 'PUT',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify({ name, type, parentUnitId }),
      });
      if (!res.ok) {
        throw new Error('Failed to add unit');
      }
      // Refresh organization tree after successful add
      const [tree, people] = await Promise.all([fetchOrganizationTree(), fetchPeoples()]);
      if (tree) {
        const acc: OrgUnit[] = [];
        flattenOrg(tree, 0, null, acc);
        setUnits(acc);
        const byId: Record<string, ApiPerson> = {};
        (people || []).forEach((p) => {
          if (p && typeof p.id === 'string') {
            byId[p.id] = p as ApiPerson;
            const email = typeof p.email === 'string' ? p.email : '';
            if (email && email.includes('@')) {
              const login = email.split('@')[0];
              if (login) byId[login] = p as ApiPerson;
            }
          }
        });
        const devs: Developer[] = [];
        acc.forEach((u) => {
          const managers = Array.isArray(u.managerIds) ? u.managerIds : [];
          const members = Array.isArray(u.memberIds) ? u.memberIds : [];
          const all = [...new Set([...managers, ...members])];
          all.forEach((pid) => {
            const p = byId[pid];
            if (!p || p.technical) return;
            const full = (p.name || '').trim();
            const parts = full ? full.split(/\s+/).filter(Boolean) : [];
            const first = parts.length <= 1 ? (parts[0] || 'Unknown') : parts.slice(0, -1).join(' ');
            const last = parts.length <= 1 ? '' : parts[parts.length - 1];
            const login = p.email && p.email.includes('@') ? p.email.split('@')[0] : (p.name || '').trim().toLowerCase().replace(/\s+/g, '.') || 'user';
            devs.push({
              id: pid,
              name: first,
              surname: last,
              login,
              email: p.email || '',
              language: '—',
              level: 'Mid',
              unitId: u.id,
              otherEmails: Array.isArray(p.commiterEmails) ? p.commiterEmails.join(', ') : undefined,
              isManager: managers.includes(pid),
            });
          });
        });
        setDevelopers(devs);
      }
      // Notify other parts of the app (e.g., Layout) that organization changed
      try { window.dispatchEvent(new Event('organization.changed')); } catch {}
      // Show success toast
      setToast('Operation succeeded');
      setTimeout(() => setToast(''), 1200);
    } catch (e) {
      console.error(e);
      setToast('Operation failed');
      setTimeout(() => setToast(''), 2000);
      throw e;
    }
  }

  async function handleAddManager(unitId: string, manager: string) {
    try {
      const res = await fetch(`/api/admin/organization/${encodeURIComponent(unitId)}/manager`, {
        method: 'PUT',
        credentials: 'include',
        headers: { 'Content-Type': 'text/plain', 'Accept': 'application/json' },
        body: manager,
      });
      if (!res.ok) {
        throw new Error('Failed to add manager');
      }
      // Refresh organization tree to reflect new manager
      const [tree, people] = await Promise.all([fetchOrganizationTree(), fetchPeoples()]);
      if (tree) {
        const acc: OrgUnit[] = [];
        flattenOrg(tree, 0, null, acc);
        setUnits(acc);
        const byId: Record<string, ApiPerson> = {};
        (people || []).forEach((p) => { if (p && typeof p.id === 'string') byId[p.id] = p as ApiPerson; });
        const devs: Developer[] = [];
        acc.forEach((u) => {
          const managers = Array.isArray(u.managerIds) ? u.managerIds : [];
          const members = Array.isArray(u.memberIds) ? u.memberIds : [];
          const all = [...new Set([...managers, ...members])];
          all.forEach((pid) => {
            const p = byId[pid];
            if (!p || p.technical) return;
            const full = (p.name || '').trim();
            const parts = full ? full.split(/\s+/).filter(Boolean) : [];
            const first = parts.length <= 1 ? (parts[0] || 'Unknown') : parts.slice(0, -1).join(' ');
            const last = parts.length <= 1 ? '' : parts[parts.length - 1];
            const login = p.email && p.email.includes('@') ? p.email.split('@')[0] : (p.name || '').trim().toLowerCase().replace(/\s+/g, '.') || 'user';
            devs.push({
              id: pid,
              name: first,
              surname: last,
              login,
              email: p.email || '',
              language: '—',
              level: 'Mid',
              unitId: u.id,
              otherEmails: Array.isArray(p.commiterEmails) ? p.commiterEmails.join(', ') : undefined,
              isManager: managers.includes(pid),
            });
          });
        });
        setDevelopers(devs);
      }
      // Notify others about organization change
      try { window.dispatchEvent(new Event('organization.changed')); } catch {}
      setToast('Operation succeeded');
      setTimeout(() => setToast(''), 1200);
    } catch (e) {
      console.error(e);
      setToast('Operation failed');
      setTimeout(() => setToast(''), 2000);
      throw e;
    }
  }

  async function handleAddDev(dev: Omit<Developer, 'id'>) {
    try {
      // Map local Developer form to People API shape
      const nameFull = `${dev.name} ${dev.surname}`.trim();
      const primaryEmail = (dev.email || '').trim();
      const others = (dev as any).otherEmails ? String((dev as any).otherEmails) : '';
      const otherList = others
        .split(/[,;\s]+/)
        .map((s) => s.trim())
        .filter((s) => s.length > 0);
      const emails = [primaryEmail, ...otherList]
        .map((e) => e.toLowerCase())
        .filter((v, i, a) => v && a.indexOf(v) === i);

      // Map level to API enum style (e.g., JUNIOR, MID, SENIOR, TECH_LEAD)
      const levelApi = ((): string | undefined => {
        const map: Record<string, string> = {
          Junior: 'JUNIOR',
          Mid: 'REGULAR',
          Senior: 'SENIOR',
          'Tech Lead': 'LEAD',
        };
        return map[dev.level] || (dev.level ? dev.level.toUpperCase().replace(/\s+/g, '_') : undefined);
      })();

      const skillsApi = (() => {
        const lang = (dev.language || '').trim();
        if (!lang) return undefined;
        return [lang];
      })();

      const payload: ApiPerson = {
        id: dev.login || primaryEmail || genId(),
        name: nameFull || dev.login || primaryEmail,
        email: primaryEmail || undefined,
        commiterEmails: emails.length ? emails : undefined,
        technical: false,
        admin: dev.isManager === true ? true : false,
        level: levelApi || null,
        skills: skillsApi || null,
      };

      const res = await fetch(`/api/admin/organization/peoples/save`, {
        method: 'PUT',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        throw new Error('Failed to add developer');
      }

      // After saving the person, add them to the selected unit as a member
      try {
        const resMember = await fetch(`/api/admin/organization/${encodeURIComponent(dev.unitId)}/member`, {
          method: 'PUT',
          credentials: 'include',
          headers: { 'Content-Type': 'text/plain', 'Accept': 'application/json' },
          body: dev.login,
        });
        if (!resMember.ok) {
          throw new Error('Failed to add member to unit');
        }
      } catch (e) {
        // Surface error but continue to refresh to keep UI consistent
        console.error(e);
      }

      // Refresh organization tree and people to reflect the change
      const [tree, people] = await Promise.all([fetchOrganizationTree(), fetchPeoples()]);
      if (tree) {
        const acc: OrgUnit[] = [];
        flattenOrg(tree, 0, null, acc);
        setUnits(acc);
        const byId: Record<string, ApiPerson> = {};
        (people || []).forEach((p) => { if (p && typeof p.id === 'string') byId[p.id] = p as ApiPerson; });
        const devs: Developer[] = [];
        acc.forEach((u) => {
          const managers = Array.isArray(u.managerIds) ? u.managerIds : [];
          const members = Array.isArray(u.memberIds) ? u.memberIds : [];
          const all = [...new Set([...managers, ...members])];
          all.forEach((pid) => {
            const p = byId[pid];
            if (!p || p.technical) return;
            const full = (p.name || '').trim();
            const parts = full ? full.split(/\s+/).filter(Boolean) : [];
            const first = parts.length <= 1 ? (parts[0] || 'Unknown') : parts.slice(0, -1).join(' ');
            const last = parts.length <= 1 ? '' : parts[parts.length - 1];
            const login = p.email && p.email.includes('@') ? p.email.split('@')[0] : (p.name || '').trim().toLowerCase().replace(/\s+/g, '.') || 'user';
            devs.push({
              id: pid,
              name: first,
              surname: last,
              login,
              email: p.email || '',
              language: '—',
              level: 'Mid',
              unitId: u.id,
              otherEmails: Array.isArray(p.commiterEmails) ? p.commiterEmails.join(', ') : undefined,
              isManager: managers.includes(pid),
            });
          });
        });
        // Optimistic include: if the saved person is not yet linked in org tree, show them under the selected unit
        try {
          const newId = String(payload.id || '').trim();
          const newEmail = String(payload.email || '').trim().toLowerCase();
          const present = devs.some((d) => (newId && d.id === newId) || (newEmail && d.email.toLowerCase() === newEmail));
          if (!present) {
            const p = byId[newId] || Object.values(byId).find((pp) => (pp.email || '').toLowerCase() === newEmail) || null;
            const full = (p?.name || payload.name || '').trim();
            const parts = full ? full.split(/\s+/).filter(Boolean) : [];
            const first = parts.length <= 1 ? (parts[0] || 'Unknown') : parts.slice(0, -1).join(' ');
            const last = parts.length <= 1 ? '' : parts[parts.length - 1];
            const login = (p?.email && p.email.includes('@')) ? p.email.split('@')[0] : (full || newEmail || newId || 'user').toLowerCase().replace(/\s+/g, '.');
            devs.push({
              id: newId || genId(),
              name: first,
              surname: last,
              login,
              email: (p?.email || newEmail || ''),
              language: '—',
              level: 'Mid',
              unitId: dev.unitId,
              otherEmails: Array.isArray(p?.commiterEmails) ? p!.commiterEmails!.join(', ') : undefined,
              isManager: false,
            });
          }
        } catch {}
        setDevelopers(devs);
      }
      setToast('Operation succeeded');
      setTimeout(() => setToast(''), 1200);
    } catch (e) {
      console.error(e);
      setToast('Operation failed');
      setTimeout(() => setToast(''), 2000);
      throw e;
    }
  }

  async function handleDeleteUnit(id: string) {
    try {
      // Call backend API to delete organization unit
      const res = await fetch(`/api/admin/organization/${encodeURIComponent(id)}`, {
        method: 'DELETE',
        credentials: 'include',
      });
      if (!res.ok) {
        throw new Error(`Failed to delete unit (${res.status})`);
      }

      // Refresh organization tree and peoples after successful delete
      const [tree, people] = await Promise.all([fetchOrganizationTree(), fetchPeoples()]);
      if (tree) {
        const acc: OrgUnit[] = [];
        flattenOrg(tree, 0, null, acc);
        setUnits(acc);
        const byId: Record<string, ApiPerson> = {};
        (people || []).forEach((p) => { if (p && typeof p.id === 'string') byId[p.id] = p as ApiPerson; });
        const devs: Developer[] = [];
        acc.forEach((u) => {
          const managers = Array.isArray(u.managerIds) ? u.managerIds : [];
          const members = Array.isArray(u.memberIds) ? u.memberIds : [];
          const all = [...new Set([...managers, ...members])];
          all.forEach((pid) => {
            const p = byId[pid];
            if (!p || p.technical) return;
            const full = (p.name || '').trim();
            const parts = full ? full.split(/\s+/).filter(Boolean) : [];
            const first = parts.length <= 1 ? (parts[0] || 'Unknown') : parts.slice(0, -1).join(' ');
            const last = parts.length <= 1 ? '' : parts[parts.length - 1];
            const login = p.email && p.email.includes('@') ? p.email.split('@')[0] : (p.name || '').trim().toLowerCase().replace(/\s+/g, '.') || 'user';
            devs.push({
              id: pid,
              name: first,
              surname: last,
              login,
              email: p.email || '',
              language: '—',
              level: 'Mid',
              unitId: u.id,
              otherEmails: Array.isArray(p.commiterEmails) ? p.commiterEmails.join(', ') : undefined,
              isManager: managers.includes(pid),
            });
          });
        });
        setDevelopers(devs);
      } else {
        // Fallback: update local state optimistically
        setUnits((prev) => prev.filter((u) => u.id !== id));
        setDevelopers((prev) => prev.filter((d) => d.unitId !== id));
      }

      // Notify others about organization change and close modal
      try { window.dispatchEvent(new Event('organization.changed')); } catch {}
      setDeleteUnitId(null);
      setToast('Operation succeeded');
      setTimeout(() => setToast(''), 1200);
    } catch (e) {
      console.error(e);
      setToast('Operation failed');
      setTimeout(() => setToast(''), 2000);
      // Do not mutate state on failure
    }
  }

  function handleDeleteDev(id: string) {
    setDevelopers((prev) => prev.filter((d) => d.id !== id));
  }

  function handleMoveDev(devId: string, toUnitId: string) {
    setDevelopers((prev) => prev.map((d) => d.id === devId ? { ...d, unitId: toUnitId } : d));
  }

  const roots = units.filter((u) => !u.linkedTo || !units.find((p) => p.id === u.linkedTo));
  const addUnit = addToUnitId ? units.find((u) => u.id === addToUnitId) : null;
  const deleteUnit = deleteUnitId ? units.find((u) => u.id === deleteUnitId) : null;

  return (
    <div className="p-4 sm:p-6 mx-auto space-y-5">
      {/* Page header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-col items-start gap-2 sm:flex-row sm:items-center sm:gap-3 min-w-0">
          <button
            onClick={() => navigate('/settings')}
            className="shrink-0 flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-gray-200 text-[12px] text-gray-600 hover:bg-gray-50 transition-colors"
            aria-label="Back to Settings"
          >
            <ChevronLeft className="w-4 h-4 text-gray-500" /> Back
          </button>
          <div>
            <h1 className="text-[20px] text-gray-900" style={{ fontWeight: 700 }}>Setup Organization</h1>
            <p className="text-[13px] text-gray-500 mt-0.5">Configure your organization structure and team members.</p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setUploadOpen(true)}
            className="flex items-center gap-2 px-3 py-2 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 text-gray-700 text-[13px] transition-colors"
            style={{ fontWeight: 500 }}
          >
            <Upload className="w-4 h-4 text-sky-500" /> Upload org
          </button>
          <button
            onClick={() => setOrgEditorOpen(true)}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-[13px] transition-colors shadow-sm"
            style={{ fontWeight: 500 }}
          >
            <Pencil className="w-4 h-4" /> Edit organization
          </button>
        </div>
      </div>

      {/* Branding */}
      <section className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-3 px-4 sm:px-5 py-4 border-b border-gray-100">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="shrink-0 w-7 h-7 rounded-lg bg-indigo-50 flex items-center justify-center">
              <Upload className="w-4 h-4 text-indigo-500" />
            </div>
            <div>
              <h2 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>Branding</h2>
              <p className="text-[11px] text-gray-400">Set application name and upload logo (PNG, JPG, SVG)</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={resetBranding} className="px-3 py-1.5 rounded-lg border border-gray-200 text-[12px] text-gray-700 hover:bg-gray-50">Reset</button>
            <button onClick={saveBranding} disabled={savingBrand} className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white text-[12px]" style={{ fontWeight: 600 }}>Save</button>
          </div>
        </div>
        <div className="p-5 grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <p className="text-[12px] text-gray-600 mb-1" style={{ fontWeight: 600 }}>Logo preview</p>
            <div className="w-[88px] h-[88px] rounded-lg bg-gray-50 border border-gray-200 flex items-center justify-center overflow-hidden">
              {brandLogo ? (
                <img src={brandLogo} alt="App logo" className="w-full h-full object-contain" />
              ) : (
                <span className="text-[11px] text-gray-400">No logo</span>
              )}
            </div>
          </div>
          <div className="sm:col-span-2 grid grid-cols-1 gap-3">
            <div>
              <label className="block text-[12px] text-gray-600 mb-1" style={{ fontWeight: 600 }}>Application name</label>
              <input
                type="text"
                value={brandName}
                onChange={(e) => setBrandName(e.target.value)}
                placeholder="Enter application name"
                className="w-full px-3 py-2 rounded-lg border border-gray-300 text-[13px] focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-[12px] text-gray-600 mb-1" style={{ fontWeight: 600 }}>Logo file</label>
              <input
                type="file"
                accept="image/png,image/jpeg,image/svg+xml"
                onChange={onPickBrandLogo}
                className="block w-full text-[12px] text-gray-700 file:mr-3 file:py-2 file:px-3 file:rounded-lg file:border-0 file:text-[12px] file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100"
              />
              {brandError && <p className="mt-1 text-[12px] text-red-600">{brandError}</p>}
            </div>
          </div>
        </div>
      </section>

      {/* Stats bar */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Units', value: units.length, icon: Building2 },
          { label: 'Developers', value: developers.length, icon: Users },
          { label: 'Org levels used', value: [...new Set(units.map((u) => u.level))].length, icon: ChevronDown },
        ].map(({ label, value, icon: Icon }) => (
          <div key={label} className="min-w-0 bg-white rounded-xl border border-gray-200 px-3 sm:px-4 py-3 flex items-center gap-3">
            <div className="hidden sm:flex shrink-0 w-8 h-8 rounded-lg bg-indigo-50 items-center justify-center">
              <Icon className="w-4 h-4 text-indigo-500" />
            </div>
            <div className="min-w-0">
              <p className="text-[18px] text-gray-900" style={{ fontWeight: 700 }}>{value}</p>
              <p className="text-[11px] text-gray-500">{label}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Org chart */}
      <section className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-3 px-4 sm:px-5 py-4 border-b border-gray-100">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="shrink-0 w-7 h-7 rounded-lg bg-indigo-50 flex items-center justify-center">
              <Building2 className="w-4 h-4 text-indigo-500" />
            </div>
            <div>
              <h2 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>Organization chart</h2>
              <p className="text-[11px] text-gray-400">Click <Plus className="inline w-3 h-3" /> to add · <Minus className="inline w-3 h-3" /> to remove</p>
            </div>
          </div>
          {/* Zoom controls */}
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={resetZoom}
              className="p-1.5 rounded-md border border-gray-200 bg-white hover:bg-gray-50 text-gray-600"
              title="Reset zoom"
              aria-label="Reset zoom"
            >
              <RefreshCcw className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={zoomOut}
              disabled={chartScale <= MIN_SCALE}
              className={`p-1.5 rounded-md border border-gray-200 bg-white hover:bg-gray-50 ${chartScale <= MIN_SCALE ? 'opacity-50 cursor-not-allowed' : 'text-gray-600'}`}
              title="Zoom out"
              aria-label="Zoom out"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
            <div className="px-2 text-[12px] text-gray-600 min-w-[52px] text-center select-none">
              {Math.round(chartScale * 100)}%
            </div>
            <button
              type="button"
              onClick={zoomIn}
              disabled={chartScale >= MAX_SCALE}
              className={`p-1.5 rounded-md border border-gray-200 bg-white hover:bg-gray-50 ${chartScale >= MAX_SCALE ? 'opacity-50 cursor-not-allowed' : 'text-gray-600'}`}
              title="Zoom in"
              aria-label="Zoom in"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
          </div>
          {/* Legend: manager vs developer colors */}
          <div className="hidden sm:flex items-center gap-4 text-[11px] text-gray-600">
            <div className="inline-flex items-center gap-1.5">
              <span className="relative inline-flex items-center justify-center w-4 h-4 rounded-full border-2 bg-gradient-to-br from-amber-300 to-amber-400 border-amber-100">
                <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-amber-500 border border-white" />
              </span>
              <span className="text-gray-600">Manager</span>
            </div>
            <div className="inline-flex items-center gap-1.5">
              <span className="inline-flex items-center justify-center w-4 h-4 rounded-full border-2 bg-gradient-to-br from-indigo-300 to-violet-400 border-white" />
              <span className="text-gray-600">Developer</span>
            </div>
            <div className="inline-flex items-center gap-1.5">
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-700 border border-indigo-200" style={{ fontWeight: 600 }}>Project</span>
            </div>
          </div>
        </div>

        {loadingOrg ? (
          <p className="text-[13px] text-gray-400 text-center py-12 italic">Loading organization…</p>
        ) : roots.length === 0 ? (
          <p className="text-[13px] text-gray-400 text-center py-12 italic">No units yet. Add your first unit to get started.</p>
        ) : (
          <div className="relative" >
            <div
              className="overflow-x-auto"
              ref={containerRef}
              onScroll={updateScrollHints}
            >
              <div
                ref={contentRef}
                className="flex justify-center gap-8 px-6 py-6 min-w-max mx-auto"
                style={{ transform: `scale(${chartScale})`, transformOrigin: 'top center', width: 'max-content' }}
              >
                {roots.map((root) => (
                  <OrgChartNode
                    key={root.id}
                    unit={root}
                    units={units}
                    developers={developers}
                    onAdd={setAddToUnitId}
                    onDelete={setDeleteUnitId}
                  />
                ))}
              </div>
            </div>

            {/* Scroll arrows */}
            {canScrollLeft && (
              <button
                type="button"
                onClick={() => containerRef.current?.scrollBy({ left: -240, behavior: 'smooth' })}
                className="absolute left-2 top-1/2 -translate-y-1/2 z-10 p-1.5 rounded-full bg-white/70 text-gray-400 shadow-sm hover:bg-white hover:text-gray-500 transition-colors"
                aria-label="Scroll left"
                title="Scroll left"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
            )}
            {canScrollRight && (
              <button
                type="button"
                onClick={() => containerRef.current?.scrollBy({ left: 240, behavior: 'smooth' })}
                className="absolute right-2 top-1/2 -translate-y-1/2 z-10 p-1.5 rounded-full bg-white/70 text-gray-400 shadow-sm hover:bg-white hover:text-gray-500 transition-colors"
                aria-label="Scroll right"
                title="Scroll right"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            )}
          </div>
        )}
      </section>

      {/* Modals */}
      {addUnit && (
        <AddToUnitModal
          unit={addUnit}
          units={units}
          onClose={() => setAddToUnitId(null)}
          onAddUnit={handleAddUnit}
          onAddDev={handleAddDev}
          onAddManager={handleAddManager}
        />
      )}

      {deleteUnit && (
        <ConfirmDeleteModal
          unit={deleteUnit}
          devCount={developers.filter((d) => d.unitId === deleteUnit.id).length}
          onClose={() => setDeleteUnitId(null)}
          onConfirm={() => handleDeleteUnit(deleteUnit.id)}
        />
      )}

      {orgEditorOpen && (
        <OrgEditorModal
          units={units}
          developers={developers}
          onClose={() => setOrgEditorOpen(false)}
          onDeleteDev={handleDeleteDev}
          onMoveDev={handleMoveDev}
          onDeleteUnit={handleDeleteUnit}
        />
      )}

      {uploadOpen && <UploadModal onClose={() => setUploadOpen(false)} />}

      {toast && (
        <div className="fixed bottom-4 right-4 z-[60]">
          <div className="px-4 py-2 rounded-lg bg-emerald-600 text-white text-[13px] shadow-lg">
            {toast}
          </div>
        </div>
      )}
    </div>
  );
}

export default SetupOrganization;
