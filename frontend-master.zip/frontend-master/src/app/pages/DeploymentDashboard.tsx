import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  Rocket, Clock, RefreshCw, Percent, Star, Target, ChevronRight, FileDown, CheckCircle2, AlertTriangle, XCircle,
  ArrowUpRight, ArrowDownRight, Minus, Hammer,
} from 'lucide-react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { useIsDark } from '../hooks/useIsDark';
import { useDateRange } from '../context/DateRangeContext';
import { useTeam } from '../context/TeamContext';
import { usePick } from '../i18n';
import { parseCustomRange, rangeDays, toInterval } from '../utils/dateRange';

// Organization deployment report (DORA-style KPIs per organization unit), laid out for status meetings:
// one selected unit, its KPIs against targets, the trend, the sub-teams and applications, exportable to PDF.
// Live from core: the organization units (/api/organization), deployments (release tasks moved to LIVE),
// cycle time (Jira IN PROGRESS -> LIVE) and build fail rate, per unit and period. Core has no source yet for
// MTTR, change failure rate (both still "todo" there), work types, IT domains and applications: those stay
// generated deterministically per unit and are marked as sample data on the page.

// Explicit hex colors on purpose: theme.css remaps Tailwind indigo classes to brand green.
// Work type colors are a validated categorical set (distinct also for color-blind readers).
const C = {
  dep: '#3b82f6',
  mttr: '#eab308',
  cycle: '#a855f7',
  cfr: '#ef4444',
  biz: '#3b82f6',
  fix: '#f59e0b',
  release: '#a855f7',
  maint: '#14b8a6',
};

const APPLICATIONS = ['OneLook', 'CRM'];
const DOMAINS = ['All Domains', 'e-Commerce', 'Finance'];
const CHAPTERS = ['All Chapters', 'Frontend', 'Backend'];

type Status = 'Good' | 'Warning' | 'Bad';

type Point = {
  biz: number;
  fix: number;
  release: number;
  maint: number;
  fail: number;
  mttr: number;
  cycle: number;
};

type OrgNode = {
  id: string; // unit id of core, or the full path ("Tribe - Chapter - Squad") without organization data
  name: string;
  depth: number;
  path: string[];
  pathIds: string[];
  type?: string; // TRIBE / CHAPTER / SQUAD ... of core
  children: OrgNode[];
};

type Summary = {
  deployments: number;
  depSeries: number[];
  mttr: number;
  mttrSeries: number[];
  cycle: number;
  cycleSeries: number[];
  cfr: number;
  cfrSeries: number[];
  work: { biz: number; fix: number; release: number; maint: number };
};

// ---------- data ----------

/** Points of the sample series: days up to 2 weeks, weeks above. */
function periodCount(range: string): number {
  const days = rangeDays(range);
  return days <= 14 ? days : Math.ceil(days / 7);
}

function hashCode(str: string): number {
  let h = 0;
  for (let i = 0; i < str.length; i++) {
    h = (h << 5) - h + str.charCodeAt(i);
    h |= 0;
  }
  return Math.abs(h);
}

function generateSeries(n: number, seedName: string): Point[] {
  const seed = hashCode(seedName) % 97;
  return Array.from({ length: n }, (_, idx) => {
    const wave = Math.sin((idx + (seed % 5)) / 2) * 1.5 + Math.cos((idx + (seed % 7)) / 3) * 0.8;
    const base = 2 + ((seed % 4) + (idx % 5));
    const biz = Math.max(0, Math.round(base + 2 + wave + (idx % 3 === 0 ? 1 : 0)));
    const fix = Math.max(0, Math.round(1 + (seed % 3) * 0.5 + (idx % 4) * 0.6 + (wave > 0 ? 0.5 : 0)));
    const release = Math.max(0, Math.round(0.5 + (seed % 3) * 0.4 + (idx % 2) * 0.6));
    const maint = Math.max(0, Math.round((seed % 2 ? 1 : 0) + (idx % 3) * 0.5 + (wave < 0 ? 0.5 : 0)));
    const fail = ((idx + seed) % 9 === 1 ? 1 : 0) + ((idx + seed) % 7 === 0 ? 1 : 0);
    const mttr = Math.max(0.5, Math.round((2 + (seed % 6) + (idx % 4) + (Math.sin(idx + seed) + 1) * 1.2) * 10) / 10);
    const cycle = Math.max(6, Math.round((18 + ((seed % 10) + (idx % 6)) * 1.8 + (Math.cos((idx + seed) / 2) + 1) * 3) * 10) / 10);
    return { biz, fix, release, maint, fail, mttr, cycle };
  });
}

function buildTree(teams: string[]): OrgNode[] {
  const roots: OrgNode[] = [];
  const byId = new Map<string, OrgNode>();
  for (const team of teams) {
    const parts = team.split(' - ').map((p) => p.trim()).filter(Boolean);
    let siblings = roots;
    parts.forEach((name, depth) => {
      const path = parts.slice(0, depth + 1);
      const id = path.join(' - ');
      let node = byId.get(id);
      if (!node) {
        node = { id, name, depth, path, pathIds: path.map((_, i) => path.slice(0, i + 1).join(' - ')), children: [] };
        byId.set(id, node);
        siblings.push(node);
      }
      siblings = node.children;
    });
  }
  return roots;
}

/** The organization units of core as the tree of the page. */
function unitTree(units: UnitDto[], parent?: OrgNode): OrgNode[] {
  return units.filter((it) => it?.id).map((unit) => {
    const node: OrgNode = {
      id: String(unit.id),
      name: unit.name || String(unit.id),
      depth: parent ? parent.depth + 1 : 0,
      path: [...(parent?.path ?? []), unit.name || String(unit.id)],
      pathIds: [...(parent?.pathIds ?? []), String(unit.id)],
      type: unit.type,
      children: [],
    };
    node.children = unitTree(unit.units ?? [], node);
    return node;
  });
}

function leaves(node: OrgNode): OrgNode[] {
  return node.children.length === 0 ? [node] : node.children.flatMap(leaves);
}

function seriesFor(node: OrgNode, n: number): Point[] {
  const leafSeries = leaves(node).map((l) => generateSeries(n, l.id));
  return Array.from({ length: n }, (_, i) => {
    const pts = leafSeries.map((s) => s[i]);
    const sum = (k: keyof Point) => pts.reduce((a, p) => a + p[k], 0);
    const avg = (k: keyof Point) => Math.round((sum(k) / Math.max(1, pts.length)) * 10) / 10;
    return { biz: sum('biz'), fix: sum('fix'), release: sum('release'), maint: sum('maint'), fail: sum('fail'), mttr: avg('mttr'), cycle: avg('cycle') };
  });
}

function summarize(points: Point[]): Summary {
  const depSeries = points.map((p) => p.biz + p.fix + p.release + p.maint);
  const cfrSeries = points.map((p, i) => (depSeries[i] ? Math.round((p.fail / depSeries[i]) * 1000) / 10 : 0));
  const total = (k: keyof Point) => points.reduce((a, p) => a + p[k], 0);
  const deployments = depSeries.reduce((a, b) => a + b, 0);
  const avg = (arr: number[]) => (arr.length ? Math.round((arr.reduce((a, b) => a + b, 0) / arr.length) * 10) / 10 : 0);
  return {
    deployments,
    depSeries,
    mttr: avg(points.map((p) => p.mttr)),
    mttrSeries: points.map((p) => p.mttr),
    cycle: avg(points.map((p) => p.cycle)),
    cycleSeries: points.map((p) => p.cycle),
    cfr: deployments ? Math.round((total('fail') / deployments) * 1000) / 10 : 0,
    cfrSeries,
    work: { biz: total('biz'), fix: total('fix'), release: total('release'), maint: total('maint') },
  };
}

const statusOf = {
  mttr: (s: Summary): Status => (s.mttr < 9 ? 'Good' : s.mttr < 20 ? 'Warning' : 'Bad'),
  cfr: (s: Summary): Status => (s.cfr < 10 ? 'Good' : s.cfr < 25 ? 'Warning' : 'Bad'),
};

/** Change of the second half of the period against the first half, in %; null when there is nothing to compare. */
function halfChange(series: number[]): number | null {
  if (series.length < 2) return null;
  const mid = Math.floor(series.length / 2);
  const avg = (arr: number[]) => arr.reduce((a, b) => a + b, 0) / arr.length;
  const before = avg(series.slice(0, mid));
  const after = avg(series.slice(mid));
  return before ? Math.round(((after - before) / before) * 100) : null;
}

// ---------- live data (core) ----------

/** A metric of core (MetricValue): the value in the period and its change in % against the previous period. */
type Metric = { value: number; change: number };

type UnitLive = {
  deployments: Metric | null;
  cycle: Metric | null; // hours from IN PROGRESS to LIVE of the Jira tasks
  buildFailRate: Metric | null; // % of failed pipelines
  daily?: Array<{ date: string; value: number }> | null; // release tasks moved to LIVE per day
};

type UnitDto = { id: string; name: string; type?: string; units?: UnitDto[] | null };

async function fetchMetric(path: string, unitId: string, interval: string, signal: AbortSignal): Promise<Metric | null> {
  try {
    const res = await fetch(`/api/metrics/${path}?${new URLSearchParams({ unitId, interval })}`, { credentials: 'include', signal });
    if (!res.ok) return null;
    const js = await res.json();
    return typeof js?.value === 'number' ? { value: js.value, change: typeof js.change === 'number' ? js.change : 0 } : null;
  } catch {
    return null;
  }
}

async function fetchDaily(unitId: string, interval: string, signal: AbortSignal): Promise<UnitLive['daily']> {
  try {
    const res = await fetch(`/api/metrics/dora/chart/deployment?${new URLSearchParams({ unitId, interval })}`, { credentials: 'include', signal });
    if (!res.ok) return null;
    const js = await res.json();
    return Array.isArray(js?.values) ? js.values.map((it: { startDate?: unknown; value?: unknown }) => ({ date: String(it.startDate), value: Number(it.value) || 0 })) : null;
  } catch {
    return null;
  }
}

/** Live metrics of the selected unit (with the daily deployments) and of its sub-units, refetched on a change. */
function useLiveMetrics(selectedId: string | null, childIds: string[], interval: string, enabled: boolean) {
  const [data, setData] = useState<Record<string, UnitLive>>({});
  const [loading, setLoading] = useState(false);
  const childKey = childIds.join('|');

  useEffect(() => {
    if (!enabled || !selectedId) { setData({}); return; }
    const controller = new AbortController();
    const { signal } = controller;
    const unit = async (id: string, withDaily: boolean): Promise<[string, UnitLive]> => {
      const [deployments, cycle, buildFailRate, daily] = await Promise.all([
        fetchMetric('dora/deployment', id, interval, signal),
        fetchMetric('dora/inProgressToLive', id, interval, signal),
        fetchMetric('build/failRate', id, interval, signal),
        withDaily ? fetchDaily(id, interval, signal) : Promise.resolve(undefined),
      ]);
      return [id, { deployments, cycle, buildFailRate, daily }];
    };
    setLoading(true);
    Promise.all([unit(selectedId, true), ...(childKey ? childKey.split('|') : []).map((id) => unit(id, false))]).then((entries) => {
      if (signal.aborted) return;
      setData(Object.fromEntries(entries));
      setLoading(false);
    });
    return () => controller.abort();
  }, [selectedId, childKey, interval, enabled]);

  return { data, loading };
}

/** Thresholds from Settings → Thresholds (saved in this browser), with the defaults of that screen. */
function readThresholds() {
  const result = { df: 5, lt: 3, cfr: 20, mttr: 4 }; // per week, days, %, hours
  try {
    const stored = JSON.parse(localStorage.getItem('dora-thresholds') || 'null');
    (stored?.thresholds ?? []).forEach((it: { key?: string; value?: unknown }) => {
      if (it?.key && it.key in result && typeof it.value === 'number') result[it.key as keyof typeof result] = it.value;
    });
  } catch {
    // defaults
  }
  return result;
}

/** Within the threshold: on target; up to 50 % worse: watch; else off target. */
function statusAgainst(value: number | null | undefined, threshold: number, lowerIsBetter: boolean): Status | null {
  if (value == null || !Number.isFinite(value)) return null;
  if (lowerIsBetter) return value <= threshold ? 'Good' : value <= threshold * 1.5 ? 'Warning' : 'Bad';
  return value >= threshold ? 'Good' : value >= threshold * 0.5 ? 'Warning' : 'Bad';
}

const worstOf = (statuses: Array<Status | null>): Status | null =>
  statuses.includes('Bad') ? 'Bad' : statuses.includes('Warning') ? 'Warning' : statuses.includes('Good') ? 'Good' : null;

/** Hours as on the Overview: in days from 2 days up. */
function formatHours(hours: number, pick: (en: string, pl: string) => string): { value: string; unit: string } {
  return hours >= 48
    ? { value: String(Math.round((hours / 24) * 10) / 10), unit: pick('days', 'dni') }
    : { value: String(Math.round(hours * 10) / 10), unit: 'h' };
}

// ---------- small building blocks ----------

const card = 'rounded-xl border border-gray-200 bg-white dark:border-white/10 dark:bg-[#121317]';
const muted = 'text-gray-500 dark:text-gray-400';
const selectCls =
  'rounded-lg border border-gray-200 bg-white px-2.5 py-1.5 text-[12.5px] text-gray-800 outline-none focus:border-blue-400 dark:border-white/10 dark:bg-white/5 dark:text-gray-100';

type Pick = (en: string, pl: string) => string;

function StatusPill({ status, pick }: { status: Status; pick: Pick }) {
  const [cls, Icon, label] =
    status === 'Good'
      ? ['bg-emerald-50 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-400', CheckCircle2, pick('On target', 'W celu')]
      : status === 'Warning'
        ? ['bg-amber-50 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400', AlertTriangle, pick('Watch', 'Do obserwacji')]
        : ['bg-red-50 text-red-700 dark:bg-red-500/15 dark:text-red-400', XCircle, pick('Off target', 'Poza celem')];
  return (
    <span className={`inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-full whitespace-nowrap ${cls}`} style={{ fontWeight: 600 }}>
      <Icon className="w-3 h-3" />{label}
    </span>
  );
}

/** Marks the parts without a data source in core yet (generated values). */
function SampleChip({ pick }: { pick: Pick }) {
  return (
    <span className={`inline-flex items-center text-[10px] px-1.5 py-0.5 rounded border border-dashed border-gray-300 dark:border-white/20 whitespace-nowrap ${muted}`} style={{ fontWeight: 600 }}>
      {pick('sample data', 'dane przykładowe')}
    </span>
  );
}

function Spark({ data, color, height = 36 }: { data: number[]; color: string; height?: number }) {
  return (
    <div style={{ width: '100%', height }}>
      <ResponsiveContainer>
        <LineChart data={data.map((v, i) => ({ i, v }))} margin={{ top: 4, right: 2, bottom: 4, left: 2 }}>
          <YAxis hide domain={['dataMin', 'dataMax']} />
          <Line type="monotone" dataKey="v" stroke={color} strokeWidth={2} dot={false} isAnimationActive={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

/** Trend arrow with the change in %; green when the change goes the good way for the metric. */
function Delta({ change, lowerIsBetter, label }: { change: number | null; lowerIsBetter: boolean; label: string }) {
  if (change === null) return null;
  const rounded = Math.round(change);
  const flat = Math.abs(rounded) < 3;
  const good = flat ? null : lowerIsBetter ? rounded < 0 : rounded > 0;
  const Icon = flat ? Minus : rounded > 0 ? ArrowUpRight : ArrowDownRight;
  const color = good === null ? 'text-gray-400' : good ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400';
  return (
    <span className={`inline-flex items-center gap-0.5 text-[11.5px] ${muted}`}>
      <Icon className={`w-3.5 h-3.5 ${color}`} />
      <span className="text-gray-700 dark:text-gray-300" style={{ fontWeight: 600 }}>{rounded > 0 ? '+' : ''}{rounded}%</span>
      &nbsp;{label}
    </span>
  );
}

type Kpi = {
  key: string;
  title: string;
  Icon: React.ComponentType<{ className?: string }>;
  color: string;
  value: string;
  unit: string;
  series: number[] | null;
  status: Status | null;
  change: number | null;
  changeLabel: string;
  target: string;
  lowerIsBetter: boolean;
  sample: boolean;
};

function KpiTile({ kpi, pick }: { kpi: Kpi; pick: Pick }) {
  return (
    <div className={`${card} p-4 flex flex-col gap-2 break-inside-avoid`}>
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 text-[13px] text-gray-700 dark:text-gray-300 min-w-0" style={{ fontWeight: 600 }}>
          <span style={{ color: kpi.color }}><kpi.Icon className="w-4 h-4" /></span><span className="truncate">{kpi.title}</span>
        </div>
        {kpi.sample ? <SampleChip pick={pick} /> : kpi.status && <StatusPill status={kpi.status} pick={pick} />}
      </div>
      <div className="flex items-baseline gap-1.5">
        <span className={`text-[34px] leading-none ${kpi.sample ? 'text-gray-400 dark:text-gray-500' : 'text-gray-900 dark:text-gray-50'}`} style={{ fontWeight: 700 }}>{kpi.value}</span>
        <span className={`text-[13px] ${muted}`}>{kpi.unit}</span>
      </div>
      {kpi.series && kpi.series.length > 1 ? <Spark data={kpi.series} color={kpi.color} /> : <div style={{ height: 36 }} />}
      <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-1">
        <Delta change={kpi.change} lowerIsBetter={kpi.lowerIsBetter} label={kpi.changeLabel} />
        <span className={`text-[11px] ${muted}`}>{kpi.target}</span>
      </div>
    </div>
  );
}

function SectionTitle({ children, aside }: { children: React.ReactNode; aside?: React.ReactNode }) {
  return (
    <div className="flex flex-wrap items-baseline justify-between gap-2 mb-3">
      <h2 className="text-[15px] text-gray-900 dark:text-gray-100 flex items-center gap-2" style={{ fontWeight: 700 }}>{children}</h2>
      {aside && <span className={`text-[11.5px] ${muted}`}>{aside}</span>}
    </div>
  );
}

// The PDF is one 16:9 page (PowerPoint widescreen, 13.333 x 7.5 in = 1280 x 720 px), so it goes onto a slide as is.
const SLIDE = { width: 1280, height: 720, padding: 22 };

/** A standalone page with the report and the app styles: one 16:9 page, the report scaled down to fit it. */
function reportHtml(node: HTMLElement, title: string) {
  // the on-screen width keeps the charts (fixed size SVGs) as they are; wide screens fill the 16:9 page best
  const width = Math.max(1280, node.offsetWidth);
  const styles = Array.from(document.querySelectorAll('style, link[rel="stylesheet"]'))
    .map((el) => (el instanceof HTMLLinkElement ? `<link rel="stylesheet" href="${el.href}">` : el.outerHTML))
    .join('\n');
  const escapeHtml = (s: string) => s.replace(/[&<>"]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]!));
  return `<!doctype html><html lang="${document.documentElement.lang || 'en'}"><head><meta charset="utf-8">
<title>${escapeHtml(title)}</title>${styles}
<style>
  @page { size: 13.333in 7.5in; margin: 0; }
  html, body { background: #fff; margin: 0; }
  body { -webkit-print-color-adjust: exact; print-color-adjust: exact; width: ${SLIDE.width}px; height: ${SLIDE.height}px; overflow: hidden;
         display: flex; align-items: center; justify-content: center; }
  /* the desktop layout of the report, scaled by the script below to fit the slide */
  .report-root { width: ${width}px; flex: none; }
  .report-root .space-y-4 > :not(:last-child) { margin-bottom: 12px; }
  .report-root .xl\\:grid-cols-5 { grid-template-columns: repeat(5, minmax(0, 1fr)); }
  .report-root .xl\\:grid-cols-3 { grid-template-columns: repeat(3, minmax(0, 1fr)); }
  .report-root .xl\\:col-span-2 { grid-column: span 2 / span 2; }
  .report-root .md\\:grid-cols-2 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .recharts-wrapper, .recharts-responsive-container { width: 100% !important; }
  .recharts-surface { max-width: 100%; height: auto; }
  .break-inside-avoid { break-inside: avoid; }
  [data-no-print] { display: none !important; }
</style></head><body><div class="report-root">${node.outerHTML}</div>
<script>
  (function fit() {
    var root = document.querySelector('.report-root');
    root.style.zoom = '1';
    var w = root.scrollWidth, h = root.scrollHeight;
    root.style.zoom = String(Math.min((${SLIDE.width - 2 * SLIDE.padding}) / w, (${SLIDE.height - 2 * SLIDE.padding}) / h));
    if (document.readyState !== 'complete') window.addEventListener('load', fit, { once: true });
  })();
</script></body></html>`;
}

/** Opens the report alone in a new window and the print dialog, where "Save as PDF" makes the file. */
function printReport(node: HTMLElement, title: string) {
  const win = window.open('', '_blank', 'width=1200,height=900');
  if (!win) return;
  win.document.open();
  win.document.write(reportHtml(node, title));
  win.document.close();
  // give the stylesheets and fonts a moment before the print dialog
  const go = () => setTimeout(() => { win.focus(); win.print(); }, 400);
  if (win.document.readyState === 'complete') go(); else win.addEventListener('load', go);
}

// ---------- page ----------

export function DeploymentDashboard(props: { teamName?: string; dateRangeOverride?: string }) {
  const isDark = useIsDark();
  const pick = usePick();
  const { dateRange: ctxRange, label: ctxLabel } = useDateRange();
  const { teams, selectedUnitId } = useTeam();
  const dateRange = props.dateRangeOverride ?? ctxRange;
  const interval = toInterval(dateRange);
  const dateRangeLabel = props.dateRangeOverride ?? ctxLabel;
  const n = periodCount(dateRange);
  const reportRef = useRef<HTMLDivElement>(null);
  const thresholds = useMemo(readThresholds, []);

  const [domain, setDomain] = useState(DOMAINS[0]);
  const [chapter, setChapter] = useState(CHAPTERS[0]);
  const [application, setApplication] = useState('All Applications');
  const [vitalOnly, setVitalOnly] = useState(false);
  const [kpiOnly, setKpiOnly] = useState(false);

  // The organization units of the user from core; the team names of the top bar only when that fails.
  const [orgUnits, setOrgUnits] = useState<UnitDto[] | null>(null);
  useEffect(() => {
    let cancelled = false;
    fetch('/api/organization', { credentials: 'include' })
      .then((res) => (res.ok ? res.json() : []))
      .catch(() => [])
      .then((js) => { if (!cancelled) setOrgUnits(Array.isArray(js) ? js : []); });
    return () => { cancelled = true; };
  }, []);
  const live = !!orgUnits && orgUnits.length > 0;
  const tree = useMemo(
    () => (live ? unitTree(orgUnits!) : buildTree(teams.filter((t) => t !== 'All Teams'))),
    [live, orgUnits, teams],
  );
  const allNodes = useMemo(() => {
    const out: OrgNode[] = [];
    const walk = (ns: OrgNode[]) => ns.forEach((x) => { out.push(x); walk(x.children); });
    walk(tree);
    return out;
  }, [tree]);

  // Chapter filter keeps branches containing a unit whose name mentions the chapter (e.g. "Frontend").
  const matchesChapter = (node: OrgNode): boolean =>
    chapter === CHAPTERS[0] || node.name.toLowerCase().includes(chapter.toLowerCase()) || node.children.some(matchesChapter);

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const selected = allNodes.find((x) => x.id === selectedId)
    ?? allNodes.find((x) => x.id === selectedUnitId) // the team chosen in the top bar
    ?? allNodes.find((x) => x.depth === 1) ?? allNodes[0] ?? null;

  const subUnits = useMemo(() => (selected ? selected.children.filter(matchesChapter) : []),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [selected, chapter]);
  const { data: liveData, loading } = useLiveMetrics(selected?.id ?? null, subUnits.map((it) => it.id), interval, live);
  const selLive = selected ? liveData[selected.id] : undefined;

  // sample values for what core has no source of yet (MTTR, CFR, work types, applications)
  const sample = useMemo(() => (selected ? summarize(seriesFor(selected, n)) : null), [selected, n]);

  // deployments per day (up to 2 weeks) or per week, from the daily release tasks moved to LIVE
  const buckets = useMemo(() => {
    const daily = selLive?.daily;
    if (!daily || daily.length === 0) return null;
    const size = daily.length <= 14 ? 1 : 7;
    const out: Array<{ label: string; deployments: number }> = [];
    for (let i = 0; i < daily.length; i += size) {
      const slice = daily.slice(i, i + size);
      out.push({
        label: new Date(slice[0].date).toLocaleDateString(pick('en-GB', 'pl-PL'), { day: '2-digit', month: 'short' }),
        deployments: slice.reduce((a, it) => a + it.value, 0),
      });
    }
    return { size, values: out };
  }, [selLive, pick]);

  const days = selLive?.daily?.length ?? rangeDays(dateRange);
  const weeks = Math.max(1, days / 7);
  const perWeek = (deployments: number | undefined) => (deployments == null ? null : Math.round((deployments / weeks) * 10) / 10);
  const fmtDate = (d: Date) => d.toLocaleDateString(pick('en-GB', 'pl-PL'), { dateStyle: 'medium' });
  const periodText = (() => {
    const daily = selLive?.daily;
    if (daily && daily.length) return `${fmtDate(new Date(daily[0].date))} – ${fmtDate(new Date(daily[daily.length - 1].date))}`;
    const custom = parseCustomRange(dateRange);
    if (custom) return `${fmtDate(new Date(`${custom.from}T00:00:00`))} – ${fmtDate(new Date(`${custom.to}T00:00:00`))}`;
    const from = new Date();
    from.setDate(from.getDate() - days + 1);
    return `${fmtDate(from)} – ${fmtDate(new Date())}`;
  })();
  const levelName = (node: OrgNode) => node.type
    ? node.type.charAt(0).toUpperCase() + node.type.slice(1).toLowerCase()
    : [pick('Organization', 'Organizacja'), 'Tribe', 'Chapter', pick('Team', 'Zespół')][Math.min(node.depth, 3)];

  const apps = APPLICATIONS
    .filter((a) => application === 'All Applications' || a === application)
    .map((name, i) => {
      const s = selected ? summarize(seriesFor({ ...selected, id: `${selected.id}#${name}`, children: [] }, n)) : null;
      const achieved = s ? statusOf.cfr(s) !== 'Bad' && statusOf.mttr(s) !== 'Bad' : false;
      return { name, s, achieved, vital: i === 0, strategic: true };
    })
    .filter((a) => (!vitalOnly || a.vital) && (!kpiOnly || a.strategic));

  const vsPrevious = pick('vs previous period', 'vs poprzedni okres');
  const dash = loading ? '…' : '—';
  const depStatus = (dep: Metric | null | undefined) => statusAgainst(perWeek(dep?.value), thresholds.df, false);
  const cycleStatus = (cycle: Metric | null | undefined) => statusAgainst(cycle?.value, thresholds.lt * 24, true);
  const failStatus = (fail: Metric | null | undefined) => statusAgainst(fail?.value, thresholds.cfr, true);
  const cycleShown = selLive?.cycle ? formatHours(selLive.cycle.value, pick) : null;

  const kpis: Kpi[] = selected && sample ? [
    {
      key: 'dep', title: pick('Deployments', 'Wdrożenia'), Icon: Rocket, color: C.dep,
      value: selLive?.deployments ? String(selLive.deployments.value) : dash,
      unit: selLive?.deployments ? `${pick('in period', 'w okresie')} · ${perWeek(selLive.deployments.value)} / ${pick('week', 'tydz.')}` : '',
      series: buckets ? buckets.values.map((it) => it.deployments) : null,
      status: depStatus(selLive?.deployments), change: selLive?.deployments?.change ?? null, changeLabel: vsPrevious,
      target: `${pick('target', 'cel')} ≥ ${thresholds.df} / ${pick('week', 'tydz.')}`, lowerIsBetter: false, sample: false,
    },
    {
      key: 'cycle', title: 'Cycle Time', Icon: RefreshCw, color: C.cycle,
      value: cycleShown?.value ?? dash, unit: cycleShown ? `${cycleShown.unit} · In progress → Live` : '', series: null,
      status: cycleStatus(selLive?.cycle), change: selLive?.cycle?.change ?? null, changeLabel: vsPrevious,
      target: `${pick('target', 'cel')} ≤ ${thresholds.lt} ${pick('days', 'dni')}`, lowerIsBetter: true, sample: false,
    },
    {
      key: 'build', title: 'Build Fail Rate', Icon: Hammer, color: C.cfr,
      value: selLive?.buildFailRate ? String(Math.round(selLive.buildFailRate.value * 10) / 10) : dash, unit: selLive?.buildFailRate ? '%' : '',
      series: null, status: failStatus(selLive?.buildFailRate), change: selLive?.buildFailRate?.change ?? null, changeLabel: vsPrevious,
      target: `${pick('target', 'cel')} ≤ ${thresholds.cfr}%`, lowerIsBetter: true, sample: false,
    },
    {
      key: 'mttr', title: 'MTTR', Icon: Clock, color: C.mttr, value: String(sample.mttr),
      unit: 'h', series: sample.mttrSeries, status: null, change: halfChange(sample.mttrSeries), changeLabel: pick('vs first half', 'vs 1. połowa'),
      target: `${pick('target', 'cel')} ≤ ${thresholds.mttr} h`, lowerIsBetter: true, sample: true,
    },
    {
      key: 'cfr', title: 'CFR', Icon: Percent, color: C.cfr, value: String(sample.cfr),
      unit: '%', series: sample.cfrSeries, status: null, change: halfChange(sample.cfrSeries), changeLabel: pick('vs first half', 'vs 1. połowa'),
      target: `${pick('target', 'cel')} ≤ ${thresholds.cfr}%`, lowerIsBetter: true, sample: true,
    },
  ] : [];
  const liveStatuses = kpis.filter((k) => !k.sample && k.status).map((k) => k.status!);
  const onTarget = liveStatuses.filter((s) => s === 'Good').length;
  const worst = worstOf(liveStatuses);

  const workParts: Array<[string, number, string]> = sample ? [
    [pick('Business change', 'Zmiana biznesowa'), sample.work.biz, C.biz],
    ['Fix', sample.work.fix, C.fix],
    ['Release', sample.work.release, C.release],
    [pick('Maintenance', 'Utrzymanie'), sample.work.maint, C.maint],
  ] : [];
  const workTotal = workParts.reduce((a, [, v]) => a + v, 0);

  const teamRows = subUnits
    .map((node) => ({ node, l: liveData[node.id] }))
    .sort((a, b) => (b.l?.deployments?.value ?? -1) - (a.l?.deployments?.value ?? -1));

  const filterChips = [
    [pick('Period', 'Okres'), dateRangeLabel],
    ['IT Domain', domain],
    ['Chapter', chapter],
    [pick('Application', 'Aplikacja'), application],
    ...(vitalOnly ? [[pick('Apps', 'Aplikacje'), 'Vital only']] : []),
    ...(kpiOnly ? [['KPI', pick('Only with targets', 'Tylko z celami')]] : []),
  ];

  const gridColor = isDark ? 'rgba(255,255,255,0.08)' : '#eef0f3';
  const axisColor = isDark ? '#9ca3af' : '#6b7280';
  const generatedAt = new Date().toLocaleString(pick('en-GB', 'pl-PL'), { dateStyle: 'medium', timeStyle: 'short' });
  const reportTitle = `${pick('Deployment report', 'Raport wdrożeń')} - ${selected?.name ?? ''} - ${new Date().toISOString().slice(0, 10)}`;
  const selDeployments = selLive?.deployments?.value ?? 0;

  return (
    <div className="p-4 md:p-6 space-y-4 text-gray-900 dark:text-gray-100">
      {/* Toolbar: what goes into the report */}
      <div className={`${card} px-4 py-3 flex flex-wrap items-end gap-3`} data-no-print>
        <label className="flex flex-col gap-1 min-w-[220px]">
          <span className={`text-[11px] ${muted}`} style={{ fontWeight: 600 }}>{pick('Organization unit', 'Jednostka organizacji')}</span>
          <select className={selectCls} value={selected?.id ?? ''} onChange={(e) => setSelectedId(e.target.value)}>
            {allNodes.filter(matchesChapter).map((node) => (
              <option key={node.id} value={node.id}>{'  '.repeat(node.depth)}{node.name}</option>
            ))}
          </select>
        </label>
        <label className="flex flex-col gap-1">
          <span className={`text-[11px] ${muted}`} style={{ fontWeight: 600 }}>IT Domain</span>
          <select className={selectCls} value={domain} onChange={(e) => setDomain(e.target.value)}>
            {DOMAINS.map((o) => <option key={o}>{o}</option>)}
          </select>
        </label>
        <label className="flex flex-col gap-1">
          <span className={`text-[11px] ${muted}`} style={{ fontWeight: 600 }}>Chapter</span>
          <select className={selectCls} value={chapter} onChange={(e) => setChapter(e.target.value)}>
            {CHAPTERS.map((o) => <option key={o}>{o}</option>)}
          </select>
        </label>
        <label className="flex flex-col gap-1">
          <span className={`text-[11px] ${muted}`} style={{ fontWeight: 600 }}>{pick('Application', 'Aplikacja')}</span>
          <select className={selectCls} value={application} onChange={(e) => setApplication(e.target.value)}>
            {['All Applications', ...APPLICATIONS].map((o) => <option key={o}>{o}</option>)}
          </select>
        </label>
        <div className="flex flex-col gap-1.5 pb-1 text-[12px] text-gray-700 dark:text-gray-300">
          <label className="inline-flex items-center gap-1.5 cursor-pointer text-[12px]">
            <input type="checkbox" className="accent-blue-600" checked={vitalOnly} onChange={(e) => setVitalOnly(e.target.checked)} /> Vital apps only
          </label>
          <label className="inline-flex items-center gap-1.5 cursor-pointer text-[12px]">
            <input type="checkbox" className="accent-blue-600" checked={kpiOnly} onChange={(e) => setKpiOnly(e.target.checked)} />
            {pick('Only with KPI targets', 'Tylko z celami KPI')}
          </label>
        </div>
        <div className="flex-1" />
        <div className="flex flex-col items-end gap-1">
          <button
            onClick={() => reportRef.current && printReport(reportRef.current, reportTitle)}
            disabled={!selected || loading}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-white text-[13px] disabled:opacity-50"
            style={{ backgroundColor: '#2563eb', fontWeight: 600 }}
          >
            <FileDown className="w-4 h-4" /> {pick('Export to PDF', 'Eksport do PDF')}
          </button>
          <span className={`text-[10.5px] ${muted}`}>{pick('One 16:9 page, ready for a slide', 'Jedna strona 16:9, gotowa na slajd')}</span>
        </div>
      </div>

      {!selected || !sample ? (
        <div className={`${card} p-6 text-[13px] ${muted}`}>
          {orgUnits === null ? pick('Loading…', 'Ładowanie…') : pick('No organization units.', 'Brak jednostek organizacji.')}
        </div>
      ) : (
        <div ref={reportRef} id="deployment-report" className="space-y-4">
          {/* Report header */}
          <div className={`${card} p-5 break-inside-avoid`}>
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div className="min-w-0">
                <div className={`text-[11px] uppercase tracking-wider ${muted}`} style={{ fontWeight: 700 }}>
                  {pick('Deployment report', 'Raport wdrożeń')} · {levelName(selected)}
                </div>
                <h1 className="text-[26px] leading-tight mt-1" style={{ fontWeight: 800 }}>{selected.name}</h1>
                <div className="flex flex-wrap items-center gap-1 mt-1 text-[12.5px]">
                  {selected.path.map((p, i, arr) => (
                    <React.Fragment key={`${p}-${i}`}>
                      {i > 0 && <ChevronRight className={`w-3.5 h-3.5 ${muted}`} />}
                      <button
                        className={i === arr.length - 1 ? 'text-gray-800 dark:text-gray-200' : `${muted} hover:text-gray-900 dark:hover:text-white`}
                        onClick={() => setSelectedId(selected.pathIds[i])}
                      >{p}</button>
                    </React.Fragment>
                  ))}
                </div>
              </div>
              <div className="text-right text-[12.5px] space-y-0.5">
                <div><span className={muted}>{pick('Period', 'Okres')}: </span><span style={{ fontWeight: 600 }}>{periodText}</span></div>
                <div className={muted}>{pick('Generated', 'Wygenerowano')}: {generatedAt}</div>
              </div>
            </div>
            <div className="mt-4 flex flex-wrap items-center gap-2">
              {worst && (
                <span className="inline-flex items-center gap-2 text-[13px]" style={{ fontWeight: 600 }}>
                  <StatusPill status={worst} pick={pick} />
                  {pick(`${onTarget} of ${liveStatuses.length} KPIs on target`, `${onTarget} z ${liveStatuses.length} KPI w celu`)}
                </span>
              )}
              {worst && <span className="mx-1 h-4 w-px bg-gray-200 dark:bg-white/10" />}
              {filterChips.map(([k, v]) => (
                <span key={k} className="text-[11.5px] px-2 py-0.5 rounded-md bg-gray-100 text-gray-700 dark:bg-white/5 dark:text-gray-300">
                  <span className={muted}>{k}:</span> {v}
                </span>
              ))}
            </div>
          </div>

          {/* KPI tiles */}
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-4">
            {kpis.map((k) => <KpiTile key={k.key} kpi={k} pick={pick} />)}
          </div>

          {/* Trend + work type */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
            <div className={`${card} p-5 xl:col-span-2 break-inside-avoid`}>
              <SectionTitle aside={buckets?.size === 1 ? pick('per day', 'dziennie') : pick('per week (week start)', 'tygodniowo (początek tygodnia)')}>
                {pick('Deployments (release tasks moved to LIVE)', 'Wdrożenia (release taski przeniesione na LIVE)')}
              </SectionTitle>
              <div style={{ height: 262 }}>
                {buckets ? (
                  <ResponsiveContainer>
                    <BarChart data={buckets.values} margin={{ top: 8, right: 8, bottom: 0, left: -18 }} barCategoryGap="22%">
                      <CartesianGrid stroke={gridColor} vertical={false} />
                      <XAxis dataKey="label" tick={{ fontSize: 11, fill: axisColor }} axisLine={false} tickLine={false} interval="preserveStartEnd" />
                      <YAxis tick={{ fontSize: 11, fill: axisColor }} axisLine={false} tickLine={false} allowDecimals={false} />
                      <Tooltip
                        cursor={{ fill: isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.04)' }}
                        contentStyle={{ fontSize: 12, borderRadius: 8, background: isDark ? '#1f2024' : '#fff', borderColor: isDark ? 'rgba(255,255,255,0.1)' : '#e5e7eb' }}
                        formatter={(value: number) => [value, pick('Deployments', 'Wdrożenia')]}
                      />
                      <Bar dataKey="deployments" fill={C.dep} radius={[4, 4, 0, 0]} isAnimationActive={false} />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className={`h-full flex items-center justify-center text-[12.5px] ${muted}`}>
                    {loading ? pick('Loading…', 'Ładowanie…') : pick('No deployment data for this unit.', 'Brak danych o wdrożeniach dla tej jednostki.')}
                  </div>
                )}
              </div>
            </div>

            <div className={`${card} p-5 break-inside-avoid`}>
              <SectionTitle aside={<SampleChip pick={pick} />}>{pick('Work type mix', 'Struktura pracy')}</SectionTitle>
              <div className="space-y-3.5">
                {workParts.map(([name, v, color]) => {
                  const pct = workTotal ? Math.round((v / workTotal) * 100) : 0;
                  return (
                    <div key={name}>
                      <div className="flex justify-between text-[12.5px] mb-1">
                        <span className="text-gray-700 dark:text-gray-300">{name}</span>
                        <span><span style={{ fontWeight: 700 }}>{v}</span> <span className={muted}>· {pct}%</span></span>
                      </div>
                      <div className="h-2 rounded-full bg-gray-100 dark:bg-white/5 overflow-hidden">
                        <div className="h-full rounded-full" style={{ width: `${pct}%`, backgroundColor: color }} />
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="mt-5 pt-4 border-t border-gray-100 dark:border-white/5 grid grid-cols-2 gap-3 text-[12px]">
                <div>
                  <div className={muted}>{pick('Deployments / week', 'Wdrożenia / tydzień')}</div>
                  <div className="text-[20px]" style={{ fontWeight: 700 }}>{perWeek(selLive?.deployments?.value) ?? dash}</div>
                </div>
                <div>
                  <div className={muted}>{pick('Successful builds', 'Udane buildy')}</div>
                  <div className="text-[20px]" style={{ fontWeight: 700 }}>
                    {selLive?.buildFailRate ? `${Math.round((100 - selLive.buildFailRate.value) * 10) / 10}%` : dash}
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 items-start">
            {/* Sub-teams */}
            <div className={`${card} p-5 xl:col-span-2`}>
              <SectionTitle aside={teamRows.length ? <>{pick('sorted by deployments', 'sortowane wg wdrożeń')}<span data-no-print> · {pick('click a row to drill down', 'kliknij wiersz, aby wejść głębiej')}</span></> : undefined}>
                {pick('Teams', 'Zespoły')} ({teamRows.length})
              </SectionTitle>
              {teamRows.length === 0 ? (
                <div className={`text-[12.5px] ${muted}`}>{pick('No sub-teams in this unit.', 'Ta jednostka nie ma podzespołów.')}</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-[13px]">
                    <thead>
                      <tr className={`text-left text-[11px] uppercase tracking-wide ${muted} border-b border-gray-200 dark:border-white/10`}>
                        <th className="py-2 pr-3">{pick('Team', 'Zespół')}</th>
                        <th className="py-2 px-3 text-right">{pick('Deployments', 'Wdrożenia')}</th>
                        <th className="py-2 px-3 w-[24%]">{pick('Share', 'Udział')}</th>
                        <th className="py-2 px-3 text-right">Cycle Time</th>
                        <th className="py-2 px-3 text-right">Build Fail</th>
                        <th className="py-2 pl-3">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {teamRows.map(({ node, l }) => {
                        const statuses = [depStatus(l?.deployments), cycleStatus(l?.cycle), failStatus(l?.buildFailRate)];
                        const overall = worstOf(statuses);
                        const share = selDeployments && l?.deployments ? (l.deployments.value / selDeployments) * 100 : 0;
                        const cellColor = (st: Status | null) => (st === 'Warning' ? 'text-amber-700 dark:text-amber-400' : st === 'Bad' ? 'text-red-700 dark:text-red-400' : '');
                        const cycle = l?.cycle ? formatHours(l.cycle.value, pick) : null;
                        return (
                          <tr key={node.id} className="border-b border-gray-100 last:border-0 dark:border-white/5 cursor-pointer hover:bg-gray-50 dark:hover:bg-white/[0.03] break-inside-avoid" onClick={() => setSelectedId(node.id)}>
                            <td className="py-2.5 pr-3" style={{ fontWeight: 600 }} title={node.path.join(' - ')}>{node.name}</td>
                            <td className="py-2.5 px-3 text-right tabular-nums" style={{ fontWeight: 700 }}>{l?.deployments ? l.deployments.value : dash}</td>
                            <td className="py-2.5 px-3">
                              <div className="flex items-center gap-2">
                                <div className="flex-1 h-1.5 rounded-full bg-gray-100 dark:bg-white/5 overflow-hidden">
                                  <div className="h-full rounded-full" style={{ width: `${Math.min(100, share)}%`, backgroundColor: C.dep }} />
                                </div>
                                <span className={`text-[11px] w-9 text-right tabular-nums ${muted}`}>{Math.round(share)}%</span>
                              </div>
                            </td>
                            <td className={`py-2.5 px-3 text-right tabular-nums ${cellColor(statuses[1])}`}>{cycle ? `${cycle.value} ${cycle.unit}` : dash}</td>
                            <td className={`py-2.5 px-3 text-right tabular-nums ${cellColor(statuses[2])}`}>{l?.buildFailRate ? `${Math.round(l.buildFailRate.value * 10) / 10}%` : dash}</td>
                            <td className="py-2.5 pl-3">{overall ? <StatusPill status={overall} pick={pick} /> : <span className={muted}>{dash}</span>}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Applications */}
            <div className={`${card} p-5 break-inside-avoid`}>
              <SectionTitle aside={<SampleChip pick={pick} />}>{pick('Applications · Strategic KPI', 'Aplikacje · strategiczne KPI')}</SectionTitle>
              {apps.length === 0 ? (
                <div className={`text-[12.5px] ${muted}`}>{pick('No applications match the filters.', 'Brak aplikacji dla wybranych filtrów.')}</div>
              ) : (
                <div className="grid grid-cols-1 gap-3">
                  {apps.map((app) => app.s && (
                    <div key={app.name} className={`rounded-lg border p-3.5 flex items-center gap-3 ${app.achieved ? 'border-emerald-200 bg-emerald-50/50 dark:border-emerald-500/30 dark:bg-emerald-500/5' : 'border-amber-200 bg-amber-50/50 dark:border-amber-500/30 dark:bg-amber-500/5'}`}>
                      {app.achieved
                        ? <Star className="w-7 h-7 shrink-0 text-amber-400 fill-amber-400" />
                        : <Target className="w-7 h-7 shrink-0 text-amber-500" />}
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="text-[14px]" style={{ fontWeight: 700 }}>{app.name}</span>
                          {app.vital && <span className={`text-[10px] px-1.5 py-0.5 rounded bg-gray-100 dark:bg-white/10 ${muted}`} style={{ fontWeight: 600 }}>VITAL</span>}
                        </div>
                        <div className={`text-[12px] mt-0.5 ${muted}`}>
                          {app.s.deployments} {pick('deployments', 'wdrożeń')} · MTTR {app.s.mttr} h · CFR {app.s.cfr}%
                        </div>
                      </div>
                      <span className={`text-[11px] px-2 py-0.5 rounded-full whitespace-nowrap ${app.achieved ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-400' : 'bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-400'}`} style={{ fontWeight: 700 }}>
                        {app.achieved ? pick('KPI achieved', 'KPI osiągnięte') : pick('KPI at risk', 'KPI zagrożone')}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className={`text-[11px] ${muted} flex flex-wrap justify-between gap-2`}>
            <span>
              OneLook · {pick('Deployment report', 'Raport wdrożeń')} · {selected.path.join(' - ')} ·{' '}
              {live
                ? pick('Deployments, Cycle Time and Build Fail Rate from OneLook; parts marked "sample data" have no data source yet',
                  'Wdrożenia, Cycle Time i Build Fail Rate z OneLook; części oznaczone „dane przykładowe” nie mają jeszcze źródła danych')
                : pick('no organization data from OneLook, sample data only', 'brak danych organizacji z OneLook, tylko dane przykładowe')}
            </span>
            <span>{generatedAt}</span>
          </div>
        </div>
      )}
    </div>
  );
}

export default DeploymentDashboard;
