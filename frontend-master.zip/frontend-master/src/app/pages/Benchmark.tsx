import { useEffect, useMemo, useState } from 'react';
import { useDateRange } from '../context/DateRangeContext';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RTooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';
import { AlertTriangle, Target, Timer, Rocket } from 'lucide-react';

// Simple tooltip style consistent with other pages
const tooltipStyle = {
  backgroundColor: 'white',
  border: '1px solid #e5e7eb',
  borderRadius: '8px',
  fontSize: '12px',
  boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
};

// Mock baseline numbers representing organization-wide averages
const orgBenchmarks = {
  deploymentFrequency: 12.5, // per week
  leadTime: 3.3, // hours
  changeFailureRate: 4.5, // %
  mttr: 0.8, // hours
};

// Mock external (tech companies) benchmarks
const techBenchmarks = {
  deploymentFrequency: 21.0,
  leadTime: 1.6,
  changeFailureRate: 3.0,
  mttr: 0.6,
};

// Produce a pseudo-deterministic variation for a team based on its name
function teamAdjust(team: string) {
  if (!team || team === 'All Teams') return 1;
  let hash = 0;
  for (let i = 0; i < team.length; i++) hash = (hash * 31 + team.charCodeAt(i)) >>> 0;
  // Map to ~0.9..1.1 range
  return 0.9 + (hash % 21) / 100; // 0.90 .. 1.10
}

// Adjust factor based on selected period from the top bar
function rangeAdjust(range: string) {
  switch (range) {
    case 'Last 7 days':
      return 1.02; // slightly better recently
    case 'Last 2 weeks':
      return 1.01;
    case 'Last 4 weeks':
      return 1.0; // baseline
    case 'Last 3 months':
      return 0.98;
    case 'Last 6 months':
      return 0.96;
    default:
      return 1.0;
  }
}

export function Benchmark() {
  const [teams, setTeams] = useState<string[]>(['All Teams']);
  const [selectedTeam, setSelectedTeam] = useState<string>('All Teams');
  const { dateRange } = useDateRange();

  useEffect(() => {
    let cancelled = false;
    async function loadTeams() {
      try {
        const res = await fetch('/api/organization', { credentials: 'include' });
        if (!res.ok) return;
        const data = await res.json();
        if (!Array.isArray(data)) return;
        const apiTeams = data
          .filter((item: any) => (item?.type || '').toLowerCase() === 'team')
          .map((t: any) => t?.name)
          .filter((n: any) => typeof n === 'string' && n.trim().length > 0);
        const unique = Array.from(new Set(apiTeams));
        if (!cancelled) setTeams(['All Teams', ...unique]);
      } catch (_e) {
        // ignore
      }
    }
    loadTeams();
    return () => {
      cancelled = true;
    };
  }, []);

  const teamFactor = useMemo(() => teamAdjust(selectedTeam), [selectedTeam]);
  const dateFactor = useMemo(() => rangeAdjust(dateRange), [dateRange]);
  const orgByDate = useMemo(
    () => ({
      deploymentFrequency: Number((orgBenchmarks.deploymentFrequency * dateFactor).toFixed(1)),
      leadTime: Number((orgBenchmarks.leadTime / dateFactor).toFixed(2)),
      changeFailureRate: Number((orgBenchmarks.changeFailureRate / dateFactor).toFixed(2)),
      mttr: Number((orgBenchmarks.mttr / dateFactor).toFixed(2)),
    }),
    [dateFactor]
  );

  const comparativeData = useMemo(
    () => [
      {
        metric: 'Deployments/wk',
        team: Number((orgByDate.deploymentFrequency * teamFactor).toFixed(1)),
        organization: orgByDate.deploymentFrequency,
        tech: techBenchmarks.deploymentFrequency,
        tooltip: 'Deployment Frequency (per week) — higher is better',
      },
      {
        metric: 'Lead Time (h)',
        team: Number((orgByDate.leadTime / teamFactor).toFixed(2)),
        organization: orgByDate.leadTime,
        tech: techBenchmarks.leadTime,
        tooltip: 'Lead Time for changes (hours) — lower is better',
      },
      {
        metric: 'Change Failure (%)',
        team: Number((orgByDate.changeFailureRate / teamFactor).toFixed(2)),
        organization: orgByDate.changeFailureRate,
        tech: techBenchmarks.changeFailureRate,
        tooltip: 'Change Failure Rate (%) — lower is better',
      },
      {
        metric: 'MTTR (h)',
        team: Number((orgByDate.mttr / teamFactor).toFixed(2)),
        organization: orgByDate.mttr,
        tech: techBenchmarks.mttr,
        tooltip: 'Mean Time To Restore (hours) — lower is better',
      },
    ],
    [teamFactor, orgByDate]
  );

  // Helpers to compute metrics for any team and compare to benchmark (organization)
  const benchmarkRef = orgByDate;
  const computeTeamMetrics = (name: string) => {
    const f = teamAdjust(name);
    return {
      deploymentFrequency: Number((orgByDate.deploymentFrequency * f).toFixed(1)), // higher is better
      leadTime: Number((orgByDate.leadTime / f).toFixed(2)), // lower is better
      changeFailureRate: Number((orgByDate.changeFailureRate / f).toFixed(2)), // lower is better
      mttr: Number((orgByDate.mttr / f).toFixed(2)), // lower is better
    };
  };
  const metricsList = [
    { key: 'deploymentFrequency' as const, label: 'Deployments/wk', better: 'higher' as const, suffix: '' },
    { key: 'leadTime' as const, label: 'Lead Time (h)', better: 'lower' as const, suffix: 'h' },
    { key: 'changeFailureRate' as const, label: 'Change Failure (%)', better: 'lower' as const, suffix: '%' },
    { key: 'mttr' as const, label: 'MTTR (h)', better: 'lower' as const, suffix: 'h' },
  ];
  const teamsToShow = useMemo(() => {
    const list = teams.filter((t) => t !== 'All Teams');
    if (list.length > 0) return list;
    // Fallback demo teams if API returns nothing
    return ['Core', 'Platform', 'Web', 'SRE'];
  }, [teams]);

  const compareColor = (metricKey: keyof typeof benchmarkRef, value: number) => {
    const bench = benchmarkRef[metricKey as keyof typeof benchmarkRef] as number;
    const conf = metricsList.find((m) => m.key === metricKey)!;
    if (conf.better === 'higher') {
      if (value > bench) return 'text-emerald-600';
      if (value < bench) return 'text-rose-600';
      return 'text-gray-600';
    } else {
      // lower is better
      if (value < bench) return 'text-emerald-600';
      if (value > bench) return 'text-rose-600';
      return 'text-gray-600';
    }
  };

  const eisenhower = useMemo(
    () => ({
      urgentImportant: [
        { title: 'Fix critical pipeline flakiness', owner: 'DevEx', impact: 'High' },
        { title: 'Resolve production incident #4321', owner: 'SRE', impact: 'High' },
      ],
      notUrgentImportant: [
        { title: 'Automate dependency updates', owner: 'Platform', impact: 'Medium' },
        { title: 'Adopt feature flags rollout policy', owner: 'Core', impact: 'Medium' },
      ],
      urgentNotImportant: [
        { title: 'Hotfix UI copy issue', owner: 'Web', impact: 'Low' },
      ],
      notUrgentNotImportant: [
        { title: 'Refactor legacy utils (exploration)', owner: 'Core', impact: 'Low' },
      ],
    }),
    []
  );

  return (
    <div className="p-4 sm:p-6 mx-auto space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-[20px] text-gray-900" style={{ fontWeight: 700 }}>Benchmark</h1>
          <p className="text-[13px] text-gray-500 mt-0.5">Team results compared to the organization and the market (tech companies)</p>
        </div>
      </div>

      {/* Comparative charts */}
      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-[16px] text-gray-900" style={{ fontWeight: 700 }}>Key metrics (comparison)</h2>
            <p className="text-[13px] text-gray-500">Team vs Organization vs Tech</p>
          </div>
          <div className="flex items-center gap-2 text-[12px] text-gray-500">
            <div className="flex items-center gap-1"><Rocket className="w-3.5 h-3.5 text-indigo-600" /> Team</div>
            <div className="flex items-center gap-1"><Target className="w-3.5 h-3.5 text-emerald-600" /> Organization</div>
            <div className="flex items-center gap-1"><Timer className="w-3.5 h-3.5 text-amber-600" /> Tech</div>
          </div>
        </div>
        <div className="w-full h-[320px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={comparativeData} margin={{ top: 8, right: 16, bottom: 8, left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
              <XAxis dataKey="metric" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <RTooltip contentStyle={tooltipStyle as any} formatter={(value: any, name: any, _props: any) => [value, name]} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Bar dataKey="team" name="Team" fill="#6366f1" radius={[4,4,0,0]} />
              <Bar dataKey="organization" name="Organization" fill="#10b981" radius={[4,4,0,0]} />
              <Bar dataKey="tech" name="Tech" fill="#f59e0b" radius={[4,4,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Teams vs Benchmark list */}
      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-[16px] text-gray-900" style={{ fontWeight: 700 }}>Teams vs Benchmark</h2>
            <p className="text-[13px] text-gray-500">Color indicates performance vs organization benchmark</p>
          </div>
          <div className="text-[12px] text-gray-500">Green = better · Red = worse · Gray = equal</div>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-[13px]">
            <thead>
              <tr className="text-gray-500">
                <th className="py-2 pr-4 font-medium">Team</th>
                {metricsList.map((m) => (
                  <th key={m.key} className="py-2 px-3 font-medium whitespace-nowrap">{m.label}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {teamsToShow.map((t) => {
                const vals = computeTeamMetrics(t);
                return (
                  <tr key={t} className="border-t border-gray-100">
                    <td className="py-2 pr-4 text-gray-900" style={{ fontWeight: 600 }}>{t}</td>
                    {metricsList.map((m) => {
                      const v = vals[m.key];
                      const color = compareColor(m.key as any, v);
                      const suffix = m.suffix;
                      return (
                        <td key={m.key} className="py-2 px-3 whitespace-nowrap">
                          <span className={color} style={{ fontWeight: 600 }}>{v}{suffix}</span>
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Eisenhower Matrix */}
      <div className="bg-white rounded-xl border border-gray-200 p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-[16px] text-gray-900" style={{ fontWeight: 700 }}>Eisenhower Matrix</h2>
            <p className="text-[13px] text-gray-500">Important/Urgent — priorities for engineering initiatives</p>
          </div>
          <div className="flex items-center gap-1 text-amber-600 text-[12px]"><AlertTriangle className="w-4 h-4" /> Mock data</div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Urgent & Important */}
          <div className="border rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[13px] text-gray-500">Urgent and Important</span>
              <span className="text-[11px] text-gray-400">Do now</span>
            </div>
            <ul className="space-y-2">
              {eisenhower.urgentImportant.map((t, i) => (
                <li key={i} className="bg-rose-50 border border-rose-200 rounded-md px-3 py-2">
                  <div className="text-[13px] text-gray-900" style={{ fontWeight: 600 }}>{t.title}</div>
                  <div className="text-[12px] text-gray-500">Owner: {t.owner} · Impact: {t.impact}</div>
                </li>
              ))}
            </ul>
          </div>

          {/* Not Urgent & Important */}
          <div className="border rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[13px] text-gray-500">Not urgent but Important</span>
              <span className="text-[11px] text-gray-400">Schedule</span>
            </div>
            <ul className="space-y-2">
              {eisenhower.notUrgentImportant.map((t, i) => (
                <li key={i} className="bg-emerald-50 border border-emerald-200 rounded-md px-3 py-2">
                  <div className="text-[13px] text-gray-900" style={{ fontWeight: 600 }}>{t.title}</div>
                  <div className="text-[12px] text-gray-500">Owner: {t.owner} · Impact: {t.impact}</div>
                </li>
              ))}
            </ul>
          </div>

          {/* Urgent & Not Important */}
          <div className="border rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[13px] text-gray-500">Urgent but Not Important</span>
              <span className="text-[11px] text-gray-400">Delegate</span>
            </div>
            <ul className="space-y-2">
              {eisenhower.urgentNotImportant.map((t, i) => (
                <li key={i} className="bg-amber-50 border border-amber-200 rounded-md px-3 py-2">
                  <div className="text-[13px] text-gray-900" style={{ fontWeight: 600 }}>{t.title}</div>
                  <div className="text-[12px] text-gray-500">Owner: {t.owner} · Impact: {t.impact}</div>
                </li>
              ))}
            </ul>
          </div>

          {/* Not Urgent & Not Important */}
          <div className="border rounded-lg p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[13px] text-gray-500">Not Urgent and Not Important</span>
              <span className="text-[11px] text-gray-400">Eliminate</span>
            </div>
            <ul className="space-y-2">
              {eisenhower.notUrgentNotImportant.map((t, i) => (
                <li key={i} className="bg-gray-50 border border-gray-200 rounded-md px-3 py-2">
                  <div className="text-[13px] text-gray-900" style={{ fontWeight: 600 }}>{t.title}</div>
                  <div className="text-[12px] text-gray-500">Owner: {t.owner} · Impact: {t.impact}</div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Benchmark;
