import { workingAgreements } from '../data/mockData';
import { TrendingUp, TrendingDown, Minus, CheckCircle2, AlertCircle, XCircle, Filter, Plus } from 'lucide-react';
import { useState } from 'react';

type Status = 'passing' | 'warning' | 'failing';

const statusConfig: Record<Status, { label: string; icon: React.ElementType; bg: string; text: string; border: string; dot: string }> = {
  passing: { label: 'Passing', icon: CheckCircle2, bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-200', dot: 'bg-emerald-500' },
  warning: { label: 'Warning', icon: AlertCircle, bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-200', dot: 'bg-amber-500' },
  failing: { label: 'Failing', icon: XCircle, bg: 'bg-red-50', text: 'text-red-700', border: 'border-red-200', dot: 'bg-red-500' },
};

const categoryColors: Record<string, string> = {
  Reviews: 'bg-indigo-100 text-indigo-700',
  'Code Quality': 'bg-violet-100 text-violet-700',
  Workflow: 'bg-blue-100 text-blue-700',
  'CI/CD': 'bg-cyan-100 text-cyan-700',
  Deployment: 'bg-emerald-100 text-emerald-700',
  Security: 'bg-red-100 text-red-700',
  Testing: 'bg-amber-100 text-amber-700',
};

function ComplianceBar({ value, target }: { value: number; target: number }) {
  const pct = value;
  const color =
    value >= target ? 'bg-emerald-500' :
    value >= target * 0.85 ? 'bg-amber-500' : 'bg-red-500';

  return (
    <div className="space-y-1">
      <div className="flex justify-between items-center">
        <span className="text-[12px] text-gray-500">Compliance</span>
        <div className="flex items-center gap-1.5">
          <span className="text-[12px] text-gray-400">Target: {target}%</span>
          <span className="text-[13px] text-gray-900" style={{ fontWeight: 700 }}>{value}%</span>
        </div>
      </div>
      <div className="relative w-full bg-gray-100 rounded-full h-2">
        <div className={`h-2 rounded-full transition-all ${color}`} style={{ width: `${pct}%` }} />
        <div
          className="absolute top-0 w-0.5 h-2 bg-gray-400 rounded"
          style={{ left: `${target}%` }}
        />
      </div>
    </div>
  );
}

export function WorkingAgreements() {
  const [filter, setFilter] = useState<'all' | Status>('all');
  const [categoryFilter, setCategoryFilter] = useState('All');

  const categories = ['All', ...Array.from(new Set(workingAgreements.map((a) => a.category)))];

  const filtered = workingAgreements.filter((a) => {
    const statusOk = filter === 'all' || a.status === filter;
    const catOk = categoryFilter === 'All' || a.category === categoryFilter;
    return statusOk && catOk;
  });

  const passingCount = workingAgreements.filter((a) => a.status === 'passing').length;
  const warningCount = workingAgreements.filter((a) => a.status === 'warning').length;
  const failingCount = workingAgreements.filter((a) => a.status === 'failing').length;
  const avgCompliance = Math.round(workingAgreements.reduce((s, a) => s + a.compliance, 0) / workingAgreements.length);

  return (
    <div className="p-4 sm:p-6 mx-auto space-y-6">

      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-[20px] text-gray-900" style={{ fontWeight: 700 }}>Working Agreements</h1>
          <p className="text-[13px] text-gray-500 mt-0.5">
            Automated rules that keep your engineering practices healthy
          </p>
        </div>
        <button className="flex items-center gap-1.5 px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-[13px] rounded-lg transition-colors">
          <Plus className="w-4 h-4" />
          New Agreement
        </button>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl border border-gray-200 p-4 text-center">
          <p className="text-[32px] text-gray-900" style={{ fontWeight: 700, lineHeight: 1 }}>{avgCompliance}%</p>
          <p className="text-[12px] text-gray-500 mt-1">Overall Compliance</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-4 text-center">
          <p className="text-[32px] text-emerald-600" style={{ fontWeight: 700, lineHeight: 1 }}>{passingCount}</p>
          <p className="text-[12px] text-gray-500 mt-1">Passing</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-4 text-center">
          <p className="text-[32px] text-amber-600" style={{ fontWeight: 700, lineHeight: 1 }}>{warningCount}</p>
          <p className="text-[12px] text-gray-500 mt-1">Warnings</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-200 p-4 text-center">
          <p className="text-[32px] text-red-600" style={{ fontWeight: 700, lineHeight: 1 }}>{failingCount}</p>
          <p className="text-[12px] text-gray-500 mt-1">Failing</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex items-center gap-1 text-[12px] text-gray-500">
          <Filter className="w-3.5 h-3.5" /> Filter:
        </div>
        {(['all', 'passing', 'warning', 'failing'] as const).map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`px-3 py-1.5 rounded-full text-[12px] border transition-colors ${
              filter === s
                ? s === 'all'
                  ? 'bg-gray-900 text-white border-gray-900'
                  : `${statusConfig[s as Status].bg} ${statusConfig[s as Status].text} ${statusConfig[s as Status].border}`
                : 'bg-white text-gray-500 border-gray-200 hover:border-gray-300'
            }`}
            style={{ fontWeight: filter === s ? 600 : 400 }}
          >
            {s === 'all' ? 'All' : statusConfig[s as Status].label}
            {s !== 'all' && (
              <span className="ml-1.5 text-[11px]">
                ({s === 'passing' ? passingCount : s === 'warning' ? warningCount : failingCount})
              </span>
            )}
          </button>
        ))}
        <div className="w-px h-4 bg-gray-200" />
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setCategoryFilter(cat)}
            className={`px-3 py-1.5 rounded-full text-[12px] border transition-colors ${
              categoryFilter === cat
                ? 'bg-gray-900 text-white border-gray-900'
                : 'bg-white text-gray-500 border-gray-200 hover:border-gray-300'
            }`}
            style={{ fontWeight: categoryFilter === cat ? 600 : 400 }}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Agreement cards */}
      <div className="space-y-3">
        {filtered.map((agreement) => {
          const sc = statusConfig[agreement.status];
          const StatusIcon = sc.icon;
          const catColor = categoryColors[agreement.category] ?? 'bg-gray-100 text-gray-700';

          return (
            <div
              key={agreement.id}
              className="bg-white rounded-xl border border-gray-200 p-5 hover:border-gray-300 transition-colors"
            >
              <div className="flex items-start gap-4">
                {/* Status icon */}
                <div className={`flex-shrink-0 w-9 h-9 rounded-lg ${sc.bg} flex items-center justify-center mt-0.5`}>
                  <StatusIcon className={`w-5 h-5 ${sc.text}`} />
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0 space-y-3">
                  <div className="flex items-start justify-between gap-4">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <h3 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>
                          {agreement.title}
                        </h3>
                        <span className={`px-2 py-0.5 rounded text-[11px] ${catColor}`} style={{ fontWeight: 500 }}>
                          {agreement.category}
                        </span>
                      </div>
                      <p className="text-[12px] text-gray-500">{agreement.description}</p>
                    </div>
                    <div className="flex-shrink-0 flex items-center gap-2">
                      {agreement.trend === 'up' && <TrendingUp className="w-4 h-4 text-emerald-500" />}
                      {agreement.trend === 'down' && <TrendingDown className="w-4 h-4 text-red-500" />}
                      {agreement.trend === 'stable' && <Minus className="w-4 h-4 text-gray-400" />}
                      <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-[12px] ${sc.bg} ${sc.text} ${sc.border}`} style={{ fontWeight: 600 }}>
                        <div className={`w-1.5 h-1.5 rounded-full ${sc.dot}`} />
                        {sc.label}
                      </div>
                    </div>
                  </div>

                  <ComplianceBar value={agreement.compliance} target={agreement.target} />

                  <div className="flex items-center gap-4 text-[12px] text-gray-400">
                    <span>Affects: <span className="text-gray-600" style={{ fontWeight: 500 }}>{agreement.affectedTeam}</span></span>
                    <span>Target: <span className="text-gray-600" style={{ fontWeight: 500 }}>{agreement.target}%</span></span>
                    {agreement.compliance >= agreement.target ? (
                      <span className="text-emerald-600" style={{ fontWeight: 500 }}>
                        +{agreement.compliance - agreement.target}pp above target
                      </span>
                    ) : (
                      <span className="text-red-500" style={{ fontWeight: 500 }}>
                        {agreement.target - agreement.compliance}pp below target
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-12 text-gray-400">
          <CheckCircle2 className="w-10 h-10 mx-auto mb-2 opacity-40" />
          <p className="text-[14px]">No agreements match your filter</p>
        </div>
      )}
    </div>
  );
}
