import { useEffect, useMemo, useState } from 'react';
import {
  doraMetrics,
  deploymentFrequencyData,
  leadTimeData,
  changeFailureRateData,
  mttrData,
} from '../data/mockData';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
} from 'recharts';
import { TrendingDown, TrendingUp, Rocket, Clock, AlertTriangle, Wrench } from 'lucide-react';
import { CycleTimeBreakdown } from '../components/CycleTimeBreakdown';
import { useTr, usePick, useLang } from '../i18n';
import { useDateRange } from '../context/DateRangeContext';
import { useTeam } from '../context/TeamContext';
import LoadingSpinner from '../components/LoadingSpinner';
import { useNoDataTimeout } from '../hooks/useNoDataTimeout';
import HelpTip from '../components/HelpTip';
import { getIntervalSuffix } from '../utils/intervalUnit';
import { OrgBenchmarkBadge, fetchOrgBenchmark, type OrgBenchItem, type OrgBenchResponse } from '../components/OrgBenchmarkBadge';
import { toInterval } from '../utils/dateRange';

type Rating = 'elite' | 'high' | 'medium' | 'low';

const RATING_CONFIG: Record<Rating, { bg: string; text: string; border: string; dot: string }> = {
  elite: { bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-200', dot: 'bg-emerald-500' },
  high: { bg: 'bg-blue-50', text: 'text-blue-700', border: 'border-blue-200', dot: 'bg-blue-500' },
  medium: { bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-200', dot: 'bg-amber-500' },
  low: { bg: 'bg-red-50', text: 'text-red-700', border: 'border-red-200', dot: 'bg-red-500' },
};

const tooltipStyle = {
  backgroundColor: 'white',
  border: '1px solid #e5e7eb',
  borderRadius: '8px',
  fontSize: '12px',
  boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
};

function DoraCard({
  title,
  value,
  unit,
  previous,
  trend,
  rating,
  goodDirection = 'up',
  icon: Icon,
  iconColor,
  bench,
  benchUnitType,
  help,
}: {
  title: string;
  value: number;
  unit: string;
  previous: number;
  trend: 'up' | 'down';
  rating: Rating;
  goodDirection?: 'up' | 'down';
  icon: React.ElementType;
  iconColor: string;
  bench?: OrgBenchItem | null;
  benchUnitType?: string | null;
  help?: string;
}) {
  const t = useTr();
  const pct = Math.abs(((value - previous) / previous) * 100).toFixed(1);
  const isGood = trend === goodDirection;
  const r = RATING_CONFIG[rating];

  return (
    <div className="bg-white rounded-xl border border-gray-200 p-5 flex flex-col gap-3">
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <div className={`w-8 h-8 shrink-0 ${iconColor} rounded-lg flex items-center justify-center`}>
            <Icon className="w-4 h-4 text-white" />
          </div>
          <span className="text-[13px] text-gray-600" style={{ fontWeight: 500 }}>{title}</span>
          {help && <HelpTip size="sm" content={help} />}
        </div>
        <div className={`shrink-0 flex items-center gap-1.5 px-2 py-0.5 rounded-full border text-[11px] ${r.bg} ${r.text} ${r.border}`} style={{ fontWeight: 600 }}>
          <div className={`w-1.5 h-1.5 rounded-full ${r.dot}`} />
          {rating === 'elite' ? t('ratingElite') : rating === 'high' ? t('ratingHigh') : rating === 'medium' ? t('ratingMedium') : t('ratingLow')}
        </div>
      </div>

      <div className="flex items-baseline flex-wrap gap-1.5">
        <span className="text-[32px] text-gray-900" style={{ fontWeight: 700, lineHeight: 1 }}>{value}</span>
        <span className="text-[14px] text-gray-400">{unit}</span>
      </div>
      {bench !== undefined && <div className="-mt-2"><OrgBenchmarkBadge item={bench} unit={unit} unitType={benchUnitType} /></div>}

      <div className={`flex flex-wrap items-center gap-1 text-[12px] ${isGood ? 'text-emerald-600' : 'text-red-500'}`}>
        {trend === 'up' ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
        <span style={{ fontWeight: 500 }}>{pct}%</span>
        <span className="text-gray-400">{t('vsPrevPeriod')} · {t('was')} {previous} {unit}</span>
      </div>
    </div>
  );
}

const benchmarks: Record<Rating, { deploy: string; lead: string; mttr: string; cfr: string }> = {
  elite: { deploy: 'On-demand (multiple/day)', lead: '< 1 hour', mttr: '< 1 hour', cfr: '0–15%' },
  high: { deploy: '1×/day to 1×/week', lead: '1 day to 1 week', mttr: '< 1 day', cfr: '16–30%' },
  medium: { deploy: '1×/week to 1×/month', lead: '1 week to 1 month', mttr: '< 1 week', cfr: '16–30%' },
  low: { deploy: '< 1×/month or < 1×/6mo', lead: '> 6 months', mttr: '> 6 months', cfr: '> 45%' },
};


type DoraProps = { interval?: string; team?: string };

export function DoraMetrics({ interval: intervalProp, team: teamProp }: DoraProps = {}) {
  const t = useTr();
  const pick = usePick();
  const { timedOut, reset } = useNoDataTimeout(180000);
  const [hasData, setHasData] = useState(false);
  const { dateRange, label: dateRangeLabel } = useDateRange();
  const { selectedTeamName, selectedUnitId } = useTeam();

  const derivedInterval = useMemo(() => {
    return toInterval(dateRange, 'WEEKS_1');
  }, [dateRange]);

  const interval = useMemo(() => intervalProp ?? derivedInterval, [intervalProp, derivedInterval]);
  const effectiveTeam = useMemo(() => {
    if (teamProp && teamProp !== 'All Teams') return teamProp;
    if (selectedTeamName && selectedTeamName !== 'All Teams') return selectedTeamName;
    return undefined;
  }, [teamProp, selectedTeamName]);

  // Reset timeout and clear hasData on key filters change
  useEffect(() => {
    reset();
    setHasData(false);
  }, [interval, effectiveTeam, selectedUnitId]);

  // Deployment Frequency state (API-backed with mock fallback)
  const { lang } = useLang();
  const initialUnit = getIntervalSuffix(dateRange, lang);
  const [depCurrent, setDepCurrent] = useState<number>(doraMetrics.deploymentFrequency.current);
  const [depPrevious, setDepPrevious] = useState<number>(doraMetrics.deploymentFrequency.previous);
  const [depTrend, setDepTrend] = useState<'up'|'down'>(doraMetrics.deploymentFrequency.trend);
  const [depRating, setDepRating] = useState<Rating>(doraMetrics.deploymentFrequency.rating);
  const [depUnit, setDepUnit] = useState<string>(initialUnit);
  // one point per day: Jira release tasks moved to LIVE that day (date = YYYY-MM-DD, label = DD.MM)
  const [depSeries, setDepSeries] = useState<{ date: string; label: string; deployments: number }[]>(
    deploymentFrequencyData.map((d) => ({ date: d.week, label: d.week, deployments: d.deployments }))
  );
  const depTotal = useMemo(() => depSeries.reduce((sum, d) => sum + d.deployments, 0), [depSeries]);

  // Lead Time for Changes state (API-backed with mock fallback)
  const [ltCurrent, setLtCurrent] = useState<number>(doraMetrics.leadTime.current);
  const [ltPrevious, setLtPrevious] = useState<number>(doraMetrics.leadTime.previous);
  const [ltTrend, setLtTrend] = useState<'up'|'down'>(doraMetrics.leadTime.trend);
  const [ltRating, setLtRating] = useState<Rating>(doraMetrics.leadTime.rating);
  const [ltUnit, setLtUnit] = useState<string>(doraMetrics.leadTime.unit || 'hours');
  const [ltSeries, setLtSeries] = useState<{ week: string; leadTime: number; target?: number }[]>(leadTimeData);
  const ltTarget = useMemo(() => {
    const t = ltSeries.find((s) => typeof (s as any).target === 'number') as any;
    return typeof t?.target === 'number' && isFinite(t.target) ? t.target : 3;
  }, [ltSeries]);

  useEffect(() => {
    let cancelled = false;
    async function loadDeployment() {
      try {
        const params = new URLSearchParams({ interval });
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        if (effectiveTeam) params.set('team', effectiveTeam);
        const endpoints = [
          `/api/metrics/dora/deployment?${params.toString()}`,
        ];
        let data: any | undefined;
        for (const url of endpoints) {
          try {
            const res = await fetch(url, { credentials: 'include' });
            if (res.ok) {
              data = await res.json();
              break;
            } else {
              console.warn('[DoraMetrics] Deployment endpoint responded with', res.status, 'for', url);
            }
          } catch (e) {
            console.warn('[DoraMetrics] Deployment request failed for', url, e);
          }
        }
        if (!data) return; // keep mocks
        setHasData(true);
        if (cancelled) return;

        // Defaults to existing values, override if present
        let current = depCurrent;
        let previous = depPrevious;
        let unit = depUnit;
        let trend: 'up'|'down' = depTrend;
        let rating: Rating = depRating;
        let series = depSeries;

        const normalizeSeriesItem = (it: any) => {
          const label = (typeof it?.week === 'string' && it.week)
            || (typeof it?.label === 'string' && it.label)
            || (typeof it?.date === 'string' && it.date)
            || String(it?.x ?? '');
          const valRaw = it?.deployments ?? it?.value ?? it?.count ?? it?.y ?? it?.number;
          const val = Number(valRaw);
          const goal = Number(it?.goal ?? it?.target);
          const item: { week: string; deployments: number; goal?: number } = {
            week: label || '',
            deployments: Number.isFinite(val) ? val : 0,
          };
          if (Number.isFinite(goal)) item.goal = goal;
          return item;
        };

        if (Array.isArray(data)) {
          const arr = data.map(normalizeSeriesItem).filter((d: any) => d.week !== '');
          if (arr.length > 0) {
            series = arr;
            const last = arr[arr.length - 1]?.deployments ?? depCurrent;
            const prev = arr[arr.length - 2]?.deployments ?? depPrevious;
            current = last;
            previous = prev;
            trend = last >= prev ? 'up' : 'down';
          }
        } else if (typeof data === 'object' && data) {
          // Support multiple payload shapes similar to Lead Time parser
          // 1) { current, previous, unit, trend, rating, series }
          // 2) { value, prev|previousValue, unit, positive, rating, values }
          // 3) { current: { value, unit }, previous: { value }, series: [...] }

          // Direct numeric fields
          if (typeof (data as any).current === 'number') current = (data as any).current;
          if (typeof (data as any).previous === 'number') previous = (data as any).previous;

          // Alternative naming
          if (typeof (data as any).value === 'number') current = (data as any).value;
          if (typeof (data as any).prev === 'number') previous = (data as any).prev;
          if (typeof (data as any).previousValue === 'number') previous = (data as any).previousValue;

          // Nested objects with value/unit
          if (data && typeof (data as any).current === 'object' && (data as any).current) {
            const c = (data as any).current;
            if (typeof c.value === 'number') current = c.value;
            // Normalize unit to selected interval suffix regardless of backend value
            unit = getIntervalSuffix(dateRange, lang);
          }
          if (data && typeof (data as any).previous === 'object' && (data as any).previous) {
            const p = (data as any).previous;
            if (typeof p.value === 'number') previous = p.value;
          }

          // Unit at root
          if (typeof (data as any).unit === 'string') unit = getIntervalSuffix(dateRange, lang);

          // Trend/rating handling
          if (typeof (data as any).trend === 'string') trend = (data as any).trend === 'down' ? 'down' : 'up';
          if (typeof (data as any).positive === 'boolean') {
            // For Deployment Frequency: positive=true means improvement (higher is better)
            trend = (data as any).positive ? 'up' : 'down';
          }
          if (typeof (data as any).rating === 'string') {
            const r = String((data as any).rating).toLowerCase();
            if (r === 'elite' || r === 'high' || r === 'medium' || r === 'low') rating = r as Rating;
          }

          // Series can be under series or values
          if (Array.isArray((data as any).series)) {
            const arr = (data as any).series.map(normalizeSeriesItem).filter((d: any) => d.week !== '');
            if (arr.length > 0) series = arr;
          } else if (Array.isArray((data as any).values)) {
            const arr = (data as any).values.map((it: any) => {
              const label = (typeof it?.startDate === 'string' && it.startDate)
                || (typeof it?.label === 'string' && it.label)
                || (typeof it?.week === 'string' && it.week)
                || (typeof it?.date === 'string' && it.date)
                || String(it?.x ?? '');
              const valRaw = it?.value ?? it?.deployments ?? it?.count ?? it?.y ?? it?.number;
              const val = Number(valRaw);
              const goal = Number(it?.goal ?? it?.target);
              const item: { week: string; deployments: number; goal?: number } = {
                week: label || '',
                deployments: Number.isFinite(val) ? val : 0,
              };
              if (Number.isFinite(goal)) item.goal = goal;
              return item;
            }).filter((d: any) => d.week !== '');
            if (arr.length > 0) series = arr;
          }

          // If trend is missing, derive it from current/previous (higher is better here)
          if (!('trend' in (data as any)) && !('positive' in (data as any)) && typeof current === 'number' && typeof previous === 'number') {
            trend = current >= previous ? 'up' : 'down';
          }
        } else {
          console.warn('[DoraMetrics] Unexpected deployment payload shape');
        }

        if (!cancelled) {
          setDepCurrent(current);
          setDepPrevious(previous);
          setDepUnit(unit);
          setDepTrend(trend);
          setDepRating(rating);
          setDepSeries(series);
        }
      } catch (e) {
        console.warn('[DoraMetrics] /api/metrics/dora/deployment request failed', e);
      }
    }
    loadDeployment();
    return () => { cancelled = true; };
  }, [interval, selectedUnitId]);

  // Fetch Deployment Frequency chart series from /metrics/dora/chart/deployment
  useEffect(() => {
    let cancelled = false;
    async function loadDeploymentChart() {
      try {
        const params = new URLSearchParams({ interval });
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        if (effectiveTeam) params.set('team', effectiveTeam);
        // Try double-slash variant first (some deployments expose it this way), then single-slash
        const endpoints = [
          `/api/metrics/dora/chart/deployment?${params.toString()}`,
        ];
        let data: any | undefined;
        for (const url of endpoints) {
          try {
            const res = await fetch(url, { credentials: 'include' });
            if (res.ok) {
              data = await res.json();
              break;
            } else {
              console.warn('[DoraMetrics] Deployment chart endpoint responded with', res.status, 'for', url);
            }
          } catch (e) {
            console.warn('[DoraMetrics] Deployment chart request failed for', url, e);
          }
        }
        if (cancelled || !data) return;

        // Expected shape: one value per day (startDate = endDate = the day)
        // { values: [{ startDate, endDate, value }...], sum: { startDate, endDate, value } }
        if (!Array.isArray(data.values)) {
          console.warn('[DoraMetrics] Unexpected deployment chart payload shape');
          return;
        }

        const arr = data.values
          .map((it: any) => {
            const date = typeof it?.startDate === 'string' ? it.startDate : '';
            const val = Number(it?.value);
            return {
              date,
              label: date.length >= 10 ? `${date.slice(8, 10)}.${date.slice(5, 7)}` : date,
              deployments: Number.isFinite(val) ? val : 0,
            };
          })
          .filter((d: { date: string }) => d.date);

        if (arr.length > 0 && !cancelled) {
          setDepSeries(arr);
          // Keep unit consistent with selected date range
          setDepUnit(getIntervalSuffix(dateRange, lang));
          // Do not overwrite KPI current/previous coming from /api/metrics/dora/deployment
        }
      } catch (e) {
        console.warn('[DoraMetrics] Failed to load deployment chart series', e);
      }
    }
    loadDeploymentChart();
    return () => { cancelled = true; };
  }, [interval, selectedUnitId]);

  // Fetch Lead Time for Changes chart series from /metrics/dora/chart/leadTime
  useEffect(() => {
    let cancelled = false;
    async function loadLeadTimeChart() {
      try {
        const params = new URLSearchParams({ interval });
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        const endpoints = [
          `/api/metrics/dora/chart/leadTime?${params.toString()}`,
        ];
        let data: any | undefined;
        for (const url of endpoints) {
          try {
            const res = await fetch(url, { credentials: 'include' });
            if (res.ok) {
              data = await res.json();
              break;
            } else {
              console.warn('[DoraMetrics] Lead Time chart endpoint responded with', res.status, 'for', url);
            }
          } catch (e) {
            console.warn('[DoraMetrics] Lead Time chart request failed for', url, e);
          }
        }
        if (cancelled || !data) return;
        if (!Array.isArray(data.values)) {
          console.warn('[DoraMetrics] Unexpected lead time chart payload shape');
          return;
        }
        const arr = data.values
          .map((it: any) => {
            const start = typeof it?.startDate === 'string' ? it.startDate : '';
            const end = typeof it?.endDate === 'string' ? it.endDate : '';
            const label = end ? `${start} – ${end}` : start;
            const val = Number(it?.value);
            const item: { week: string; leadTime: number } = {
              week: label,
              leadTime: Number.isFinite(val) ? val : 0,
            };
            return item;
          })
          .filter((d: any) => d.week);
        if (arr.length > 0 && !cancelled) {
          setLtSeries(arr);
          // Keep units consistent; KPI fetch controls ltUnit
        }
      } catch (e) {
        console.warn('[DoraMetrics] Failed to load lead time chart series', e);
      }
    }
    loadLeadTimeChart();
    return () => { cancelled = true; };
  }, [interval, selectedUnitId]);

  // Fetch Lead Time for Changes
  useEffect(() => {
    let cancelled = false;
    async function loadLeadTime() {
      try {
        const params = new URLSearchParams({ interval });
        if (selectedUnitId) params.set('unitId', selectedUnitId);
        if (effectiveTeam) params.set('team', effectiveTeam);
        const endpoints = [

          `/api/metrics/dora/leadTime?${params.toString()}`,
        ];
        let data: any | undefined;
        for (const url of endpoints) {
          try {
            const res = await fetch(url, { credentials: 'include' });
            if (res.ok) {
              data = await res.json();
              break;
            } else {
              console.warn('[DoraMetrics] Lead Time endpoint responded with', res.status, 'for', url);
            }
          } catch (e) {
            console.warn('[DoraMetrics] Lead Time request failed for', url, e);
          }
        }
        if (!data) return; // keep mocks
        setHasData(true);
        if (cancelled) return;

        // Defaults to existing values, override if present
        let current = ltCurrent;
        let previous = ltPrevious;
        let unit = ltUnit;
        let trend: 'up'|'down' = ltTrend;
        let rating: Rating = ltRating;
        let series = ltSeries;

        const normalizeSeriesItem = (it: any) => {
          const label = (typeof it?.week === 'string' && it.week) || (typeof it?.label === 'string' && it.label) || (typeof it?.date === 'string' && it.date) || String(it?.x ?? '');
          const valRaw = it?.leadTime ?? it?.value ?? it?.hours ?? it?.y ?? it?.number;
          const val = Number(valRaw);
          const target = Number(it?.target ?? it?.goal);
          const item: { week: string; leadTime: number; target?: number } = {
            week: label || '',
            leadTime: Number.isFinite(val) ? val : 0,
          };
          if (Number.isFinite(target)) (item as any).target = target;
          return item;
        };

        if (Array.isArray(data)) {
          const arr = data.map(normalizeSeriesItem).filter((d: any) => d.week !== '');
          if (arr.length > 0) {
            series = arr;
            const last = arr[arr.length - 1]?.leadTime ?? ltCurrent;
            const prev = arr[arr.length - 2]?.leadTime ?? ltPrevious;
            current = last;
            previous = prev;
            trend = last <= prev ? 'down' : 'up';
          }
        } else if (typeof data === 'object' && data) {
          // Support multiple payload shapes
          // 1) { current, previous, unit, trend, rating, series }
          // 2) { value, prev|previousValue, unit, positive, rating, values }
          // 3) { current: { value, unit }, previous: { value }, series: [...] }

          // Direct numeric fields
          if (typeof (data as any).current === 'number') current = (data as any).current;
          if (typeof (data as any).previous === 'number') previous = (data as any).previous;

          // Alternative naming
          if (typeof (data as any).value === 'number') current = (data as any).value;
          if (typeof (data as any).prev === 'number') previous = (data as any).prev;
          if (typeof (data as any).previousValue === 'number') previous = (data as any).previousValue;

          // Nested objects with value/unit
          if (data && typeof (data as any).current === 'object' && (data as any).current) {
            const c = (data as any).current;
            if (typeof c.value === 'number') current = c.value;
            if (typeof c.unit === 'string') unit = c.unit || 'hours';
          }
          if (data && typeof (data as any).previous === 'object' && (data as any).previous) {
            const p = (data as any).previous;
            if (typeof p.value === 'number') previous = p.value;
          }

          // Unit at root
          if (typeof (data as any).unit === 'string') unit = (data as any).unit || 'hours';

          // Trend/rating handling
          if (typeof (data as any).trend === 'string') trend = (data as any).trend === 'up' ? 'up' : 'down';
          if (typeof (data as any).positive === 'boolean') {
            // For Lead Time: positive=true means improvement (lower is better) => trend 'down'
            trend = (data as any).positive ? 'down' : 'up';
          }
          if (typeof (data as any).rating === 'string') {
            const r = String((data as any).rating).toLowerCase();
            if (r === 'elite' || r === 'high' || r === 'medium' || r === 'low') rating = r as Rating;
          }

          // Series can be under series or values
          if (Array.isArray((data as any).series)) {
            const arr = (data as any).series.map(normalizeSeriesItem).filter((d: any) => d.week !== '');
            if (arr.length > 0) series = arr;
          } else if (Array.isArray((data as any).values)) {
            const arr = (data as any).values.map((it: any) => {
              // Expect shapes like { startDate, endDate, value } or generic label/value
              const label = (typeof it?.startDate === 'string' && it.startDate)
                || (typeof it?.label === 'string' && it.label)
                || (typeof it?.week === 'string' && it.week)
                || (typeof it?.date === 'string' && it.date)
                || String(it?.x ?? '');
              const valRaw = it?.value ?? it?.leadTime ?? it?.hours ?? it?.y ?? it?.number;
              const val = Number(valRaw);
              const target = Number(it?.target ?? it?.goal);
              const item: { week: string; leadTime: number; target?: number } = {
                week: label || '',
                leadTime: Number.isFinite(val) ? val : 0,
              };
              if (Number.isFinite(target)) (item as any).target = target;
              return item;
            }).filter((d: any) => d.week !== '');
            if (arr.length > 0) series = arr;
          }

          // If trend is missing, derive it from current/previous (lower is better here)
          if (!('trend' in (data as any)) && !('positive' in (data as any)) && typeof current === 'number' && typeof previous === 'number') {
            trend = current <= previous ? 'down' : 'up';
          }
        } else {
          console.warn('[DoraMetrics] Unexpected leadTime payload shape');
        }

        if (!cancelled) {
          setLtCurrent(current);
          setLtPrevious(previous);
          setLtUnit(unit);
          setLtTrend(trend);
          setLtRating(rating);
          setLtSeries(series);
        }
      } catch (e) {
        console.warn('[DoraMetrics] /api/metrics/dora/leadTime request failed', e);
      }
    }
    loadLeadTime();
    return () => { cancelled = true; };
  }, [interval, selectedUnitId]);
  const [localBenchmark, setLocalBenchmark] = useState(false);
  // Local Benchmark: each KPI against the average of all units of the same type in the organization
  // (/api/metrics/benchmark/dora, same period)
  const [doraBench, setDoraBench] = useState<OrgBenchResponse | null>(null);

  useEffect(() => {
    if (!localBenchmark) { setDoraBench(null); return; }
    const controller = new AbortController();
    fetchOrgBenchmark('dora', interval, selectedUnitId, controller.signal).then((data) => {
      if (!controller.signal.aborted) setDoraBench(data ?? { metrics: {} });
    });
    return () => controller.abort();
  }, [interval, selectedUnitId, localBenchmark]);

  // undefined hides the badge (benchmark off or loading), null shows "no data"
  const benchFor = (key: string): OrgBenchItem | null | undefined =>
    !localBenchmark || !doraBench ? undefined : (doraBench.metrics?.[key] ?? null);

  if (!hasData) {
    return (
      <div className="p-6 mx-auto">
        {!timedOut ? (
          <div className="bg-white rounded-xl border border-gray-200 p-10 flex items-center justify-center">
            <LoadingSpinner size={22} />
          </div>
        ) : (
          <div className="bg-white rounded-xl border border-gray-200 p-10 text-center text-gray-500 text-[12px]">
            {t('noData')}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="p-4 sm:p-6 mx-auto space-y-6">

      {/* Header */}
      <div className="flex flex-col gap-2">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-start gap-2 min-w-0">
            <div className="min-w-0">
              <h1 className="text-[20px] text-gray-900" style={{ fontWeight: 700 }}>{t('doraMetrics')}</h1>
              <p className="text-[13px] text-gray-500 mt-0.5">
                {t('devopsSubtitle')} · {dateRangeLabel}
              </p>
            </div>
            <HelpTip
              size="sm"
              content={pick(
                'DORA metrics track software delivery performance: Deployment Frequency (how often you ship), Lead Time for Changes (speed to deliver), Change Failure Rate (quality/risk), and MTTR (operational resilience). Use together to balance speed and stability.',
                'Metryki DORA opisują wydajność dostarczania oprogramowania: Częstotliwość wdrożeń (jak często wdrażasz), Czas realizacji zmian (szybkość dostarczania), Wskaźnik nieudanych wdrożeń (jakość/ryzyko) oraz MTTR (odporność operacyjna). Używaj ich łącznie, aby równoważyć szybkość i stabilność.'
              )}
            />
          </div>
          {/* Local Benchmark toggle */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => setLocalBenchmark((v) => !v)}
              className={`px-3 py-1.5 rounded-md border text-[12px] transition-colors ${
                localBenchmark ? 'bg-indigo-600 text-white border-indigo-600' : 'bg-white text-gray-700 border-gray-200 hover:bg-gray-50'
              }`}
            >
              {t('localBenchmark')}
            </button>
          </div>
        </div>
      </div>


      {/* 4 DORA KPI Cards with attached Local Benchmark badges */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <div className="relative">
          <DoraCard
            title={t('deployFrequency')}
            value={depCurrent}
            unit={depUnit}
            previous={depPrevious}
            trend={depTrend}
            rating={depRating}
            goodDirection="up"
            icon={Rocket}
            iconColor="bg-indigo-500"
            bench={benchFor('deployFreq')}
            benchUnitType={doraBench?.unitType}
            help={pick(
              'How often code is released to production. Higher is better and usually correlates with smaller batch sizes and faster feedback.',
              'Jak często kod trafia na produkcję. Wyższa wartość zwykle oznacza mniejsze paczki zmian i szybszą informację zwrotną.'
            )}
          />
        </div>

        <div className="relative">
          <DoraCard
            title={t('leadTimeForChanges')}
            value={ltCurrent}
            unit={lang === 'pl' ? 'godziny' : 'h'}
            previous={ltPrevious}
            trend={ltTrend}
            rating={ltRating}
            goodDirection="down"
            icon={Clock}
            iconColor="bg-violet-500"
            bench={benchFor('leadTime')}
            benchUnitType={doraBench?.unitType}
            help={pick(
              'Average time from the first commit of a merge request to its merge into main/master, over merge requests merged in the period. It is the sum of the Coding, Pickup, Review and Merge stages below. Lower is better.',
              'Średni czas od pierwszego commita merge requesta do jego merge\'a do main/master, liczony dla MR-ów zmergowanych w okresie. To suma etapów Kodowanie, Podjęcie, Przegląd i Scalenie poniżej. Mniej znaczy lepiej.'
            )}
          />
        </div>

        <div className="relative">
          <DoraCard
            title={t('changeFailureRate')}
            value={doraMetrics.changeFailureRate.current}
            unit="%"
            previous={doraMetrics.changeFailureRate.previous}
            trend={doraMetrics.changeFailureRate.trend}
            rating={doraMetrics.changeFailureRate.rating}
            goodDirection="down"
            icon={AlertTriangle}
            iconColor="bg-amber-500"
            bench={benchFor('changeFailure')}
            benchUnitType={doraBench?.unitType}
            help={pick(
              'Share of deployments that cause incidents, degraded service, or require rollback. Lower is better; improve with quality gates, testing, and gradual rollouts.',
              'Udział wdrożeń powodujących incydenty, degradację usług lub wymagających wycofania. Mniej znaczy lepiej; poprawiaj dzięki bramkom jakości, testom i stopniowym wdrożeniom.'
            )}
          />
        </div>

        <div className="relative">
          <DoraCard
            title={t('meanTimeToRecovery')}
            value={doraMetrics.mttr.current}
            unit={lang === 'pl' ? 'godziny' : 'h'}
            previous={doraMetrics.mttr.previous}
            trend={doraMetrics.mttr.trend}
            rating={doraMetrics.mttr.rating}
            goodDirection="down"
            icon={Wrench}
            iconColor="bg-emerald-500"
            bench={benchFor('mttr')}
            benchUnitType={doraBench?.unitType}
            help={pick(
              'Average time to restore service after a production incident. Lower is better; invest in observability, on-call readiness, and fast rollback.',
              'Średni czas przywrócenia usługi po incydencie produkcyjnym. Mniej znaczy lepiej; inwestuj w obserwowalność, gotowość on‑call i szybkie wycofanie.'
            )}
          />
        </div>
      </div>


        {/* Cycle Time Breakdown (API-backed) */}
        <CycleTimeBreakdown interval={interval} team={effectiveTeam} />
      {/* Trend charts — 2×2 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">

        {/* Deployment Frequency */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-1 mb-1">
            <h2 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>{t('deployFrequency')}</h2>
            <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-50 border border-emerald-200 text-[11px] text-emerald-700" style={{ fontWeight: 600 }}>
              <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full" /> {t('ratingElite')}
            </div>
          </div>
          <p className="text-[12px] text-gray-400 mb-4">
            {pick('Jira release tasks moved to LIVE per day', 'Taski release z Jiry przestawione na LIVE dziennie')} · {pick('total', 'razem')}: {depTotal}
          </p>
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={depSeries}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                <XAxis dataKey="label" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} minTickGap={16} />
                <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} allowDecimals={false} />
                <Tooltip
                  contentStyle={tooltipStyle}
                  labelFormatter={(_: unknown, payload: ReadonlyArray<{ payload?: { date?: string } }>) => payload?.[0]?.payload?.date ?? ''}
                />
                <Line type="monotone" dataKey="deployments" stroke="#6366f1" strokeWidth={2} dot={depSeries.length <= 31 ? { r: 2.5 } : false} name={pick('Releases to LIVE', 'Wdrożenia na LIVE')} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Lead Time */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-1 mb-1">
            <h2 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>{t('leadTimeForChanges')}</h2>
            <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-50 border border-emerald-200 text-[11px] text-emerald-700" style={{ fontWeight: 600 }}>
              <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full" /> {t('ratingElite')}
            </div>
          </div>
          <p className="text-[12px] text-gray-400 mb-4">{pick('Hours from commit to production · target: 3h','Godziny od commita do produkcji · cel: 3 godziny')}</p>
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={ltSeries}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                <XAxis dataKey="week" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} unit="h" />
                <Tooltip contentStyle={tooltipStyle} />
                <ReferenceLine y={ltTarget} stroke="#f59e0b" strokeDasharray="4 4" strokeWidth={1.5} label={{ value: t('target'), fill: '#f59e0b', fontSize: 10, position: 'right' }} />
                <Line type="monotone" dataKey="leadTime" stroke="#8b5cf6" strokeWidth={2.5} dot={{ fill: '#8b5cf6', r: 4, strokeWidth: 0 }} activeDot={{ r: 6 }} name={t('leadTimeForChanges')} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Change Failure Rate */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-1 mb-1">
            <h2 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>{t('changeFailureRate')}</h2>
            <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-50 border border-emerald-200 text-[11px] text-emerald-700" style={{ fontWeight: 600 }}>
              <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full" /> {t('ratingElite')}
            </div>
          </div>
          <p className="text-[12px] text-gray-400 mb-4">{pick('% of deployments causing failures · target: <5%','% wdrożeń powodujących awarie · cel: <5%')}</p>
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={changeFailureRateData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                <XAxis dataKey="week" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} unit="%" />
                <Tooltip contentStyle={tooltipStyle} />
                <ReferenceLine y={5} stroke="#ef4444" strokeDasharray="4 4" strokeWidth={1.5} label={{ value: t('target'), fill: '#ef4444', fontSize: 10, position: 'right' }} />
                <Line type="monotone" dataKey="rate" stroke="#f59e0b" strokeWidth={2.5} dot={{ fill: '#f59e0b', r: 4, strokeWidth: 0 }} activeDot={{ r: 6 }} name={t('changeFailureRate')} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* MTTR */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex flex-wrap items-start justify-between gap-x-3 gap-y-1 mb-1">
            <h2 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>{t('meanTimeToRecovery')}</h2>
            <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-50 border border-emerald-200 text-[11px] text-emerald-700" style={{ fontWeight: 600 }}>
              <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full" /> {t('ratingElite')}
            </div>
          </div>
          <p className="text-[12px] text-gray-400 mb-4">{pick('Hours to restore service · target: <1h','Godziny do przywrócenia usługi · cel: <1 godzina')}</p>
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={mttrData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                <XAxis dataKey="week" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} unit="h" />
                <Tooltip contentStyle={tooltipStyle} />
                <ReferenceLine y={1} stroke="#ef4444" strokeDasharray="4 4" strokeWidth={1.5} label={{ value: t('target'), fill: '#ef4444', fontSize: 10, position: 'right' }} />
                <Line type="monotone" dataKey="hours" stroke="#10b981" strokeWidth={2.5} dot={{ fill: '#10b981', r: 4, strokeWidth: 0 }} activeDot={{ r: 6 }} name="MTTR" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>




      {/* DORA Benchmarks Table */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-100">
          <h2 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>{t('doraBenchTitle')}</h2>
          <p className="text-[12px] text-gray-400 mt-0.5">{t('doraBenchSubtitle')}</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px]">
            <thead>
              <tr className="bg-gray-50">
                <th className="px-5 py-3 text-left text-[11px] text-gray-500 uppercase tracking-wide" style={{ fontWeight: 600 }}>{t('metric')}</th>
                {(['elite', 'high', 'medium', 'low'] as Rating[]).map((r) => (
                  <th key={r} className="px-5 py-3 text-left text-[11px] uppercase tracking-wide" style={{ fontWeight: 600 }}>
                    <div className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full border ${RATING_CONFIG[r].bg} ${RATING_CONFIG[r].text} ${RATING_CONFIG[r].border}`}>
                      <div className={`w-1.5 h-1.5 rounded-full ${RATING_CONFIG[r].dot}`} />
                      {r === 'elite' ? t('ratingElite') : r === 'high' ? t('ratingHigh') : r === 'medium' ? t('ratingMedium') : t('ratingLow')}
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {[
                { label: t('deployFrequency'), key: 'deploy' },
                { label: t('leadTimeForChanges'), key: 'lead' },
                { label: 'MTTR', key: 'mttr' },
                { label: t('changeFailureRate'), key: 'cfr' },
              ].map((row) => (
                <tr key={row.key} className="hover:bg-gray-50/50">
                  <td className="px-5 py-3 text-[13px] text-gray-700" style={{ fontWeight: 500 }}>{row.label}</td>
                  {(['elite', 'high', 'medium', 'low'] as Rating[]).map((r) => (
                    <td key={r} className="px-5 py-3 text-[12px] text-gray-500">
                      {benchmarks[r][row.key as keyof typeof benchmarks.elite]}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>



    </div>
  );
}
