import { codeQualityMetrics, testCoverageData, prMetricsData } from '../data/mockData';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Area,
  AreaChart,
  ReferenceLine,
  Cell,
} from 'recharts';
import { TrendingUp, TrendingDown, GitPullRequest, Clock, TestTube2, Shuffle } from 'lucide-react';
import { useDateRange } from '../context/DateRangeContext';

const tooltipStyle = {
  backgroundColor: 'white',
  border: '1px solid #e5e7eb',
  borderRadius: '8px',
  fontSize: '12px',
  boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
};

function MetricTile({
  label,
  value,
  unit,
  previous,
  trend,
  goodDirection = 'up',
  icon: Icon,
  iconBg,
}: {
  label: string;
  value: number;
  unit: string;
  previous: number;
  trend: 'up' | 'down';
  goodDirection?: 'up' | 'down';
  icon: React.ElementType;
  iconBg: string;
}) {
  const pct = Math.abs(((value - previous) / previous) * 100).toFixed(1);
  const isGood = trend === goodDirection;
  return (
    <div className="bg-white rounded-xl border border-gray-200 p-5">
      <div className="flex items-center gap-2 mb-3">
        <div className={`w-8 h-8 rounded-lg ${iconBg} flex items-center justify-center`}>
          <Icon className="w-4 h-4 text-white" />
        </div>
        <span className="text-[12px] text-gray-500 uppercase tracking-wide" style={{ fontWeight: 600, letterSpacing: '0.05em' }}>{label}</span>
      </div>
      <div className="flex items-baseline gap-1.5 mb-2">
        <span className="text-[28px] text-gray-900" style={{ fontWeight: 700, lineHeight: 1 }}>{value}</span>
        <span className="text-[13px] text-gray-400">{unit}</span>
      </div>
      <div className={`flex items-center gap-1 text-[12px] ${isGood ? 'text-emerald-600' : 'text-red-500'}`}>
        {trend === 'up' ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
        <span style={{ fontWeight: 500 }}>{pct}%</span>
        <span className="text-gray-400">· was {previous} {unit}</span>
      </div>
    </div>
  );
}

const prSizeData = [
  { range: '<50', count: 28, fill: '#10b981' },
  { range: '50–200', count: 45, fill: '#6366f1' },
  { range: '200–500', count: 19, fill: '#f59e0b' },
  { range: '500+', count: 8, fill: '#ef4444' },
];

export function CodeQuality() {
  const { dateRange, label: dateRangeLabel } = useDateRange();
  return (
    <div className="p-4 sm:p-6 mx-auto space-y-6">

      {/* Header */}
      <div>
        <h1 className="text-[20px] text-gray-900" style={{ fontWeight: 700 }}>Code Quality</h1>
        <p className="text-[13px] text-gray-500 mt-0.5">Monitor code health, PR practices, and test coverage · {dateRangeLabel}</p>
      </div>

      {/* KPI cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricTile
          label="Review Time"
          value={codeQualityMetrics.codeReviewTime.current}
          unit="hours"
          previous={codeQualityMetrics.codeReviewTime.previous}
          trend={codeQualityMetrics.codeReviewTime.trend}
          goodDirection="down"
          icon={Clock}
          iconBg="bg-indigo-500"
        />
        <MetricTile
          label="Avg PR Size"
          value={codeQualityMetrics.prSize.current}
          unit="lines"
          previous={codeQualityMetrics.prSize.previous}
          trend={codeQualityMetrics.prSize.trend}
          goodDirection="down"
          icon={GitPullRequest}
          iconBg="bg-violet-500"
        />
        <MetricTile
          label="Test Coverage"
          value={codeQualityMetrics.testCoverage.current}
          unit="%"
          previous={codeQualityMetrics.testCoverage.previous}
          trend={codeQualityMetrics.testCoverage.trend}
          goodDirection="up"
          icon={TestTube2}
          iconBg="bg-emerald-500"
        />
        <MetricTile
          label="Code Churn"
          value={codeQualityMetrics.codeChurn.current}
          unit="%"
          previous={codeQualityMetrics.codeChurn.previous}
          trend={codeQualityMetrics.codeChurn.trend}
          goodDirection="down"
          icon={Shuffle}
          iconBg="bg-amber-500"
        />
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">

        {/* Test Coverage Trend */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex items-center justify-between mb-1">
            <h2 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>Test Coverage</h2>
            <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-50 border border-emerald-200 text-[11px] text-emerald-700" style={{ fontWeight: 600 }}>
              84.5% · Above target
            </div>
          </div>
          <p className="text-[12px] text-gray-400 mb-4">Rolling 6 months · Target: 80%</p>
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={testCoverageData}>
                <defs>
                  <linearGradient id="gradCov" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.2} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} unit="%" domain={[68, 90]} />
                <Tooltip contentStyle={tooltipStyle} />
                <ReferenceLine y={80} stroke="#f59e0b" strokeDasharray="4 4" strokeWidth={1.5} label={{ value: 'Target', fill: '#f59e0b', fontSize: 10, position: 'right' }} />
                <Area type="monotone" dataKey="coverage" stroke="#10b981" strokeWidth={2.5} fill="url(#gradCov)" dot={{ fill: '#10b981', r: 4, strokeWidth: 0 }} name="Coverage %" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* PR Activity */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex items-center justify-between mb-1">
            <h2 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>PR Activity</h2>
          </div>
          <p className="text-[12px] text-gray-400 mb-4">Opened / Merged / Closed this week</p>
          <div className="h-52">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={prMetricsData} barSize={10}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" vertical={false} />
                <XAxis dataKey="day" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                <Tooltip contentStyle={tooltipStyle} cursor={{ fill: '#f9fafb' }} />
                <Legend formatter={(v) => <span className="text-[11px] text-gray-500">{v}</span>} iconSize={8} />
                <Bar dataKey="opened" fill="#6366f1" name="Opened" radius={[3, 3, 0, 0]} />
                <Bar dataKey="merged" fill="#10b981" name="Merged" radius={[3, 3, 0, 0]} />
                <Bar dataKey="closed" fill="#ef4444" name="Closed" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* PR size distribution + review turnaround */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">

        {/* PR Size Distribution */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h2 className="text-[14px] text-gray-900 mb-4" style={{ fontWeight: 600 }}>PR Size Distribution</h2>
          <div className="h-44">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={prSizeData} layout="vertical" barSize={16}>
                <XAxis type="number" tick={{ fontSize: 11, fill: '#9ca3af' }} axisLine={false} tickLine={false} />
                <YAxis type="category" dataKey="range" tick={{ fontSize: 11, fill: '#6b7280' }} axisLine={false} tickLine={false} width={55} />
                <Tooltip contentStyle={tooltipStyle} cursor={{ fill: '#f9fafb' }} />
                <Bar dataKey="count" name="PRs" radius={[0, 4, 4, 0]}>
                  {prSizeData.map((entry, i) => (
                    <Cell key={i} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-3 pt-3 border-t border-gray-100">
            <p className="text-[12px] text-gray-500">
              <span className="text-emerald-600" style={{ fontWeight: 600 }}>73% of PRs</span> are under 200 lines — great for reviewability.
            </p>
          </div>
        </div>

        {/* Review Turnaround */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h2 className="text-[14px] text-gray-900 mb-4" style={{ fontWeight: 600 }}>Review Turnaround</h2>
          <div className="space-y-4">
            {[
              { label: 'First response', value: '2.3h', pct: 85, color: 'bg-emerald-500' },
              { label: 'Review completion', value: '4.5h', pct: 72, color: 'bg-indigo-500' },
              { label: 'Approval to merge', value: '1.2h', pct: 90, color: 'bg-violet-500' },
            ].map((item) => (
              <div key={item.label}>
                <div className="flex justify-between items-center mb-1.5">
                  <span className="text-[12px] text-gray-600">{item.label}</span>
                  <span className="text-[13px] text-gray-900" style={{ fontWeight: 600 }}>{item.value}</span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-2">
                  <div className={`h-2 rounded-full ${item.color}`} style={{ width: `${item.pct}%` }} />
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 pt-4 border-t border-gray-100 grid grid-cols-2 gap-3">
            <div>
              <p className="text-[11px] text-gray-400">PRs with reviews</p>
              <p className="text-[16px] text-gray-900" style={{ fontWeight: 700 }}>98%</p>
            </div>
            <div>
              <p className="text-[11px] text-gray-400">Comments / PR</p>
              <p className="text-[16px] text-gray-900" style={{ fontWeight: 700 }}>5.3</p>
            </div>
          </div>
        </div>

        {/* Quality scores */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h2 className="text-[14px] text-gray-900 mb-4" style={{ fontWeight: 600 }}>Quality Scores</h2>
          <div className="space-y-4">
            {[
              { label: 'Code Maintainability', score: 8.7, color: 'bg-emerald-500', textColor: 'text-emerald-600' },
              { label: 'PR Quality', score: 9.2, color: 'bg-indigo-500', textColor: 'text-indigo-600' },
              { label: 'Test Quality', score: 8.4, color: 'bg-violet-500', textColor: 'text-violet-600' },
            ].map((item) => (
              <div key={item.label}>
                <div className="flex justify-between items-center mb-1.5">
                  <span className="text-[12px] text-gray-600">{item.label}</span>
                  <span className={`text-[13px] ${item.textColor}`} style={{ fontWeight: 700 }}>{item.score}/10</span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-2">
                  <div className={`h-2 rounded-full ${item.color}`} style={{ width: `${item.score * 10}%` }} />
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 pt-4 border-t border-gray-100">
            <div className="flex justify-between items-center">
              <span className="text-[12px] text-gray-500">Open code issues</span>
              <div className="text-right">
                <p className="text-[16px] text-gray-900" style={{ fontWeight: 700 }}>23</p>
                <p className="text-[11px] text-red-500">12 critical</p>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}
