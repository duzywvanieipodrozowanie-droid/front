import React, { useEffect, useMemo, useState } from 'react';
import { ShieldCheck, Gauge, Activity, BadgeCheck, Settings2, ChevronDown } from 'lucide-react';

function Donut({ value, size = 160, stroke = 14, color = '#6366F1' }: { value: number; size?: number; stroke?: number; color?: string }) {
  // Make responsive using viewBox and percentage sizing; "size" acts as nominal viewBox size
  const vb = size;
  const r = (vb - stroke) / 2;
  const c = 2 * Math.PI * r;
  const clamped = Math.max(0, Math.min(100, value));
  const off = c * (1 - clamped / 100);
  return (
    <svg viewBox={`0 0 ${vb} ${vb}`} preserveAspectRatio="xMidYMid meet" className="block w-full h-auto">
      <g transform={`rotate(-90 ${vb / 2} ${vb / 2})`}>
        <circle cx={vb / 2} cy={vb / 2} r={r} stroke="#E5E7EB" strokeWidth={stroke} fill="none" />
        <circle cx={vb / 2} cy={vb / 2} r={r} stroke={color} strokeWidth={stroke} fill="none" strokeDasharray={c} strokeDashoffset={off} strokeLinecap="round" />
      </g>
      <text x="50%" y="48%" textAnchor="middle" className="fill-gray-900" style={{ fontSize: 24, fontWeight: 800 }}>{clamped.toFixed(1)}%</text>
      <text x="50%" y="64%" textAnchor="middle" className="fill-gray-500" style={{ fontSize: 11, fontWeight: 600 }}>Organization</text>
    </svg>
  );
}

function MiniKPI({ title, value, sub, color = 'indigo' }: { title: string; value: string; sub?: string; color?: 'indigo'|'emerald'|'violet'|'amber' }) {
  const map: Record<string, string> = {
    indigo: 'bg-indigo-50 text-indigo-700 border-indigo-200',
    emerald: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    violet: 'bg-violet-50 text-violet-700 border-violet-200',
    amber: 'bg-amber-50 text-amber-700 border-amber-200',
  };
  return (
    <div className="flex items-center gap-3">
      <div className={`px-2 py-0.5 rounded-full border text-[11px] ${map[color]}`} style={{ fontWeight: 700 }}>{value}</div>
      <div>
        <div className="text-[12px] text-gray-800" style={{ fontWeight: 600 }}>{title}</div>
        {sub && <div className="text-[11px] text-gray-500">{sub}</div>}
      </div>
    </div>
  );
}

function TrendBars({ values, color = '#10B981' }: { values: number[]; color?: string }) {
  // Responsive sparkline with viewBox and fluid width
  const w = 90, h = 36, pad = 4;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const rng = Math.max(1, max - min);
  const innerW = w - pad * 2;
  const innerH = h - pad * 2;
  const n = Math.max(1, values.length - 1);
  const ptsArr = values.map((v, i) => {
    const x = pad + (i * innerW) / Math.max(1, n);
    const y = h - pad - ((v - min) / rng) * innerH;
    return [x, y] as const;
  });
  const points = ptsArr.map(([x, y]) => `${x},${y}`).join(' ');
  const baseY = h - pad;
  const firstX = ptsArr[0]?.[0] ?? pad;
  const lastX = ptsArr[ptsArr.length - 1]?.[0] ?? (w - pad);
  const gid = React.useId();
  return (
    <svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" className="overflow-visible w-full h-9">
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity={0.26} />
          <stop offset="100%" stopColor={color} stopOpacity={0} />
        </linearGradient>
      </defs>
      {/* area under line */}
      <polygon fill={`url(#${gid})`} stroke="none" points={`${points} ${lastX},${baseY} ${firstX},${baseY}`} />
      <polyline fill="none" stroke={color} strokeWidth={2} points={points} strokeLinejoin="round" strokeLinecap="round" />
      {ptsArr.map(([x, y], i) => (
        <circle key={i} cx={x} cy={y} r={2.5} fill="#fff" stroke={color} strokeWidth={1.5} />
      ))}
    </svg>
  );
}

// Compact vertical bars like on the reference card (4 bars)
function BarMini({ values, color = '#10B981' }: { values: number[]; color?: string }) {
  // Responsive mini bars using viewBox and fluid sizing
  const w = 90, h = 36, pad = 6;
  const min = Math.min(...values);
  const max = Math.max(...values);
  const rng = Math.max(1, max - min);
  const n = values.length;
  const gap = 4;
  const colW = Math.max(6, Math.floor((w - pad * 2 - gap * (n - 1)) / Math.max(1, n)));
  return (
    <svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" className="w-full h-9">
      {values.map((v, i) => {
        const x = pad + i * (colW + gap);
        const hh = ((v - min) / rng) * (h - pad * 2);
        const y = h - pad - hh;
        const fill = color;
        return <rect key={i} x={x} y={y} width={colW} height={Math.max(1, hh)} rx={2} ry={2} fill={fill} opacity={0.9} />;
      })}
    </svg>
  );
}

// Simple horizontal progress bar to show AI users vs team size
function AiUsageBar({ percent }: { percent: number }) {
  const pct = Math.max(0, Math.min(100, Math.round(percent)));
  return (
    <div className="w-full h-2 rounded-full bg-gray-200 overflow-hidden">
      <div className="h-full bg-amber-500" style={{ width: `${pct}%` }} />
    </div>
  );
}

interface SubTeam { name: string; metrics: { label: string; value: number; trend: number[]; type: 'eff'|'qual'|'speed'|'ai' }[]; aiAdoption: number; aiUsers: number; teamSize: number }
interface Domain { name: string; score: number; teams: SubTeam[] }

// Helpers for deterministic mock metrics
function hash(s: string): number {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
function prng(seed: number) {
  let x = seed >>> 0;
  return () => {
    x ^= x << 13; x ^= x >>> 17; x ^= x << 5;
    return ((x >>> 0) % 10000) / 10000;
  };
}
function around(base: number, jitter: number, rnd: () => number) {
  const v = base + (rnd() * 2 - 1) * jitter;
  return Math.max(0, Math.min(100, Math.round(v)));
}
function mkTrend(len: number, start: number, drift: number, rnd: () => number): number[] {
  const out: number[] = [];
  let cur = start;
  for (let i = 0; i < len; i++) {
    cur = cur + drift + (rnd() * 2 - 1) * 0.6;
    out.push(Math.max(0, Math.min(10, Math.round(cur))));
  }
  return out;
}
function mkTeam(name: string, seedLabel: string): SubTeam {
  const rnd = prng(hash(seedLabel + ':' + name));
  const effBase = 80 + Math.round(rnd() * 15);
  const qualBase = 75 + Math.round(rnd() * 18);
  const speedBase = 82 + Math.round(rnd() * 14);
  const aiBase = 50 + Math.round(rnd() * 45);
  const aiAdoption = around(aiBase, 8, rnd);
  const teamSize = 6 + Math.floor(rnd() * 9);
  const aiUsers = Math.max(0, Math.min(teamSize, Math.round(teamSize * aiAdoption / 100)));
  return {
    name,
    metrics: [
      { label: 'Process Efficiency', value: around(effBase, 4, rnd), trend: mkTrend(7, 6 + rnd() * 2, 0.4 + rnd() * 0.2, rnd), type: 'eff' },
      { label: 'Development Quality', value: around(qualBase, 5, rnd), trend: mkTrend(7, 6 + rnd() * 2, 0.2 + rnd() * 0.2, rnd), type: 'qual' },
      { label: 'Software Delivery', value: around(speedBase, 3, rnd), trend: mkTrend(7, 7 + rnd() * 2, 0.3 + rnd() * 0.2, rnd), type: 'speed' },
      { label: 'AI Adoption', value: aiAdoption, trend: mkTrend(7, 6 + rnd() * 2, 0.25 + rnd() * 0.2, rnd), type: 'ai' },
    ],
    aiAdoption,
    aiUsers,
    teamSize,
  };
}

export function ControlTower() {
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const [domains, setDomains] = useState<Domain[] | null>(null);
  const [global, setGlobal] = useState<number>(0);
  const [aiGlobal, setAiGlobal] = useState<number>(0);
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);

  // Check admin role from /api/user
  useEffect(() => {
    let cancelled = false;
    async function load() {
      try {
        const res = await fetch('/api/user', { credentials: 'include' });
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const js = await res.json();
        const auths: string[] = Array.isArray(js?.authorities) ? js.authorities : [];
        const norm = (s: any) => String(s || '').toUpperCase();
        if (!cancelled) setIsAdmin(auths.map(norm).includes('ADMIN'));
      } catch {
        if (!cancelled) setIsAdmin(false);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }
    load();
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    if (!isAdmin) return; // only load data for admins
    let cancelled = false;

    const norm = (s: any): string => String(s ?? '').trim().toLowerCase();
    const isType = (node: any, ...keys: string[]) => {
      const t = norm((node && (node.type || node.level || node.kind || node.category)) ?? '');
      return keys.some(k => t.includes(k));
    };
    const getChildren = (node: any): any[] => {
      const fields = ['children', 'units', 'subunits', 'chapters', 'teams'];
      for (const f of fields) {
        if (Array.isArray(node?.[f])) return node[f];
      }
      return [];
    };
    const readName = (node: any): string => {
      const candidates = [node?.name, node?.tribeName, node?.domainName, node?.chapterName, node?.title, node?.label];
      for (const v of candidates) {
        if (typeof v === 'string') {
          const s = v.trim();
          if (s) return s;
        }
      }
      return '';
    };

    async function fetchOrgs(): Promise<any[] | null> {
      try {
        const res = await fetch('/api/organization', { credentials: 'include' });
        if (!res.ok) return null;
        const ct = res.headers.get('content-type') || '';
        const body = ct.includes('application/json') ? await res.json() : null;
        if (!body) return null;
        return Array.isArray(body) ? body : [body];
      } catch {
        return null;
      }
    }

    function buildFromApi(payloads: any[]): Domain[] {
      const domains: Domain[] = [];

      function visit(node: any) {
        if (!node || typeof node !== 'object') return;
        const name = readName(node);
        const kids = getChildren(node);

        // Tribe/Domain: prefer explicit type; else a node that has chapter/team children
        const hasChapterKids = kids.some(k => isType(k, 'chapter', 'team', 'squad', 'suad', 'zesp'));
        const isTribe = isType(node, 'tribe', 'domain') || (hasChapterKids && !!name);
        if (isTribe && name) {
          // Collect chapter/team children of this tribe
          const chapterKids = kids.filter(k => isType(k, 'chapter', 'team', 'squad', 'suad', 'zesp'));
          const chapterNames = chapterKids.map((c: any) => (typeof c?.name === 'string' ? c.name.trim() : '')).filter(Boolean);
          const teams = (chapterNames.length > 0 ? chapterNames : kids.map((c: any) => String(c?.name || '')).filter(Boolean))
            .map((tn: string) => mkTeam(tn, name));
          const values: number[] = [];
          teams.forEach(t => t.metrics.forEach(m => values.push(m.value)));
          const score = Math.round(values.reduce((a, v) => a + v, 0) / Math.max(1, values.length));
          domains.push({ name, score, teams });
          // Do not descend further from tribe, we've captured its children
          return;
        }
        // Otherwise keep traversing
        kids.forEach(visit);
      }

      payloads.forEach(root => visit(root));

      // Deduplicate by name in case multiple roots include same tribe
      const byName: Record<string, Domain> = {};
      domains.forEach(d => { if (!byName[d.name]) byName[d.name] = d; });
      return Object.values(byName);
    }

    function computeAggregates(d: Domain[]) {
      const g = Math.round(d.reduce((a, dom) => a + dom.score, 0) / Math.max(1, d.length) * 10) / 10;
      const allTeams = d.flatMap(dom => dom.teams);
      const ai = Math.round(allTeams.reduce((a, t) => a + t.aiAdoption, 0) / Math.max(1, allTeams.length));
      return { g, ai };
    }

    (async () => {
      const api = await fetchOrgs();
      if (!cancelled && api && api.length > 0) {
        const built = buildFromApi(api);
        if (built.length > 0) {
          const { g, ai } = computeAggregates(built);
          setDomains(built);
          setGlobal(g);
          setAiGlobal(ai);
          return;
        }
      }
      // Fallback to static sample if API missing or unparseable
      if (cancelled) return;
      const domainNames = ['Finance', 'Logistics', 'Retail', 'Healthcare', 'Marketing'];
      const teamNames = ['Team: Core', 'Team: Supply Chain'];
      const d: Domain[] = domainNames.map((dn) => {
        const teams = teamNames.map((tn) => mkTeam(tn, dn));
        const values: number[] = [];
        teams.forEach((t) => t.metrics.forEach((m) => values.push(m.value)));
        const score = Math.round(values.reduce((a, v) => a + v, 0) / Math.max(1, values.length));
        return { name: dn, score, teams };
      });
      const { g, ai } = computeAggregates(d);
      setDomains(d);
      setGlobal(g);
      setAiGlobal(ai);
    })();

    return () => { cancelled = true; };
  }, [isAdmin]);

  if (loading) {
    return (
      <div className="p-6 mx-auto">
        <p className="text-[13px] text-gray-500">Ładowanie…</p>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="p-6 mx-auto">
        <div className="bg-white border border-gray-200 rounded-xl p-5">
          <p className="text-[14px] text-gray-800" style={{ fontWeight: 600 }}>Brak dostępu</p>
          <p className="text-[12px] text-gray-500 mt-1">Ekran Control Tower jest dostępny tylko dla użytkowników z rolą ADMIN.</p>
        </div>
      </div>
    );
  }

  const hasData = Array.isArray(domains) && domains.length > 0;

  return (
    <div className="p-4 sm:p-6 space-y-5 overflow-x-hidden">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-[20px] text-gray-900" style={{ fontWeight: 700 }}>Control Tower</h1>
          <p className="text-[13px] text-gray-500 mt-0.5">Enterprise Team Health Index — global overview</p>
        </div>
        <div className="hidden sm:flex items-center gap-2 px-2 py-1 rounded-md border border-gray-200 bg-white">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span className="text-[12px] text-gray-700" style={{ fontWeight: 600 }}>Health</span>
        </div>
      </div>

      {/* Global score */}
      <div className="bg-white rounded-2xl border border-gray-200 p-4">
        <div className="flex items-center justify-center">
          <div className="flex flex-col sm:flex-row items-center gap-4 sm:gap-6">
            <div className="relative w-36 sm:w-40 md:w-48 max-w-full">
              <Donut value={global} color="#F59E0B" />
              <div className="absolute -right-2 -top-2 px-2 py-0.5 rounded-full bg-white border border-gray-200 text-[11px]" style={{ fontWeight: 700 }}>{global.toFixed(1)}%</div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full sm:w-auto">
              <MiniKPI title="Process Efficiency" value="91%" sub="Sprint predictability" color="emerald" />
              <MiniKPI title="Development Quality" value="85%" sub="Cycle/Lead quality" color="violet" />
              <MiniKPI title="Software Delivery" value="96%" sub="Throughput trend" color="indigo" />
              <MiniKPI title="AI Adoption" value={`${aiGlobal}%`} sub="GenAI usage" color="amber" />
            </div>
          </div>
        </div>
      </div>

      {/* Domains grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4">
        {hasData && domains!.map((domain) => {
          const isOpen = !!expanded[domain.name];
          return (
            <div key={domain.name} className="bg-white rounded-2xl border border-gray-200 p-4">
              <button
                type="button"
                onClick={() => setExpanded((prev) => ({ ...prev, [domain.name]: !prev[domain.name] }))}
                className="w-full flex items-center justify-between mb-2 text-left group"
                aria-expanded={isOpen}
              >
                <div className="flex items-center gap-2">
                  <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform ${isOpen ? 'rotate-0' : '-rotate-90'}`} />
                  <div>
                    <div className="text-[14px] text-gray-900" style={{ fontWeight: 700 }}>{domain.name}: {domain.score}%</div>
                    <div className="text-[12px] text-gray-500">Domain Health</div>
                  </div>
                </div>
                <div className="px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200 text-[11px]" style={{ fontWeight: 700 }}>{domain.score}%</div>
              </button>

              {isOpen && domain.teams.map((t) => (
                <div key={t.name} className="mt-3 rounded-xl border border-gray-100 p-3">
                  <div className="flex items-center mb-2">
                    <div className="text-[12px] text-gray-700" style={{ fontWeight: 700 }}>{t.name}</div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                    {t.metrics.map((m, i) => {
                      const color = m.type === 'eff' ? '#10B981' : m.type === 'qual' ? '#8B5CF6' : m.type === 'speed' ? '#6366F1' : '#F59E0B';
                      const tone = m.type === 'eff' ? 'emerald' : m.type === 'qual' ? 'violet' : m.type === 'speed' ? 'indigo' : 'amber';
                      const badge = {
                        indigo: 'bg-indigo-50 text-indigo-700 border-indigo-200',
                        emerald: 'bg-emerald-50 text-emerald-700 border-emerald-200',
                        violet: 'bg-violet-50 text-violet-700 border-violet-200',
                        amber: 'bg-amber-50 text-amber-700 border-amber-200',
                      }[tone];
                      return (
                        <div key={i} className="rounded-lg border border-gray-200 p-2.5 bg-white">
                          <div className="flex items-start justify-between">
                            <div>
                              <div className="text-[11px] text-gray-700 font-semibold">{m.label}</div>
                              <div className="text-[10px] text-gray-400">
                                {m.type === 'eff' ? 'Sprint Predictability' : m.type === 'qual' ? 'Cycletime Efficiency' : m.type === 'speed' ? 'Code Quality Gate' : 'GenAI Usage'}
                              </div>
                            </div>
                            <div className={`px-2 py-0.5 rounded-full border text-[12px] ${badge}`} style={{ fontWeight: 800 }}>{m.value}%</div>
                          </div>
                          <div className="mt-1.5">
                            {m.type === 'qual' || m.type === 'ai' ? (
                              <TrendBars values={m.trend} color={color} />
                            ) : (
                              <BarMini values={(m.trend.slice(-4)).map(v=>Math.max(1, v*10))} color={m.type==='eff' ? '#3B82F6' : '#10B981'} />
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          );
        })}
      </div>

      {/* Footer helper */}
      <div className="text-[11px] text-gray-400 flex items-center gap-2"><Settings2 className="w-3.5 h-3.5" />{hasData ? 'Data from /api/organizations — metrics mocked for display.' : 'Mock data displayed — ready for API integration.'}</div>
    </div>
  );
}

export default ControlTower;
