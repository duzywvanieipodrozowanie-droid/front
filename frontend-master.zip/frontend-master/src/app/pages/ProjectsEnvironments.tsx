import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Boxes, ChevronLeft, ChevronRight, Plus, Trash2, X } from 'lucide-react';

// Settings → Projects and environments (core /api/admin/organization/project, ADMIN only): the projects of the
// Service Map with the promotion order of their environments (dev -> test -> prod), the modules shown first and
// the regex of the task keys. The importer job "architecture" creates the projects it finds in the ArgoCD deploy
// repository and adds the new environments at the end; the order set here stays.

type Project = { id: string; label: string | null; taskRegex: string | null; envs: string[] | null; priorityModules: string[] | null };

const section = 'bg-white rounded-2xl border border-gray-200 p-5 space-y-4 dark:bg-[#2b2d31] dark:border-white/10';
const inputCls =
  'w-full rounded-lg border border-gray-200 bg-white px-3 py-2 text-[13px] text-gray-800 outline-none focus:border-indigo-400 dark:border-white/10 dark:bg-black/20 dark:text-gray-100';
const label = 'text-[11px] uppercase tracking-wide text-gray-500';

async function errorText(res: Response) {
  try {
    const js = await res.json();
    return js?.message || js?.errorCode || `HTTP ${res.status}`;
  } catch {
    return `HTTP ${res.status}`;
  }
}

function ProjectEditor({ project, onSaved, onDeleted }: { project: Project; onSaved: (list: Project[]) => void; onDeleted: (list: Project[]) => void }) {
  const [draft, setDraft] = useState<Project>({ ...project, envs: project.envs ?? [], priorityModules: project.priorityModules ?? [] });
  const [newEnv, setNewEnv] = useState('');
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const envs = draft.envs ?? [];
  const changed = JSON.stringify(draft) !== JSON.stringify({ ...project, envs: project.envs ?? [], priorityModules: project.priorityModules ?? [] });

  const move = (i: number, d: number) => {
    const next = [...envs];
    [next[i], next[i + d]] = [next[i + d], next[i]];
    setDraft({ ...draft, envs: next });
  };
  const addEnv = () => {
    const env = newEnv.trim().toLowerCase();
    if (env && !envs.includes(env)) setDraft({ ...draft, envs: [...envs, env] });
    setNewEnv('');
  };

  async function save() {
    setSaving(true);
    setMessage(null);
    try {
      const res = await fetch('/api/admin/organization/project/save', {
        method: 'PUT', credentials: 'include', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(draft),
      });
      if (!res.ok) throw new Error(await errorText(res));
      onSaved(await res.json());
      setMessage({ ok: true, text: 'Zapisano' });
    } catch (e) {
      setMessage({ ok: false, text: e instanceof Error ? e.message : String(e) });
    } finally {
      setSaving(false);
    }
  }

  async function remove() {
    if (!window.confirm(`Usunąć projekt ${project.id} z Mapy serwisów? Zgłoszone wersje na środowiskach zostają w bazie.`)) return;
    const res = await fetch(`/api/admin/organization/project/${encodeURIComponent(project.id)}`, { method: 'DELETE', credentials: 'include' });
    if (res.ok) onDeleted(await res.json());
    else setMessage({ ok: false, text: await errorText(res) });
  }

  return (
    <section className={section}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-[16px] text-gray-900 dark:text-gray-100" style={{ fontWeight: 700 }}>{draft.label || project.id}</div>
          <div className="text-[12px] text-gray-500 font-mono">{project.id}</div>
        </div>
        <button onClick={remove} className="p-2 rounded-lg text-gray-400 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-500/10" title="Usuń projekt">
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <label className="space-y-1 block">
          <span className={label}>Nazwa wyświetlana</span>
          <input className={inputCls} value={draft.label ?? ''} onChange={(e) => setDraft({ ...draft, label: e.target.value })} placeholder={project.id} />
        </label>
        <label className="space-y-1 block">
          <span className={label}>Regex kluczy Jira (opcjonalnie)</span>
          <input className={`${inputCls} font-mono`} value={draft.taskRegex ?? ''} onChange={(e) => setDraft({ ...draft, taskRegex: e.target.value || null })} placeholder="np. FXP-\d+" />
        </label>
      </div>

      <div className="space-y-2">
        <span className={label}>Środowiska w kolejności promocji</span>
        <div className="flex flex-wrap items-center gap-2">
          {envs.length === 0 && <span className="text-[12.5px] text-gray-500">Brak środowisk. Dodaj np. dev, test, prod.</span>}
          {envs.map((env, i) => (
            <span key={env} className="inline-flex items-center gap-1 pl-2.5 pr-1 py-1 rounded-lg border border-gray-200 bg-gray-50 text-[13px] dark:border-white/10 dark:bg-white/5">
              <span className="text-gray-400 text-[11px] mr-0.5">{i + 1}.</span><span className="font-mono">{env}</span>
              <button disabled={i === 0} onClick={() => move(i, -1)} className="p-0.5 rounded hover:bg-gray-200 disabled:opacity-30 dark:hover:bg-white/10" title="Wcześniej"><ChevronLeft className="w-3.5 h-3.5" /></button>
              <button disabled={i === envs.length - 1} onClick={() => move(i, 1)} className="p-0.5 rounded hover:bg-gray-200 disabled:opacity-30 dark:hover:bg-white/10" title="Później"><ChevronRight className="w-3.5 h-3.5" /></button>
              <button onClick={() => setDraft({ ...draft, envs: envs.filter((e) => e !== env) })} className="p-0.5 rounded hover:bg-gray-200 dark:hover:bg-white/10" title="Usuń"><X className="w-3.5 h-3.5" /></button>
            </span>
          ))}
          <span className="inline-flex items-center gap-1">
            <input className={`${inputCls} w-28 py-1.5`} value={newEnv} onChange={(e) => setNewEnv(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && addEnv()} placeholder="nowe env" />
            <button onClick={addEnv} className="p-2 rounded-lg border border-gray-200 hover:bg-gray-50 dark:border-white/10 dark:hover:bg-white/5" title="Dodaj"><Plus className="w-4 h-4" /></button>
          </span>
        </div>
        <p className="text-[11.5px] text-gray-500">Kolejność wyznacza, co jest „następnym środowiskiem” na Mapie serwisów (np. co z dev czeka na test).</p>
      </div>

      <label className="space-y-1 block">
        <span className={label}>Mikroserwisy pokazywane na górze (po przecinku)</span>
        <input className={inputCls} value={(draft.priorityModules ?? []).join(', ')}
               onChange={(e) => setDraft({ ...draft, priorityModules: e.target.value.split(',').map((s) => s.trim()).filter(Boolean) })}
               placeholder="np. api-gateway, payment-service" />
      </label>

      <div className="flex items-center gap-3">
        <button onClick={save} disabled={!changed || saving} className="px-4 py-2 rounded-xl bg-indigo-600 text-white text-[13px] disabled:opacity-50" style={{ fontWeight: 600 }}>
          {saving ? 'Zapisywanie…' : 'Zapisz'}
        </button>
        {message && <span className={`text-[12px] ${message.ok ? 'text-emerald-600' : 'text-red-600'}`}>{message.text}</span>}
      </div>
    </section>
  );
}

export function ProjectsEnvironments() {
  const navigate = useNavigate();
  const [projects, setProjects] = useState<Project[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [newId, setNewId] = useState('');

  useEffect(() => {
    fetch('/api/admin/organization/project', { credentials: 'include' })
      .then(async (r) => (r.ok ? r.json() : Promise.reject(new Error(await errorText(r)))))
      .then((list: Project[]) => setProjects(list))
      .catch((e) => { setProjects([]); setError(e.message); });
  }, []);

  async function create() {
    const id = newId.trim();
    if (!id) return;
    if (projects?.some((p) => p.id === id)) { setError(`Projekt ${id} już istnieje`); return; }
    const res = await fetch('/api/admin/organization/project/save', {
      method: 'PUT', credentials: 'include', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, label: id, taskRegex: null, envs: ['dev', 'test', 'prod'], priorityModules: [] }),
    });
    if (res.ok) { setProjects(await res.json()); setNewId(''); setError(null); } else setError(await errorText(res));
  }

  return (
    <div className="p-4 sm:p-6 mx-auto max-w-4xl space-y-4">
      <button onClick={() => navigate('/settings')} className="flex items-center gap-1.5 text-[12px] text-gray-500 hover:text-gray-800 dark:hover:text-gray-200">
        <ArrowLeft className="w-4 h-4" /> Ustawienia
      </button>
      <div className="flex items-start gap-3">
        <Boxes className="w-7 h-7 text-indigo-600 mt-0.5" />
        <div>
          <h1 className="text-[22px] text-gray-900 dark:text-gray-100" style={{ fontWeight: 800 }}>Projekty i środowiska</h1>
          <p className="text-[13px] text-gray-500 mt-1">
            Projekty Mapy serwisów i kolejność ich środowisk. Id projektu musi być takie jak projekt OneLook w imporcie GitLaba (ZS_PROJ_*).
            Job importera <span className="font-mono">architecture</span> zakłada projekty automatycznie z repo ArgoCD i dopisuje nowe środowiska na końcu.
          </p>
        </div>
      </div>

      {error && <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-[13px] text-red-700 dark:border-red-500/30 dark:bg-red-500/10 dark:text-red-300">{error}</div>}

      <section className={section}>
        <div className="flex flex-wrap items-end gap-2">
          <label className="space-y-1 block flex-1 min-w-[220px]">
            <span className={label}>Nowy projekt (id)</span>
            <input className={inputCls} value={newId} onChange={(e) => setNewId(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && create()} placeholder="np. FXP" />
          </label>
          <button onClick={create} disabled={!newId.trim()} className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 text-white text-[13px] disabled:opacity-50" style={{ fontWeight: 600 }}>
            <Plus className="w-4 h-4" /> Dodaj
          </button>
        </div>
      </section>

      {projects === null && <p className="text-[13px] text-gray-500">Ładowanie…</p>}
      {projects?.length === 0 && !error && <p className="text-[13px] text-gray-500">Brak projektów. Dodaj projekt albo uruchom job importera <span className="font-mono">architecture</span>.</p>}
      {projects?.map((p) => (
        <ProjectEditor key={`${p.id}:${(p.envs ?? []).join(',')}:${p.label}`} project={p} onSaved={setProjects} onDeleted={setProjects} />
      ))}
    </div>
  );
}

export default ProjectsEnvironments;
