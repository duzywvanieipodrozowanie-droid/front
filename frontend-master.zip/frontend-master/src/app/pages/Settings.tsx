import { useState, useRef, useEffect } from 'react';
import {
  Building2, Plus, Pencil, Trash2, X, ChevronDown, ChevronLeft, ChevronRight,
  ArrowRightLeft, Users, Check, Upload,
  FileText, AlertCircle, Search, Minus, HelpCircle,
} from 'lucide-react';

// ─── Types ───────────────────────────────────────────────────────────────────

interface OrgUnit {
  id: string;
  name: string;
  level: number;
  linkedTo: string | null;
}

interface Developer {
  id: string;
  name: string;
  surname: string;
  login: string;
  email: string;
  language: string;
  level: 'Junior' | 'Mid' | 'Senior' | 'Tech Lead';
  unitId: string;
}

// ─── Constants ────────────────────────────────────────────────────────────────

const ORG_LEVELS = [0, 1, 2, 3, 4];
const LANGUAGES = [
  'JavaScript', 'TypeScript', 'Python', 'Java', 'Go', 'Rust',
  'C#', 'C++', 'C', 'Ruby', 'PHP', 'Swift', 'Kotlin', 'Scala',
  'Dart', 'R', 'Elixir', 'Haskell', 'Clojure', 'Lua',
  'Shell / Bash', 'SQL', 'HTML / CSS',
];
const DEV_LEVELS = ['Junior', 'Mid', 'Senior', 'Tech Lead'] as const;
const LEVEL_COLORS: Record<string, string> = {
  Junior: 'bg-emerald-100 text-emerald-700',
  Mid: 'bg-blue-100 text-blue-700',
  Senior: 'bg-violet-100 text-violet-700',
  'Tech Lead': 'bg-orange-100 text-orange-700',
};
const CARD_STYLE: Record<number, { border: string; header: string; badge: string; text: string; sub: string }> = {
  0: { border: 'border-indigo-500', header: 'bg-indigo-600', badge: 'bg-white/20 text-white', text: 'text-white', sub: 'text-white/60' },
  1: { border: 'border-indigo-300', header: 'bg-indigo-50', badge: 'bg-indigo-100 text-indigo-600', text: 'text-gray-800', sub: 'text-gray-400' },
  2: { border: 'border-violet-300', header: 'bg-violet-50', badge: 'bg-violet-100 text-violet-600', text: 'text-gray-800', sub: 'text-gray-400' },
  3: { border: 'border-emerald-300', header: 'bg-emerald-50', badge: 'bg-emerald-100 text-emerald-600', text: 'text-gray-800', sub: 'text-gray-400' },
  4: { border: 'border-amber-300', header: 'bg-amber-50', badge: 'bg-amber-100 text-amber-600', text: 'text-gray-800', sub: 'text-gray-400' },
};

function genId() { return Math.random().toString(36).slice(2, 9); }

// ─── Form helpers ─────────────────────────────────────────────────────────────

const inputCls = 'w-full rounded-lg border border-gray-200 bg-white px-3 py-2 text-[13px] text-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder-gray-400';

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-col gap-1">
      <label className="text-[11px] text-gray-500 uppercase tracking-wide">{label}</label>
      {children}
    </div>
  );
}

function Sel({ value, onChange, placeholder, children }: { value: string; onChange: (v: string) => void; placeholder?: string; children: React.ReactNode }) {
  return (
    <div className="relative">
      <select value={value} onChange={(e) => onChange(e.target.value)} className={inputCls + ' appearance-none cursor-pointer pr-8'}>
        {placeholder && <option value="">{placeholder}</option>}
        {children}
      </select>
      <ChevronDown className="pointer-events-none absolute right-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
    </div>
  );
}

// ─── Avatar strip (6 max + dots) ─────────────────────────────────────────────

function AvatarStrip({ devs }: { devs: Developer[] }) {
  const shown = devs.slice(0, 6);
  const extra = devs.length - shown.length;
  return (
    <div className="flex flex-wrap items-center gap-0.5 mt-1.5">
      {shown.map((d) => (
        <div
          key={d.id}
          title={`${d.name} ${d.surname} · ${d.level}`}
          className="w-5 h-5 rounded-full bg-gradient-to-br from-indigo-300 to-violet-400 border-2 border-white flex items-center justify-center text-[7px] text-white flex-shrink-0"
          style={{ fontWeight: 800 }}
        >
          {d.name[0]}{d.surname[0]}
        </div>
      ))}
      {extra > 0 && (
        <div className="flex items-center gap-0.5 ml-0.5">
          {[0, 1, 2].map((i) => (
            <div key={i} className="w-1.5 h-1.5 rounded-full bg-gray-400/60" />
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Add-to-unit modal ────────────────────────────────────────────────────────

function AddToUnitModal({
  unit, units, onClose, onAddUnit, onAddDev,
}: {
  unit: OrgUnit;
  units: OrgUnit[];
  onClose: () => void;
  onAddUnit: (name: string, level: number, linkedTo: string) => void;
  onAddDev: (dev: Omit<Developer, 'id'>) => void;
}) {
  const [tab, setTab] = useState<'unit' | 'dev'>('dev');

  // unit form
  const [uName, setUName] = useState('');
  const [uLevel, setULevel] = useState(String(Math.min(unit.level + 1, 4)));

  // dev form
  const [dName, setDName] = useState('');
  const [dSurname, setDSurname] = useState('');
  const [dLogin, setDLogin] = useState('');
  const [dEmail, setDEmail] = useState('');
  const [dLang, setDLang] = useState('');
  const [dLevel, setDLevel] = useState('');

  function submitUnit() {
    if (!uName.trim()) return;
    onAddUnit(uName.trim(), Number(uLevel), unit.id);
    onClose();
  }

  function submitDev() {
    if (!dName.trim() || !dSurname.trim() || !dLogin.trim() || !dEmail.trim() || !dLang || !dLevel) return;
    onAddDev({ name: dName.trim(), surname: dSurname.trim(), login: dLogin.trim(), email: dEmail.trim(), language: dLang, level: dLevel as Developer['level'], unitId: unit.id });
    onClose();
  }

  const cs = CARD_STYLE[unit.level] ?? CARD_STYLE[4];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className={`${cs.header} px-5 py-4 border-b border-gray-100 flex items-center justify-between`}>
          <div className="flex items-center gap-2">
            <Plus className="w-4 h-4 text-indigo-500" />
            <span className="text-[14px] text-gray-800" style={{ fontWeight: 600 }}>
              Add to <span className="text-indigo-600">{unit.name}</span>
            </span>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-black/5 transition-colors">
            <X className="w-4 h-4 text-gray-500" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-100">
          {(['dev', 'unit'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`flex-1 py-2.5 text-[13px] transition-colors ${tab === t ? 'text-indigo-600 border-b-2 border-indigo-500' : 'text-gray-500 hover:text-gray-700'}`}
              style={{ fontWeight: tab === t ? 600 : 400 }}
            >
              {t === 'dev' ? '👤 Add developer' : '🏢 Add sub-unit'}
            </button>
          ))}
        </div>

        {/* Body */}
        <div className="p-5 space-y-3">
          {tab === 'unit' ? (
            <>
              <Field label="Unit name">
                <input className={inputCls} placeholder="e.g. QA" value={uName} onChange={(e) => setUName(e.target.value)} autoFocus />
              </Field>
              <Field label="Organization level">
                <Sel value={uLevel} onChange={setULevel}>
                  {ORG_LEVELS.map((l) => <option key={l} value={l}>Level {l}{l === 0 ? ' (top)' : ''}</option>)}
                </Sel>
              </Field>
              <Field label="Linked to">
                <input className={inputCls + ' bg-gray-50 text-gray-500'} value={`L${unit.level} — ${unit.name}`} readOnly />
              </Field>
            </>
          ) : (
            <>
              <div className="grid grid-cols-2 gap-3">
                <Field label="First name"><input className={inputCls} placeholder="Name" value={dName} onChange={(e) => setDName(e.target.value)} autoFocus /></Field>
                <Field label="Last name"><input className={inputCls} placeholder="Surname" value={dSurname} onChange={(e) => setDSurname(e.target.value)} /></Field>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Login"><input className={inputCls} placeholder="@handle" value={dLogin} onChange={(e) => setDLogin(e.target.value)} /></Field>
                <Field label="Email"><input className={inputCls} placeholder="dev@co.com" type="email" value={dEmail} onChange={(e) => setDEmail(e.target.value)} /></Field>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Field label="Language">
                  <Sel value={dLang} onChange={setDLang} placeholder="Select…">
                    {LANGUAGES.map((l) => <option key={l} value={l}>{l}</option>)}
                  </Sel>
                </Field>
                <Field label="Level">
                  <Sel value={dLevel} onChange={setDLevel} placeholder="Select…">
                    {DEV_LEVELS.map((l) => <option key={l} value={l}>{l}</option>)}
                  </Sel>
                </Field>
              </div>
              <Field label="Unit">
                <input className={inputCls + ' bg-gray-50 text-gray-500'} value={`L${unit.level} — ${unit.name}`} readOnly />
              </Field>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="flex justify-end gap-2 px-5 pb-5">
          <button onClick={onClose} className="px-4 py-2 rounded-lg text-[13px] text-gray-600 hover:bg-gray-100 transition-colors">Cancel</button>
          <button
            onClick={tab === 'unit' ? submitUnit : submitDev}
            disabled={tab === 'unit' ? !uName.trim() : (!dName.trim() || !dSurname.trim() || !dLogin.trim() || !dEmail.trim() || !dLang || !dLevel)}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 disabled:cursor-not-allowed text-white text-[13px] transition-colors"
            style={{ fontWeight: 500 }}
          >
            <Plus className="w-3.5 h-3.5" /> {tab === 'unit' ? 'Add unit' : 'Add developer'}
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Confirm delete modal ─────────────────────────────────────────────────────

function ConfirmDeleteModal({
  unit, devCount, onClose, onConfirm,
}: {
  unit: OrgUnit;
  devCount: number;
  onClose: () => void;
  onConfirm: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
      <div className="bg-white w-full max-w-sm rounded-2xl shadow-2xl overflow-hidden">
        <div className="px-6 pt-6 pb-4">
          <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center mb-4">
            <Trash2 className="w-5 h-5 text-red-500" />
          </div>
          <h2 className="text-[15px] text-gray-900" style={{ fontWeight: 700 }}>Delete "{unit.name}"?</h2>
          <p className="text-[13px] text-gray-500 mt-1.5">
            This will permanently remove the unit
            {devCount > 0 && <> and <span className="text-red-600" style={{ fontWeight: 600 }}>{devCount} developer{devCount !== 1 ? 's' : ''}</span> assigned to it</>}.
            This action cannot be undone.
          </p>
        </div>
        <div className="flex justify-end gap-2 px-6 pb-5">
          <button onClick={onClose} className="px-4 py-2 rounded-lg text-[13px] text-gray-600 hover:bg-gray-100 transition-colors">Cancel</button>
          <button
            onClick={() => { onConfirm(); onClose(); }}
            className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white text-[13px] transition-colors"
            style={{ fontWeight: 500 }}
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Horizontal org chart node ────────────────────────────────────────────────

function OrgChartNode({
  unit, units, developers, onAdd, onDelete,
}: {
  unit: OrgUnit;
  units: OrgUnit[];
  developers: Developer[];
  onAdd: (unitId: string) => void;
  onDelete: (unitId: string) => void;
}) {
  const [collapsed, setCollapsed] = useState(false);
  const children = units.filter((u) => u.linkedTo === unit.id);
  const unitDevs = developers.filter((d) => d.unitId === unit.id);
  const cs = CARD_STYLE[unit.level] ?? CARD_STYLE[4];

  return (
    <div className="flex flex-col items-center">
      {/* ── Card ── */}
      <div className={`relative border-2 rounded-xl bg-white shadow-sm ${cs.border}`} style={{ minWidth: 148, maxWidth: 172 }}>
        {/* Card header strip */}
        <div className={`${cs.header} rounded-t-[10px] px-3 py-2 flex items-center justify-between gap-1`}>
          <span className={`text-[9px] px-1.5 py-0.5 rounded ${cs.badge}`} style={{ fontWeight: 700 }}>L{unit.level}</span>
          <div className="flex items-center gap-0.5">
            {children.length > 0 && (
              <button
                type="button"
                onClick={() => setCollapsed((c) => !c)}
                className="w-5 h-5 rounded flex items-center justify-center hover:bg-black/10 transition-colors"
                title={collapsed ? 'Expand' : 'Collapse'}
              >
                <ChevronDown className={`w-3 h-3 ${cs.text} opacity-70 transition-transform duration-200 ${collapsed ? '-rotate-90' : ''}`} />
              </button>
            )}
            <button
              type="button"
              onClick={() => onAdd(unit.id)}
              className="w-5 h-5 rounded flex items-center justify-center hover:bg-black/10 transition-colors"
              title="Add sub-unit or developer"
            >
              <Plus className={`w-3 h-3 ${cs.text} opacity-70`} />
            </button>
            <button
              type="button"
              onClick={() => onDelete(unit.id)}
              className="w-5 h-5 rounded flex items-center justify-center hover:bg-red-100 transition-colors"
              title="Delete unit"
            >
              <Minus className="w-3 h-3 text-red-400" />
            </button>
          </div>
        </div>

        {/* Card body */}
        <div className="px-3 pb-3 pt-2">
          <p className="text-[12px] text-gray-800 text-center break-words leading-snug" style={{ fontWeight: 700, wordBreak: 'break-word', whiteSpace: 'normal' }}>{unit.name}</p>

          {/* Avatars */}
          {unitDevs.length > 0 ? (
            <div className="flex flex-col items-center">
              <AvatarStrip devs={unitDevs} />
              <p className="text-[10px] text-gray-400 mt-1">{unitDevs.length} dev{unitDevs.length !== 1 ? 's' : ''}</p>
            </div>
          ) : (
            <p className="text-[10px] text-gray-300 text-center mt-1">no developers</p>
          )}
        </div>
      </div>

      {/* ── Children ── */}
      {!collapsed && children.length > 0 && (
        <>
          <div className="w-px bg-gray-300" style={{ height: 20 }} />
          <div className="flex items-start">
            {children.map((child, idx) => {
              const isFirst = idx === 0;
              const isLast = idx === children.length - 1;
              const isOnly = children.length === 1;
              return (
                <div key={child.id} className="flex flex-col items-center">
                  <div className="flex w-full" style={{ height: 20 }}>
                    <div style={{ flex: 1, borderTop: !isFirst && !isOnly ? '1px solid #d1d5db' : 'none' }} />
                    <div style={{ width: 1, backgroundColor: '#d1d5db' }} />
                    <div style={{ flex: 1, borderTop: !isLast && !isOnly ? '1px solid #d1d5db' : 'none' }} />
                  </div>
                  <div className="px-3 pb-4">
                    <OrgChartNode unit={child} units={units} developers={developers} onAdd={onAdd} onDelete={onDelete} />
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}

// ─── Org editor modal (with dev search) ──────────────────────────────────────

function OrgEditorModal({
  units, developers, onClose, onDeleteDev, onMoveDev, onDeleteUnit,
}: {
  units: OrgUnit[];
  developers: Developer[];
  onClose: () => void;
  onDeleteDev: (id: string) => void;
  onMoveDev: (devId: string, toUnitId: string) => void;
  onDeleteUnit: (id: string) => void;
}) {
  const [search, setSearch] = useState('');
  const [movingDev, setMovingDev] = useState<string | null>(null);
  const [moveTarget, setMoveTarget] = useState('');

  const query = search.trim().toLowerCase();
  const filteredDevs = query
    ? developers.filter((d) => d.surname.toLowerCase().includes(query) || d.name.toLowerCase().includes(query))
    : null;

  function handleMove(devId: string) {
    if (!moveTarget) return;
    onMoveDev(devId, moveTarget);
    setMovingDev(null);
    setMoveTarget('');
  }

  const sortedUnits = [...units].sort((a, b) => a.level - b.level);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
      <div className="bg-white w-full max-w-3xl max-h-[88vh] rounded-2xl shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <div className="flex items-center gap-2.5">
            <Building2 className="w-5 h-5 text-indigo-500" />
            <h2 className="text-[16px] text-gray-900" style={{ fontWeight: 600 }}>Edit Organization</h2>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors">
            <X className="w-4 h-4 text-gray-500" />
          </button>
        </div>

        {/* Search bar */}
        <div className="px-6 py-3 border-b border-gray-100">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              className="w-full pl-9 pr-3 py-2 rounded-lg border border-gray-200 text-[13px] text-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-500 placeholder-gray-400"
              placeholder="Search developer by name or surname…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              autoFocus
            />
            {search && (
              <button onClick={() => setSearch('')} className="absolute right-2.5 top-1/2 -translate-y-1/2 p-0.5 rounded hover:bg-gray-100">
                <X className="w-3.5 h-3.5 text-gray-400" />
              </button>
            )}
          </div>
          {filteredDevs && (
            <p className="text-[11px] text-gray-400 mt-1.5">
              {filteredDevs.length === 0 ? 'No developers found.' : `Showing ${filteredDevs.length} result${filteredDevs.length !== 1 ? 's' : ''} for "${search.trim()}"`}
            </p>
          )}
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {/* Search results mode */}
          {filteredDevs ? (
            filteredDevs.length === 0 ? (
              <p className="text-[13px] text-gray-400 text-center py-8 italic">No developers match your search.</p>
            ) : (
              <div className="space-y-2">
                {filteredDevs.map((dev) => {
                  const devUnit = units.find((u) => u.id === dev.unitId);
                  return (
                    <div key={dev.id} className="flex items-center justify-between px-4 py-3 rounded-xl border border-gray-200 bg-gray-50">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-400 to-violet-500 flex items-center justify-center text-[11px] text-white flex-shrink-0" style={{ fontWeight: 700 }}>
                          {dev.name[0]}{dev.surname[0]}
                        </div>
                        <div>
                          <p className="text-[13px] text-gray-800" style={{ fontWeight: 600 }}>{dev.name} <span className="text-indigo-600">{dev.surname}</span></p>
                          <p className="text-[11px] text-gray-400">@{dev.login} · {dev.language} · {devUnit?.name ?? '—'}</p>
                        </div>
                        <span className={`text-[10px] px-1.5 py-0.5 rounded ${LEVEL_COLORS[dev.level]}`} style={{ fontWeight: 600 }}>{dev.level}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        {movingDev === dev.id ? (
                          <div className="flex items-center gap-1.5">
                            <select value={moveTarget} onChange={(e) => setMoveTarget(e.target.value)} className="text-[11px] border border-gray-200 rounded-lg px-2 py-1 focus:outline-none focus:ring-1 focus:ring-indigo-500 appearance-none">
                              <option value="">Select unit…</option>
                              {units.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
                            </select>
                            <button onClick={() => handleMove(dev.id)} className="p-1 rounded-lg text-indigo-600 hover:bg-indigo-50"><Check className="w-3.5 h-3.5" /></button>
                            <button onClick={() => { setMovingDev(null); setMoveTarget(''); }} className="p-1 rounded-lg text-gray-400 hover:bg-gray-100"><X className="w-3.5 h-3.5" /></button>
                          </div>
                        ) : (
                          <button onClick={() => { setMovingDev(dev.id); setMoveTarget(''); }} className="p-1.5 rounded-lg text-gray-400 hover:bg-gray-100" title="Move"><ArrowRightLeft className="w-3.5 h-3.5" /></button>
                        )}
                        <button onClick={() => onDeleteDev(dev.id)} className="p-1.5 rounded-lg text-red-400 hover:bg-red-50"><Trash2 className="w-3.5 h-3.5" /></button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )
          ) : (
            // Normal unit-grouped view
            <>
              {sortedUnits.length === 0 && <p className="text-[13px] text-gray-400 text-center py-8">No units yet.</p>}
              {sortedUnits.map((unit) => {
                const unitDevs = developers.filter((d) => d.unitId === unit.id);
                const parent = units.find((u) => u.id === unit.linkedTo);
                return (
                  <div key={unit.id} className="rounded-xl border border-gray-200 overflow-hidden">
                    <div className="flex items-center justify-between bg-gray-50 px-4 py-3">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-600" style={{ fontWeight: 600 }}>L{unit.level}</span>
                        <span className="text-[14px] text-gray-800" style={{ fontWeight: 600 }}>{unit.name}</span>
                        {parent && <span className="text-[11px] text-gray-400">↳ {parent.name}</span>}
                      </div>
                      <button onClick={() => onDeleteUnit(unit.id)} className="p-1.5 rounded-lg text-red-400 hover:bg-red-50"><Trash2 className="w-3.5 h-3.5" /></button>
                    </div>
                    {unitDevs.length === 0 ? (
                      <p className="text-[12px] text-gray-400 px-4 py-3 italic">No developers</p>
                    ) : (
                      <div className="divide-y divide-gray-100">
                        {unitDevs.map((dev) => (
                          <div key={dev.id} className="flex items-center justify-between px-4 py-2.5">
                            <div className="flex items-center gap-3">
                              <div className="w-7 h-7 rounded-full bg-gradient-to-br from-indigo-400 to-violet-500 flex items-center justify-center text-[10px] text-white flex-shrink-0" style={{ fontWeight: 700 }}>
                                {dev.name[0]}{dev.surname[0]}
                              </div>
                              <div>
                                <p className="text-[13px] text-gray-800">{dev.name} {dev.surname}</p>
                                <p className="text-[11px] text-gray-400">@{dev.login} · {dev.language}</p>
                              </div>
                              <span className={`text-[10px] px-1.5 py-0.5 rounded ${LEVEL_COLORS[dev.level]}`} style={{ fontWeight: 600 }}>{dev.level}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              {movingDev === dev.id ? (
                                <div className="flex items-center gap-1.5">
                                  <select value={moveTarget} onChange={(e) => setMoveTarget(e.target.value)} className="text-[11px] border border-gray-200 rounded-lg px-2 py-1 focus:outline-none focus:ring-1 focus:ring-indigo-500 appearance-none">
                                    <option value="">Select unit…</option>
                                    {units.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}
                                  </select>
                                  <button onClick={() => handleMove(dev.id)} className="p-1 rounded-lg text-indigo-600 hover:bg-indigo-50"><Check className="w-3.5 h-3.5" /></button>
                                  <button onClick={() => { setMovingDev(null); setMoveTarget(''); }} className="p-1 rounded-lg text-gray-400 hover:bg-gray-100"><X className="w-3.5 h-3.5" /></button>
                                </div>
                              ) : (
                                <button onClick={() => { setMovingDev(dev.id); setMoveTarget(''); }} className="p-1.5 rounded-lg text-gray-400 hover:bg-gray-100" title="Move"><ArrowRightLeft className="w-3.5 h-3.5" /></button>
                              )}
                              <button onClick={() => onDeleteDev(dev.id)} className="p-1.5 rounded-lg text-red-400 hover:bg-red-50"><Trash2 className="w-3.5 h-3.5" /></button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </>
          )}
        </div>

        <div className="px-6 py-4 border-t border-gray-100">
          <button onClick={onClose} className="px-4 py-2 rounded-lg bg-gray-100 text-[13px] text-gray-700 hover:bg-gray-200 transition-colors">Close</button>
        </div>
      </div>
    </div>
  );
}

// ─── Upload modal ─────────────────────────────────────────────────────────────

function UploadModal({ onClose }: { onClose: () => void }) {
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const ref = useRef<HTMLInputElement>(null);

  function onChange(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    if (!f.name.endsWith('.yml') && !f.name.endsWith('.yaml')) {
      setError('Invalid file type. Please upload a .yml or .yaml file.');
      setFile(null);
      return;
    }
    setError('');
    setFile(f);
  }

  function confirm() {
    if (!file) return;
    setSuccess(true);
    setTimeout(() => onClose(), 1800);
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100">
          <div className="flex items-center gap-2.5"><Upload className="w-5 h-5 text-sky-500" /><h2 className="text-[15px] text-gray-900" style={{ fontWeight: 600 }}>Upload organization file</h2></div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors"><X className="w-4 h-4 text-gray-500" /></button>
        </div>
        <div className="px-6 py-5 space-y-4">
          <div className="flex items-start gap-3 bg-amber-50 border border-amber-200 rounded-xl px-4 py-3">
            <AlertCircle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-[13px] text-amber-800" style={{ fontWeight: 600 }}>Required format: YML</p>
              <p className="text-[12px] text-amber-700 mt-0.5">File must be a valid <strong>.yml</strong> or <strong>.yaml</strong> file describing your organization.</p>
            </div>
          </div>
          <div className="border-2 border-dashed border-gray-200 rounded-xl p-6 flex flex-col items-center gap-3 cursor-pointer hover:border-sky-400 hover:bg-sky-50/40 transition-colors" onClick={() => ref.current?.click()}>
            <div className="w-10 h-10 rounded-full bg-sky-50 flex items-center justify-center"><FileText className="w-5 h-5 text-sky-500" /></div>
            {file ? (
              <div className="text-center">
                <p className="text-[13px] text-gray-800" style={{ fontWeight: 600 }}>{file.name}</p>
                <p className="text-[11px] text-gray-400 mt-0.5">{(file.size / 1024).toFixed(1)} KB · click to change</p>
              </div>
            ) : (
              <div className="text-center">
                <p className="text-[13px] text-gray-700" style={{ fontWeight: 500 }}>Click to select a file</p>
                <p className="text-[11px] text-gray-400 mt-0.5">Supported: <strong>.yml</strong>, <strong>.yaml</strong></p>
              </div>
            )}
            <input ref={ref} type="file" accept=".yml,.yaml" className="hidden" onChange={onChange} />
          </div>
          {error && <div className="flex items-center gap-2 text-[12px] text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2"><AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />{error}</div>}
          {success && <div className="flex items-center gap-2 text-[12px] text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2"><Check className="w-3.5 h-3.5 flex-shrink-0" />Organization imported successfully!</div>}
        </div>
        <div className="flex justify-end gap-2 px-6 pb-5">
          <button onClick={onClose} className="px-4 py-2 rounded-lg text-[13px] text-gray-600 hover:bg-gray-200 transition-colors">Cancel</button>
          <button onClick={confirm} disabled={!file || !!error || success} className="flex items-center gap-2 px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-700 disabled:opacity-40 disabled:cursor-not-allowed text-white text-[13px] transition-colors" style={{ fontWeight: 500 }}>
            <Upload className="w-3.5 h-3.5" /> Import
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Main Settings page (hub) ───────────────────────────────────────────────

import { useNavigate } from 'react-router-dom';
import { Cog, SlidersHorizontal, Workflow, MessageCircle, Mail, LifeBuoy, Wrench, GitBranch, BarChart3 } from 'lucide-react';

export function Settings() {
  const navigate = useNavigate();

  const tiles = [
    { label: 'Confluence', icon: Workflow },
    { label: 'Teams', icon: MessageCircle },
    { label: 'Exchange', icon: Mail },
    { label: 'ServiceNow', icon: LifeBuoy },
    { label: 'Jenkins', icon: Wrench },
    { label: 'Gerrit', icon: GitBranch },
    { label: 'Tableau', icon: BarChart3 },
  ];

  return (
    <div className="p-4 sm:p-6 mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-[20px] text-gray-900" style={{ fontWeight: 700 }}>Settings</h1>
          <p className="text-[13px] text-gray-500 mt-0.5">Manage setup and platform integrations.</p>
        </div>
      </div>

      {/* Primary setup actions */}
      <div className="flex flex-wrap items-center gap-3">
        <button
          onClick={() => navigate('/settings/organization')}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-[13px] transition-colors shadow-sm"
          style={{ fontWeight: 500 }}
        >
          <Cog className="w-4 h-4" /> Setup organization
        </button>
        <button
          onClick={() => navigate('/settings/thresholds')}
          className="flex items-center gap-2 px-4 py-2 rounded-xl border border-gray-200 bg-white hover:bg-gray-50 text-gray-700 text-[13px] transition-colors"
          style={{ fontWeight: 500 }}
        >
          <SlidersHorizontal className="w-4 h-4" /> Setup your thresholds
        </button>
      </div>

      {/* Add Integration section */}
      <section className="bg-white rounded-2xl border border-gray-200 overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-indigo-50 flex items-center justify-center">
              <Workflow className="w-4 h-4 text-indigo-500" />
            </div>
            <div>
              <h2 className="text-[14px] text-gray-900" style={{ fontWeight: 600 }}>Add integration</h2>
              <p className="text-[11px] text-gray-400">Connect your tools to synchronize knowledge and metrics</p>
            </div>
          </div>
        </div>
        <div className="p-5 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
          {tiles.map(({ label, icon: Icon }) => (
            <button key={label} className="group flex items-center gap-3 w-full text-left px-4 py-3 rounded-xl border border-gray-200 hover:border-indigo-300 bg-white hover:bg-indigo-50/40 transition-colors">
              <div className="w-9 h-9 rounded-lg bg-gray-50 group-hover:bg-indigo-100 flex items-center justify-center">
                <Icon className="w-5 h-5 text-gray-500 group-hover:text-indigo-600" />
              </div>
              <div>
                <div className="text-[13px] text-gray-800" style={{ fontWeight: 600 }}>{label}</div>
                <div className="text-[11px] text-gray-400">Click to configure</div>
              </div>
            </button>
          ))}
        </div>
      </section>
    </div>
  );
}

export default Settings;
