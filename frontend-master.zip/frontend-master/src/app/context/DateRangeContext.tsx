import React from 'react';

export type PresetRange =
  | 'Last 7 days'
  | 'Last 2 weeks'
  | 'Last 4 weeks'
  | 'Last month'
  | 'Last 3 months'
  | 'Last 6 months';

/** A preset ending today or a custom period "Custom:yyyy-MM-dd:yyyy-MM-dd" (see utils/dateRange). */
export type DateRangeValue = PresetRange | `Custom:${string}`;

export type DateRangeContextType = {
  dateRange: DateRangeValue;
  setDateRange: (value: DateRangeValue) => void;
  /** The period as shown to the user, e.g. "Last 4 weeks" or "1 Sep 2026 – 30 Sep 2026". */
  label: string;
};

export const DateRangeContext = React.createContext<DateRangeContextType | undefined>(undefined);

export function useDateRange(): DateRangeContextType {
  const ctx = React.useContext(DateRangeContext);
  if (!ctx) throw new Error('useDateRange must be used within a DateRangeContext.Provider');
  return ctx;
}
