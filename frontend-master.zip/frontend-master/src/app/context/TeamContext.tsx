import React from 'react';

export type TeamContextType = {
  selectedTeamName: string;
  selectedUnitId: string | null; // Backend unitId for selected team; null means All Teams
  teams: string[]; // List of team display names (includes 'All Teams')
  setSelectedTeamName: (name: string) => void;
};

export const TeamContext = React.createContext<TeamContextType | undefined>(undefined);

export function useTeam(): TeamContextType {
  const ctx = React.useContext(TeamContext);
  if (!ctx) throw new Error('useTeam must be used within a TeamContext.Provider');
  return ctx;
}
