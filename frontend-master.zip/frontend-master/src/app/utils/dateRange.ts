import type { DateRangeValue, PresetRange } from '../context/DateRangeContext';

// The period of the top bar: a preset ending today, or a custom one ("Custom:2026-09-01:2026-09-30", both days
// included). Core takes it as the interval param: WEEKS_1 ... MONTHS_6 or CUSTOM_2026-09-01_2026-09-30.

export const PRESET_RANGES: Array<{ value: PresetRange; interval: string; days: number; en: string; pl: string }> = [
  { value: 'Last 7 days', interval: 'WEEKS_1', days: 7, en: 'Last 7 days', pl: 'Ostatnie 7 dni' },
  { value: 'Last 2 weeks', interval: 'WEEKS_2', days: 14, en: 'Last 2 weeks', pl: 'Ostatnie 2 tygodnie' },
  { value: 'Last 4 weeks', interval: 'WEEKS_4', days: 28, en: 'Last 4 weeks', pl: 'Ostatnie 4 tygodnie' },
  { value: 'Last month', interval: 'MONTHS_1', days: 30, en: 'Last month', pl: 'Ostatni miesiąc' },
  { value: 'Last 3 months', interval: 'MONTHS_3', days: 91, en: 'Last 3 months', pl: 'Ostatnie 3 miesiące' },
  { value: 'Last 6 months', interval: 'MONTHS_6', days: 182, en: 'Last 6 months', pl: 'Ostatnie 6 miesięcy' },
];

const CUSTOM = /^Custom:(\d{4}-\d{2}-\d{2}):(\d{4}-\d{2}-\d{2})$/;

/** Local day as yyyy-MM-dd. */
export function isoDay(date: Date): string {
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

export function customRange(from: string, to: string): DateRangeValue {
  return from <= to ? `Custom:${from}:${to}` : `Custom:${to}:${from}`;
}

export function parseCustomRange(range: string): { from: string; to: string } | null {
  const match = CUSTOM.exec(range);
  return match ? { from: match[1], to: match[2] } : null;
}

/** The interval param of core for the period; unknown values fall back to {@code fallback}. */
export function toInterval(range: string, fallback = 'WEEKS_4'): string {
  const custom = parseCustomRange(range);
  if (custom) return `CUSTOM_${custom.from}_${custom.to}`;
  return PRESET_RANGES.find((it) => it.value === range)?.interval ?? fallback;
}

/** Number of days of the period (both ends of a custom one included). */
export function rangeDays(range: string): number {
  const custom = parseCustomRange(range);
  if (custom) return Math.round((Date.parse(custom.to) - Date.parse(custom.from)) / 86_400_000) + 1;
  return PRESET_RANGES.find((it) => it.value === range)?.days ?? 28;
}

export function rangeLabel(range: string, lang: 'en' | 'pl' = 'en'): string {
  const custom = parseCustomRange(range);
  if (custom) {
    const fmt = (day: string) => new Date(`${day}T00:00:00`).toLocaleDateString(lang === 'pl' ? 'pl-PL' : 'en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
    return `${fmt(custom.from)} – ${fmt(custom.to)}`;
  }
  const preset = PRESET_RANGES.find((it) => it.value === range);
  return preset ? (lang === 'pl' ? preset.pl : preset.en) : range;
}

/** Shortcuts of the custom period picker: this and the previous calendar month. */
export function monthRange(monthsBack: number): { from: string; to: string } {
  const now = new Date();
  const first = new Date(now.getFullYear(), now.getMonth() - monthsBack, 1);
  const last = monthsBack === 0 ? now : new Date(now.getFullYear(), now.getMonth() - monthsBack + 1, 0);
  return { from: isoDay(first), to: isoDay(last) };
}
