import { describe, it, expect } from 'vitest';
import { calculateTeamEffectiveness } from './effectiveness';

// Unit tests focusing on Alignment_Factor behavior
// Spec: If PRs_Merged > 0 and JIRA_Done == 0 => Alignment_Factor = 0.5
//       If PRs_Merged > 0 and JIRA_Done > 0 => Alignment_Factor = 1.0
// Right Y axis is 0..100 but here we only verify numerical score range and relative difference.

describe('calculateTeamEffectiveness - Alignment Factor', () => {
  it('applies 0.5 penalty when PRs > 0 and JIRA_Done == 0', () => {
    const jiraDone = 0; // triggers alignment penalty
    const prsMerged = 10;

    // Averages (over the period) - pick positive numbers to make Delivery_Ratio meaningful
    const avgJira = 8;
    const avgPrs = 12;

    const predictability = 80; // default per spec

    const scoreWithPenalty = calculateTeamEffectiveness(
      jiraDone,
      prsMerged,
      avgJira,
      avgPrs,
      predictability,
    );

    // Control scenario: same inputs but with at least 1 JIRA done to remove penalty
    const scoreWithoutPenalty = calculateTeamEffectiveness(
      5, // JIRA_Done > 0 => Alignment_Factor = 1.0
      prsMerged,
      avgJira,
      avgPrs,
      predictability,
    );

    expect(scoreWithPenalty).toBeGreaterThanOrEqual(0);
    expect(scoreWithPenalty).toBeLessThanOrEqual(100);
    expect(scoreWithoutPenalty).toBeGreaterThanOrEqual(0);
    expect(scoreWithoutPenalty).toBeLessThanOrEqual(100);

    // Penalty should reduce the score significantly
    expect(scoreWithPenalty).toBeLessThan(scoreWithoutPenalty);
  });
});

describe('calculateTeamEffectiveness - exact scores', () => {
  it('returns 100 for full delivery and full predictability', () => {
    expect(calculateTeamEffectiveness(10, 10, 10, 10, 100)).toBe(100);
  });

  it('scores only predictability when nothing was delivered', () => {
    // alignment 0 => 0.4 * 0.8 * 100
    expect(calculateTeamEffectiveness(0, 0, 10, 10)).toBe(32);
  });

  it('defaults predictability to 80% when missing', () => {
    expect(calculateTeamEffectiveness(10, 10, 10, 10, null)).toBe(92);
    expect(calculateTeamEffectiveness(10, 10, 10, 10)).toBe(92);
  });

  it('combines partial delivery with the alignment penalty', () => {
    // delivery 0.5, alignment 0.5 => 0.6*0.25 + 0.4*0.8 = 0.47
    expect(calculateTeamEffectiveness(0, 10, 10, 10, 80)).toBe(47);
  });

  it('caps delivery ratio at 1 and predictability at 100%', () => {
    expect(calculateTeamEffectiveness(50, 50, 1, 1, 250)).toBe(100);
  });

  it('treats negative and non-numeric inputs as zero', () => {
    expect(calculateTeamEffectiveness(-5, Number.NaN, 10, 10, -20)).toBe(0);
  });
});
