// Weighted Workload Utilization (WDU) calculator
// Implements hybrid algorithm combining Story Points and number of Tasks with dynamic weighting and scope creep penalty.

export type UtilizationStatus = 'UNDERUTILIZED' | 'UTILIZED' | 'OVERUTILIZED';

export interface WduInput {
  // Current vs average per developer
  currentSP?: number | null;
  averageSP?: number | null;
  currentTasks?: number | null;
  averageTasks?: number | null;

  // For scope creep penalty (initially planned vs added during sprint)
  initialTasks?: number | null; // tasks at sprint start
  initialSP?: number | null;    // SP at sprint start
  addedTasks?: number | null;   // tasks added after start
  addedSP?: number | null;      // SP added after start
}

export interface WduResult {
  utilizationPct: number; // final percent after weighting and scope factor, clamped to [0, +inf)
  status: UtilizationStatus; // UNDERUTILIZED / UTILIZED / OVERUTILIZED
  // Debug fields (optional but helpful)
  U_sp?: number | null;
  U_task: number; // always defined (falls back to 100 when no averageTasks)
  w_sp: number;
  w_task: number;
  scopeCreepFactor: number; // >=1.0
}

function clamp(n: number, min = 0, max = Number.POSITIVE_INFINITY) {
  if (!Number.isFinite(n)) return min;
  return Math.min(max, Math.max(min, n));
}

export function computeWdu(input: WduInput): WduResult {
  const avgSP = clamp(Number(input.averageSP ?? 0));
  const curSP = clamp(Number(input.currentSP ?? 0));
  const avgTasks = clamp(Number(input.averageTasks ?? 0));
  const curTasks = clamp(Number(input.currentTasks ?? 0));

  // U_sp component
  let U_sp: number | null = null;
  if (avgSP > 0) {
    U_sp = clamp((curSP / avgSP) * 100, 0);
  } else if (avgSP === 0 && curSP === 0) {
    U_sp = null; // explicitly ignored
  } else if (avgSP === 0 && curSP > 0) {
    // No historical SP but some current SP — treat as 100%+ based on tasks weight mainly; keep SP out to avoid over-amplifying
    U_sp = null;
  }

  // U_task component
  let U_task = 100; // neutral default when no history per spec
  if (avgTasks > 0) {
    U_task = clamp((curTasks / avgTasks) * 100, 0);
  } else if (avgTasks === 0) {
    U_task = 100; // neutral — can be tuned to 0 if needed, but spec suggests 100% or neutral
  }

  // Dynamic weights
  let w_sp = 0.7;
  let w_task = 0.3;
  if ((avgSP === 0 && curSP === 0) /* no SP history & no current estimates */) {
    w_sp = 0.0;
    w_task = 1.0;
  }
  // If U_sp is ignored (null), force weight to tasks only
  if (U_sp == null) {
    w_sp = 0.0;
    w_task = 1.0;
  }

  // Scope Creep Penalty
  const initialTasks = clamp(Number(input.initialTasks ?? 0));
  const initialSP = clamp(Number(input.initialSP ?? 0));
  const addedTasks = clamp(Number(input.addedTasks ?? 0));
  const addedSP = clamp(Number(input.addedSP ?? 0));
  const denom = Math.max(initialTasks + initialSP, 1);
  const unplannedRatio = (addedTasks + addedSP) / denom; // can exceed 1
  const scopeCreepFactor = 1.0 + Math.min(unplannedRatio * 0.15, 0.30);

  // Final utilization
  const base = (w_sp * (U_sp ?? 0)) + (w_task * U_task);
  const utilizationPctRaw = base * scopeCreepFactor;
  const utilizationPct = Math.round(utilizationPctRaw * 10) / 10; // 0.1% precision

  // Threshold mapping
  let status: UtilizationStatus = 'UTILIZED';
  if (utilizationPct < 85) status = 'UNDERUTILIZED';
  else if (utilizationPct > 115) status = 'OVERUTILIZED';

  return {
    utilizationPct,
    status,
    U_sp: U_sp,
    U_task,
    w_sp,
    w_task,
    scopeCreepFactor,
  };
}

export default computeWdu;
