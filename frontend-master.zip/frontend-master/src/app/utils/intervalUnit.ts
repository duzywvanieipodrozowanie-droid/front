import { DateRangeValue } from '../context/DateRangeContext';
import { Lang } from '../i18n';
import { parseCustomRange, rangeDays } from './dateRange';

export function getIntervalSuffix(dateRange: DateRangeValue, lang: Lang = 'en'): string {
  const isPL = lang === 'pl';
  switch (dateRange) {
    case 'Last 7 days':
      return isPL ? '/ 7 dni' : '/ 7 days';
    case 'Last 2 weeks':
      return isPL ? '/ 2 tygodnie' : '/ 2 weeks';
    case 'Last 4 weeks':
      return isPL ? '/ 4 tygodnie' : '/ 4 weeks';
    case 'Last month':
      return isPL ? '/ miesiąc' : '/ month';
    case 'Last 3 months':
      return isPL ? '/ 3 miesiące' : '/ 3 months';
    case 'Last 6 months':
      return isPL ? '/ 6 miesięcy' : '/ 6 months';
    default: {
      if (parseCustomRange(dateRange)) {
        const days = rangeDays(dateRange);
        return isPL ? `/ ${days} ${days === 1 ? 'dzień' : 'dni'}` : `/ ${days} ${days === 1 ? 'day' : 'days'}`;
      }
      return isPL ? '/ okres' : '/ period';
    }
  }
}
