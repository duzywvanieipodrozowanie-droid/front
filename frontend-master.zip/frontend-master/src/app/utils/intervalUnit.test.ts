import { describe, it, expect } from 'vitest';
import { getIntervalSuffix } from './intervalUnit';
import type { DateRangeValue } from '../context/DateRangeContext';

describe('getIntervalSuffix', () => {
  const cases: [DateRangeValue, string, string][] = [
    ['Last 7 days', '/ 7 days', '/ 7 dni'],
    ['Last 2 weeks', '/ 2 weeks', '/ 2 tygodnie'],
    ['Last 4 weeks', '/ 4 weeks', '/ 4 tygodnie'],
    ['Last 3 months', '/ 3 months', '/ 3 miesiące'],
    ['Last 6 months', '/ 6 months', '/ 6 miesięcy'],
  ];

  it.each(cases)('%s -> en "%s", pl "%s"', (range, en, pl) => {
    expect(getIntervalSuffix(range, 'en')).toBe(en);
    expect(getIntervalSuffix(range, 'pl')).toBe(pl);
  });

  it('defaults to English', () => {
    expect(getIntervalSuffix('Last 7 days')).toBe('/ 7 days');
  });

  it('returns a generic suffix for unknown ranges', () => {
    const unknown = 'Last year' as DateRangeValue;
    expect(getIntervalSuffix(unknown, 'en')).toBe('/ period');
    expect(getIntervalSuffix(unknown, 'pl')).toBe('/ okres');
  });
});

describe('custom and month periods', () => {
  it('maps a month and custom periods to the interval of core', async () => {
    const { toInterval, rangeDays, customRange, rangeLabel } = await import('./dateRange');
    expect(toInterval('Last month')).toBe('MONTHS_1');
    expect(toInterval('Last 3 months')).toBe('MONTHS_3');
    expect(toInterval(customRange('2026-09-30', '2026-09-01'))).toBe('CUSTOM_2026-09-01_2026-09-30');
    expect(rangeDays('Custom:2026-09-01:2026-09-30')).toBe(30);
    expect(rangeLabel('Custom:2026-09-01:2026-09-30', 'en')).toMatch(/^1 \S+ 2026 – 30 \S+ 2026$/);
    expect(rangeLabel('Last month', 'pl')).toBe('Ostatni miesiąc');
    expect(getIntervalSuffix('Custom:2026-09-01:2026-09-30', 'pl')).toBe('/ 30 dni');
    expect(getIntervalSuffix('Last month', 'en')).toBe('/ month');
  });
});
