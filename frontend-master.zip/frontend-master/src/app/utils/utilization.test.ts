import { describe, it, expect } from 'vitest';
import { computeWdu } from './utilization';

describe('computeWdu', () => {
  it('weights SP 70% and tasks 30% when SP history exists', () => {
    const r = computeWdu({ currentSP: 10, averageSP: 10, currentTasks: 5, averageTasks: 10 });
    expect(r.w_sp).toBe(0.7);
    expect(r.w_task).toBe(0.3);
    expect(r.U_sp).toBe(100);
    expect(r.U_task).toBe(50);
    expect(r.utilizationPct).toBe(85);
    expect(r.status).toBe('UTILIZED');
  });

  it('falls back to tasks only when there is no SP history', () => {
    const r = computeWdu({ currentSP: 0, averageSP: 0, currentTasks: 12, averageTasks: 10 });
    expect(r.U_sp).toBeNull();
    expect(r.w_sp).toBe(0);
    expect(r.w_task).toBe(1);
    expect(r.utilizationPct).toBe(120);
    expect(r.status).toBe('OVERUTILIZED');
  });

  it('ignores SP when there is current SP but no SP history', () => {
    const r = computeWdu({ currentSP: 8, averageSP: 0, currentTasks: 5, averageTasks: 10 });
    expect(r.U_sp).toBeNull();
    expect(r.w_task).toBe(1);
    expect(r.utilizationPct).toBe(50);
  });

  it('treats task utilization as neutral 100% when there is no task history', () => {
    const r = computeWdu({});
    expect(r.U_task).toBe(100);
    expect(r.utilizationPct).toBe(100);
    expect(r.scopeCreepFactor).toBe(1);
    expect(r.status).toBe('UTILIZED');
  });

  it('applies scope creep penalty proportional to unplanned work', () => {
    const r = computeWdu({ currentTasks: 10, averageTasks: 10, initialTasks: 10, addedTasks: 5 });
    expect(r.scopeCreepFactor).toBeCloseTo(1.075);
    expect(r.utilizationPct).toBe(107.5);
  });

  it('caps scope creep penalty at 30%', () => {
    const r = computeWdu({ currentTasks: 10, averageTasks: 10, initialTasks: 1, addedTasks: 100 });
    expect(r.scopeCreepFactor).toBeCloseTo(1.3);
    expect(r.utilizationPct).toBe(130);
  });

  it('clamps negative and non-finite inputs to zero', () => {
    const r = computeWdu({ currentTasks: -5, averageTasks: 10, currentSP: Number.NaN, averageSP: 10 });
    expect(r.U_task).toBe(0);
    expect(r.U_sp).toBe(0);
    expect(r.utilizationPct).toBe(0);
    expect(r.status).toBe('UNDERUTILIZED');
  });

  it('maps thresholds: <85 under, 85..115 utilized, >115 over', () => {
    const at = (cur: number) => computeWdu({ currentTasks: cur, averageTasks: 100 }).status;
    expect(at(84)).toBe('UNDERUTILIZED');
    expect(at(85)).toBe('UTILIZED');
    expect(at(115)).toBe('UTILIZED');
    expect(at(116)).toBe('OVERUTILIZED');
  });
});
