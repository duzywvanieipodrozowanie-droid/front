// Effectiveness score calculator for Team Effectiveness chart
// Implements the specified algorithm combining Delivery Ratio, Alignment Factor, and Predictability.

export function calculateTeamEffectiveness(
  jiraDone: number,
  prsMerged: number,
  avgJira: number,
  avgPrs: number,
  predictabilityPercent?: number | null
): number {
  const toNum = (v: unknown) => (Number.isFinite(Number(v)) ? Number(v) : 0);
  const J = Math.max(0, toNum(jiraDone));
  const P = Math.max(0, toNum(prsMerged));
  const AJ = Math.max(0, toNum(avgJira));
  const AP = Math.max(0, toNum(avgPrs));
  const predPct = Math.max(0, toNum(predictabilityPercent ?? 80)); // default 80%

  // 1) Delivery Ratio
  const totalDelivered = J + P;
  const avgDelivered = AJ + AP;
  const deliveryRatio = Math.min(1.0, totalDelivered / Math.max(avgDelivered, 1));

  // 2) JIRA-to-PR Alignment Factor
  let alignmentFactor = 1.0;
  if (P > 0 && J > 0) alignmentFactor = 1.0;
  else if (P > 0 && J === 0) alignmentFactor = 0.5;
  else if (P === 0 && J === 0) alignmentFactor = 0.0;

  // 3) Predictability Score (0..1)
  const predictabilityScore = Math.max(0, Math.min(1, predPct / 100));

  // 4) Final score (0..100)
  const raw = (0.6 * deliveryRatio * alignmentFactor + 0.4 * predictabilityScore) * 100;
  const effectiveness = Math.min(100, Math.max(0, Math.round(raw)));
  return effectiveness;
}

export default calculateTeamEffectiveness;
