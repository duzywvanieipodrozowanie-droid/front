import { useEffect, useState, Suspense } from 'react';
import { RouterProvider } from 'react-router-dom';
import { router } from './routes';

export default function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);

  useEffect(() => {
    let cancelled = false;

    // // Allow accessing the Welcome screen without SSO and allow demo login
    // try {
    //   const isWelcomePath = window.location.pathname.startsWith('/welcome');
    //   const isRootPath = window.location.pathname === '/';
    //   const demoLoggedIn =
    //     localStorage.getItem('zen.wizard.loggedIn') === '1' ||
    //     localStorage.getItem('demoLoggedIn') === 'true' ||
    //     localStorage.getItem('demo.welcome.loggedin') === 'true';
    //
    //   if (isWelcomePath || demoLoggedIn) {
    //     // Mark as authenticated in local storage for Welcome page logic
    //     try { localStorage.setItem('sso.authenticated', '1'); } catch {}
    //     // If user is logged in and landed on root, start at Welcome
    //     if (!isWelcomePath && isRootPath) {
    //       window.location.replace('/welcome');
    //       return () => {
    //         cancelled = true;
    //       };
    //     }
    //     setIsAuthenticated(true);
    //     setIsLoading(false);
    //     return () => {
    //       cancelled = true;
    //     };
    //   }
    // } catch (_e) {}

    fetch('/api/hc', { credentials: 'include' })
      .then((res) => {
        if (cancelled) return;
        if (res.ok) {
          try { localStorage.setItem('sso.authenticated', '1'); } catch {}
          setIsAuthenticated(true);
          setIsLoading(false);
        } else {
          setIsAuthenticated(false);
          // Redirect to backend which should initiate Keycloak SSO
          window.location.href = '/api/';
        }
      })
      .catch(() => {
        if (cancelled) return;
        setIsAuthenticated(false);
        window.location.href = '/api/';
      });

    return () => {
      cancelled = true;
    };
  }, []);

  if (isLoading || !isAuthenticated) {
    // Show nothing or minimal placeholder while checking/redirecting
    return null;
  }

  return (
    <Suspense fallback={null}>
      <RouterProvider router={router} />
    </Suspense>
  );
}
