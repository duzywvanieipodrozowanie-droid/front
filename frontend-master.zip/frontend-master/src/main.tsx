
  import { createRoot } from "react-dom/client";
  import App from "./app/App.tsx";
  import "./styles/index.css";

  // Application entry point: mounts the root App component into #root
  createRoot(document.getElementById("root")!).render(<App />);
  