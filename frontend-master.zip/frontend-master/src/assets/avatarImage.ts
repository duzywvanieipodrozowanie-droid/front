// Avatar images from src/assets/
import imagePng from './image.png';
import imageWebp from './image.webp';

export const avatarImgPng = imagePng;
export const avatarImgWebp = imageWebp;
