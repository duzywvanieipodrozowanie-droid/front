// Mock data generators for the dashboard

export interface MockMetrics {
    avgCycleTime: number;
    cycleTimeChange: number;
    totalCommits: number;
    commitsChange: number;
    deployments: number;
    deploymentsChange: number;
    activeIssues: number;
    issuesChange: number;
}

export type DataLevel = 'ORGANIZATION' | 'DOMAIN' | 'CHAPTER' | 'SQUAD';
export type SquadId = 'SQUAD1' | 'SQUAD2' | 'SQUAD3';

export interface CycleTimeData {
    period: string;
    team1: number;
    team2: number;
    team3: number;
    team4: number;
}

export interface TaskBreakdownData {
    period: string;
    features: number;
    bugs: number;
}

export interface CommitsData {
    period: string;
    commits: number;
    pullRequests: number;
}

export interface DeploymentsData {
    period: string;
    deployments: number;
}

export interface CicdMetrics {
    avgCommitTime: number;
    avgReviewTime: number;
    avgBuildTime: number;
    avgDeploymentTime: number;
    totalPipelineTime: number;
    successRate: number;
    failureRate: number;
    avgQueueTime: number;
}

export interface CicdTimeData {
    period: string;
    commits: number;
    builds: number;
    deployments: number;
    testDeployments: number;
}

export interface CicdHourlyData {
    hour: number;
    commits: number;
    builds: number;
    deployments: number;
}

export interface CicdQualityData {
    period: string;
    testCoverage: number;
    codeQuality: number;
    securityScore: number;
    performance: number;
}

export interface Developer {
    id: string;
    firstName: string;
    lastName: string;
    gender: 'Male' | 'Female';
    position: 'Junior' | 'Regular' | 'Senior' | 'Tech Lead';
    yearsInOrg: number;
    rating: 'A' | 'B' | 'C' | 'D';
    effectiveness: number; // 0-100
    codeQuality: number; // 0-10
    technology: string;
    organization: DataLevel;
    squad?: SquadId;
}

export const generateDevelopers = (): Developer[] => {
    const firstNames = {
        Male: ['Adam', 'Bartosz', 'Cezary', 'Damian', 'Emil', 'Filip', 'Grzegorz', 'Hubert', 'Igor', 'Jakub', 'Kamil', 'Łukasz', 'Marcin', 'Norbert', 'Oskar', 'Paweł', 'Robert', 'Sebastian', 'Tomasz', 'Wojciech'],
        Female: ['Anna', 'Barbara', 'Celina', 'Dorota', 'Ewa', 'Franciszka', 'Gabriela', 'Hanna', 'Iga', 'Joanna', 'Katarzyna', 'Laura', 'Magdalena', 'Natalia', 'Olga', 'Paulina', 'Renata', 'Sylwia', 'Teresa', 'Urszula']
    };

    const lastNames = ['Kowalski', 'Nowak', 'Wiśniewski', 'Wójcik', 'Kowalczyk', 'Kamiński', 'Lewandowski', 'Zieliński', 'Szymański', 'Woźniak', 'Dąbrowski', 'Kozłowski', 'Jankowski', 'Mazur', 'Kwiatkowski', 'Krawczyk', 'Piotrowski', 'Grabowski', 'Nowakowski', 'Pawłowski'];

    const technologies = ['React', 'Angular', 'Vue.js', 'Node.js', 'Python', 'Java', 'C#', '.NET', 'PHP', 'Ruby', 'Go', 'Rust', 'TypeScript', 'JavaScript', 'Kotlin', 'Swift', 'Flutter', 'React Native'];

    const positions: Developer['position'][] = ['Junior', 'Regular', 'Senior', 'Tech Lead'];
    const organizations: DataLevel[] = ['ORGANIZATION', 'DOMAIN', 'CHAPTER', 'SQUAD'];
    const squads: SquadId[] = ['SQUAD1', 'SQUAD2', 'SQUAD3'];

    const developers: Developer[] = [];

    for (let i = 0; i < 10; i++) {
        const gender = Math.random() > 0.5 ? 'Male' : 'Female';
        const firstName = firstNames[gender][Math.floor(Math.random() * firstNames[gender].length)];
        const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
        const position = positions[Math.floor(Math.random() * positions.length)];
        const organization = organizations[Math.floor(Math.random() * organizations.length)];

        // Position influences rating and effectiveness
        let baseEffectiveness = 50;
        let baseRating = 'C';

        switch (position) {
            case 'Tech Lead':
                baseEffectiveness = 80 + Math.floor(Math.random() * 20);
                baseRating = Math.random() > 0.7 ? 'A' : 'B';
                break;
            case 'Senior':
                baseEffectiveness = 70 + Math.floor(Math.random() * 25);
                baseRating = Math.random() > 0.5 ? 'B' : Math.random() > 0.7 ? 'A' : 'C';
                break;
            case 'Regular':
                baseEffectiveness = 60 + Math.floor(Math.random() * 30);
                baseRating = Math.random() > 0.4 ? 'B' : Math.random() > 0.7 ? 'C' : 'A';
                break;
            case 'Junior':
                baseEffectiveness = 40 + Math.floor(Math.random() * 40);
                baseRating = Math.random() > 0.6 ? 'C' : Math.random() > 0.8 ? 'B' : 'D';
                break;
        }

        const developer: Developer = {
            id: `dev_${i + 1}`,
            firstName,
            lastName,
            gender,
            position,
            yearsInOrg: Math.floor(Math.random() * 15) + 1,
            rating: baseRating as Developer['rating'],
            effectiveness: Math.min(100, Math.max(0, baseEffectiveness + Math.floor(Math.random() * 20) - 10)),
            codeQuality: Math.floor(Math.random() * 11), // 0-10
            technology: technologies[Math.floor(Math.random() * technologies.length)],
            organization,
            squad: organization === 'SQUAD' ? squads[Math.floor(Math.random() * squads.length)] : undefined
        };

        developers.push(developer);
    }

    return developers;
};

export const getMockMetrics = (timeframe: 'week' | 'month' | 'quarter' | 'year', dataLevel: DataLevel, squadId: SquadId, dataKey: number): MockMetrics => {
    // Use dataKey as seed for randomization to get different data each time
    const seed = dataKey * 1000 + timeframe.length + dataLevel.length + squadId.length;
    const random = (min: number, max: number) => Math.floor((Math.sin(seed + min + max) * 10000) % (max - min + 1)) + min;

    const baseMetrics = {
        week: {
            avgCycleTime: random(20, 50) / 10, // 2.0 - 5.0
            totalCommits: random(500, 1200),
            deployments: random(8, 20),
            activeIssues: random(15, 40),
        },
        month: {
            avgCycleTime: random(25, 45) / 10, // 2.5 - 4.5
            totalCommits: random(2500, 5000),
            deployments: random(35, 70),
            activeIssues: random(60, 120),
        },
        quarter: {
            avgCycleTime: random(28, 42) / 10, // 2.8 - 4.2
            totalCommits: random(8000, 15000),
            deployments: random(120, 200),
            activeIssues: random(180, 300),
        },
        year: {
            avgCycleTime: random(30, 40) / 10, // 3.0 - 4.0
            totalCommits: random(35000, 60000),
            deployments: random(500, 800),
            activeIssues: random(700, 1200),
        }
    };

    // Adjust values based on data level
    const levelMultiplier = {
        ORGANIZATION: 1.0,
        DOMAIN: 0.7,
        CHAPTER: 0.4,
        SQUAD: 0.2
    };

    // Additional multiplier for specific squads
    const squadMultiplier = {
        SQUAD1: 1.2, // Squad 1 is more active
        SQUAD2: 0.8, // Squad 2 is less active
        SQUAD3: 1.0  // Squad 3 is average
    };

    const base = baseMetrics[timeframe];
    const multiplier = levelMultiplier[dataLevel] * (dataLevel === 'SQUAD' ? squadMultiplier[squadId] : 1);

    return {
        avgCycleTime: base.avgCycleTime,
        cycleTimeChange: random(-15, 15),
        totalCommits: Math.round(base.totalCommits * multiplier),
        commitsChange: random(-20, 25),
        deployments: Math.round(base.deployments * multiplier),
        deploymentsChange: random(-25, 30),
        activeIssues: Math.round(base.activeIssues * multiplier),
        issuesChange: random(-20, 10),
    };
};

export const getCycleTimeData = (timeframe: 'week' | 'month' | 'quarter' | 'year', dataLevel: DataLevel, squadId: SquadId, dataKey: number): CycleTimeData[] => {
    const seed = dataKey * 2000 + timeframe.length + dataLevel.length + squadId.length;
    const random = (min: number, max: number) => Math.floor((Math.sin(seed + min + max) * 10000) % (max - min + 1)) + min;

    const periods = {
        week: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        month: ['W1', 'W2', 'W3', 'W4'],
        quarter: ['Jan', 'Feb', 'Mar'],
        year: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    };

    return periods[timeframe].map((period) => ({
        period,
        team1: random(15, 60) / 10,
        team2: random(12, 50) / 10,
        team3: random(18, 65) / 10,
        team4: random(14, 55) / 10,
    }));
};

export const getTaskBreakdownData = (timeframe: 'week' | 'month' | 'quarter' | 'year', dataLevel: DataLevel, squadId: SquadId, dataKey: number): TaskBreakdownData[] => {
    const seed = dataKey * 3000 + timeframe.length + dataLevel.length + squadId.length;
    const random = (min: number, max: number, offset: number = 0) => 
        Math.floor((Math.sin(seed + min + max + offset) * 10000) % (max - min + 1)) + min;

    // Different granularity based on timeframe
    const periods = {
        week: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],  // 5 working days
        month: ['Sprint 1', 'Sprint 2', 'Sprint 3', 'Sprint 4'],  // 4 sprints
        quarter: ['Month 1', 'Month 2', 'Month 3'],  // 3 months
        year: ['Q1', 'Q2', 'Q3', 'Q4']  // 4 quarters
    };

    const levelMultiplier = {
        ORGANIZATION: 1.0,
        DOMAIN: 0.7,
        CHAPTER: 0.4,
        SQUAD: 0.2
    };

    const squadMultiplier = {
        SQUAD1: 1.2,
        SQUAD2: 0.8,
        SQUAD3: 1.0
    };

    const finalMultiplier = levelMultiplier[dataLevel] * (dataLevel === 'SQUAD' ? squadMultiplier[squadId] : 1);

    // Base ranges depend on timeframe - only features and bugs
    const baseRanges = {
        week: { features: [5, 15], bugs: [2, 8] },
        month: { features: [20, 55], bugs: [8, 30] },
        quarter: { features: [65, 160], bugs: [25, 90] },
        year: { features: [250, 550], bugs: [100, 300] }
    };

    const ranges = baseRanges[timeframe];

    return periods[timeframe].map((period, index) => {
        // Create variation between periods by using index as additional offset
        const periodOffset = index * 1000;

        return {
            period,
            features: Math.max(1, Math.round(random(ranges.features[0], ranges.features[1], periodOffset) * finalMultiplier)),
            bugs: Math.max(1, Math.round(random(ranges.bugs[0], ranges.bugs[1], periodOffset + 200) * finalMultiplier)),
        };
    });
};

export const getCommitsData = (timeframe: 'week' | 'month' | 'quarter' | 'year', dataLevel: DataLevel, squadId: SquadId, dataKey: number): CommitsData[] => {
    const seed = dataKey * 4000 + timeframe.length + dataLevel.length + squadId.length;
    const random = (min: number, max: number) => Math.floor((Math.sin(seed + min + max) * 10000) % (max - min + 1)) + min;

    const periods = {
        week: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        month: ['W1', 'W2', 'W3', 'W4'],
        quarter: ['Jan', 'Feb', 'Mar'],
        year: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    };

    const levelMultiplier = {
        ORGANIZATION: 1.0,
        DOMAIN: 0.7,
        CHAPTER: 0.4,
        SQUAD: 0.2
    };

    const squadMultiplier = {
        SQUAD1: 1.2,
        SQUAD2: 0.8,
        SQUAD3: 1.0
    };

    const finalMultiplier = levelMultiplier[dataLevel] * (dataLevel === 'SQUAD' ? squadMultiplier[squadId] : 1);

    return periods[timeframe].map((period) => ({
        period,
        commits: Math.max(1, Math.round(random(15, 80) * finalMultiplier)),
        pullRequests: Math.max(1, Math.round(random(3, 25) * finalMultiplier)),
    }));
};

export const getDeploymentsData = (timeframe: 'week' | 'month' | 'quarter' | 'year', dataLevel: DataLevel, squadId: SquadId, dataKey: number): DeploymentsData[] => {
    const seed = dataKey * 5000 + timeframe.length + dataLevel.length + squadId.length;
    const random = (min: number, max: number, offset: number = 0) => 
        Math.floor((Math.sin(seed + min + max + offset) * 10000) % (max - min + 1)) + min;

    const periods = {
        week: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        month: ['W1', 'W2', 'W3', 'W4'],
        quarter: ['Jan', 'Feb', 'Mar'],
        year: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    };

    const levelMultiplier = {
        ORGANIZATION: 1.0,
        DOMAIN: 0.7,
        CHAPTER: 0.4,
        SQUAD: 0.2
    };

    const squadMultiplier = {
        SQUAD1: 1.2,
        SQUAD2: 0.8,
        SQUAD3: 1.0
    };

    const finalMultiplier = levelMultiplier[dataLevel] * (dataLevel === 'SQUAD' ? squadMultiplier[squadId] : 1);

    // Wider range for more variation
    const baseRanges = {
        week: { min: 1, max: 8 },
        month: { min: 3, max: 15 },
        quarter: { min: 8, max: 25 },
        year: { min: 20, max: 60 }
    };

    const range = baseRanges[timeframe];

    return periods[timeframe].map((period, index) => {
        // Create variation between periods by using index as additional offset
        const periodOffset = index * 1000;

        return {
            period,
            deployments: Math.max(1, Math.round(random(range.min, range.max, periodOffset) * finalMultiplier)),
        };
    });
};

export const getCicdMetrics = (timeframe: 'week' | 'month' | 'quarter' | 'year', dataLevel: DataLevel, squadId: SquadId, dataKey: number): CicdMetrics => {
    const seed = dataKey * 6000 + timeframe.length + dataLevel.length + squadId.length;
    const random = (min: number, max: number) => Math.floor((Math.sin(seed + min + max) * 10000) % (max - min + 1)) + min;

    const levelMultiplier = {
        ORGANIZATION: 1.0,
        DOMAIN: 0.9,
        CHAPTER: 0.8,
        SQUAD: 0.7
    };

    const squadMultiplier = {
        SQUAD1: 0.8, // Squad 1 is more efficient
        SQUAD2: 1.2, // Squad 2 is slower
        SQUAD3: 1.0  // Squad 3 is average
    };

    const multiplier = levelMultiplier[dataLevel] * (dataLevel === 'SQUAD' ? squadMultiplier[squadId] : 1);

    return {
        avgCommitTime: Math.round(random(5, 15) * multiplier), // minutes
        avgReviewTime: Math.round(random(30, 120) * multiplier), // minutes
        avgBuildTime: Math.round(random(8, 25) * multiplier), // minutes
        avgDeploymentTime: Math.round(random(10, 30) * multiplier), // minutes
        totalPipelineTime: Math.round(random(60, 180) * multiplier), // minutes
        successRate: Math.max(70, Math.min(98, random(85, 95))), // percentage
        failureRate: Math.max(2, Math.min(30, random(5, 15))), // percentage
        avgQueueTime: Math.round(random(2, 8) * multiplier), // minutes
    };
};

export const getCicdTimeData = (timeframe: 'week' | 'month' | 'quarter' | 'year', dataLevel: DataLevel, squadId: SquadId, dataKey: number): CicdTimeData[] => {
    const seed = dataKey * 7000 + timeframe.length + dataLevel.length + squadId.length;
    const random = (min: number, max: number) => Math.floor((Math.sin(seed + min + max) * 10000) % (max - min + 1)) + min;

    const periods = {
        week: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        month: ['W1', 'W2', 'W3', 'W4'],
        quarter: ['Jan', 'Feb', 'Mar'],
        year: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    };

    const levelMultiplier = {
        ORGANIZATION: 1.0,
        DOMAIN: 0.7,
        CHAPTER: 0.4,
        SQUAD: 0.2
    };

    const squadMultiplier = {
        SQUAD1: 1.3,
        SQUAD2: 0.7,
        SQUAD3: 1.0
    };

    const finalMultiplier = levelMultiplier[dataLevel] * (dataLevel === 'SQUAD' ? squadMultiplier[squadId] : 1);

    return periods[timeframe].map((period) => ({
        period,
        commits: Math.max(1, Math.round(random(20, 80) * finalMultiplier)),
        builds: Math.max(1, Math.round(random(15, 60) * finalMultiplier)),
        deployments: Math.max(1, Math.round(random(3, 15) * finalMultiplier)),
        testDeployments: Math.max(1, Math.round(random(5, 20) * finalMultiplier)),
    }));
};

export const getCicdHourlyData = (dataLevel: DataLevel, squadId: SquadId, dataKey: number): CicdHourlyData[] => {
    const seed = dataKey * 8000 + dataLevel.length + squadId.length;
    const random = (min: number, max: number) => Math.floor((Math.sin(seed + min + max) * 10000) % (max - min + 1)) + min;

    const levelMultiplier = {
        ORGANIZATION: 1.0,
        DOMAIN: 0.7,
        CHAPTER: 0.4,
        SQUAD: 0.2
    };

    const squadMultiplier = {
        SQUAD1: 1.2,
        SQUAD2: 0.8,
        SQUAD3: 1.0
    };

    const finalMultiplier = levelMultiplier[dataLevel] * (dataLevel === 'SQUAD' ? squadMultiplier[squadId] : 1);

    return Array.from({ length: 24 }, (_, hour) => {
        // Peak hours: 9-11 AM and 2-4 PM
        const isPeakHour = (hour >= 9 && hour <= 11) || (hour >= 14 && hour <= 16);
        const peakMultiplier = isPeakHour ? 2.5 : hour >= 8 && hour <= 18 ? 1.5 : 0.3;

        return {
            hour,
            commits: Math.max(0, Math.round(random(2, 12) * finalMultiplier * peakMultiplier)),
            builds: Math.max(0, Math.round(random(1, 8) * finalMultiplier * peakMultiplier)),
            deployments: Math.max(0, Math.round(random(0, 3) * finalMultiplier * peakMultiplier)),
        };
    });
};

// CodeMap data types and generators
export interface GitCommit {
    id: string;
    author: string;
    message: string;
    timestamp: string;
    hash: string;
}

export interface JiraTicket {
    id: string;
    title: string;
    commits: GitCommit[];
}

export interface MicroserviceTag {
    tagNumber: string;
    commitCount: number;
    jiraTickets: JiraTicket[];
    deployedAt: string;
}

export interface MicroserviceEnvironment {
    alfa: MicroserviceTag[];
    beta: MicroserviceTag[];
    prod: MicroserviceTag[];
}

export interface Microservice {
    name: string;
    environments: MicroserviceEnvironment;
    lastDeployment?: {
        environment: 'alfa' | 'beta' | 'prod';
        tag: string;
        timestamp: string;
    };
}



export const getCicdQualityData = (timeframe: 'week' | 'month' | 'quarter' | 'year', dataLevel: DataLevel, squadId: SquadId, dataKey: number): CicdQualityData[] => {
    const seed = dataKey * 9000 + timeframe.length + dataLevel.length + squadId.length;
    const random = (min: number, max: number) => Math.floor((Math.sin(seed + min + max) * 10000) % (max - min + 1)) + min;

    const periods = {
        week: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        month: ['W1', 'W2', 'W3', 'W4'],
        quarter: ['Jan', 'Feb', 'Mar'],
        year: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    };

    const squadQualityMultiplier = {
        SQUAD1: { test: 1.1, quality: 1.2, security: 1.1, performance: 1.0 },
        SQUAD2: { test: 0.9, quality: 0.8, security: 0.9, performance: 0.9 },
        SQUAD3: { test: 1.0, quality: 1.0, security: 1.0, performance: 1.1 }
    };

    const multipliers = dataLevel === 'SQUAD' ? squadQualityMultiplier[squadId] : { test: 1.0, quality: 1.0, security: 1.0, performance: 1.0 };

    return periods[timeframe].map((period) => ({
        period,
        testCoverage: Math.max(60, Math.min(95, Math.round(random(75, 90) * multipliers.test))),
        codeQuality: Math.max(70, Math.min(98, Math.round(random(80, 95) * multipliers.quality))),
        securityScore: Math.max(65, Math.min(100, Math.round(random(78, 92) * multipliers.security))),
        performance: Math.max(70, Math.min(99, Math.round(random(82, 96) * multipliers.performance))),
    }));
};