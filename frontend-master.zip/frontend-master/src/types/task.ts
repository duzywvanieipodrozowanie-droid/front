export interface TaskUser {
  accountId: string;
  displayName: string;
}

export interface TaskHistory {
  fieldType: string;
  from: string;
  to: string;
  created: string;
  author: TaskUser;
}

export interface Task {
  id: number;
  key: string;
  self: string;
  project: string;
  type: string;
  parent: string | null;
  summary: string;
  labels: string[];
  status: string;
  priority: string;
  assignee: TaskUser | null;
  creator: TaskUser;
  text: string[];
  updated: string;
  created: string;
  dependencies: any[];
  images: any[];
  histories: TaskHistory[];
}
export interface TaskUser {
  accountId: string;
  displayName: string;
}

export interface TaskHistory {
  fieldType: string;
  from: string;
  to: string;
  created: string;
  author: TaskUser;
}

export interface Task {
  id: number;
  key: string;
  self: string;
  project: string;
  type: string;
  parent: string | null;
  summary: string;
  labels: string[];
  status: string;
  priority: string;
  assignee: TaskUser | null;
  creator: TaskUser;
  text: string[];
  updated: string;
  created: string;
  dependencies: any[];
  images: any[];
  histories: TaskHistory[];
}

export interface TaskTreeResponse {
  [taskString: string]: {};
}
export interface TaskTreeResponse {
  [taskString: string]: {};
}
