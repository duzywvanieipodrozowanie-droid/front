
  # Swarmia clone application

  This is a code bundle for Swarmia clone application. The original project is available at https://www.figma.com/design/FMNN1c2GscdJK39gnlWPPa/Swarmia-clone-application.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
  The Vite dev server proxies API calls from `/api/*` to your backend (default `http://localhost:8080`).
  If your backend runs elsewhere, set `VITE_BACKEND_URL` before starting dev, for example:
  
  macOS/Linux:
  
  VITE_BACKEND_URL=http://localhost:9090 npm run dev
  
  Windows (PowerShell):
  
  $Env:VITE_BACKEND_URL="http://localhost:9090"; npm run dev
